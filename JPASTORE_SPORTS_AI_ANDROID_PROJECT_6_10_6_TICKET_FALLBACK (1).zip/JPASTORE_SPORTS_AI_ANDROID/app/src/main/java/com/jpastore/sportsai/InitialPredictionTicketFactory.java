package com.jpastore.sportsai;

import java.util.*;

/**
 * Creates clearly-labelled review candidates from the initial 1X2 prediction only.
 * It never promotes them to conservative status and never invents odds/history.
 */
final class InitialPredictionTicketFactory {
    static ArrayList<TicketBatchGenerator.Candidate> football(
            String eventKey,String matchup,String league,String kickoff,
            String home,String away,int homePct,int drawPct,int awayPct){
        ArrayList<TicketBatchGenerator.Candidate> out=new ArrayList<>();
        StatisticalCalibrationEngine.Outcome3 o=StatisticalCalibrationEngine.normalizeOutcome(homePct,drawPct,awayPct,"Predição inicial");
        if(o==null)return out;

        int oneX=o.home+o.draw, xTwo=o.draw+o.away, twelve=o.home+o.away;
        if(oneX>=xTwo&&oneX>=twelve)add(out,eventKey,matchup,league,kickoff,"Dupla chance",home+" ou Empate",oneX);
        else if(xTwo>=oneX&&xTwo>=twelve)add(out,eventKey,matchup,league,kickoff,"Dupla chance","Empate ou "+away,xTwo);
        else add(out,eventKey,matchup,league,kickoff,"Dupla chance",home+" ou "+away,twelve);

        boolean homeDnb=o.home>=o.away;int dnb=StatisticalCalibrationEngine.drawNoBetProbability(o,homeDnb);
        add(out,eventKey,matchup,league,kickoff,"Empate anula",(homeDnb?home:away)+" • empate anula",dnb);

        int best=Math.max(o.home,Math.max(o.draw,o.away));String result=best==o.home?home:(best==o.away?away:"Empate");
        add(out,eventKey,matchup,league,kickoff,"Resultado",result,best);
        return out;
    }

    private static void add(ArrayList<TicketBatchGenerator.Candidate> out,String eventKey,String matchup,String league,String kickoff,String market,String pick,int raw){
        StatisticalCalibrationEngine.Calibration c=StatisticalCalibrationEngine.calibrate(raw,0,0,0,0,0,Double.NaN,Double.NaN,true);
        c.status="REVISÃO NECESSÁRIA";c.risk="RISCO ALTO";c.confidenceLevel="BAIXA";
        out.add(new TicketBatchGenerator.Candidate(eventKey,matchup,league,kickoff,market,pick,c.rawProbability,c.calibratedProbability,c.confidenceScore,0,0,0,Double.NaN,c.status,c.risk,c.confidenceLevel,"SEM FONTE CONFIRMADA","não confirmado"));
    }
    private InitialPredictionTicketFactory(){}
}
