package com.jpastore.sportsai;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.widget.*;import android.view.*;import androidx.work.*;import java.util.concurrent.TimeUnit;
public class MainActivity extends Activity{
 PremiumView ui;
 @Override public void onBackPressed(){if(ui!=null&&ui.handleBack())return;super.onBackPressed();}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(2,10,14));getWindow().setNavigationBarColor(Color.rgb(2,10,14));ui=new PremiumView(this);setContentView(ui);scheduleInternetSync();handleIncomingImage(getIntent());}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIncomingImage(i);}
 public void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
 public void searchDialog(){
  final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(22),dp(22),dp(20));root.setBackground(roundBg(Color.rgb(7,22,27),Color.rgb(29,232,116),22));
  TextView title=label("BUSCAR NO FUTEBOL",20,Color.WHITE,true);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
  TextView sub=label("Comece a digitar o nome. A J.Pastore AI completa times e campeonatos para você.",12,Color.rgb(166,188,194),false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(6);sp.bottomMargin=dp(16);root.addView(sub,sp);
  final AutoCompleteTextView e=new AutoCompleteTextView(this);e.setSingleLine(true);e.setThreshold(2);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.rgb(126,151,158));e.setTextSize(16);e.setHint("Ex.: corin..., manch..., real mad...");e.setPadding(dp(16),0,dp(16),0);e.setBackground(roundBg(Color.rgb(12,38,44),Color.rgb(45,82,88),15));e.setDropDownBackgroundDrawable(roundBg(Color.rgb(9,29,34),Color.rgb(45,82,88),12));e.setDropDownVerticalOffset(dp(6));e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);root.addView(e,new LinearLayout.LayoutParams(-1,dp(54)));
  TextView hint=label("Sugestões aparecem a partir de 2 letras • busca sem acento também funciona",10,Color.rgb(119,154,160),false);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(9);root.addView(hint,hp);
  final java.util.ArrayList<String> data=new java.util.ArrayList<>();
  final ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,data){@Override public View getView(int pos,View cv,android.view.ViewGroup parent){TextView t=(TextView)super.getView(pos,cv,parent);t.setTextColor(Color.WHITE);t.setTextSize(15);t.setPadding(dp(16),dp(12),dp(16),dp(12));t.setBackgroundColor(Color.rgb(9,29,34));return t;}@Override public View getDropDownView(int pos,View cv,android.view.ViewGroup parent){return getView(pos,cv,parent);}};
  e.setAdapter(adapter);
  final Handler h=new Handler(Looper.getMainLooper());final Runnable[] pending=new Runnable[1];
  e.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){}public void afterTextChanged(android.text.Editable ed){String q=ed.toString().trim();if(pending[0]!=null)h.removeCallbacks(pending[0]);if(q.length()<2){data.clear();adapter.notifyDataSetChanged();return;}pending[0]=()->new Thread(()->{java.util.ArrayList<String> got=ui.smartSearchSuggestions(q);runOnUiThread(()->{if(!e.getText().toString().trim().equalsIgnoreCase(q))return;data.clear();data.addAll(got);adapter.notifyDataSetChanged();if(!data.isEmpty()&&e.hasFocus())e.showDropDown();});}).start();h.postDelayed(pending[0],280);}});
  e.setOnItemClickListener((p,v,pos,id)->{String chosen=(String)p.getItemAtPosition(pos);d.dismiss();ui.searchGlobal(chosen);});
  LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(android.view.Gravity.END);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(18);root.addView(actions,ap);
  Button cancel=button("CANCELAR",Color.rgb(28,51,57),Color.WHITE);Button go=button("BUSCAR",Color.rgb(29,232,116),Color.rgb(2,17,14));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(46),1);bp.rightMargin=dp(7);actions.addView(cancel,bp);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(46),1);gp.leftMargin=dp(7);actions.addView(go,gp);cancel.setOnClickListener(v->d.dismiss());go.setOnClickListener(v->{String q=e.getText().toString().trim();if(q.length()<3){toast("Digite pelo menos 3 letras");return;}d.dismiss();ui.searchGlobal(q);});
  d.setContentView(root);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams lp=w.getAttributes();lp.width=WindowManager.LayoutParams.MATCH_PARENT;lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.72f;lp.gravity=android.view.Gravity.CENTER;w.setAttributes(lp);}d.setOnShowListener(x->{e.requestFocus();if(d.getWindow()!=null)d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});d.show();if(d.getWindow()!=null){d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),WindowManager.LayoutParams.WRAP_CONTENT);}
 }
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
 private android.graphics.drawable.GradientDrawable roundBg(int fill,int stroke,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
 private TextView label(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);return t;}
 private Button button(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setTextSize(12);b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);b.setAllCaps(false);b.setBackground(roundBg(bg,bg,13));return b;}
 public void timeFilterDialog(){
  java.util.ArrayList<String> actual=ui==null?new java.util.ArrayList<>():ui.availableTimes();
  java.util.ArrayList<String> opts=new java.util.ArrayList<>();opts.add("Todos os horários");
  for(String t:actual)if(opts.size()<8)opts.add(t);
  opts.add("Escolher outro horário...");
  String[] items=opts.toArray(new String[0]);
  new AlertDialog.Builder(this).setTitle("Filtrar por horário • Brasília").setItems(items,(d,which)->{
   String v=items[which];
   if("Todos os horários".equals(v)){ui.setTimeFilter("");return;}
   if("Escolher outro horário...".equals(v)){
    java.util.Calendar cal=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));
    new android.app.TimePickerDialog(this,(view,h,m)->ui.setTimeFilter(String.format(java.util.Locale.US,"%02d:%02d",h,m)),cal.get(java.util.Calendar.HOUR_OF_DAY),0,true).show();
   }else ui.setTimeFilter(v);
  }).setNegativeButton("CANCELAR",null).show();
 }

 public void pickVisionImage(){
  Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,9401);
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode==9401&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
   android.net.Uri u=data.getData();
   try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
   analyzeVisionImage(u);
  }
 }
 void handleIncomingImage(Intent i){
  if(i==null||!Intent.ACTION_SEND.equals(i.getAction())||i.getType()==null||!i.getType().startsWith("image/"))return;
  android.net.Uri tmp=null;
  try{tmp=(android.net.Uri)i.getParcelableExtra(Intent.EXTRA_STREAM);}catch(Exception ignored){}
  if(tmp==null&&i.getClipData()!=null&&i.getClipData().getItemCount()>0)tmp=i.getClipData().getItemAt(0).getUri();
  final android.net.Uri u=tmp;
  if(u!=null)new Handler(Looper.getMainLooper()).postDelayed(()->analyzeVisionImage(u),450);
 }
 public void analyzeVisionImage(android.net.Uri uri){
  if(uri==null)return;
  if(ui!=null)ui.setVisionLoading(true,"Lendo o print e identificando futebol...");
  try{
   com.google.mlkit.vision.common.InputImage img=com.google.mlkit.vision.common.InputImage.fromFilePath(this,uri);
   com.google.mlkit.vision.text.TextRecognizer rec=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);
   rec.process(img)
    .addOnSuccessListener(t->{String raw=t==null?"":t.getText();if(ui!=null)ui.receiveVisionText(raw);rec.close();})
    .addOnFailureListener(e->{if(ui!=null)ui.setVisionError("Não consegui ler esse print. Tente uma imagem mais nítida ou recortada.");rec.close();});
  }catch(Exception e){if(ui!=null)ui.setVisionError("Não consegui abrir essa imagem. Escolha outro print.");}
 }

 public void aiDialog(){final EditText e=new EditText(this);e.setHint("Ex.: Quem chega melhor e por quê?");new AlertDialog.Builder(this).setTitle("Perguntar à J.Pastore AI").setView(e).setPositiveButton("ANALISAR",(d,w)->ui.askAi(e.getText().toString().trim())).setNegativeButton("CANCELAR",null).show();}
 public void visionAiDialog(){final EditText e=new EditText(this);e.setHint("Ex.: qual seleção está mais arriscada?");e.setMinLines(2);new AlertDialog.Builder(this).setTitle("Perguntar sobre o print").setMessage("A J.Pastore Vision AI usa o texto reconhecido da imagem e, quando a partida está vinculada, cruza com o motor estatístico do app.").setView(e).setPositiveButton("ANALISAR",(d,w)->{String q=e.getText().toString().trim();if(q.isEmpty()){toast("Digite uma pergunta sobre o print");return;}infoDialog("J.Pastore Vision AI",ui.askVision(q));}).setNegativeButton("CANCELAR",null).show();}
 public void infoDialog(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}
 public void shareTicket(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,ui!=null&&ui.ticketStore!=null?ui.ticketStore.copyText():"J.Pastore Sports AI • Bilhete para revisão.");startActivity(Intent.createChooser(i,"Compartilhar bilhete"));}
 public void copyText(String label,String value){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText(label,value));toast("Bilhete copiado. Agora é só colar onde quiser.");}
 public void scheduleInternetSync(){Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest r=new PeriodicWorkRequest.Builder(BackgroundSyncWorker.class,6,TimeUnit.HOURS).setConstraints(c).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("jpastore-internet-sync",ExistingPeriodicWorkPolicy.UPDATE,r);}
 public String apiKey(){return getPreferences(0).getString("api","");}
 public void apiDialog(){
  final EditText e=new EditText(this);
  e.setHint("Cole sua chave API-Sports / API-Football");
  e.setSingleLine(true);
  e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  String current=apiKey();if(!current.isEmpty())e.setText(current);
  new AlertDialog.Builder(this).setTitle("API-Football / API-Sports").setMessage("A chave fica salva somente neste aparelho e não é enviada ao GitHub.").setView(e)
   .setPositiveButton("SALVAR E TESTAR",(d,w)->{String k=e.getText().toString().trim();if(k.isEmpty()){toast("Digite uma chave válida");return;}getPreferences(0).edit().putString("api",k).apply();toast("Chave salva. Testando conexão...");new ApiClient(this).test(k,ok->runOnUiThread(()->{toast(ok?"API conectada com sucesso":"Chave salva, mas a API recusou a conexão");if(ui!=null){ui.refreshFixtures();ui.invalidate();}}));})
   .setNegativeButton("CANCELAR",null).show();
 }
 public void testApi(){String k=apiKey();if(k.isEmpty()){toast("Configure a chave da API primeiro");return;}toast("Testando API...");new ApiClient(this).test(k,ok->runOnUiThread(()->toast(ok?"API conectada com sucesso":"Falha ao conectar. Verifique a chave e o plano.")));}
 public void clearApi(){getPreferences(0).edit().remove("api").apply();toast("Chave da API removida deste aparelho");if(ui!=null){ui.refreshFixtures();ui.invalidate();}}
}
