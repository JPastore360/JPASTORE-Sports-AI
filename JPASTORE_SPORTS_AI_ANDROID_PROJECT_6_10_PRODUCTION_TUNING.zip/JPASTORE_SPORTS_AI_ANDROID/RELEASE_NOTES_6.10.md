# J.Pastore Sports AI 6.10.0 — Production Tuning

Incremental revision over 6.9.1 HOTFIX. Existing features and applicationId are preserved.

## Production tuning
- Recent Form 2.0: recency, competition relevance and opponent-strength weighting.
- Raw and weighted averages shown separately; weighted metrics drive the model.
- Robust outlier treatment (median/MAD/winsorization) and effective weighted sample.
- League baseline normalization for cross-competition basketball analysis.
- Back-to-back series detection, recent-H2H emphasis and days-rest modifiers.
- Source deduplication, unique source count and convergence score.
- Confidence Score remains separate from win probability and now includes recency explicitly.
- Market check remains a calibration reference; severe divergence forces review.
- Basketball expected home/away points, total and projected margin integrated into market selection.
- Pregame gate accepts only SCHEDULED events; LIVE/FINISHED stay out of pregame tickets.
- Central status/time normalization and audit fields.

## UX / reliability
- Home football view shows the full loaded daily list again, ordered by relevance, instead of hiding completed/relevant teams behind a short card set.
- Exact time picker: any hour/minute can be selected; +/−1 minute and +/−1 hour shortcuts included.
- Basketball/sports placeholders no longer show generic “FC”; initials/sport icon are used.
- Nullable score/status values are sanitized so “null” is never rendered.
- Long team names can use two centered lines on the matchup header.
- Existing API panel, 5Dollar Football, Highlightly Basketball, cache and fallbacks preserved.

## Validation
- 12 Production Tuning tests.
- 20 legacy calibrated-statistics regression tests.
- Cases cover Alvark–Ryukyu, Cairns–Tasmania, Shanghai–RSSB, Nagasaki–Shimane, source-count rules, placeholders, nulls, scheduled/live separation and H2H ageing.
