package com.jpastore.sportsai;
import java.util.*;
public class ProductionTuningSelfTest{
 static int ok=0;static void check(boolean b,String n){if(!b)throw new AssertionError("FAIL: "+n);System.out.println("PASS: "+n);ok++;}
 static RecentFormEngine.Sample g(String d,String c,String opp,boolean h,int pf,int pa){return new RecentFormEngine.Sample(d,c,opp,h,pf,pa);}
 public static void main(String[]a){
  // A Alvark x Ryukyu: 22/09 previous meeting must be the strongest H2H signal for 23/09.
  ArrayList<RecentFormEngine.Sample> h2h=new ArrayList<>();h2h.add(g("2026-09-22","B.League Cup","Ryukyu Golden Kings",true,86,82));h2h.add(g("2026-05-11","B.League","Ryukyu Golden Kings",true,78,81));
  RecentFormEngine.SeriesInfo si=RecentFormEngine.seriesInfo(h2h,"2026-09-23");check(si.backToBack&&si.lastMeetingDaysAgo==1&&Math.abs(si.lastMeetingWeight-1.20)<.01,"A Alvark x Ryukyu back-to-back e H2H recente com peso extra");
  check(RecentFormEngine.recencyWeight(1)>RecentFormEngine.recencyWeight(135),"A jogo antigo recebe peso menor");

  // B Cairns x Tasmania: preseason remains, but below current official game weight.
  RecentFormEngine.Sample pre=g("2026-09-20","NBL Preseason","Tasmania JackJumpers",true,92,86),old=g("2026-05-01","NBL","Perth Wildcats",true,80,77);
  double wp=RecentFormEngine.gameWeight(pre,"NBL",RecentFormEngine.parseDate("2026-09-23")),wo=RecentFormEngine.gameWeight(old,"NBL",RecentFormEngine.parseDate("2026-09-23"));
  check(wp>0&&wp<1&&wp>wo,"B pré-temporada recente entra com peso reduzido, sem desaparecer");

  // C Shanghai x RSSB: cross-league normalization uses baseline rather than raw points alone.
  double no=RecentFormEngine.normalizedOffense(96,90),nd=RecentFormEngine.normalizedDefense(82,90);check(no>1&&nd>1,"C normalização entre ligas por baseline");

  // D Nagasaki x Shimane: robust mean resists one extreme score and market check remains calibration only.
  ArrayList<RecentFormEngine.Sample> form=new ArrayList<>();int[] pts={82,79,85,81,128};for(int i=0;i<pts.length;i++)form.add(g("2026-09-"+(18+i),"B.League","Opponent "+i,true,pts[i],76));
  RecentFormEngine.Metrics m=RecentFormEngine.analyze(form,"B.League","2026-09-23");check(m.weightedFor<100&&m.weightedFor>78,"D outlier não domina forma ponderada");
  StatisticalCalibrationEngine.Calibration cal=StatisticalCalibrationEngine.calibrate(64,78,8,3,88,84,61,.14,88,false);check(!"REVISÃO NECESSÁRIA".equals(cal.status),"D mercado 61 x IA 64 permanece coerente");

  check("FONTE ÚNICA • CONFIANÇA LIMITADA".equals(ProductionRules.consensusLabel(1,90)),"E 1 fonte nunca é consenso");
  check("CONSENSO FORTE".equals(ProductionRules.consensusLabel(3,84)),"F 3 fontes convergentes = consenso forte");
  check(!"FC".equals(ProductionRules.sportPlaceholder("basketball","Nagasaki Velca"))&&"NV".equals(ProductionRules.sportPlaceholder("basketball","Nagasaki Velca")),"G basquete sem FC, usa iniciais reais");
  check(ProductionRules.sanitizeNullable("null").isEmpty(),"H null não é renderizado");
  check(ProductionRules.pregameAllowed("SCHEDULED")&&!ProductionRules.pregameAllowed("LIVE")&&!ProductionRules.pregameAllowed("FINISHED"),"I/J futuro permitido, LIVE/FINISHED bloqueados no pré-jogo");
  check(Math.abs(RecentFormEngine.h2hWeight(20)-1.0)<.01&&RecentFormEngine.h2hWeight(500)<.3,"H2H antigo tem peso muito baixo");
  System.out.println("ALL PRODUCTION TESTS PASSED: "+ok);
 }
}
