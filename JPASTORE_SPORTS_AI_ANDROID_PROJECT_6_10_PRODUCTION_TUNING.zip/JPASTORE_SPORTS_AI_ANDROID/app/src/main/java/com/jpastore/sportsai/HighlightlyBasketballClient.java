package com.jpastore.sportsai;

import android.content.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.regex.*;

/**
 * Optional FAST basketball provider backed by Highlightly.
 * The key is user-supplied and persisted only in app preferences.
 * This source never gates the app: quota/auth/network failures fall through to public/API-Sports sources.
 */
final class HighlightlyBasketballClient {
    static final String SOURCE="highlightly_basketball";
    static final String TITLE="Highlightly Basketball";
    static final String BASE="https://basketball.highlightly.net/";
    static final String ALT_BASE="https://sports.highlightly.net/basketball/";
    private static final String STORE="jp_persistent_v1", KEY="api_highlightly_basketball";
    private static final String META="jp_highlightly_basket_meta", CACHE="jp_highlightly_basket_cache";
    private final Context c;

    HighlightlyBasketballClient(Context c){this.c=c;}
    static String key(Context c){return c==null?"":c.getSharedPreferences(STORE,0).getString(KEY,"").trim();}
    static boolean configured(Context c){return !key(c).isEmpty();}
    static void saveKey(Context c,String v){if(c!=null)c.getSharedPreferences(STORE,0).edit().putString(KEY,v==null?"":v.trim()).apply();}
    static void clearKey(Context c){if(c!=null)c.getSharedPreferences(STORE,0).edit().remove(KEY).apply();}

    static final class Status {
        String plan=""; int remaining=-1,limit=-1;
        String text(){String p=plan==null||plan.isEmpty()?"Plano detectado":plan.toUpperCase(Locale.ROOT);if(remaining>=0&&limit>0)return p+" • restante "+remaining+"/"+limit;return remaining>=0?p+" • restante "+remaining:p;}
    }
    static final class Response {String body="";int remaining=-1,limit=-1,code=-1;}

    Response request(String path,String apiKey)throws Exception{
        if(apiKey==null||apiKey.trim().isEmpty())throw new IOException("Chave Highlightly não configurada");
        SharedPreferences meta=c.getSharedPreferences(META,0);String blockedDay=meta.getString("blocked_day","");
        if(localDay().equals(blockedDay))throw new IOException("Highlightly pausada até amanhã por limite diário");
        Response out=call(BASE,null,path,apiKey.trim());
        // A chave criada diretamente no Basketball API usa basketball.highlightly.net. Também aceitamos
        // uma chave do produto All Sports como fallback sem obrigar o usuário a escolher manualmente o host.
        if(out.code==401||out.code==403)try{Response alt=call(ALT_BASE,"sport-highlights-api.p.rapidapi.com",path,apiKey.trim());if(alt.code>=200&&alt.code<300||alt.code==429)out=alt;}catch(Exception ignored){}
        SharedPreferences.Editor ed=meta.edit();if(out.remaining>=0)ed.putInt("remaining",out.remaining);if(out.limit>=0)ed.putInt("limit",out.limit);if(out.code>=200&&out.code<300)ed.putLong("last_ok",System.currentTimeMillis());
        if(out.code==429||out.remaining==0){ed.putString("blocked_day",localDay()).apply();throw new IOException("Limite diário da Highlightly atingido • fallbacks continuam ativos");}
        ed.apply();
        if(out.code==401||out.code==403)throw new IOException("Highlightly recusou a chave ou este endpoint não faz parte do plano");
        if(out.code<200||out.code>=300)throw new IOException("Highlightly HTTP "+out.code);
        return out;
    }
    Response call(String base,String host,String path,String apiKey)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(base+path).openConnection();
        h.setRequestProperty("x-rapidapi-key",apiKey);if(host!=null&&!host.isEmpty())h.setRequestProperty("x-rapidapi-host",host);h.setRequestProperty("Accept","application/json");h.setRequestProperty("User-Agent","J.Pastore-Sports-AI/6.9 Android");
        h.setConnectTimeout(3000);h.setReadTimeout(4500);int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();StringBuilder b=new StringBuilder();
        if(in!=null){BufferedReader r=new BufferedReader(new InputStreamReader(in));for(String line;(line=r.readLine())!=null;)b.append(line);}
        Response out=new Response();out.code=code;out.body=b.toString();out.remaining=headerInt(h,"x-ratelimit-requests-remaining");out.limit=headerInt(h,"x-ratelimit-requests-limit");return out;
    }

    void test(String apiKey,Consumer<Boolean> cb){new Thread(()->{try{String d=localDay();request("matches?date="+d+"&timezone=America%2FSao_Paulo&limit=1",apiKey);cb.accept(true);}catch(Exception e){cb.accept(false);}}).start();}
    void status(String apiKey,Consumer<Status> ok,Consumer<String> err){new Thread(()->{try{Response rr=request("matches?date="+localDay()+"&timezone=America%2FSao_Paulo&limit=1",apiKey);JSONObject root=new JSONObject(rr.body);Status s=new Status();JSONObject p=root.optJSONObject("plan");if(p!=null){s.plan=p.optString("tier","");rememberPlan(rr.body);}s.remaining=rr.remaining>=0?rr.remaining:c.getSharedPreferences(META,0).getInt("remaining",-1);s.limit=rr.limit>=0?rr.limit:c.getSharedPreferences(META,0).getInt("limit",-1);ok.accept(s);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    ArrayList<MultiSportClient.Event> matches(String apiKey,String date)throws Exception{
        String ck="matches_"+date;long ttl=date.equals(localDay())?60L*1000L:30L*60*1000L;String raw=cacheGet(ck,ttl);
        if(raw==null){raw=request("matches?date="+URLEncoder.encode(date,"UTF-8")+"&timezone=America%2FSao_Paulo&limit=100",apiKey).body;cachePut(ck,raw);}rememberPlan(raw);return parseEvents(raw);
    }

    MultiSportWebClient.Research research(String apiKey,MultiSportClient.Event ev,boolean deep)throws Exception{
        if(ev==null)return null;resolve(apiKey,ev);if(ev.highlightlyHomeId<=0||ev.highlightlyAwayId<=0)return null;
        MultiSportWebClient.Research r=new MultiSportWebClient.Research();r.homeName=ev.home;r.awayName=ev.away;r.targetHomeId=ev.highlightlyHomeId;r.targetAwayId=ev.highlightlyAwayId;r.query=ev.home+" "+ev.away+" basketball";
        ExecutorService ex=Executors.newFixedThreadPool(4);
        Future<ArrayList<MultiSportWebClient.GameRow>> fh=ex.submit(()->rows(requestCached("last_home_"+ev.highlightlyHomeId,"last-five-games?teamId="+ev.highlightlyHomeId,apiKey,15L*60*1000L)));
        Future<ArrayList<MultiSportWebClient.GameRow>> fa=ex.submit(()->rows(requestCached("last_away_"+ev.highlightlyAwayId,"last-five-games?teamId="+ev.highlightlyAwayId,apiKey,15L*60*1000L)));
        Future<ArrayList<MultiSportWebClient.GameRow>> fhh=ex.submit(()->rows(requestCached("h2h_"+ev.highlightlyHomeId+"_"+ev.highlightlyAwayId,"head-2-head?teamIdOne="+ev.highlightlyHomeId+"&teamIdTwo="+ev.highlightlyAwayId,apiKey,45L*60*1000L)));
        Future<MarketOddsBook> fo=ex.submit(()->{try{return odds(apiKey,ev);}catch(Exception e){return new MarketOddsBook();}});
        long deadline=System.currentTimeMillis()+(deep?6500L:3800L);MultiSportWebClient web=new MultiSportWebClient(c);
        ArrayList<MultiSportWebClient.GameRow> hr=getBefore(fh,deadline),ar=getBefore(fa,deadline),hh=getBefore(fhh,deadline);
        web.mergeSourceRows(r,hr,ev,"Highlightly");web.mergeSourceRows(r,ar,ev,"Highlightly");web.mergeSourceRows(r,hh,ev,"Highlightly");
        try{long left=deadline-System.currentTimeMillis();if(left>0){MarketOddsBook b=fo.get(left,TimeUnit.MILLISECONDS);if(b!=null)r.marketOdds.merge(b);}}catch(Exception ignored){}
        ex.shutdownNow();web.rebuildResearch(r);if(r.hasStructured())r.source="Highlightly";return r;
    }

    void resolve(String apiKey,MultiSportClient.Event target)throws Exception{
        if(target.highlightlyId>0&&target.highlightlyHomeId>0&&target.highlightlyAwayId>0)return;
        ArrayList<MultiSportClient.Event> list=matches(apiKey,target.date==null||target.date.length()<10?localDay():target.date.substring(0,10));int best=-1;MultiSportClient.Event win=null;
        for(MultiSportClient.Event e:list){int s=ApiClient.teamScore(target.home,e.home)+ApiClient.teamScore(target.away,e.away);int rev=ApiClient.teamScore(target.home,e.away)+ApiClient.teamScore(target.away,e.home)-20;s=Math.max(s,rev);if(s>best){best=s;win=e;}}
        if(win!=null&&best>=120){target.highlightlyId=win.highlightlyId;target.highlightlyHomeId=win.highlightlyHomeId;target.highlightlyAwayId=win.highlightlyAwayId;target.highlightlyLeagueId=win.highlightlyLeagueId;if(target.homeLogo.isEmpty())target.homeLogo=win.homeLogo;if(target.awayLogo.isEmpty())target.awayLogo=win.awayLogo;}
    }

    MarketOddsBook odds(String apiKey,MultiSportClient.Event ev)throws Exception{
        MarketOddsBook out=new MarketOddsBook();if(ev==null||ev.highlightlyId<=0)return out;String tier=c.getSharedPreferences(META,0).getString("plan_tier","");if(!oddsAvailableForTier(tier))return out;boolean pre=StatisticalCalibrationEngine.isPregameStatus(ev.status);
        try{String raw=requestCached("odds_"+ev.highlightlyId,"odds?matchId="+ev.highlightlyId+"&oddsType="+oddsTypeForStatus(ev.status)+"&limit=5",apiKey,pre?10L*60*1000L:90L*1000L);rememberPlan(raw);JSONArray data=new JSONObject(raw).optJSONArray("data");if(data==null)return out;for(int i=0;i<data.length();i++){JSONObject item=data.optJSONObject(i);JSONArray os=item==null?null:item.optJSONArray("odds");if(os==null)continue;for(int j=0;j<os.length();j++)parseOdd(out,os.optJSONObject(j));}}catch(IOException e){String m=e.getMessage()==null?"":e.getMessage().toLowerCase(Locale.ROOT);if(m.contains("plano")||m.contains("endpoint"))c.getSharedPreferences(META,0).edit().putString("plan_tier","BASIC").apply();else throw e;}return out;
    }
    static boolean oddsAvailableForTier(String tier){String t=tier==null?"":tier.trim();return !("FREE".equalsIgnoreCase(t)||"BASIC".equalsIgnoreCase(t));}
    static String oddsTypeForStatus(String status){return StatisticalCalibrationEngine.isPregameStatus(status)?"prematch":"live";}

    static void parseOdd(MarketOddsBook out,JSONObject o){if(out==null||o==null)return;String market=o.optString("market","");String book=o.optString("bookmakerName","Highlightly");JSONArray vals=o.optJSONArray("values");if(vals==null||vals.length()<2)return;LinkedHashMap<String,Double> m=new LinkedHashMap<>();String low=market.toLowerCase(Locale.ROOT);
        if(low.equals("moneyline")||low.contains("full time result")||low.contains("3-way")){for(int i=0;i<vals.length();i++){JSONObject v=vals.optJSONObject(i);String x=v==null?"":v.optString("value","").toLowerCase(Locale.ROOT);double odd=v==null?Double.NaN:v.optDouble("odd",Double.NaN);if(x.contains("home"))m.put(MarketOddsBook.HOME,odd);else if(x.contains("away"))m.put(MarketOddsBook.AWAY,odd);else if(x.contains("draw"))m.put(MarketOddsBook.DRAW,odd);}out.addBookmakerMarket(m,book,market);return;}
        Matcher total=Pattern.compile("(?:total points|totals)\\s*([0-9]+(?:\\.[0-9]+)?)",Pattern.CASE_INSENSITIVE).matcher(market);if(total.find()){double line=Double.parseDouble(total.group(1));for(int i=0;i<vals.length();i++){JSONObject v=vals.optJSONObject(i);String x=v==null?"":v.optString("value","").toLowerCase(Locale.ROOT);double odd=v==null?Double.NaN:v.optDouble("odd",Double.NaN);if(x.contains("over"))m.put(MarketOddsBook.totalKey(true,line),odd);else if(x.contains("under"))m.put(MarketOddsBook.totalKey(false,line),odd);}out.addBookmakerMarket(m,book,market);return;}
        if(low.startsWith("spread")){Matcher nums=Pattern.compile("([+-]?[0-9]+(?:\\.[0-9]+)?)").matcher(market);ArrayList<Double> ns=new ArrayList<>();while(nums.find())try{ns.add(Double.parseDouble(nums.group(1)));}catch(Exception ignored){}double homeLine=ns.isEmpty()?Double.NaN:ns.get(0),awayLine=ns.size()>1?ns.get(1):(Double.isNaN(homeLine)?Double.NaN:-homeLine);for(int i=0;i<vals.length();i++){JSONObject v=vals.optJSONObject(i);String x=v==null?"":v.optString("value","").toLowerCase(Locale.ROOT);double odd=v==null?Double.NaN:v.optDouble("odd",Double.NaN);if(x.contains("home")&&!Double.isNaN(homeLine))m.put(MarketOddsBook.handicapKey(true,homeLine),odd);else if(x.contains("away")&&!Double.isNaN(awayLine))m.put(MarketOddsBook.handicapKey(false,awayLine),odd);}out.addBookmakerMarket(m,book,market);}
    }

    static ArrayList<MultiSportClient.Event> parseEvents(String raw)throws Exception{ArrayList<MultiSportClient.Event> out=new ArrayList<>();JSONArray a=new JSONObject(raw).optJSONArray("data");if(a==null)return out;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);MultiSportClient.Event e=parseEvent(o);if(e!=null)out.add(e);}return out;}
    static MultiSportClient.Event parseEvent(JSONObject o){if(o==null)return null;JSONObject h=o.optJSONObject("homeTeam"),a=o.optJSONObject("awayTeam"),l=o.optJSONObject("league"),st=o.optJSONObject("state");if(h==null||a==null)return null;MultiSportClient.Event e=new MultiSportClient.Event(MultiSportClient.BASKETBALL);e.apiSource=SOURCE;e.id=o.optLong("id",0);e.highlightlyId=e.id;e.highlightlyHomeId=h.optLong("id",0);e.highlightlyAwayId=a.optLong("id",0);e.highlightlyLeagueId=l==null?0:l.optLong("id",0);e.homeId=e.highlightlyHomeId;e.awayId=e.highlightlyAwayId;e.leagueId=e.highlightlyLeagueId;e.home=h.optString("name","");e.away=a.optString("name","");e.homeLogo=h.optString("logo","");e.awayLogo=a.optString("logo","");e.competition=l==null?"":l.optString("name","");e.season=l==null?"":String.valueOf(l.optInt("season",0));if("0".equals(e.season))e.season="";String[] dt=localIso(o.optString("date",""));e.date=dt[0];e.time=dt[1];e.status=st==null?"":st.optString("description","");JSONObject sc=st==null?null:st.optJSONObject("score");if(sc!=null){String cur=sc.optString("current","");if(!cur.isEmpty())e.score=cur.replace("-","×");}e.detail="Highlightly • "+e.competition+" • "+e.status;return e.home.isEmpty()||e.away.isEmpty()?null:e;}

    ArrayList<MultiSportWebClient.GameRow> rows(String raw)throws Exception{ArrayList<MultiSportWebClient.GameRow> out=new ArrayList<>();Object parsed=new JSONTokener(raw).nextValue();JSONArray a=parsed instanceof JSONArray?(JSONArray)parsed:((JSONObject)parsed).optJSONArray("data");if(a==null)return out;for(int i=0;i<a.length();i++){MultiSportWebClient.GameRow g=row(a.optJSONObject(i));if(g!=null)out.add(g);}return out;}
    static MultiSportWebClient.GameRow row(JSONObject o){if(o==null)return null;JSONObject h=o.optJSONObject("homeTeam"),a=o.optJSONObject("awayTeam"),st=o.optJSONObject("state");if(h==null||a==null)return null;MultiSportWebClient.GameRow g=new MultiSportWebClient.GameRow();g.home=h.optString("name","");g.away=a.optString("name","");g.homeId=h.optLong("id",0);g.awayId=a.optLong("id",0);JSONObject lg=o.optJSONObject("league");g.competition=lg==null?"":lg.optString("name","");g.competitionType=RecentFormEngine.norm(g.competition);g.dataSource="Highlightly";g.lastUpdated=System.currentTimeMillis();String[] dt=localIso(o.optString("date",""));g.date=dt[0];g.status=st==null?"":st.optString("description","");JSONObject sc=st==null?null:st.optJSONObject("score");int[] p=scorePair(sc==null?"":sc.optString("current",""));g.hs=p[0];g.as=p[1];String s=g.status.toLowerCase(Locale.ROOT);g.completed=s.contains("finished")&&g.hs>=0&&g.as>=0;g.score=(g.hs>=0?g.hs:"—")+" × "+(g.as>=0?g.as:"—");return g;}

    String requestCached(String key,String path,String apiKey,long ttl)throws Exception{String old=cacheGet(key,ttl);if(old!=null)return old;String raw=request(path,apiKey).body;cachePut(key,raw);return raw;}
    void rememberPlan(String raw){try{JSONObject p=new JSONObject(raw).optJSONObject("plan");String tier=p==null?"":p.optString("tier","");if(!tier.trim().isEmpty())c.getSharedPreferences(META,0).edit().putString("plan_tier",tier.trim()).apply();}catch(Exception ignored){}}
    static <T> ArrayList<T> getBefore(Future<ArrayList<T>> f,long deadline){try{long left=deadline-System.currentTimeMillis();return left>0?f.get(left,TimeUnit.MILLISECONDS):new ArrayList<>();}catch(Exception e){return new ArrayList<>();}}
    static int[] scorePair(String s){int[] z={-1,-1};if(s==null)return z;Matcher m=Pattern.compile("(\\d{1,3})\\s*[-×:]\\s*(\\d{1,3})").matcher(s);if(m.find())try{z[0]=Integer.parseInt(m.group(1));z[1]=Integer.parseInt(m.group(2));}catch(Exception ignored){}return z;}
    static String[] localIso(String iso){EventTimeNormalizer.Converted c=EventTimeNormalizer.fromIso(iso,"UTC");return new String[]{c.date,c.time};}
    String localDay(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(new Date());}
    static int headerInt(HttpURLConnection h,String n){try{String v=h.getHeaderField(n);return v==null?-1:Integer.parseInt(v.trim());}catch(Exception e){return -1;}}
    void cachePut(String k,String v){c.getSharedPreferences(CACHE,0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long age){SharedPreferences p=c.getSharedPreferences(CACHE,0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=age?p.getString(k,null):null;}
}
