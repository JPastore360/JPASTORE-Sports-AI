package com.jpastore.sportsai;

import java.util.*;

/** Small Android-free production rules shared by UI/tests. */
final class ProductionRules {
 static String consensusLabel(int uniqueSourceCount,int convergence){if(uniqueSourceCount<=1)return "FONTE ÚNICA • CONFIANÇA LIMITADA";if(uniqueSourceCount>=3&&convergence>=75)return "CONSENSO FORTE";return "CONSENSO MODERADO";}
 static String sanitizeNullable(String s){if(s==null)return "";String x=s.trim();return "null".equalsIgnoreCase(x)||"undefined".equalsIgnoreCase(x)?"":x;}
 static String initials(String team){String x=sanitizeNullable(team);if(x.isEmpty())return "?";StringBuilder b=new StringBuilder();for(String p:x.split("\\s+")){String n=p.replaceAll("[^\\p{L}0-9]","");if(n.isEmpty()||n.equalsIgnoreCase("fc")||n.equalsIgnoreCase("club"))continue;b.append(Character.toUpperCase(n.charAt(0)));if(b.length()>=2)break;}return b.length()==0?"?":b.toString();}
 static String sportPlaceholder(String sport,String team){String i=initials(team);return i.equals("?")?("basketball".equalsIgnoreCase(sport)?"🏀":("tennis".equalsIgnoreCase(sport)?"🎾":"⚽")):i;}
 static boolean pregameAllowed(String status){return "SCHEDULED".equals(EventTimeNormalizer.canonicalStatus(status));}
 private ProductionRules(){}
}
