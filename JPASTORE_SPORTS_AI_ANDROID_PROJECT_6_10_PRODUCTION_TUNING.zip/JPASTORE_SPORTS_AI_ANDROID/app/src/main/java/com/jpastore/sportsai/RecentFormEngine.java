package com.jpastore.sportsai;

import java.text.Normalizer;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * Production form model (6.10). Android-free and deterministic.
 * Recent games are weighted by recency, competition relevance and opponent strength.
 * Raw numbers are preserved for transparency; weighted numbers drive the model.
 */
final class RecentFormEngine {
    static final class Sample {
        String date="", competition="", opponent="", source="";
        boolean home;
        int pointsFor=-1, pointsAgainst=-1;
        double opponentStrengthWeight=1.0;
        Sample(){}
        Sample(String date,String competition,String opponent,boolean home,int pf,int pa){this.date=date;this.competition=competition;this.opponent=opponent;this.home=home;this.pointsFor=pf;this.pointsAgainst=pa;}
    }
    static final class Metrics {
        int games=0,wins=0,losses=0,draws=0;
        double rawFor=Double.NaN,rawAgainst=Double.NaN,rawMargin=Double.NaN,rawWinRate=Double.NaN;
        double weightedFor=Double.NaN,weightedAgainst=Double.NaN,weightedMargin=Double.NaN,weightedWinRate=Double.NaN,recentFormScore=Double.NaN;
        double effectiveSample=0,recencyScore=0,stabilityScore=0,robustTotalMean=Double.NaN,robustTotalStd=Double.NaN;
        int daysRest=-1;String latestDate="";
    }
    static final class SeriesInfo {boolean backToBack=false;int lastMeetingDaysAgo=-1;double lastMeetingWeight=1.0;}

    static Metrics analyze(List<Sample> input,String currentCompetition,String targetDate){
        Metrics m=new Metrics();if(input==null||input.isEmpty())return m;
        ArrayList<Sample> rows=dedupe(input);Collections.sort(rows,(a,b)->safe(b.date).compareTo(safe(a.date)));
        LocalDate target=parseDate(targetDate);if(target==null)target=LocalDate.now();
        double rawF=0,rawA=0,weightedF=0,weightedA=0,weightSum=0,winWeight=0;
        ArrayList<Double> totals=new ArrayList<>();ArrayList<Double> weightedTotals=new ArrayList<>();ArrayList<Double> weights=new ArrayList<>();
        for(Sample s:rows){if(s==null||s.pointsFor<0||s.pointsAgainst<0)continue;m.games++;rawF+=s.pointsFor;rawA+=s.pointsAgainst;if(s.pointsFor>s.pointsAgainst)m.wins++;else if(s.pointsFor<s.pointsAgainst)m.losses++;else m.draws++;
            double w=gameWeight(s,currentCompetition,target);weightSum+=w;weightedF+=winsorPoint(s.pointsFor,rows,true)*w;weightedA+=winsorPoint(s.pointsAgainst,rows,false)*w;if(s.pointsFor>s.pointsAgainst)winWeight+=w;else if(s.pointsFor==s.pointsAgainst)winWeight+=.5*w;
            totals.add((double)(s.pointsFor+s.pointsAgainst));weightedTotals.add((double)(s.pointsFor+s.pointsAgainst));weights.add(w);
            if(m.latestDate.isEmpty()||safe(s.date).compareTo(m.latestDate)>0)m.latestDate=s.date;
        }
        if(m.games==0)return m;
        m.rawFor=rawF/m.games;m.rawAgainst=rawA/m.games;m.rawMargin=m.rawFor-m.rawAgainst;m.rawWinRate=m.wins/(double)m.games;
        m.weightedFor=weightedF/Math.max(.001,weightSum);m.weightedAgainst=weightedA/Math.max(.001,weightSum);m.weightedMargin=m.weightedFor-m.weightedAgainst;m.weightedWinRate=winWeight/Math.max(.001,weightSum);
        m.effectiveSample=weightSum;m.recencyScore=recencyScore(rows,target);m.recentFormScore=clamp(50+(m.weightedWinRate-.5)*55+clamp(m.weightedMargin,-25,25)*1.2,0,100);
        m.robustTotalMean=weightedRobustMean(weightedTotals,weights);m.robustTotalStd=robustStd(totals);m.stabilityScore=stability(m.robustTotalMean,m.robustTotalStd);
        LocalDate last=parseDate(m.latestDate);if(last!=null){long d=Math.max(0,ChronoUnit.DAYS.between(last,target));m.daysRest=(int)Math.min(99,d);}
        return m;
    }

    static SeriesInfo seriesInfo(List<Sample> h2h,String targetDate){SeriesInfo x=new SeriesInfo();if(h2h==null||h2h.isEmpty())return x;LocalDate target=parseDate(targetDate);if(target==null)return x;int best=Integer.MAX_VALUE;for(Sample s:h2h){LocalDate d=parseDate(s.date);if(d==null)continue;long gap=ChronoUnit.DAYS.between(d,target);if(gap>=0&&gap<best)best=(int)gap;}if(best<Integer.MAX_VALUE){x.lastMeetingDaysAgo=best;x.backToBack=best<=2;x.lastMeetingWeight=x.backToBack?1.20:(best<30?1.0:(best<=90?.72:(best<=365?.45:.25)));}return x;}

    static double gameWeight(Sample s,String currentCompetition,LocalDate target){LocalDate d=parseDate(s.date);long days=d==null?180:Math.max(0,ChronoUnit.DAYS.between(d,target));double r=recencyWeight(days),c=competitionWeight(s.competition,currentCompetition,days),o=clamp(s.opponentStrengthWeight,.90,1.10);return r*c*o;}
    static double recencyWeight(long days){if(days<=7)return 1.00;if(days<=30)return .90;if(days<=60)return .75;if(days<=120)return .55;return .35;}
    static double competitionWeight(String competition,String current,long days){String c=norm(competition),cur=norm(current);if(c.contains("friendly")||c.contains("amistoso"))return .45;if(c.contains("preseason")||c.contains("pre season")||c.contains("pre-tempor")||c.contains("pre temporada")||c.contains("summer league")||c.contains("preparat"))return .60;if(c.contains("cup")||c.contains("copa")||c.contains("tournament")||c.contains("torneio"))return .90;if(!cur.isEmpty()&&(c.equals(cur)||c.contains(cur)||cur.contains(c)))return 1.00;if(days>120)return .50;return .78;}
    static double h2hWeight(int days){if(days<0)return .25;if(days<30)return 1.0;if(days<=90)return .70;if(days<=365)return .40;return .20;}
    static double normalizedOffense(double teamAverage,double leagueAverage){return leagueAverage>0?teamAverage/leagueAverage:Double.NaN;}
    static double normalizedDefense(double allowed,double leagueAverage){return allowed>0&&leagueAverage>0?leagueAverage/allowed:Double.NaN;}
    static double opponentStrengthWeight(String band){String x=norm(band);if(x.contains("elite"))return 1.10;if(x.contains("forte")||x.contains("strong"))return 1.05;if(x.contains("fraco")||x.contains("weak")){if(x.contains("muito")||x.contains("very"))return .90;return .95;}return 1.00;}

    static ArrayList<Sample> dedupe(List<Sample> rows){LinkedHashMap<String,Sample> m=new LinkedHashMap<>();for(Sample s:rows){if(s==null)continue;String k=norm(s.opponent)+"|"+safe(s.date)+"|"+s.pointsFor+"|"+s.pointsAgainst+"|"+(s.home?"H":"A");if(!m.containsKey(k))m.put(k,s);}return new ArrayList<>(m.values());}
    static double recencyScore(List<Sample> rows,LocalDate target){double s=0,w=0;for(Sample x:rows){LocalDate d=parseDate(x.date);if(d==null)continue;long days=Math.max(0,ChronoUnit.DAYS.between(d,target));double rw=recencyWeight(days);s+=rw*100;w++;}return w==0?30:s/w;}
    static double weightedRobustMean(List<Double> values,List<Double> weights){if(values==null||values.isEmpty())return Double.NaN;double med=median(values),mad=mad(values,med);double lo=med-Math.max(4,2.5*mad),hi=med+Math.max(4,2.5*mad);double s=0,w=0;for(int i=0;i<values.size();i++){double v=clamp(values.get(i),lo,hi),q=i<weights.size()?weights.get(i):1;s+=v*q;w+=q;}return w<=0?Double.NaN:s/w;}
    static double winsorPoint(double value,List<Sample> rows,boolean pf){ArrayList<Double> a=new ArrayList<>();for(Sample s:rows)if(s!=null&&(pf?s.pointsFor:s.pointsAgainst)>=0)a.add((double)(pf?s.pointsFor:s.pointsAgainst));if(a.size()<5)return value;double med=median(a),mad=mad(a,med);double span=Math.max(5,2.5*mad);return clamp(value,med-span,med+span);}
    static double robustStd(List<Double> values){if(values==null||values.size()<2)return values==null||values.isEmpty()?Double.NaN:0;double med=median(values),mad=mad(values,med);if(mad>0)return 1.4826*mad;double mean=0;for(double v:values)mean+=v;mean/=values.size();double s=0;for(double v:values){double d=v-mean;s+=d*d;}return Math.sqrt(s/(values.size()-1));}
    static double stability(double mean,double std){if(Double.isNaN(mean)||mean<=0||Double.isNaN(std))return 50;double cv=std/mean;if(cv<=.08)return 95;if(cv<=.13)return 85;if(cv<=.20)return 72;if(cv<=.30)return 58;return 38;}
    static double median(List<Double> a){ArrayList<Double>x=new ArrayList<>(a);Collections.sort(x);int n=x.size();return n%2==1?x.get(n/2):(x.get(n/2-1)+x.get(n/2))/2.0;}
    static double mad(List<Double>a,double med){ArrayList<Double>d=new ArrayList<>();for(double v:a)d.add(Math.abs(v-med));return d.isEmpty()?0:median(d);}
    static LocalDate parseDate(String s){try{if(s==null||s.length()<10)return null;return LocalDate.parse(s.substring(0,10),DateTimeFormatter.ISO_LOCAL_DATE);}catch(Exception e){return null;}}
    static String norm(String s){if(s==null)return "";String x=Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();return x;}
    static String safe(String s){return s==null?"":s.trim();}
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    private RecentFormEngine(){}
}
