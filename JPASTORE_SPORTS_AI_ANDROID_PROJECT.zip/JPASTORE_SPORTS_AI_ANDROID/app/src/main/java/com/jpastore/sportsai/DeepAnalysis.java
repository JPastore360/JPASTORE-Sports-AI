package com.jpastore.sportsai;

import java.util.*;

public class DeepAnalysis {
    public int homePct, drawPct, awayPct, confidence;
    public String primaryPick = "Sem sinal forte";
    public String trend = "Equilíbrio";
    public String apiAdvice = "";
    public String apiUnderOver = "";
    public String predictedHomeGoals = "";
    public String predictedAwayGoals = "";
    public String winnerComment = "";

    public int formHome, formAway;
    public int attackHome, attackAway;
    public int defenseHome, defenseAway;
    public int poissonHome, poissonAway;
    public int h2hHome, h2hAway;
    public int comparisonTotalHome, comparisonTotalAway;

    public TeamProfile homeProfile = new TeamProfile();
    public TeamProfile awayProfile = new TeamProfile();
    public final List<MarketSignal> markets = new ArrayList<>();
    public String modelReading = "";
    public String dataQuality = "";

    public static class TeamProfile {
        public String form = "";
        public int played, wins, draws, losses;
        public double goalsForAvg = -1, goalsAgainstAvg = -1;
        public double yellowCardsAvg = -1, redCardsAvg = -1;
        public double cleanSheetPct = -1, failedToScorePct = -1;

        public boolean hasUsefulData() {
            return played > 0 || goalsForAvg >= 0 || yellowCardsAvg >= 0;
        }
    }

    public static class MarketSignal {
        public final String title;
        public final String signal;
        public final int confidence;
        public final String source;

        public MarketSignal(String title, String signal, int confidence, String source) {
            this.title = title;
            this.signal = signal;
            this.confidence = Math.max(1, Math.min(99, confidence));
            this.source = source;
        }
    }
}
