package com.jpastore.sportsai;

import java.util.*;

public class AdvancedAnalysis {
    public final int homePct, drawPct, awayPct;
    public final int confidence;
    public final int formHome, formAway, attackHome, attackAway, defenceHome, defenceAway;
    public final int poissonHome, poissonAway, h2hHome, h2hAway, goalsHome, goalsAway;
    public final double expectedHomeGoals, expectedAwayGoals;
    public final String winner, underOver, apiAdvice, aiSummary, dataQuality;
    public final boolean oddsUsed;
    public final List<Market> markets;

    public AdvancedAnalysis(int homePct, int drawPct, int awayPct, int confidence,
                            int formHome, int formAway, int attackHome, int attackAway,
                            int defenceHome, int defenceAway, int poissonHome, int poissonAway,
                            int h2hHome, int h2hAway, int goalsHome, int goalsAway,
                            double expectedHomeGoals, double expectedAwayGoals,
                            String winner, String underOver, String apiAdvice,
                            String aiSummary, String dataQuality, boolean oddsUsed,
                            List<Market> markets) {
        this.homePct = homePct; this.drawPct = drawPct; this.awayPct = awayPct; this.confidence = confidence;
        this.formHome = formHome; this.formAway = formAway; this.attackHome = attackHome; this.attackAway = attackAway;
        this.defenceHome = defenceHome; this.defenceAway = defenceAway; this.poissonHome = poissonHome; this.poissonAway = poissonAway;
        this.h2hHome = h2hHome; this.h2hAway = h2hAway; this.goalsHome = goalsHome; this.goalsAway = goalsAway;
        this.expectedHomeGoals = expectedHomeGoals; this.expectedAwayGoals = expectedAwayGoals;
        this.winner = safe(winner); this.underOver = safe(underOver); this.apiAdvice = safe(apiAdvice);
        this.aiSummary = safe(aiSummary); this.dataQuality = safe(dataQuality); this.oddsUsed = oddsUsed;
        this.markets = markets == null ? new ArrayList<>() : markets;
    }

    private static String safe(String s) { return s == null ? "" : s; }

    public static class Market {
        public final String category, selection, source, note;
        public final int probability, confidence;
        public final double marketOdd, fairOdd, valuePct;

        public Market(String category, String selection, int probability, int confidence, String source, String note) {
            this(category, selection, probability, confidence, source, note, 0.0);
        }

        public Market(String category, String selection, int probability, int confidence, String source, String note, double marketOdd) {
            this.category = category;
            this.selection = selection;
            this.probability = Math.max(1, Math.min(99, probability));
            this.confidence = Math.max(1, Math.min(99, confidence));
            this.source = source == null ? "Modelo" : source;
            this.note = note == null ? "" : note;
            this.marketOdd = marketOdd > 1.0 ? marketOdd : 0.0;
            this.fairOdd = 100.0 / this.probability;
            this.valuePct = this.marketOdd > 0 ? ((this.marketOdd / this.fairOdd) - 1.0) * 100.0 : 0.0;
        }

        public String valueLabel() {
            if (marketOdd <= 0) return "ODD IA";
            if (valuePct >= 6) return "POSSÍVEL VALOR";
            if (valuePct <= -6) return "ODD POUCO ATRATIVA";
            return "NEUTRO";
        }
    }
}
