package com.jpastore.sportsai;
import android.content.*;import org.json.*;import java.util.*;

/** Persistent multi-match ticket assembled only from probabilities already calculated by the app. */
public class TicketStore {
 static class Selection {
  String market,pick,confidence; int probability,sample;
  Selection(String m,String p,int pr,int s,String c){market=m;pick=p;probability=pr;sample=s;confidence=c;}
 }
 static class Block {
  String key,home,away,league,kickoff,mode; ArrayList<Selection> selections=new ArrayList<>();
 }
 private final SharedPreferences sp;
 TicketStore(Context c){sp=c.getSharedPreferences("jp_ai_ticket",0);}

 ArrayList<Block> all(){ArrayList<Block> out=new ArrayList<>();try{JSONArray a=new JSONArray(sp.getString("blocks","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Block b=new Block();b.key=o.optString("key");b.home=o.optString("home");b.away=o.optString("away");b.league=o.optString("league");b.kickoff=o.optString("kickoff");b.mode=o.optString("mode","COMPLETO");JSONArray s=o.optJSONArray("selections");if(s!=null)for(int j=0;j<s.length();j++){JSONObject x=s.getJSONObject(j);b.selections.add(new Selection(x.optString("market"),x.optString("pick"),x.optInt("probability"),x.optInt("sample"),x.optString("confidence")));}out.add(b);}}catch(Exception ignored){}return out;}
 int blockCount(){return all().size();}
 int selectionCount(){int n=0;for(Block b:all())n+=b.selections.size();return n;}
 void clear(){sp.edit().remove("blocks").apply();}

 int add(ApiClient.Game g,ApiClient.Prediction p,ApiClient.DeepAnalysis d,String mode){if(g==null)return 0;Block b=new Block();b.key=key(g);b.home=g.home;b.away=g.away;b.league=g.league==null?"":g.league;b.kickoff=g.time==null?"":g.time;b.mode=mode==null?"COMPLETO":mode;int min=threshold(b.mode);
  if(p!=null){int hp=p.home+p.draw,ap=p.away+p.draw;if(Math.max(hp,ap)>=min){boolean home=hp>=ap;int pr=home?hp:ap;String pick=home?g.home+" ou empate":"Empate ou "+g.away;b.selections.add(new Selection("Dupla chance",pick,pr,0,confidence(pr)));}}
  if(d!=null){String[] order={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};for(String name:order){ApiClient.MetricProjection m=d.metrics.get(name);if(m==null||m.line<=0||m.overProb<0||m.sample<minSample(b.mode))continue;int over=m.overProb,under=100-over;boolean useOver=over>=under;int pr=Math.max(over,under);double line=m.line;if(pr<min&&m.lineHigh>0&&m.overProbHigh>=0){int oh=m.overProbHigh,uh=100-oh;if(Math.max(oh,uh)>pr){useOver=oh>=uh;pr=Math.max(oh,uh);line=m.lineHigh;}}if(pr<min)continue;String pick=(useOver?"Mais de ":"Menos de ")+fmt(line)+" "+marketUnit(name);b.selections.add(new Selection(name,pick,pr,m.sample,confidence(pr)));}}
  ArrayList<Block> blocks=all();for(Iterator<Block> it=blocks.iterator();it.hasNext();){Block old=it.next();if(java.util.Objects.equals(old.key,b.key))it.remove();}if(!b.selections.isEmpty())blocks.add(b);return save(blocks)?b.selections.size():-1;
 }
 private boolean save(ArrayList<Block> blocks){try{JSONArray a=new JSONArray();for(Block b:blocks){JSONObject o=new JSONObject();o.put("key",b.key);o.put("home",b.home);o.put("away",b.away);o.put("league",b.league);o.put("kickoff",b.kickoff);o.put("mode",b.mode);JSONArray s=new JSONArray();for(Selection x:b.selections){JSONObject q=new JSONObject();q.put("market",x.market);q.put("pick",x.pick);q.put("probability",x.probability);q.put("sample",x.sample);q.put("confidence",x.confidence);s.put(q);}o.put("selections",s);a.put(o);}return sp.edit().putString("blocks",a.toString()).commit();}catch(Exception ignored){return false;}}
 String copyText(){ArrayList<Block> blocks=all();StringBuilder s=new StringBuilder("J.PASTORE AI • BILHETE PARA REVISÃO\n");s.append(blocks.size()).append(" confrontos • ").append(selectionCount()).append(" seleções\n\n");int i=1;for(Block b:blocks){s.append(i++).append(") ").append(b.home).append(" × ").append(b.away);if(!b.league.isEmpty())s.append(" • ").append(b.league);s.append("\n");for(Selection x:b.selections){s.append("• ").append(x.pick).append(" — estimativa ").append(x.probability).append("% • ").append(x.confidence);if(x.sample>0)s.append(" • amostra ").append(x.sample);s.append("\n");}s.append("\n");}s.append("Estimativas estatísticas da J.Pastore AI. Revise as linhas e as odds reais na plataforma antes de qualquer decisão. Não há garantia de resultado.");return s.toString();}
 static String key(ApiClient.Game g){return g.fixtureId+"|"+g.home+"|"+g.away+"|"+(g.time==null?"":g.time);}
 static int threshold(String mode){return "ENXUTO".equals(mode)?62:("EQUILIBRADO".equals(mode)?56:50);}
 static int minSample(String mode){return "ENXUTO".equals(mode)?4:("EQUILIBRADO".equals(mode)?3:2);}
 static String confidence(int p){return p>=68?"FAVORÁVEL":(p>=58?"ATENÇÃO":"DUVIDOSO");}
 static String fmt(double x){return String.format(Locale.US,"%.1f",x);}
 static String marketUnit(String n){if("Gols".equals(n))return "gols";if("Escanteios".equals(n))return "escanteios";if("Laterais".equals(n))return "laterais";if("Tiros de meta".equals(n))return "tiros de meta";if("Faltas".equals(n))return "faltas";if("Finalizações".equals(n))return "finalizações";if("Chutes no alvo".equals(n))return "chutes no alvo";if("Impedimentos".equals(n))return "impedimentos";if("Cartões amarelos".equals(n))return "cartões amarelos";if("Tiros livres".equals(n))return "tiros livres";return n.toLowerCase(Locale.ROOT);}
}
