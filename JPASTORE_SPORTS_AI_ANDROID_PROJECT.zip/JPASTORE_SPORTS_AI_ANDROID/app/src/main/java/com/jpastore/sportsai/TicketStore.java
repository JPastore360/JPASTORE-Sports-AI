package com.jpastore.sportsai;
import android.content.*;import org.json.*;import java.util.*;

/** Persistent multi-match ticket assembled only from probabilities already calculated by the app. */
public class TicketStore {
 static class Selection {
  String market,pick,confidence,detail; int probability,sample;
  Selection(String m,String p,int pr,int s,String c){this(m,p,pr,s,c,"");}
  Selection(String m,String p,int pr,int s,String c,String d){market=m;pick=p;probability=pr;sample=s;confidence=c;detail=d==null?"":d;}
 }
 static class Block {
  String key,home,away,league,kickoff,mode,quality,sport="football"; int coverage,baseSample,availableMarkets; ArrayList<Selection> selections=new ArrayList<>();
 }
 private final SharedPreferences sp;
 TicketStore(Context c){sp=c.getSharedPreferences("jp_ai_ticket",0);}

 ArrayList<Block> all(){ArrayList<Block> out=new ArrayList<>();try{JSONArray a=new JSONArray(sp.getString("blocks","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Block b=new Block();b.key=o.optString("key");b.home=o.optString("home");b.away=o.optString("away");b.league=o.optString("league");b.kickoff=o.optString("kickoff");b.mode=o.optString("mode","COMPLETO");b.sport=o.optString("sport","football");b.coverage=o.optInt("coverage",0);b.baseSample=o.optInt("baseSample",0);b.quality=normalizeQuality(o.optString("quality",""));b.availableMarkets=o.optInt("availableMarkets",0);JSONArray s=o.optJSONArray("selections");if(s!=null)for(int j=0;j<s.length();j++){JSONObject x=s.getJSONObject(j);b.selections.add(new Selection(x.optString("market"),x.optString("pick"),x.optInt("probability"),x.optInt("sample"),x.optString("confidence"),x.optString("detail","")));}if(b.availableMarkets==0){HashSet<String> mk=new HashSet<>();for(Selection x:b.selections)if(!"Dupla chance".equals(x.market))mk.add(x.market);b.availableMarkets=mk.size();}out.add(b);}}catch(Exception ignored){}return out;}
 int blockCount(){return all().size();}
 int selectionCount(){int n=0;for(Block b:all())n+=b.selections.size();return n;}
 void clear(){sp.edit().remove("blocks").apply();}

 int add(ApiClient.Game g,ApiClient.Prediction p,ApiClient.DeepAnalysis d,String mode){
  if(g==null)return 0;
  Block b=new Block();b.key=key(g);b.home=g.home;b.away=g.away;b.league=g.league==null?"":g.league;b.kickoff=g.time==null?"":g.time;b.mode=mode==null?"COMPLETO":mode;
  b.baseSample=d==null?0:(d.homeMatches+d.awayMatches+d.h2hMatches);
  b.coverage=coverage(d);b.availableMarkets=marketCount(d);b.quality=dataQuality(b.coverage,b.baseSample);
  ArrayList<Selection> candidates=new ArrayList<>();

  // Double chance remains only one possible market. The raw 1X2 sum is shrunk toward 50%
  // and capped so the app never displays artificial 90/100% certainty.
  if(p!=null){
   int hp=p.home+p.draw,ap=p.away+p.draw;boolean home=hp>=ap;int raw=home?hp:ap;
   int pr=calibrate(raw,b.baseSample,true);String pick=home?g.home+" ou empate":"Empate ou "+g.away;
   if(pr>=thresholdResult(b.mode))candidates.add(new Selection("Dupla chance",pick,pr,b.baseSample,confidence(pr,b.baseSample),"Modelo 1X2 calibrado • sem garantia"));
  }

  if(d!=null){
   String[] order={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};
   for(String name:order){
    ApiClient.MetricProjection m=d.metrics.get(name);if(m==null||m.line<=0||m.overProb<0||m.sample<minSample(b.mode))continue;
    int rawOver=m.overProb,rawUnder=100-rawOver;boolean useOver=rawOver>=rawUnder;int raw=Math.max(rawOver,rawUnder);double line=m.line;
    if(m.lineHigh>0&&m.overProbHigh>=0){int oh=m.overProbHigh,uh=100-oh;int bestHigh=Math.max(oh,uh);if(bestHigh>raw+4){useOver=oh>=uh;raw=bestHigh;line=m.lineHigh;}}
    int pr=calibrate(raw,m.sample,false);if(pr<thresholdEvent(b.mode))continue;
    String pick=(useOver?"Mais de ":"Menos de ")+fmt(line)+" "+marketUnit(name);
    String detail="Projeção "+fmt(m.total)+" • faixa "+fmt(m.low)+"–"+fmt(m.high)+(m.source==null||m.source.isEmpty()?"":" • fonte "+m.source);
    candidates.add(new Selection(name,pick,pr,m.sample,confidence(pr,m.sample),detail));
   }
  }

  // Complete keeps every supported market. Equilibrado/Enxuto keep only the strongest,
  // so the three modes really behave differently.
  Collections.sort(candidates,(x,y)->{int c=Integer.compare(y.probability,x.probability);if(c!=0)return c;return Integer.compare(y.sample,x.sample);});
  int max="ENXUTO".equals(b.mode)?3:("EQUILIBRADO".equals(b.mode)?6:12);
  for(int i=0;i<Math.min(max,candidates.size());i++)b.selections.add(candidates.get(i));

  ArrayList<Block> blocks=all();for(Iterator<Block> it=blocks.iterator();it.hasNext();){Block old=it.next();if(java.util.Objects.equals(old.key,b.key))it.remove();}
  if(!b.selections.isEmpty())blocks.add(b);
  return save(blocks)?b.selections.size():-1;
 }

 int addSport(MultiSportClient.Event e,String sport,MultiSportWebClient.Research r,String mode){return addSportInternal(e,sport,r,mode,false);}
 int addSportMulti(MultiSportClient.Event e,String sport,MultiSportWebClient.Research r,String mode){return addSportInternal(e,sport,r,mode,true);}
 private int addSportInternal(MultiSportClient.Event e,String sport,MultiSportWebClient.Research r,String mode,boolean multi){
  if(e==null)return 0;
  SportTicketEngine.Result result=multi?SportTicketEngine.buildForMulti(sport,e,r,mode):SportTicketEngine.build(sport,e,r,mode);
  if(result==null||result.picks.isEmpty())return 0;
  Block b=new Block();b.key="sport|"+sport+"|"+e.id+"|"+e.home+"|"+e.away+"|"+e.date+"|"+e.time;b.home=e.home;b.away=e.away;b.league=e.competition==null?"":e.competition;b.kickoff=e.when();b.mode=mode==null?SportTicketEngine.CONSERVADOR:mode;b.sport=sport==null?"sport":sport;b.baseSample=result.sample;b.coverage=result.coverage;b.availableMarkets=result.picks.size();b.quality=result.quality;
  for(SportTicketEngine.Pick x:result.picks)b.selections.add(new Selection(x.market,x.pick,x.confidence,x.sample,x.risk,x.detail));
  ArrayList<Block> blocks=all();for(Iterator<Block> it=blocks.iterator();it.hasNext();){Block old=it.next();if(java.util.Objects.equals(old.key,b.key))it.remove();}blocks.add(b);
  return save(blocks)?b.selections.size():-1;
 }
 private boolean save(ArrayList<Block> blocks){try{JSONArray a=new JSONArray();for(Block b:blocks){JSONObject o=new JSONObject();o.put("key",b.key);o.put("home",b.home);o.put("away",b.away);o.put("league",b.league);o.put("kickoff",b.kickoff);o.put("mode",b.mode);o.put("sport",b.sport);o.put("coverage",b.coverage);o.put("baseSample",b.baseSample);o.put("quality",b.quality);o.put("availableMarkets",b.availableMarkets);JSONArray s=new JSONArray();for(Selection x:b.selections){JSONObject q=new JSONObject();q.put("market",x.market);q.put("pick",x.pick);q.put("probability",x.probability);q.put("sample",x.sample);q.put("confidence",x.confidence);q.put("detail",x.detail);s.put(q);}o.put("selections",s);a.put(o);}return sp.edit().putString("blocks",a.toString()).commit();}catch(Exception ignored){return false;}}

 String copyText(){
  ArrayList<Block> blocks=all();StringBuilder s=new StringBuilder("J.PASTORE AI • BILHETE PARA REVISÃO\n");s.append(blocks.size()).append(" confrontos • ").append(selectionCount()).append(" seleções\n\n");
  int i=1,totalProb=0,totalSel=0;
  for(Block b:blocks){
   s.append(i++).append(") ").append(b.home).append(" × ").append(b.away);if(!b.league.isEmpty())s.append(" • ").append(b.league);s.append("\n");
   s.append("Base: ").append(b.baseSample>0?b.baseSample+" jogos/eventos relevantes":"limitada").append(" • cobertura: ").append(b.coverage).append("% • mercados sugeridos: ").append(b.availableMarkets).append(" • ").append(b.quality).append(" • modo ").append(b.mode);if(b.sport!=null&&!"football".equals(b.sport))s.append(" • ").append(MultiSportClient.label(b.sport));s.append("\n");
   for(Selection x:b.selections){
    totalProb+=x.probability;totalSel++;
    s.append("• ").append(x.pick).append("\n");
    if(x.detail!=null&&!x.detail.isEmpty())s.append("  ").append(x.detail).append(" • ");else s.append("  ");
    if(b.sport!=null&&!"football".equals(b.sport))s.append("índice IA ").append(x.probability).append("% • ").append(x.confidence);else s.append("estimativa ").append(x.probability).append("% • cotação justa estimada ~").append(odd(x.probability)).append(" • ").append(x.confidence);
    if(x.sample>0)s.append(" • amostra ").append(x.sample);s.append("\n");
   }
   s.append("\n");
  }
  if(totalSel>0)s.append("Índice médio das seleções: ").append(Math.round(totalProb/(float)totalSel)).append("%. Isso NÃO é probabilidade conjunta do bilhete; mercados podem ser correlacionados.\n\n");
  s.append("Estimativas estatísticas da J.Pastore AI. Revise as linhas e as cotações reais na plataforma antes de qualquer decisão. Não há garantia de resultado.");return s.toString();
 }
 static String key(ApiClient.Game g){return g.fixtureId+"|"+g.home+"|"+g.away+"|"+(g.time==null?"":g.time);}
 static int coverage(ApiClient.DeepAnalysis d){return ApiClient.coveragePercent(d);}
 static String dataQuality(int coverage,int sample){if(coverage>=80&&sample>=8)return "COBERTURA FORTE";if(coverage>=50&&sample>=5)return "COBERTURA MODERADA";return "COBERTURA LIMITADA";}
 static String normalizeQuality(String q){if(q==null)return "";if(q.contains("AMOSTRA LIMITADA"))return "COBERTURA LIMITADA";if(q.contains("DADOS FORTES"))return "COBERTURA FORTE";if(q.contains("DADOS MODERADOS"))return "COBERTURA MODERADA";return q;}
 static int marketCount(ApiClient.DeepAnalysis d){if(d==null)return 0;String[] core={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};int n=0;for(String k:core)if(d.metrics.get(k)!=null)n++;return n;}
 static int thresholdResult(String mode){return "ENXUTO".equals(mode)?68:("EQUILIBRADO".equals(mode)?63:59);}
 static int thresholdEvent(String mode){return "ENXUTO".equals(mode)?68:("EQUILIBRADO".equals(mode)?62:56);}
 static int minSample(String mode){return "ENXUTO".equals(mode)?6:("EQUILIBRADO".equals(mode)?4:3);}
 static int calibrate(int raw,int sample,boolean resultMarket){double rel;if(sample<=0)rel=resultMarket?.48:.40;else rel=Math.min(.88,.48+sample*.04);int v=(int)Math.round(50+(raw-50)*rel);int cap=resultMarket?86:88;return Math.max(51,Math.min(cap,v));}
 static String confidence(int p,int sample){if(p>=72&&sample>=6)return "FAVORÁVEL";if(p>=60&&(sample>=3||sample==0))return "ATENÇÃO";return "DUVIDOSO";}
 static String fmt(double x){return String.format(new Locale("pt","BR"),"%.1f",x);}
 static String odd(int p){if(p<=0)return "—";return String.format(new Locale("pt","BR"),"%.2f",100.0/p);}
 static String marketUnit(String n){if("Gols".equals(n))return "gols";if("Escanteios".equals(n))return "escanteios";if("Laterais".equals(n))return "laterais";if("Tiros de meta".equals(n))return "tiros de meta";if("Faltas".equals(n))return "faltas";if("Finalizações".equals(n))return "finalizações";if("Chutes no alvo".equals(n))return "chutes no alvo";if("Impedimentos".equals(n))return "impedimentos";if("Cartões amarelos".equals(n))return "cartões amarelos";if("Tiros livres".equals(n))return "tiros livres";return n.toLowerCase(Locale.ROOT);}
}
