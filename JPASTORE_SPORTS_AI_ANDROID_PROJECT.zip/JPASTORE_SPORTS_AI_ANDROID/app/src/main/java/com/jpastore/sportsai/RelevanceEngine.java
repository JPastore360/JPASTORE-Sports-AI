package com.jpastore.sportsai;

import java.text.Normalizer;
import java.util.*;

public class RelevanceEngine {
    private static final String[] GIANTS = {
            "corinthians","flamengo","palmeiras","sao paulo","santos","vasco","botafogo","fluminense","gremio","internacional","cruzeiro","atletico mineiro","atletico-mg",
            "real madrid","barcelona","atletico madrid","arsenal","liverpool","manchester city","manchester united","chelsea","tottenham","bayern","borussia dortmund",
            "paris saint germain","psg","juventus","milan","inter","napoli","roma","benfica","porto","ajax","sporting","galatasaray","fenerbahce"
    };
    private static final String[] STRONG = {
            "athletico paranaense","bahia","fortaleza","bragantino","vitoria","sport recife","ceara",
            "newcastle","aston villa","west ham","everton","leverkusen","rb leipzig","sevilla","villarreal","real sociedad","athletic club",
            "lazio","atalanta","fiorentina","marseille","lyon","monaco","psv","feyenoord","olympiacos"
    };

    public static int score(String home, String away, String league, String country) {
        int score = Math.max(teamScore(home), teamScore(away));
        score += leagueScore(league, country);
        if (teamScore(home) >= 70 && teamScore(away) >= 70) score += 25;
        return Math.min(200, score);
    }

    public static boolean isFamous(String name) { return teamScore(name) >= 70; }

    private static int teamScore(String name) {
        String n = norm(name);
        for (String s : GIANTS) if (n.contains(s)) return 90;
        for (String s : STRONG) if (n.contains(s)) return 62;
        return 25;
    }

    private static int leagueScore(String league, String country) {
        String n = norm((league == null ? "" : league) + " " + (country == null ? "" : country));
        if (n.contains("copa libertadores") || n.contains("libertadores")) return 45;
        if (n.contains("champions league")) return 48;
        if (n.contains("brasileirao") || n.contains("serie a") && n.contains("brazil")) return 42;
        if (n.contains("copa do brasil")) return 40;
        if (n.contains("premier league")) return 42;
        if (n.contains("la liga")) return 42;
        if (n.contains("bundesliga")) return 38;
        if (n.contains("serie a") && (n.contains("italy") || n.contains("italia"))) return 38;
        if (n.contains("ligue 1")) return 34;
        if (n.contains("europa league")) return 36;
        if (n.contains("sudamericana") || n.contains("sul-americana")) return 34;
        return 10;
    }

    private static String norm(String s) {
        if (s == null) return "";
        String x = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return x.toLowerCase(Locale.ROOT).replace('-', ' ').trim();
    }
}
