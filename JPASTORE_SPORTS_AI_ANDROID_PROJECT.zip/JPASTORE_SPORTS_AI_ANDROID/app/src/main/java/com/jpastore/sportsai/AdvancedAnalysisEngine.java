package com.jpastore.sportsai;

import java.util.*;

public class AdvancedAnalysisEngine {
    private AdvancedAnalysisEngine() {}

    public static AdvancedAnalysis build(Game game,
                                         int homePct, int drawPct, int awayPct,
                                         int formH, int formA, int attH, int attA,
                                         int defH, int defA, int poissonH, int poissonA,
                                         int h2hH, int h2hA, int goalsH, int goalsA,
                                         double recentForH, double recentAgainstH,
                                         double recentForA, double recentAgainstA,
                                         String winner, String underOver, String advice,
                                         List<AdvancedAnalysis.Market> oddsMarkets) {

        int max = Math.max(homePct, Math.max(drawPct, awayPct));
        int second = homePct + drawPct + awayPct - max - Math.min(homePct, Math.min(drawPct, awayPct));
        int margin = Math.max(0, max - second);

        int comparisonCompleteness = completeness(formH, formA, attH, attA, defH, defA, poissonH, poissonA, h2hH, h2hA);
        int agreement = directionalAgreement(homePct, awayPct, formH, formA, attH, attA, poissonH, poissonA, h2hH, h2hA);
        int confidence = clamp((int)Math.round(0.58 * max + 0.18 * margin + 0.14 * agreement + 0.10 * comparisonCompleteness), 38, 92);

        double recentEnv = positiveAverage(recentForH, recentAgainstH, recentForA, recentAgainstA);
        if (recentEnv <= 0.01) recentEnv = 1.30;
        double totalGoals = inferTotalGoals(underOver, recentEnv);
        double homeWeight = 0.50 + (homePct - awayPct) / 230.0 + (attH - attA) / 500.0;
        homeWeight = clampD(homeWeight, 0.25, 0.75);
        double expHome = totalGoals * homeWeight;
        double expAway = totalGoals - expHome;

        List<AdvancedAnalysis.Market> markets = new ArrayList<>();
        markets.add(new AdvancedAnalysis.Market("Resultado 1X2", resultSelection(game, homePct, drawPct, awayPct), max, confidence, "API-Football + consenso do modelo", "Probabilidade base ajustada por consistência dos indicadores."));

        int dcHome = clamp(homePct + drawPct, 1, 99);
        int dcAway = clamp(awayPct + drawPct, 1, 99);
        if (dcHome >= dcAway) markets.add(new AdvancedAnalysis.Market("Dupla chance", game.home + " ou empate", dcHome, Math.min(90, confidence + 8), "Derivado de 1X2", "Soma das probabilidades de mandante e empate."));
        else markets.add(new AdvancedAnalysis.Market("Dupla chance", game.away + " ou empate", dcAway, Math.min(90, confidence + 8), "Derivado de 1X2", "Soma das probabilidades de visitante e empate."));

        int over15 = poissonOver(totalGoals, 1.5);
        int over25 = poissonOver(totalGoals, 2.5);
        int under35 = 100 - poissonOver(totalGoals, 3.5);
        int btts = clamp((int)Math.round((1 - Math.exp(-expHome)) * (1 - Math.exp(-expAway)) * 100), 8, 90);
        markets.add(new AdvancedAnalysis.Market("Gols", "Mais de 1.5 gols", over15, marketConfidence(comparisonCompleteness, 76), "Modelo Poisson local", fmtGoals(expHome, expAway)));
        markets.add(new AdvancedAnalysis.Market("Gols", "Mais de 2.5 gols", over25, marketConfidence(comparisonCompleteness, 70), "Modelo Poisson local", "Total esperado ≈ " + one(totalGoals) + " gols."));
        markets.add(new AdvancedAnalysis.Market("Gols", "Menos de 3.5 gols", under35, marketConfidence(comparisonCompleteness, 72), "Modelo Poisson local", "Faixa calculada a partir de forma, ataque e previsão de gols."));
        markets.add(new AdvancedAnalysis.Market("Ambas marcam", "Sim", btts, marketConfidence(comparisonCompleteness, 67), "Modelo Poisson local", "Usa gols esperados estimados para cada equipe."));

        double openness = clampD((recentEnv - 1.05) / 0.75, 0.0, 1.0);
        double balance = 1.0 - Math.min(1.0, Math.abs(homePct - awayPct) / 55.0);
        double cornerMean = 8.9 + 1.3 * openness + 0.7 * balance;
        double shotMean = 20.5 + 5.3 * openness + 1.8 * balance;
        double sotMean = 6.7 + 2.5 * openness + 0.8 * balance;
        double cardMean = 4.0 + 0.9 * balance + 0.35 * (1.0 - openness);
        double foulMean = 22.0 + 2.0 * balance + 0.7 * cardMean;
        double throwMean = 32.5 + 3.0 * (1.0 - openness) + 1.2 * balance;
        double offsideMean = 3.2 + 1.2 * openness;

        addCount(markets, "Escanteios", "Mais de 8.5 escanteios", cornerMean, 8.5, 58, "Estimativa IA estatística", "Média projetada ≈ " + one(cornerMean) + ". Mercado melhora quando odds específicas estão disponíveis.");
        addCount(markets, "Escanteios", "Mais de 9.5 escanteios", cornerMean, 9.5, 55, "Estimativa IA estatística", "Linha alternativa para perfil de jogo ofensivo/equilibrado.");
        addCount(markets, "Cartões", "Mais de 3.5 cartões", cardMean, 3.5, 52, "Estimativa IA estatística", "Sem árbitro confirmado, a confiança é reduzida.");
        addCount(markets, "Cartões", "Mais de 4.5 cartões", cardMean, 4.5, 49, "Estimativa IA estatística", "Indicador de risco disciplinar, não dado oficial pré-jogo.");
        addCount(markets, "Chutes", "Mais de 19.5 chutes", shotMean, 19.5, 54, "Estimativa IA estatística", "Projeção de volume total de finalizações.");
        addCount(markets, "Chutes no alvo", "Mais de 6.5 no alvo", sotMean, 6.5, 53, "Estimativa IA estatística", "Projeção total das duas equipes.");
        addCount(markets, "Faltas", "Mais de 21.5 faltas", foulMean, 21.5, 48, "Estimativa IA estatística", "Mercado sensível ao árbitro e ao contexto do jogo.");
        addCount(markets, "Laterais", "Mais de 31.5 laterais", throwMean, 31.5, 46, "Estimativa IA estatística", "Estimativa de arremessos laterais; cobertura varia muito entre competições.");
        addCount(markets, "Impedimentos", "Mais de 2.5 impedimentos", offsideMean, 2.5, 48, "Estimativa IA estatística", "Derivado do ritmo e agressividade ofensiva estimados.");

        boolean oddsUsed = oddsMarkets != null && !oddsMarkets.isEmpty();
        if (oddsUsed) mergeOdds(markets, oddsMarkets);
        sortMarkets(markets);

        String summary = buildSummary(game, homePct, drawPct, awayPct, formH, formA, attH, attA, defH, defA, poissonH, poissonA, h2hH, h2hA, totalGoals, confidence, markets, oddsUsed);
        String quality = comparisonCompleteness >= 80 ? "ALTA" : (comparisonCompleteness >= 55 ? "MÉDIA" : "LIMITADA");

        return new AdvancedAnalysis(homePct, drawPct, awayPct, confidence,
                formH, formA, attH, attA, defH, defA, poissonH, poissonA, h2hH, h2hA, goalsH, goalsA,
                expHome, expAway, winner, underOver, advice, summary, quality, oddsUsed, markets);
    }

    private static void mergeOdds(List<AdvancedAnalysis.Market> base, List<AdvancedAnalysis.Market> odds) {
        for (AdvancedAnalysis.Market om : odds) {
            boolean replaced = false;
            for (int i = 0; i < base.size(); i++) {
                AdvancedAnalysis.Market bm = base.get(i);
                if (sameMarket(bm.category, om.category) && similarSelection(bm.selection, om.selection)) {
                    base.set(i, om);
                    replaced = true;
                    break;
                }
            }
            if (!replaced) base.add(om);
        }
    }

    private static boolean sameMarket(String a, String b) { return norm(a).equals(norm(b)); }
    private static boolean similarSelection(String a, String b) {
        String na = norm(a), nb = norm(b);
        if (na.equals(nb)) return true;
        String la = numericLine(na), lb = numericLine(nb);
        return !la.isEmpty() && la.equals(lb) && ((na.contains("mais") && nb.contains("over")) || (na.contains("menos") && nb.contains("under")));
    }

    private static String numericLine(String s) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+(?:[.,]\\d+)?)").matcher(s);
        return m.find() ? m.group(1).replace(',', '.') : "";
    }

    private static String norm(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT); }

    private static void sortMarkets(List<AdvancedAnalysis.Market> markets) {
        Collections.sort(markets, (a, b) -> {
            int c = Integer.compare(categoryOrder(a.category), categoryOrder(b.category));
            if (c != 0) return c;
            return Integer.compare(b.probability, a.probability);
        });
    }

    private static int categoryOrder(String c) {
        String n = norm(c);
        if (n.contains("resultado")) return 1;
        if (n.contains("dupla")) return 2;
        if (n.contains("gol")) return 3;
        if (n.contains("ambas")) return 4;
        if (n.contains("escante")) return 5;
        if (n.contains("cart")) return 6;
        if (n.contains("chute")) return 7;
        if (n.contains("falta")) return 8;
        if (n.contains("later")) return 9;
        if (n.contains("imped")) return 10;
        return 20;
    }

    private static String buildSummary(Game g, int hp, int dp, int ap, int fH, int fA, int aH, int aA, int dH, int dA, int pH, int pA, int hH, int hA, double tg, int conf, List<AdvancedAnalysis.Market> markets, boolean oddsUsed) {
        String leader = hp >= ap && hp >= dp ? g.home : (ap >= hp && ap >= dp ? g.away : "empate");
        String edge = Math.abs(hp - ap) >= 18 ? "vantagem estatística clara" : (Math.abs(hp - ap) >= 8 ? "vantagem moderada" : "confronto equilibrado");
        String form = fH > 0 && fA > 0 ? (fH >= fA ? g.home + " chega com melhor índice de forma" : g.away + " chega com melhor índice de forma") : "a forma recente não está completa para ambos";
        String attack = aH > 0 && aA > 0 ? (aH >= aA ? g.home + " tem vantagem ofensiva" : g.away + " tem vantagem ofensiva") : "o dado ofensivo está parcial";
        String defensive = dH > 0 && dA > 0 ? (dH >= dA ? g.home + " apresenta melhor comparação defensiva" : g.away + " apresenta melhor comparação defensiva") : "a comparação defensiva está parcial";
        AdvancedAnalysis.Market best = null;
        for (AdvancedAnalysis.Market m : markets) {
            if (best == null || (m.confidence + m.probability) > (best.confidence + best.probability)) best = m;
        }
        String bestText = best == null ? "sem mercado destacado" : best.selection + " (" + best.probability + "%)";
        return "A IA estatística identifica " + edge + " com maior peso para " + leader + ". " +
                cap(form) + "; " + attack + "; " + defensive + ". " +
                "O modelo projeta cerca de " + one(tg) + " gols no confronto. " +
                "Sinal de maior consistência agora: " + bestText + ". " +
                (oddsUsed ? "As odds disponíveis foram usadas para recalibrar alguns mercados. " : "Sem odds específicas disponíveis, mercados avançados usam estimativa do modelo. ") +
                "Confiança global da leitura: " + conf + "%.";
    }

    private static String cap(String s) { return s == null || s.isEmpty() ? "" : Character.toUpperCase(s.charAt(0)) + s.substring(1); }
    private static String resultSelection(Game g, int h, int d, int a) {
        if (h >= d && h >= a) return g.home;
        if (a >= h && a >= d) return g.away;
        return "Empate";
    }

    private static String fmtGoals(double h, double a) { return "Gols esperados estimados: " + one(h) + " × " + one(a) + "."; }
    private static String one(double d) { return String.format(Locale.US, "%.1f", d).replace('.', ','); }

    private static int marketConfidence(int completeness, int base) { return clamp((int)Math.round(base * 0.72 + completeness * 0.28), 42, 86); }

    private static void addCount(List<AdvancedAnalysis.Market> markets, String category, String selection, double mean, double line, int confidence, String source, String note) {
        int p = poissonOver(mean, line);
        markets.add(new AdvancedAnalysis.Market(category, selection, p, confidence, source, note));
    }

    public static int poissonOver(double lambda, double line) {
        int k = (int)Math.floor(line);
        double term = Math.exp(-lambda);
        double cumulative = term;
        for (int i = 1; i <= k; i++) {
            term *= lambda / i;
            cumulative += term;
        }
        return clamp((int)Math.round((1.0 - cumulative) * 100.0), 1, 99);
    }

    private static double inferTotalGoals(String underOver, double recentEnv) {
        double base = 2.55;
        if (underOver != null) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+(?:[.,]\\d+)?)").matcher(underOver);
            if (m.find()) {
                try {
                    double line = Double.parseDouble(m.group(1).replace(',', '.'));
                    String n = underOver.toLowerCase(Locale.ROOT);
                    boolean under = n.contains("under") || n.trim().startsWith("-");
                    boolean over = n.contains("over") || n.trim().startsWith("+");
                    if (under) base = line - 0.55;
                    else if (over) base = line + 0.35;
                    else base = line;
                } catch (Exception ignored) {}
            }
        }
        base = 0.72 * base + 0.28 * (recentEnv * 2.0);
        return clampD(base, 1.55, 4.25);
    }

    private static int directionalAgreement(int hp, int ap, int fH, int fA, int aH, int aA, int pH, int pA, int hH, int hA) {
        int dir = Integer.compare(hp, ap);
        if (dir == 0) return 50;
        int agree = 0, known = 0;
        int[][] pairs = {{fH,fA},{aH,aA},{pH,pA},{hH,hA}};
        for (int[] x : pairs) {
            if (x[0] <= 0 && x[1] <= 0) continue;
            known++;
            if (Integer.compare(x[0], x[1]) == dir) agree++;
        }
        return known == 0 ? 50 : (int)Math.round(100.0 * agree / known);
    }

    private static int completeness(int... values) {
        int known = 0;
        for (int v : values) if (v > 0) known++;
        return (int)Math.round(100.0 * known / values.length);
    }

    private static double positiveAverage(double... vals) {
        double s = 0; int n = 0;
        for (double v : vals) if (v > 0) { s += v; n++; }
        return n == 0 ? 0 : s / n;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static double clampD(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}
