package com.jpastore.sportsai;

public class AnalysisEngine {
    public static Result evaluate(int home, int draw, int away) {
        int max = Math.max(home, Math.max(draw, away));
        int min = Math.min(home, Math.min(draw, away));
        int second = home + draw + away - max - min;
        int margin = Math.max(0, max - second);
        double concentration = (home * home + draw * draw + away * away) / 10000.0;
        int consistency = (int)Math.round(Math.min(100, 35 + margin * 1.25 + concentration * 30));
        int confidence = (int)Math.round(max * 0.70 + consistency * 0.30);
        confidence = Math.max(1, Math.min(99, confidence));

        String trend;
        String pick;
        if (max == home) {
            trend = "Tendência: mandante";
            pick = "Mandante";
        } else if (max == away) {
            trend = "Tendência: visitante";
            pick = "Visitante";
        } else {
            trend = "Tendência: equilíbrio/empate";
            pick = "Empate";
        }

        String riskBand = confidence >= 70 ? "alta confiança" : (confidence >= 55 ? "confiança moderada" : "cenário arriscado");
        String reason = "Análise 1: maior probabilidade em " + max + "%. Análise 2: consistência de " + consistency +
                "% baseada na distância entre cenários e na concentração das probabilidades. Resultado final: " + riskBand + ".";
        return new Result(confidence, trend, reason, pick);
    }

    public static class Result {
        public final int confidence;
        public final String trend, reason, pick;
        Result(int c, String t, String r, String p) {
            confidence = c;
            trend = t;
            reason = r;
            pick = p;
        }
    }
}
