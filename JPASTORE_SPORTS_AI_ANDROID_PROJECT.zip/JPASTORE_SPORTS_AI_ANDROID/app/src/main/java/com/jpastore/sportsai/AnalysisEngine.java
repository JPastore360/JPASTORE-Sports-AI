package com.jpastore.sportsai;

import java.util.*;

public class AnalysisEngine {
    public static void finalizeDeepAnalysis(DeepAnalysis d) {
        int max = Math.max(d.homePct, Math.max(d.drawPct, d.awayPct));
        int min = Math.min(d.homePct, Math.min(d.drawPct, d.awayPct));
        int second = d.homePct + d.drawPct + d.awayPct - max - min;
        int margin = Math.max(0, max - second);

        int comparisonEdge = Math.abs(d.comparisonTotalHome - d.comparisonTotalAway);
        int profileSupport = profileSupport(d.homeProfile, d.awayProfile);
        int consistency = clamp(35 + (int)Math.round(margin * 1.15) + comparisonEdge / 3 + profileSupport / 8, 25, 95);
        d.confidence = clamp((int)Math.round(max * 0.72 + consistency * 0.28), 30, 94);

        if (max == d.homePct) {
            d.primaryPick = "Mandante";
            d.trend = d.homePct - d.awayPct >= 18 ? "Vantagem clara do mandante" : "Leve vantagem do mandante";
        } else if (max == d.awayPct) {
            d.primaryPick = "Visitante";
            d.trend = d.awayPct - d.homePct >= 18 ? "Vantagem clara do visitante" : "Leve vantagem do visitante";
        } else {
            d.primaryPick = "Empate / equilíbrio";
            d.trend = "Confronto equilibrado";
        }

        d.markets.clear();
        addResultMarkets(d);
        addGoalMarkets(d);
        addBttsMarket(d);
        addCornerMarket(d);
        addCardMarket(d);
        addThrowinMarket(d);
        addShotsMarket(d);

        int sources = 1;
        if (d.homeProfile.hasUsefulData()) sources++;
        if (d.awayProfile.hasUsefulData()) sources++;
        if (d.comparisonTotalHome > 0 || d.comparisonTotalAway > 0) sources++;
        d.dataQuality = sources >= 4 ? "Dados fortes: previsão + comparação + estatísticas de temporada" :
                (sources >= 2 ? "Dados moderados: parte da análise usa estimativas locais" : "Dados limitados: sinais locais com cautela");

        String edge = Math.abs(d.comparisonTotalHome - d.comparisonTotalAway) >= 15 ? "há diferença relevante de força entre as equipes" : "o confronto tem forças relativamente próximas";
        String goals = goalReading(d);
        String cards = cardReading(d);
        d.modelReading = "O modelo combina a previsão da API com força de ataque/defesa, forma, desempenho de temporada e regras locais de consistência. " +
                "Neste jogo, " + edge + ". " + goals + " " + cards +
                " Escanteios e laterais são estimativas do modelo quando a fonte não oferece média pré-jogo direta para o confronto.";
    }

    private static void addResultMarkets(DeepAnalysis d) {
        int max = Math.max(d.homePct, Math.max(d.drawPct, d.awayPct));
        String result = d.primaryPick;
        d.markets.add(new DeepAnalysis.MarketSignal("Resultado", result, d.confidence, "API + modelo local"));

        if (d.homePct >= d.awayPct) {
            int dc = clamp(d.homePct + d.drawPct - 8, 45, 92);
            d.markets.add(new DeepAnalysis.MarketSignal("Dupla chance", "1X (mandante ou empate)", dc, "Probabilidades combinadas"));
        } else {
            int dc = clamp(d.awayPct + d.drawPct - 8, 45, 92);
            d.markets.add(new DeepAnalysis.MarketSignal("Dupla chance", "X2 (empate ou visitante)", dc, "Probabilidades combinadas"));
        }
    }

    private static void addGoalMarkets(DeepAnalysis d) {
        String api = safe(d.apiUnderOver);
        double expected = expectedGoals(d);
        String signal;
        int conf;
        if (!api.isEmpty()) {
            signal = api;
            conf = clamp(58 + (int)Math.round(Math.abs(expected - 2.5) * 10), 55, 84);
        } else if (expected >= 2.85) {
            signal = "Mais de 2.5 gols";
            conf = clamp(58 + (int)((expected - 2.5) * 12), 55, 82);
        } else if (expected >= 2.05) {
            signal = "Mais de 1.5 gols";
            conf = 68;
        } else {
            signal = "Menos de 3.5 gols";
            conf = 64;
        }
        d.markets.add(new DeepAnalysis.MarketSignal("Gols", signal, conf, !api.isEmpty() ? "Previsão API" : "Modelo local"));
    }

    private static void addBttsMarket(DeepAnalysis d) {
        double hgf = positive(d.homeProfile.goalsForAvg, 1.25);
        double hga = positive(d.homeProfile.goalsAgainstAvg, 1.15);
        double agf = positive(d.awayProfile.goalsForAvg, 1.20);
        double aga = positive(d.awayProfile.goalsAgainstAvg, 1.20);
        double score = (hgf + agf + hga + aga) / 4.0;
        boolean yes = score >= 1.18 && d.homePct < 70 && d.awayPct < 70;
        int conf = clamp((int)Math.round(54 + Math.abs(score - 1.18) * 24), 52, 78);
        d.markets.add(new DeepAnalysis.MarketSignal("Ambas marcam", yes ? "Sim" : "Não / sem sinal forte", conf, "Gols pró/contra + equilíbrio"));
    }

    private static void addCornerMarket(DeepAnalysis d) {
        double attack = (positivePct(d.attackHome, 50) + positivePct(d.attackAway, 50)) / 2.0;
        double form = (positivePct(d.formHome, 50) + positivePct(d.formAway, 50)) / 2.0;
        double expected = 8.4 + (attack - 50.0) / 13.0 + (form - 50.0) / 35.0;
        expected = Math.max(7.0, Math.min(12.5, expected));
        String signal;
        if (expected >= 9.7) signal = "Tendência de 9–12 escanteios";
        else if (expected <= 8.2) signal = "Tendência de 7–9 escanteios";
        else signal = "Faixa provável de 8–11 escanteios";
        int conf = clamp(52 + (int)Math.round(Math.abs(expected - 9.0) * 6), 50, 69);
        d.markets.add(new DeepAnalysis.MarketSignal("Escanteios", signal, conf, "Estimativa local de pressão ofensiva"));
    }

    private static void addCardMarket(DeepAnalysis d) {
        double hy = d.homeProfile.yellowCardsAvg;
        double ay = d.awayProfile.yellowCardsAvg;
        String signal;
        int conf;
        String source;
        if (hy >= 0 && ay >= 0) {
            double total = hy + ay;
            if (total >= 5.0) signal = "Jogo propenso a 5+ cartões";
            else if (total >= 3.6) signal = "Faixa provável de 4–6 cartões";
            else signal = "Tendência de até 4 cartões";
            conf = clamp(58 + (int)Math.round(Math.abs(total - 4.0) * 5), 55, 78);
            source = "Média de cartões na temporada";
        } else {
            int balance = 100 - Math.abs(d.comparisonTotalHome - d.comparisonTotalAway);
            signal = balance >= 85 ? "Partida equilibrada: atenção a 4–6 cartões" : "Sem sinal forte de cartões";
            conf = 48;
            source = "Estimativa local";
        }
        d.markets.add(new DeepAnalysis.MarketSignal("Cartões", signal, conf, source));
    }

    private static void addThrowinMarket(DeepAnalysis d) {
        int balance = 100 - Math.abs(positivePct(d.attackHome, 50) - positivePct(d.attackAway, 50));
        String signal = balance >= 78 ? "Faixa estimada de 34–46 laterais" : "Faixa estimada de 30–42 laterais";
        d.markets.add(new DeepAnalysis.MarketSignal("Laterais", signal, 45, "Estimativa contextual — baixa confiança"));
    }

    private static void addShotsMarket(DeepAnalysis d) {
        int attack = (positivePct(d.attackHome, 50) + positivePct(d.attackAway, 50)) / 2;
        String signal = attack >= 58 ? "Volume alto de finalizações" : (attack >= 47 ? "Volume médio de finalizações" : "Volume baixo/moderado de finalizações");
        d.markets.add(new DeepAnalysis.MarketSignal("Finalizações", signal, clamp(50 + Math.abs(attack - 50) / 2, 50, 72), "Força ofensiva comparada"));
    }

    private static int profileSupport(DeepAnalysis.TeamProfile a, DeepAnalysis.TeamProfile b) {
        int x = 0;
        if (a.played > 0) x += 15;
        if (b.played > 0) x += 15;
        if (a.goalsForAvg >= 0) x += 10;
        if (b.goalsForAvg >= 0) x += 10;
        if (a.yellowCardsAvg >= 0) x += 8;
        if (b.yellowCardsAvg >= 0) x += 8;
        return x;
    }

    private static double expectedGoals(DeepAnalysis d) {
        double api = parseNumber(d.predictedHomeGoals) + parseNumber(d.predictedAwayGoals);
        if (api > 0.2) return api;
        double h = positive(d.homeProfile.goalsForAvg, 1.25);
        double a = positive(d.awayProfile.goalsForAvg, 1.15);
        return h + a;
    }

    private static String goalReading(DeepAnalysis d) {
        double exp = expectedGoals(d);
        if (exp >= 2.8) return "O perfil aponta para uma partida com potencial ofensivo acima da média.";
        if (exp <= 2.0) return "O perfil sugere um jogo mais controlado e com menor expectativa de gols.";
        return "A expectativa de gols fica em uma faixa intermediária.";
    }

    private static String cardReading(DeepAnalysis d) {
        if (d.homeProfile.yellowCardsAvg >= 0 && d.awayProfile.yellowCardsAvg >= 0) {
            double total = d.homeProfile.yellowCardsAvg + d.awayProfile.yellowCardsAvg;
            if (total >= 4.8) return "As médias disciplinares indicam atenção especial ao mercado de cartões.";
        }
        return "Para cartões, o modelo usa dados de temporada quando disponíveis.";
    }

    private static double parseNumber(String s) {
        if (s == null) return 0;
        try { return Double.parseDouble(s.replace(',', '.').replaceAll("[^0-9.]", "")); }
        catch(Exception e) { return 0; }
    }

    private static double positive(double v, double fallback) { return v >= 0 ? v : fallback; }
    private static int positivePct(int v, int fallback) { return v > 0 ? v : fallback; }
    private static String safe(String s) { return s == null ? "" : s.trim(); }
    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
