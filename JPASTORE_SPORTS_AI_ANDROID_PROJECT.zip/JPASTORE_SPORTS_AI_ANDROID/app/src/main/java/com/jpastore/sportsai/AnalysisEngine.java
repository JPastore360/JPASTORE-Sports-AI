package com.jpastore.sportsai;

public class AnalysisEngine {
    public static Result evaluate(int home, int draw, int away) {
        int max = Math.max(home, Math.max(draw, away));
        int second = home + draw + away - max - Math.min(home, Math.min(draw, away));
        int margin = Math.max(0, max - second);
        double concentration = (home*home + draw*draw + away*away) / 10000.0;
        int consistency = (int)Math.round(Math.min(100, 35 + margin * 1.25 + concentration * 30));
        int confidence = (int)Math.round(max * 0.70 + consistency * 0.30);
        confidence = Math.max(1, Math.min(99, confidence));

        String trend;
        if (max == home) trend = "Tendência: mandante";
        else if (max == away) trend = "Tendência: visitante";
        else trend = "Tendência: equilíbrio/empate";

        String reason = "Análise 1: probabilidade-base " + max + "%.  Análise 2: consistência " + consistency +
                "%, considerando distância entre cenários e concentração das probabilidades.";
        return new Result(confidence, trend, reason);
    }
    public static class Result {
        public final int confidence; public final String trend, reason;
        Result(int c, String t, String r) { confidence=c; trend=t; reason=r; }
    }
}
