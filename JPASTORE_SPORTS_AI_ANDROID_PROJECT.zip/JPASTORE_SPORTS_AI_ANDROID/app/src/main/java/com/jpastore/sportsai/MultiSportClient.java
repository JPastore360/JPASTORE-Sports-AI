package com.jpastore.sportsai;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.function.Consumer;

/** API-Sports client for the non-football modules. Keeps each sport isolated and cache-aware. */
public class MultiSportClient {
    final Context c;
    MultiSportClient(Context c){this.c=c;}

    static final String FOOTBALL="football", BASKETBALL="basketball", NBA="nba", MMA="mma", F1="f1", NFL="nfl", BASEBALL="baseball";
    static final String[] MODULES={FOOTBALL,BASKETBALL,MMA,F1,NFL,BASEBALL};
    static final String[] SOURCES={FOOTBALL,BASKETBALL,NBA,MMA,F1,NFL,BASEBALL};

    static String label(String id){
        if(BASKETBALL.equals(id))return "Basquete";
        if(NBA.equals(id))return "NBA";
        if(MMA.equals(id))return "MMA";
        if(F1.equals(id))return "Fórmula 1";
        if(NFL.equals(id))return "NFL";
        if(BASEBALL.equals(id))return "Baseball";
        return "Futebol";
    }
    static String icon(String id){
        if(BASKETBALL.equals(id)||NBA.equals(id))return "🏀";
        if(MMA.equals(id))return "🥊";
        if(F1.equals(id))return "🏎";
        if(NFL.equals(id))return "🏈";
        if(BASEBALL.equals(id))return "⚾";
        return "⚽";
    }
    static String sourceTitle(String id){
        if(NBA.equals(id))return "API-NBA";
        if(BASKETBALL.equals(id))return "API-BASKETBALL";
        if(MMA.equals(id))return "API-MMA";
        if(F1.equals(id))return "API-FORMULA-1";
        if(NFL.equals(id))return "API-NFL & NCAA";
        if(BASEBALL.equals(id))return "API-BASEBALL";
        return "API-FOOTBALL";
    }
    static String base(String id){
        if(BASKETBALL.equals(id))return "https://v1.basketball.api-sports.io/";
        if(NBA.equals(id))return "https://v2.nba.api-sports.io/";
        if(MMA.equals(id))return "https://v1.mma.api-sports.io/";
        if(F1.equals(id))return "https://v1.formula-1.api-sports.io/";
        if(NFL.equals(id))return "https://v1.american-football.api-sports.io/";
        if(BASEBALL.equals(id))return "https://v1.baseball.api-sports.io/";
        return "https://v3.football.api-sports.io/";
    }

    static class ApiStatus {String plan="";int current=-1,limit=-1;boolean active=false;String text(){String p=plan==null||plan.isEmpty()?"Plano":plan;return current>=0&&limit>0?p+" • "+current+"/"+limit+" hoje":p+(active?" • ativo":"");}}

    static class Event {
        long id,homeId,awayId,leagueId;
        String sport="",apiSource="",competition="",season="",home="",away="",homeLogo="",awayLogo="",date="",time="",status="",score="",detail="";
        Event(String sport){this.sport=sport;this.apiSource=sport;}
        String when(){return (date==null?"":date)+(time==null||time.isEmpty()?"":" • "+time);}
        String matchup(){return away==null||away.trim().isEmpty()?home:home+" × "+away;}
    }

    String get(String source,String path,String key)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(base(source)+path).openConnection();
        h.setRequestProperty("x-apisports-key",key);h.setRequestProperty("Accept","application/json");
        h.setRequestProperty("User-Agent","J.Pastore-Sports-AI/5.6 Android");h.setConnectTimeout(7000);h.setReadTimeout(9000);
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();
        if(in==null)throw new IOException("HTTP "+code);
        BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s);
        if(code<200||code>=300)throw new IOException("HTTP "+code);
        JSONObject root=new JSONObject(b.toString());
        Object errors=root.opt("errors");
        if(errors instanceof JSONObject&&((JSONObject)errors).length()>0)throw new IOException("API recusou a consulta");
        if(errors instanceof JSONArray&&((JSONArray)errors).length()>0)throw new IOException("API recusou a consulta");
        return b.toString();
    }
    void test(String source,String key,Consumer<Boolean> cb){new Thread(()->{try{get(source,"status",key);cb.accept(true);}catch(Exception e){cb.accept(false);}}).start();}
    void status(String source,String key,Consumer<ApiStatus> ok,Consumer<String> err){new Thread(()->{try{JSONObject root=new JSONObject(get(source,"status",key));JSONObject r=root.optJSONObject("response");if(r==null)throw new IOException("Status indisponível");ApiStatus s=new ApiStatus();JSONObject sub=r.optJSONObject("subscription"),req=r.optJSONObject("requests");if(sub!=null){s.plan=sub.optString("plan","");s.active=sub.optBoolean("active",false);}if(req!=null){s.current=req.optInt("current",-1);s.limit=req.optInt("limit_day",-1);}ok.accept(s);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    void cachePut(String k,String v){c.getSharedPreferences("jp_multisport_cache",0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long age){android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_cache",0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=age?p.getString(k,null):null;}

    void events(String sport,String date,String key,String secondaryKey,Consumer<ArrayList<Event>> ok,Consumer<String> err){new Thread(()->{
        try{
            ArrayList<Event> out=new ArrayList<>();
            if(BASKETBALL.equals(sport)){
                if(key!=null&&!key.trim().isEmpty())out.addAll(load(BASKETBALL,date,key.trim()));
                if(secondaryKey!=null&&!secondaryKey.trim().isEmpty())out.addAll(load(NBA,date,secondaryKey.trim()));
                out=dedupe(out);
            }else{
                if(key==null||key.trim().isEmpty())throw new IOException("Configure "+sourceTitle(sport)+" em APIs & FONTES");
                out=load(sport,date,key.trim());
            }
            sort(out);ok.accept(out);
        }catch(Exception e){err.accept(e.getMessage()==null?"Dados indisponíveis":e.getMessage());}
    }).start();}

    ArrayList<Event> load(String source,String date,String key)throws Exception{
        String ck="v1_"+source+"_"+date;long ttl=6*60*1000L;if(F1.equals(source))ttl=6*60*60*1000L;
        String raw=cacheGet(ck,ttl);
        if(raw==null){
            String path;
            if(F1.equals(source)){String year=date!=null&&date.length()>=4?date.substring(0,4):String.valueOf(Calendar.getInstance().get(Calendar.YEAR));path="races?season="+year+"&type=Race";}
            else if(MMA.equals(source))path="fights?date="+date+"&timezone=America%2FSao_Paulo";
            else if(NBA.equals(source))path="games?date="+date;
            else path="games?date="+date+"&timezone=America%2FSao_Paulo";
            raw=get(source,path,key);cachePut(ck,raw);
        }
        JSONObject root=new JSONObject(raw);JSONArray a=root.optJSONArray("response");ArrayList<Event> out=new ArrayList<>();if(a==null)return out;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;Event e;
            if(F1.equals(source))e=parseF1(o,date);else if(MMA.equals(source))e=parseMma(o);else if(NBA.equals(source))e=parseNba(o);else if(NFL.equals(source))e=parseNfl(o);else e=parseGenericGame(source,o);
            if(e!=null)out.add(e);
        }
        if(F1.equals(source))out=selectF1(out,date);
        return out;
    }

    Event parseGenericGame(String sport,JSONObject o){
        Event e=new Event(sport);e.apiSource=sport;e.id=o.optLong("id",0);e.date=o.optString("date","");e.time=o.optString("time","");
        JSONObject st=o.optJSONObject("status");if(st!=null)e.status=first(st.optString("short",""),st.optString("long",""));
        JSONObject lg=o.optJSONObject("league");if(lg!=null){e.competition=lg.optString("name","");e.leagueId=lg.optLong("id",0);e.season=first(lg.optString("season",""),String.valueOf(lg.optInt("season",0)));if("0".equals(e.season))e.season="";}
        JSONObject teams=o.optJSONObject("teams");if(teams!=null){JSONObject h=teams.optJSONObject("home"),a=teams.optJSONObject("away");if(h!=null){e.homeId=h.optLong("id",0);e.home=h.optString("name","");e.homeLogo=h.optString("logo","");}if(a!=null){e.awayId=a.optLong("id",0);e.away=a.optString("name","");e.awayLogo=a.optString("logo","");}}
        JSONObject scores=o.optJSONObject("scores");if(scores!=null){String hs=scoreValue(scores.opt("home")),as=scoreValue(scores.opt("away"));if(!hs.isEmpty()||!as.isEmpty())e.score=emptyScore(hs)+" × "+emptyScore(as);}
        if(e.date!=null&&e.date.contains("T")){String[] z=localIso(e.date);e.date=z[0];e.time=z[1];}
        e.detail=sourceTitle(sport)+" • "+safe(e.competition,"Competição")+" • "+safe(e.status,"Status não informado");return e;
    }

    Event parseNba(JSONObject o){
        Event e=new Event(BASKETBALL);e.apiSource=NBA;e.id=o.optLong("id",0);e.competition="NBA • "+o.optString("league","standard");e.season=String.valueOf(o.optInt("season",0));if("0".equals(e.season))e.season="";
        JSONObject d=o.optJSONObject("date");if(d!=null){String[] z=localIso(d.optString("start",""));e.date=z[0];e.time=z[1];}
        JSONObject st=o.optJSONObject("status");if(st!=null)e.status=statusNba(st.optInt("short",0),st.optString("long",""));
        JSONObject teams=o.optJSONObject("teams");if(teams!=null){JSONObject h=teams.optJSONObject("home"),v=teams.optJSONObject("visitors");if(h!=null){e.homeId=h.optLong("id",0);e.home=h.optString("name","");e.homeLogo=h.optString("logo","");}if(v!=null){e.awayId=v.optLong("id",0);e.away=v.optString("name","");e.awayLogo=v.optString("logo","");}}
        JSONObject scores=o.optJSONObject("scores");if(scores!=null){JSONObject h=scores.optJSONObject("home"),v=scores.optJSONObject("visitors");String hs=h==null?"":numString(h.opt("points")),vs=v==null?"":numString(v.opt("points"));if(!hs.isEmpty()||!vs.isEmpty())e.score=emptyScore(hs)+" × "+emptyScore(vs);}
        e.detail="API-NBA • temporada "+o.optInt("season",0)+" • "+safe(e.status,"status não informado");return e;
    }

    Event parseNfl(JSONObject o){
        Event e=new Event(NFL);e.apiSource=NFL;JSONObject game=o.optJSONObject("game");if(game==null)game=o;e.id=game.optLong("id",0);JSONObject d=game.optJSONObject("date");if(d!=null){e.date=d.optString("date","");e.time=d.optString("time","");}JSONObject st=game.optJSONObject("status");if(st!=null)e.status=first(st.optString("short",""),st.optString("long",""));
        JSONObject lg=o.optJSONObject("league");if(lg!=null){e.competition=lg.optString("name","NFL")+(game.optString("week","").isEmpty()?"":" • "+game.optString("week"));e.leagueId=lg.optLong("id",0);e.season=first(lg.optString("season",""),String.valueOf(lg.optInt("season",0)));if("0".equals(e.season))e.season="";}
        JSONObject teams=o.optJSONObject("teams");if(teams!=null){JSONObject h=teams.optJSONObject("home"),a=teams.optJSONObject("away");if(h!=null){e.homeId=h.optLong("id",0);e.home=h.optString("name","");e.homeLogo=h.optString("logo","");}if(a!=null){e.awayId=a.optLong("id",0);e.away=a.optString("name","");e.awayLogo=a.optString("logo","");}}
        JSONObject scores=o.optJSONObject("scores");if(scores!=null){String hs=scoreValue(scores.opt("home")),as=scoreValue(scores.opt("away"));if(!hs.isEmpty()||!as.isEmpty())e.score=emptyScore(hs)+" × "+emptyScore(as);}
        e.detail="API-NFL • "+safe(game.optString("stage","") ,"temporada")+" • "+safe(e.status,"status não informado");return e;
    }

    Event parseMma(JSONObject o){
        Event e=new Event(MMA);e.apiSource=MMA;e.id=o.optLong("id",o.optLong("fight_id",0));e.date=first(o.optString("date",""),o.optString("fight_date",""));e.time=o.optString("time","");e.competition=first(o.optString("category",""),o.optString("event",""),o.optString("event_name",""),o.optString("promotion","MMA"));
        JSONObject st=o.optJSONObject("status");e.status=st==null?o.optString("status",""):first(st.optString("short",""),st.optString("long",""));
        JSONObject fs=o.optJSONObject("fighters");if(fs!=null){JSONObject f1=firstObj(fs,"first","home","fighter1"),f2=firstObj(fs,"second","away","fighter2");if(f1!=null){e.homeId=f1.optLong("id",0);e.home=f1.optString("name","");e.homeLogo=first(f1.optString("logo",""),f1.optString("photo",""));}if(f2!=null){e.awayId=f2.optLong("id",0);e.away=f2.optString("name","");e.awayLogo=first(f2.optString("logo",""),f2.optString("photo",""));}}
        if(e.home.isEmpty()){Object f1=o.opt("fighter1"),f2=o.opt("fighter2");e.home=nameValue(f1);e.away=nameValue(f2);}
        String winner=o.optString("winner","");String method=o.optString("method","");if(!winner.isEmpty())e.score="Vencedor: "+winner+(method.isEmpty()?"":" • "+method);
        e.detail="API-MMA • "+safe(e.competition,"Evento")+" • "+safe(e.status,"status não informado");return e;
    }

    Event parseF1(JSONObject o,String selectedDate){
        Event e=new Event(F1);e.apiSource=F1;e.id=o.optLong("id",0);JSONObject comp=o.optJSONObject("competition");if(comp!=null)e.home=comp.optString("name","");else e.home=first(o.optString("competition",""),o.optString("name",""));
        JSONObject circuit=o.optJSONObject("circuit");if(circuit!=null){e.away=circuit.optString("name","");e.awayLogo=circuit.optString("image","");}
        if(e.away.isEmpty())e.away=o.optString("circuit","");e.competition=first(o.optString("type",""),"Grand Prix");e.status=o.optString("status","");
        String d=o.optString("date","");if(d.contains("T")){String[] z=localIso(d);e.date=z[0];e.time=z[1];}else{e.date=d;e.time=o.optString("time","");}
        e.detail="API-FORMULA-1 • "+safe(e.competition,"Race")+" • "+safe(e.status,"programada");return e;
    }

    static JSONObject firstObj(JSONObject p,String... keys){for(String k:keys){JSONObject o=p.optJSONObject(k);if(o!=null)return o;}return null;}
    static String nameValue(Object o){if(o instanceof JSONObject)return ((JSONObject)o).optString("name","");return o==null?"":String.valueOf(o);}
    static String safe(String s,String d){return s==null||s.trim().isEmpty()?d:s;}
    static String first(String... s){for(String x:s)if(x!=null&&!x.trim().isEmpty()&&!"null".equalsIgnoreCase(x.trim()))return x;return "";}
    static String emptyScore(String s){return s==null||s.isEmpty()?"—":s;}
    static String numString(Object o){if(o==null||o==JSONObject.NULL)return "";return String.valueOf(o).replace(".0","");}
    static String scoreValue(Object o){if(o==null||o==JSONObject.NULL)return "";if(o instanceof Number||o instanceof String)return numString(o);if(o instanceof JSONObject){JSONObject q=(JSONObject)o;String[] ks={"total","points","runs","score"};for(String k:ks){String v=numString(q.opt(k));if(!v.isEmpty())return v;}}return "";}
    static String statusNba(int s,String longStatus){if(s==1)return "NS";if(s==2)return "LIVE";if(s==3)return "FT";if(s==4)return "PST";if(s==5)return "DLY";if(s==6)return "CANC";return first(longStatus,String.valueOf(s));}

    static String[] localIso(String iso){
        if(iso==null||iso.trim().isEmpty())return new String[]{"",""};
        String[] patterns={"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'","yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mmXXX"};
        for(String p:patterns)try{SimpleDateFormat in=new SimpleDateFormat(p,Locale.US);if(p.endsWith("'Z'"))in.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=in.parse(iso);SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US),tf=new SimpleDateFormat("HH:mm",Locale.US);TimeZone z=TimeZone.getTimeZone("America/Sao_Paulo");df.setTimeZone(z);tf.setTimeZone(z);return new String[]{df.format(d),tf.format(d)};}catch(Exception ignored){}
        String d=iso.length()>=10?iso.substring(0,10):iso;String t=iso.length()>=16?iso.substring(11,16):"";return new String[]{d,t};
    }

    static ArrayList<Event> dedupe(ArrayList<Event> in){LinkedHashMap<String,Event> m=new LinkedHashMap<>();for(Event e:in){String k=(safe(e.home,"")+"|"+safe(e.away,"")+"|"+safe(e.date,"")+"|"+safe(e.time,"")).toLowerCase(Locale.ROOT);Event old=m.get(k);if(old==null||NBA.equals(e.sport))m.put(k,e);}return new ArrayList<>(m.values());}
    static void sort(ArrayList<Event> a){Collections.sort(a,(x,y)->(safe(x.date,"")+"|"+safe(x.time,"")).compareTo(safe(y.date,"")+"|"+safe(y.time,"")));}
    static ArrayList<Event> selectF1(ArrayList<Event> all,String date){ArrayList<Event> exact=new ArrayList<>();for(Event e:all)if(date.equals(e.date))exact.add(e);if(!exact.isEmpty())return exact;ArrayList<Event> future=new ArrayList<>();for(Event e:all)if(e.date!=null&&e.date.compareTo(date)>=0)future.add(e);sort(future);while(future.size()>8)future.remove(future.size()-1);return future;}
}
