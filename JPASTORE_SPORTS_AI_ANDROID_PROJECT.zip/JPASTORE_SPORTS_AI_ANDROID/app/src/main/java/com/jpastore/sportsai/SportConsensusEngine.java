package com.jpastore.sportsai;

import java.util.*;

/**
 * Consensus Intelligence Engine (6.3).
 *
 * It does not invent missing matches. It works only with completed historical rows already found by
 * MultiSportWebClient, balances the contribution of different sources, rewards repeated confirmation,
 * down-weights explicit source conflicts and keeps recency relevant. The resulting "agreement" is an
 * internal convergence indicator, not a probability that a bet will win.
 */
final class SportConsensusEngine {
    static class Consensus {
        int homeGames=0,awayGames=0,uniqueGames=0,sourceCount=0,confirmedGames=0,conflictGames=0,agreement=0,coverage=0;
        double homeFor=Double.NaN,homeAgainst=Double.NaN,awayFor=Double.NaN,awayAgainst=Double.NaN;
        double homeWinRate=Double.NaN,awayWinRate=Double.NaN,homeMargin=Double.NaN,awayMargin=Double.NaN;
        double totalMean=Double.NaN,totalMedian=Double.NaN,totalStd=Double.NaN;
        String level="CONSENSO INSUFICIENTE",sources="",breakdown="",note="";
        boolean usable(){return Math.min(homeGames,awayGames)>=2;}
        int minGames(){return Math.min(homeGames,awayGames);}
    }

    static class TeamStats {
        int games=0,wins=0,draws=0,losses=0;
        double avgFor=Double.NaN,avgAgainst=Double.NaN,winRate=Double.NaN,margin=Double.NaN;
    }
    static class Acc {double f=0,a=0,w=0;int n=0,wins=0,draws=0,losses=0;void add(int pf,int pa,double weight){if(pf<0||pa<0)return;f+=pf*weight;a+=pa*weight;w+=weight;n++;if(pf>pa)wins++;else if(pf==pa)draws++;else losses++;}}
    static class TotalAcc {double sum=0,w=0;int n=0;void add(double v,double weight){if(v<0)return;sum+=v*weight;w+=weight;n++;}}

    static Consensus analyze(String sport, MultiSportClient.Event e, MultiSportWebClient.Research r){
        Consensus c=new Consensus();
        if(e==null||r==null){c.note="A pesquisa ainda não formou uma base histórica.";return c;}
        ArrayList<MultiSportWebClient.GameRow> h=teamRows(r.mergedHome,e.home,e.homeId,14);
        ArrayList<MultiSportWebClient.GameRow> a=teamRows(r.mergedAway,e.away,e.awayId,14);
        TeamStats hs=teamStats(h,e.home,e.homeId),as=teamStats(a,e.away,e.awayId);
        c.homeGames=hs.games;c.awayGames=as.games;c.homeFor=hs.avgFor;c.homeAgainst=hs.avgAgainst;c.awayFor=as.avgFor;c.awayAgainst=as.avgAgainst;
        c.homeWinRate=hs.winRate;c.awayWinRate=as.winRate;c.homeMargin=hs.margin;c.awayMargin=as.margin;

        ArrayList<MultiSportWebClient.GameRow> union=new ArrayList<>();
        for(MultiSportWebClient.GameRow g:h)MultiSportWebClient.addUniqueGame(union,g);
        for(MultiSportWebClient.GameRow g:a)MultiSportWebClient.addUniqueGame(union,g);
        c.uniqueGames=union.size();

        LinkedHashSet<String> src=new LinkedHashSet<>();LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();
        for(MultiSportWebClient.GameRow g:union){
            if(g==null)continue;if(g.sources.size()>1)c.confirmedGames++;if(g.sourceConflict)c.conflictGames++;
            if(g.sources.isEmpty()){src.add("Internet");counts.put("Internet",counts.getOrDefault("Internet",0)+1);}else for(String s:g.sources){String z=cleanSource(s);if(z.isEmpty())continue;src.add(z);counts.put(z,counts.getOrDefault(z,0)+1);}
        }
        if(src.isEmpty()&&!r.structuredSources.isEmpty())for(String s:r.structuredSources)src.add(cleanSource(s));
        c.sourceCount=src.size();c.sources=join(src,6);c.breakdown=breakdown(counts,6);

        ArrayList<Double> totals=new ArrayList<>();double tw=0,ts=0;int idx=0;
        LinkedHashMap<String,TotalAcc> perSourceTotals=new LinkedHashMap<>();
        for(MultiSportWebClient.GameRow g:union){if(g==null||!g.completed||g.hs<0||g.as<0)continue;double total=g.hs+g.as;totals.add(total);double w=rowWeight(g,idx++);ts+=total*w;tw+=w;Set<String> ss=g.sources.isEmpty()?Collections.singleton("Internet"):g.sources;for(String raw:ss){String z=cleanSource(raw);if(z.isEmpty())continue;perSourceTotals.computeIfAbsent(z,k->new TotalAcc()).add(total,w);}}
        if(!totals.isEmpty()){
            c.totalMedian=median(totals);c.totalStd=std(totals);
            double rowMean=tw>0?ts/tw:mean(totals);ArrayList<Double> sourceMeans=new ArrayList<>();double sw=0,ssum=0;
            for(TotalAcc x:perSourceTotals.values())if(x.w>0){double m=x.sum/x.w;sourceMeans.add(m);double q=Math.min(1.45,.75+x.n*.10);ssum+=m*q;sw+=q;}
            c.totalMean=sourceMeans.size()>=2&&sw>0?ssum/sw:rowMean;
            c.agreement=agreement(sourceMeans,c.totalMean,c.conflictGames,c.minGames(),c.sourceCount);
        }else c.agreement=35;
        c.coverage=coverage(c);
        if(c.minGames()>=5&&c.sourceCount>=3&&c.agreement>=75)c.level="CONSENSO FORTE";
        else if(c.minGames()>=3&&(c.sourceCount>=2||c.minGames()>=6)&&c.agreement>=60)c.level="CONSENSO MODERADO";
        else if(c.usable())c.level="CONSENSO EXPLORATÓRIO";
        else c.level="CONSENSO INSUFICIENTE";
        c.note=buildNote(c);
        return c;
    }

    static TeamStats teamStats(ArrayList<MultiSportWebClient.GameRow> rows,String team,long id){
        TeamStats out=new TeamStats();if(rows==null||rows.isEmpty())return out;
        LinkedHashMap<String,Acc> perSource=new LinkedHashMap<>();Acc global=new Acc();int i=0;
        for(MultiSportWebClient.GameRow g:rows){if(g==null||!g.completed||g.hs<0||g.as<0)continue;boolean home=id>0?(g.homeId==id):g.homeSide(team);if(id<=0&&!g.involves(team))continue;int pf=home?g.hs:g.as,pa=home?g.as:g.hs;double w=rowWeight(g,i++);global.add(pf,pa,w);Set<String> ss=g.sources.isEmpty()?Collections.singleton("Internet"):g.sources;for(String raw:ss){String z=cleanSource(raw);if(z.isEmpty())continue;perSource.computeIfAbsent(z,k->new Acc()).add(pf,pa,w);}}
        out.games=global.n;out.wins=global.wins;out.draws=global.draws;out.losses=global.losses;if(global.n==0)return out;
        double gf=0,ga=0,gw=0;for(Acc x:perSource.values())if(x.w>0){double q=Math.min(1.45,.75+x.n*.10);gf+=(x.f/x.w)*q;ga+=(x.a/x.w)*q;gw+=q;}
        out.avgFor=gw>0?gf/gw:global.f/Math.max(.01,global.w);out.avgAgainst=gw>0?ga/gw:global.a/Math.max(.01,global.w);out.margin=out.avgFor-out.avgAgainst;out.winRate=global.wins/(double)Math.max(1,global.n);return out;
    }

    static ArrayList<MultiSportWebClient.GameRow> teamRows(ArrayList<MultiSportWebClient.GameRow> src,String team,long id,int max){ArrayList<MultiSportWebClient.GameRow> out=new ArrayList<>();if(src==null)return out;for(MultiSportWebClient.GameRow g:src){if(g==null||!g.completed||g.hs<0||g.as<0)continue;boolean ok=id>0?(g.homeId==id||g.awayId==id):g.involves(team);if(!ok)continue;MultiSportWebClient.addUniqueGame(out,g);if(out.size()>=max)break;}return out;}
    static double rowWeight(MultiSportWebClient.GameRow g,int index){double recent=Math.max(.62,1.0-index*.035);double confirm=1.0+Math.min(.24,Math.max(0,g.confirmations()-1)*.08);double conflict=g.sourceConflict?.55:1.0;return recent*confirm*conflict;}
    static int agreement(ArrayList<Double> sourceMeans,double overall,int conflicts,int minGames,int sourceCount){if(sourceCount<=1)return Math.min(58,42+Math.min(16,minGames*3));if(sourceMeans==null||sourceMeans.size()<2)return Math.min(64,50+Math.min(14,minGames*2));double sd=std(sourceMeans),den=Math.max(1.0,Math.abs(overall)),cv=sd/den;int v=(int)Math.round(96-Math.min(48,cv*260)-conflicts*8);if(minGames<3)v=Math.min(v,68);else if(minGames<5)v=Math.min(v,82);return clamp(v,35,96);}
    static int coverage(Consensus c){int v=30+Math.min(36,c.minGames()*6)+Math.min(18,c.sourceCount*4)+Math.min(12,c.confirmedGames*2)-Math.min(20,c.conflictGames*5);return clamp(v,25,100);}
    static String buildNote(Consensus c){StringBuilder b=new StringBuilder();b.append(c.sourceCount).append(" fonte").append(c.sourceCount==1?"":"s").append(" • ").append(c.uniqueGames).append(" jogos únicos");if(c.confirmedGames>0)b.append(" • ").append(c.confirmedGames).append(" confirmados por múltiplas fontes");if(c.conflictGames>0)b.append(" • ").append(c.conflictGames).append(" conflito").append(c.conflictGames==1?"":"s").append(" reduzindo o peso");b.append(" • convergência ").append(c.agreement).append("%");return b.toString();}
    static String report(Consensus c,String unit){if(c==null)return "Consenso indisponível.";String u=unit==null?"pontos":unit;StringBuilder b=new StringBuilder();b.append(c.level).append("\n").append(c.note).append(".\n");if(!Double.isNaN(c.homeFor))b.append("Média ponderada participante 1: ").append(fmt(c.homeFor)).append(" ").append(u).append(" pró / ").append(fmt(c.homeAgainst)).append(" contra.\n");if(!Double.isNaN(c.awayFor))b.append("Média ponderada participante 2: ").append(fmt(c.awayFor)).append(" ").append(u).append(" pró / ").append(fmt(c.awayAgainst)).append(" contra.\n");if(!Double.isNaN(c.totalMean))b.append("Total médio consolidado: ").append(fmt(c.totalMean)).append(" ").append(u).append(" • mediana ").append(fmt(c.totalMedian)).append(" • dispersão ").append(fmt(c.totalStd)).append(".\n");if(c.breakdown!=null&&!c.breakdown.isEmpty())b.append("Base por fonte: ").append(c.breakdown).append(".");return b.toString();}

    static String cleanSource(String s){if(s==null)return "";String z=s.trim();if(z.equalsIgnoreCase("Busca Web"))return "Web pública";return z;}
    static String breakdown(LinkedHashMap<String,Integer> m,int max){StringBuilder b=new StringBuilder();int i=0;for(Map.Entry<String,Integer> e:m.entrySet()){if(i++>=max)break;if(b.length()>0)b.append(" • ");b.append(e.getKey()).append(" ").append(e.getValue());}if(m.size()>max)b.append(" • +").append(m.size()-max);return b.toString();}
    static String join(Collection<String> xs,int max){StringBuilder b=new StringBuilder();int i=0;for(String s:xs){if(s==null||s.trim().isEmpty())continue;if(i++>=max)break;if(b.length()>0)b.append(" + ");b.append(s);}if(xs.size()>max)b.append(" +...");return b.toString();}
    static double mean(Collection<Double> xs){if(xs==null||xs.isEmpty())return Double.NaN;double s=0;int n=0;for(Double x:xs)if(x!=null&&!Double.isNaN(x)){s+=x;n++;}return n==0?Double.NaN:s/n;}
    static double median(ArrayList<Double> xs){if(xs==null||xs.isEmpty())return Double.NaN;ArrayList<Double> z=new ArrayList<>(xs);Collections.sort(z);int n=z.size();return n%2==1?z.get(n/2):(z.get(n/2-1)+z.get(n/2))/2.0;}
    static double std(Collection<Double> xs){double m=mean(xs);if(Double.isNaN(m))return Double.NaN;double s=0;int n=0;for(Double x:xs)if(x!=null&&!Double.isNaN(x)){double d=x-m;s+=d*d;n++;}return n<=1?0:Math.sqrt(s/(n-1));}
    static int clamp(int v,int a,int b){return Math.max(a,Math.min(b,v));}
    static String fmt(double x){return Double.isNaN(x)?"—":String.format(new Locale("pt","BR"),"%.1f",x);}
    private SportConsensusEngine(){}
}
