package com.jpastore.sportsai;
import java.util.*;

/** Evidence-first local analyst. It never invents statistics: it only verbalizes values already calculated by the app. */
public final class LocalAiEngine {
 static String pct(int v){ return v>0 ? v+"%" : "dados insuficientes"; }
 static String fmt(double v){ return Double.isNaN(v)?"—":String.format(Locale.US,"%.1f",v); }
 static String confidence(ApiClient.Prediction p){
  if(p==null) return "DADOS INSUFICIENTES";
  int max=Math.max(p.home,Math.max(p.draw,p.away));
  int gap=max-Math.min(p.home,Math.min(p.draw,p.away));
  if(max>=55 && gap>=22) return "FAVORÁVEL";
  if(max>=42) return "ATENÇÃO";
  return "DUVIDOSO";
 }
 static String leader(ApiClient.Game g, ApiClient.Prediction p){
  if(p==null) return "Não há dados suficientes para apontar tendência principal.";
  if(p.home>=p.draw && p.home>=p.away) return g.home+" aparece com a maior probabilidade calculada ("+p.home+"%).";
  if(p.away>=p.home && p.away>=p.draw) return g.away+" aparece com a maior probabilidade calculada ("+p.away+"%).";
  return "O empate aparece com a maior probabilidade calculada ("+p.draw+"%).";
 }
 static String metricLine(ApiClient.MetricProjection m){
  StringBuilder b=new StringBuilder();
  b.append(m.name).append(": projeção ").append(fmt(m.total)).append(" no total");
  b.append(" (").append(fmt(m.home)).append(" × ").append(fmt(m.away)).append(")");
  b.append(", faixa provável ").append(fmt(m.low)).append("–").append(fmt(m.high));
  if(m.line>0&&m.overProb>=0)b.append(", acima de ").append(fmt(m.line)).append(" ~").append(m.overProb).append("%");
  if(m.lineHigh>0&&m.overProbHigh>=0)b.append("; acima de ").append(fmt(m.lineHigh)).append(" ~").append(m.overProbHigh).append("%");
  b.append(". Amostra: ").append(m.sample).append(" observações válidas");
  if(m.source!=null&&!m.source.isEmpty())b.append(" • fonte ").append(m.source);
  b.append(".");
  return b.toString();
 }
 static String report(ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s){return report(g,p,s,null);}
 static String report(ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s, ApiClient.DeepAnalysis d){
  if(g==null) return "Selecione um confronto para iniciar a análise.";
  StringBuilder b=new StringBuilder();
  b.append("J.PASTORE AI • ANÁLISE CONTEXTUAL\n\n");
  b.append(g.home).append(" × ").append(g.away).append("\n");
  b.append(g.league==null?"Competição não informada":g.league).append("\n\n");
  if(p==null)b.append("LEITURA\nProbabilidades principais ainda estão sendo calculadas. Nenhum percentual ausente será inventado.\n\n");
  else{
   b.append("LEITURA\n").append(leader(g,p)).append(" Casa ").append(pct(p.home)).append(" • Empate ").append(pct(p.draw)).append(" • Fora ").append(pct(p.away)).append(".\n\n");
   if(p.advice!=null&&!p.advice.trim().isEmpty()) b.append("TENDÊNCIA DO MOTOR\n").append(p.advice).append("\n\n");
   if(p.underOver!=null&&!p.underOver.trim().isEmpty()&&!"null".equalsIgnoreCase(p.underOver.trim())) b.append("GOLS\nTendência calculada: ").append(p.underOver).append(".\n\n");
   b.append("CONFIANÇA\n").append(confidence(p)).append(" — classificação baseada na força e separação das probabilidades disponíveis, não em garantia de resultado.\n\n");
  }
  if(d!=null&&!d.metrics.isEmpty()){
   int coverage=ApiClient.coveragePercent(d);
   int base=d.homeMatches+d.awayMatches+d.h2hMatches;
   b.append("BASE ESTATÍSTICA\n");
   b.append(g.home).append(": ").append(d.homeMatches).append(" jogos recentes");if(d.homeVenueMatches>0)b.append(" • ").append(d.homeVenueMatches).append(" em casa");b.append("\n");
   b.append(g.away).append(": ").append(d.awayMatches).append(" jogos recentes");if(d.awayVenueMatches>0)b.append(" • ").append(d.awayVenueMatches).append(" fora");b.append("\n");
   b.append("H2H: ").append(d.h2hMatches).append(" • base principal: ").append(base).append(" jogos • cobertura ponderada: ").append(coverage).append("%\n");
   if(d.sources!=null&&!d.sources.isEmpty())b.append("Fontes: ").append(d.sources).append("\n");b.append("\n");
   b.append("PROJEÇÕES DE EVENTOS\n");
   String[] order={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};
   for(String k:order){ApiClient.MetricProjection m=d.metrics.get(k);if(m!=null)b.append("• ").append(metricLine(m)).append("\n");else b.append("• ").append(k).append(": dados insuficientes nas fontes disponíveis.\n");}
   if(d.h2hMatches>0)b.append("• H2H: ").append(d.h2hMatches).append(" confrontos diretos entraram com peso menor que a forma recente.\n");
   b.append("\n");
  }else{
   b.append("PROJEÇÕES DE EVENTOS\n");
   b.append("• A análise procura até 10 jogos recentes de cada equipe, recorte casa/fora e até 5 H2H. A internet é consultada primeiro; a API entra apenas para completar lacunas quando configurada.\n\n");
  }
  if(p!=null){
   b.append("EVIDÊNCIAS\n");int n=0;
   for(Map.Entry<String,Integer> e:p.comparison.entrySet()){
    String[] z=e.getKey().split("\\|"); if(z.length<2||!"H".equals(z[1])) continue;
    Integer av=p.comparison.get(z[0]+"|A"); if(av==null) continue;
    b.append("• ").append(z[0]).append(": ").append(g.home).append(" ").append(e.getValue()).append("% × ").append(g.away).append(" ").append(av).append("%\n");
    if(++n>=6)break;
   }
   if(n==0)b.append("• Comparativos detalhados ainda não disponíveis.\n");
  }
  b.append("\nQUALIDADE DOS DADOS\n");
  if(d!=null){b.append("Cobertura ponderada: ").append(ApiClient.coveragePercent(d)).append("%. ");}
  if(d!=null&&!d.note.isEmpty())b.append(d.note).append(". ");
  b.append("Somente informações presentes nas fontes e cálculos do aplicativo são usadas. Estatísticas ausentes permanecem como dados insuficientes.");
  return b.toString();
 }
 static String answer(String q, ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s){return answer(q,g,p,s,null);}
 static String answer(String q, ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s, ApiClient.DeepAnalysis d){
  if(g==null)return "Selecione um confronto primeiro.";
  String x=q==null?"":q.toLowerCase(Locale.ROOT);
  if(x.contains("escante"))return metricAnswer("Escanteios",d);
  if(x.contains("lateral")||x.contains("throw"))return metricAnswer("Laterais",d);
  if(x.contains("tiro de meta")||x.contains("goal kick"))return metricAnswer("Tiros de meta",d);
  if(x.contains("falta"))return metricAnswer("Faltas",d);
  if(x.contains("chute")||x.contains("finaliza"))return metricAnswer(x.contains("alvo")?"Chutes no alvo":"Finalizações",d);
  if(x.contains("cart"))return metricAnswer("Cartões amarelos",d);
  if(x.contains("imped"))return metricAnswer("Impedimentos",d);
  if(x.contains("gol")||x.contains("over")||x.contains("under")){
   ApiClient.MetricProjection m=d==null?null:d.metrics.get("Gols");if(m!=null)return metricLine(m)+" É uma estimativa estatística, não uma garantia.";
   if(p==null||p.underOver==null||p.underOver.isEmpty())return "Ainda não há evidência suficiente sobre gols para este confronto.";
   return "Para gols, a tendência disponível é: "+p.underOver+". Isso é uma estimativa estatística, não uma garantia.";
  }
  if(x.contains("quem")||x.contains("vence")||x.contains("melhor")||x.contains("favor")) return leader(g,p)+" Confiança: "+confidence(p)+".";
  if(x.contains("prob")) return p==null?"Dados insuficientes para probabilidades.":"Probabilidades atuais: "+g.home+" "+p.home+"%, empate "+p.draw+"%, "+g.away+" "+p.away+"%.";
  if(x.contains("por que")||x.contains("porque")||x.contains("evid")){
   if(p==null||p.comparison.isEmpty())return "Os comparativos necessários ainda não estão disponíveis.";
   StringBuilder b=new StringBuilder("A leitura usa os comparativos disponíveis: ");int n=0;for(String k:p.comparison.keySet()){if(k.endsWith("|H")){if(n++>0)b.append(", ");b.append(k.substring(0,k.length()-2));if(n==6)break;}}return b.append(". Nenhum dado ausente é inventado.").toString();
  }
  return report(g,p,s,d);
 }
 static String metricAnswer(String name,ApiClient.DeepAnalysis d){ApiClient.MetricProjection m=d==null?null:d.metrics.get(name);return m==null?name+": dados insuficientes na fonte para esta análise.":metricLine(m)+" A projeção usa histórico recente e deve ser tratada como estimativa.";}
 private LocalAiEngine(){}
}
