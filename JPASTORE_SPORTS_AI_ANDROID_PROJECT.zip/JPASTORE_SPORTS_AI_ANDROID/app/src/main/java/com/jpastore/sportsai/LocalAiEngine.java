package com.jpastore.sportsai;
import java.util.*;

/** Evidence-first local analyst. It never invents statistics: it only verbalizes values already calculated by the app. */
public final class LocalAiEngine {
 static String pct(int v){ return v>0 ? v+"%" : "dados insuficientes"; }
 static String confidence(ApiClient.Prediction p){
  if(p==null) return "DADOS INSUFICIENTES";
  int max=Math.max(p.home,Math.max(p.draw,p.away));
  int gap=max-Math.min(p.home,Math.min(p.draw,p.away));
  if(max>=55 && gap>=22) return "FAVORÁVEL";
  if(max>=42) return "ATENÇÃO";
  return "DUVIDOSO";
 }
 static String leader(ApiClient.Game g, ApiClient.Prediction p){
  if(p==null) return "Não há dados suficientes para apontar tendência principal.";
  if(p.home>=p.draw && p.home>=p.away) return g.home+" aparece com a maior probabilidade calculada ("+p.home+"%).";
  if(p.away>=p.home && p.away>=p.draw) return g.away+" aparece com a maior probabilidade calculada ("+p.away+"%).";
  return "O empate aparece com a maior probabilidade calculada ("+p.draw+"%).";
 }
 static String report(ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s){
  if(g==null) return "Selecione um confronto para iniciar a análise.";
  StringBuilder b=new StringBuilder();
  b.append("J.PASTORE AI • ANÁLISE CONTEXTUAL\n\n");
  b.append(g.home).append(" × ").append(g.away).append("\n");
  b.append(g.league==null?"Competição não informada":g.league).append("\n\n");
  if(p==null){b.append("Dados insuficientes para uma leitura probabilística segura. O sistema não completará números ausentes.\n");return b.toString();}
  b.append("LEITURA\n").append(leader(g,p)).append(" Casa ").append(pct(p.home)).append(" • Empate ").append(pct(p.draw)).append(" • Fora ").append(pct(p.away)).append(".\n\n");
  if(p.advice!=null&&!p.advice.trim().isEmpty()) b.append("TENDÊNCIA DO MOTOR\n").append(p.advice).append("\n\n");
  if(p.underOver!=null&&!p.underOver.trim().isEmpty()) b.append("GOLS\nTendência calculada: ").append(p.underOver).append(".\n\n");
  b.append("CONFIANÇA\n").append(confidence(p)).append(" — classificação baseada na força e separação das probabilidades disponíveis, não em garantia de resultado.\n\n");
  b.append("EVIDÊNCIAS\n");
  int n=0;
  for(Map.Entry<String,Integer> e:p.comparison.entrySet()){
   String[] z=e.getKey().split("\\|"); if(z.length<2||!"H".equals(z[1])) continue;
   Integer av=p.comparison.get(z[0]+"|A"); if(av==null) continue;
   b.append("• ").append(z[0]).append(": ").append(g.home).append(" ").append(e.getValue()).append("% × ").append(g.away).append(" ").append(av).append("%\n");
   if(++n>=5)break;
  }
  if(n==0)b.append("• Comparativos detalhados ainda não disponíveis.\n");
  b.append("\nQUALIDADE DOS DADOS\nSomente informações presentes nas fontes e cálculos do aplicativo são usadas. Estatísticas ausentes permanecem como dados insuficientes.");
  return b.toString();
 }
 static String answer(String q, ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s){
  if(g==null)return "Selecione um confronto primeiro.";
  String x=q==null?"":q.toLowerCase(Locale.ROOT);
  if(x.contains("gol")||x.contains("over")||x.contains("under")){
   if(p==null||p.underOver==null||p.underOver.isEmpty())return "Ainda não há evidência suficiente sobre o mercado de gols para este confronto.";
   return "Para gols, a tendência disponível é: "+p.underOver+". Isso é uma estimativa estatística, não uma garantia.";
  }
  if(x.contains("quem")||x.contains("vence")||x.contains("melhor")||x.contains("favor")) return leader(g,p)+" Confiança: "+confidence(p)+".";
  if(x.contains("prob")) return p==null?"Dados insuficientes para probabilidades.":"Probabilidades atuais: "+g.home+" "+p.home+"%, empate "+p.draw+"%, "+g.away+" "+p.away+"%.";
  if(x.contains("por que")||x.contains("porque")||x.contains("evid")){
   if(p==null||p.comparison.isEmpty())return "Os comparativos necessários ainda não estão disponíveis.";
   StringBuilder b=new StringBuilder("A leitura usa os comparativos disponíveis: ");int n=0;for(String k:p.comparison.keySet()){if(k.endsWith("|H")){if(n++>0)b.append(", ");b.append(k.substring(0,k.length()-2));if(n==5)break;}}return b.append(". Nenhum dado ausente é inventado.").toString();
  }
  return report(g,p,s);
 }
 private LocalAiEngine(){}
}
