package com.jpastore.sportsai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView statusText, summaryText;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private List<Game> games = new ArrayList<>();
    private int filter = 0;
    private final int BG = Color.rgb(7,17,31), CARD = Color.rgb(15,29,48), TEXT = Color.rgb(239,244,250), MUTED = Color.rgb(151,166,185);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUI();
        load();
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(18),dp(16),dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1,-2));

        TextView brand = text("J.Pastore Sports AI", 26, TEXT, true); root.addView(brand);
        TextView creator = text("Criado e desenvolvido por J.Pastore", 13, MUTED, false); root.addView(creator);
        statusText = text("Carregando…", 12, MUTED, false); statusText.setPadding(0,dp(5),0,dp(14)); root.addView(statusText);

        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.addView(button("Todos", v->{filter=0; render();}), weight());
        nav.addView(button("🟢 Favoráveis", v->{filter=1; render();}), weight());
        nav.addView(button("Atualizar", v->load()), weight());
        root.addView(nav);

        summaryText = text("", 14, TEXT, true); summaryText.setPadding(0,dp(16),0,dp(10)); root.addView(summaryText);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);

        Button settings = button("Configurar API / modo online", v->showSettings());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,dp(48)); sp.setMargins(0,dp(16),0,dp(8)); root.addView(settings, sp);
        TextView legal = text("As cores indicam confiança estatística, não garantia de resultado. O app não executa apostas nem acessa contas de casas de apostas.", 11, MUTED, false);
        root.addView(legal);
        setContentView(scroll);
    }

    private void load() {
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            games = demoGames();
            statusText.setText("MODO DEMONSTRAÇÃO • configure sua API para partidas reais"); render(); return;
        }
        statusText.setText("Atualizando partidas e análises…");
        executor.execute(() -> {
            try {
                List<Game> g = client.loadToday();
                runOnUiThread(() -> {
                    games = g; String now = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    statusText.setText("ONLINE • atualizado às " + now + " • " + games.size() + " partidas"); render();
                });
            } catch(Exception e) {
                runOnUiThread(() -> { statusText.setText("Falha online: " + e.getMessage() + " • exibindo demonstração"); games=demoGames(); render(); });
            }
        });
    }

    private void render() {
        list.removeAllViews(); int green=0,yellow=0,red=0,shown=0;
        for(Game g: games){ if(g.confidence>=70)green++; else if(g.confidence>=55)yellow++; else red++; }
        summaryText.setText("🟢 " + green + " alta confiança   🟡 " + yellow + " moderada   🔴 " + red + " incerta");
        List<Game> sorted = new ArrayList<>(games); sorted.sort((a,b)->Integer.compare(b.confidence,a.confidence));
        for(Game g: sorted) {
            if(filter==1 && g.confidence<70) continue;
            shown++; list.addView(card(g));
        }
        if(shown==0) list.addView(text("Nenhuma partida neste filtro.",14,MUTED,false));
    }

    private View card(Game g) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(13),dp(14),dp(13));
        GradientDrawable bg = new GradientDrawable(); bg.setCornerRadius(dp(16)); bg.setColor(CARD); bg.setStroke(dp(2), riskColor(g.confidence)); c.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,0,0,dp(10)); c.setLayoutParams(cp);
        TextView lg = text(g.league + "  •  " + g.time + "  •  " + g.status, 11, MUTED,false); c.addView(lg);
        TextView teams = text(g.home + "  ×  " + g.away, 18, TEXT,true); teams.setPadding(0,dp(5),0,dp(8)); c.addView(teams);
        TextView badge = text(label(g.confidence) + "  " + g.confidence + "%", 15, riskColor(g.confidence), true); c.addView(badge);
        TextView trend = text(g.trend, 14, TEXT,true); trend.setPadding(0,dp(7),0,dp(3)); c.addView(trend);
        TextView probs = text("Mandante " + g.homePct + "%  •  Empate " + g.drawPct + "%  •  Visitante " + g.awayPct + "%", 12, MUTED,false); c.addView(probs);
        c.setOnClickListener(v -> showDetail(g)); return c;
    }

    private void showDetail(Game g) {
        String msg = g.home + " × " + g.away + "\n\n" + g.trend + "\nConfiança combinada: " + g.confidence + "%\n\n" +
                g.reason + "\n\nProbabilidades: " + g.homePct + "% / " + g.drawPct + "% / " + g.awayPct + "%";
        new AlertDialog.Builder(this).setTitle("Análise dupla").setMessage(msg)
                .setPositiveButton("Copiar análise", (d,w)->copy(msg)).setNegativeButton("Fechar",null).show();
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),dp(4),dp(20),0);
        TextView help = text("Para partidas reais, informe sua chave da API-Football (API-Sports). Ela fica salva apenas neste aparelho.",13,Color.DKGRAY,false); box.addView(help);
        EditText input = new EditText(this); input.setHint("x-apisports-key"); input.setSingleLine(true); input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setText(getPreferences(MODE_PRIVATE).getString("api_key", "")); box.addView(input);
        new AlertDialog.Builder(this).setTitle("Modo online").setView(box)
                .setPositiveButton("Salvar e atualizar", (d,w)-> { getPreferences(MODE_PRIVATE).edit().putString("api_key", input.getText().toString().trim()).apply(); load(); })
                .setNeutralButton("Usar demonstração", (d,w)-> { getPreferences(MODE_PRIVATE).edit().remove("api_key").apply(); load(); })
                .setNegativeButton("Cancelar",null).show();
    }

    private List<Game> demoGames() {
        List<Game> d = new ArrayList<>();
        d.add(mk("Brasileirão", "Palmeiras", "Bahia", "19:30", 62,22,16));
        d.add(mk("Brasileirão", "Flamengo", "Fortaleza", "21:30", 55,26,19));
        d.add(mk("Premier League", "Arsenal", "Everton", "16:00", 69,20,11));
        d.add(mk("La Liga", "Real Sociedad", "Villarreal", "17:00", 38,31,31));
        d.add(mk("Serie A", "Torino", "Udinese", "15:45", 36,35,29));
        return d;
    }
    private Game mk(String l,String h,String a,String t,int hp,int dpct,int ap){ AnalysisEngine.Result r=AnalysisEngine.evaluate(hp,dpct,ap); return new Game(0,l,h,a,t,"DEMO",hp,dpct,ap,r.confidence,r.trend,r.reason); }

    private int riskColor(int c){ return c>=70?Color.rgb(39,211,123):(c>=55?Color.rgb(255,193,7):Color.rgb(255,82,82)); }
    private String label(int c){ return c>=70?"● FAVORÁVEL":(c>=55?"● ATENÇÃO":"● DUVIDOSO"); }
    private void copy(String s){ ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Análise J.Pastore",s)); Toast.makeText(this,"Análise copiada",Toast.LENGTH_SHORT).show(); }
    private TextView text(String s,int sp,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setLineSpacing(0,1.08f); return t; }
    private Button button(String s, View.OnClickListener l){ Button b=new Button(this); b.setText(s); b.setTextSize(11); b.setAllCaps(false); b.setOnClickListener(l); return b; }
    private LinearLayout.LayoutParams weight(){ return new LinearLayout.LayoutParams(0,dp(48),1f); }
    private int dp(int v){ return Math.round(v*getResources().getDisplayMetrics().density); }
    @Override protected void onDestroy(){ super.onDestroy(); executor.shutdownNow(); }
}
