package com.jpastore.sportsai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView statusText, summaryText;
    private Button refreshButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private List<Game> games = new ArrayList<>();
    private int filter = 0;
    private long lastRefreshAt = 0L;
    private boolean upcomingLoaded = false;
    private boolean upcomingLoading = false;
    private String selectedLeagueKey = null;
    private String selectedLeagueLabel = null;
    private boolean favoritesOnly = false;
    private final Set<String> favoriteLeagueKeys = new LinkedHashSet<>();
    private final int BG = Color.rgb(7,17,31), CARD = Color.rgb(15,29,48), TEXT = Color.rgb(239,244,250), MUTED = Color.rgb(151,166,185);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadFavoriteLeagues();
        buildUI();
        load(false);
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        root.addView(text("J.Pastore Sports AI", 26, TEXT, true));
        root.addView(text("Criado e desenvolvido por J.Pastore", 13, MUTED, false));
        statusText = text("Carregando…", 12, MUTED, false);
        statusText.setPadding(0, dp(5), 0, dp(12));
        root.addView(statusText);

        ImageView hero = new ImageView(this);
        hero.setImageResource(getResources().getIdentifier("header_football", "drawable", getPackageName()));
        hero.setAdjustViewBounds(true);
        hero.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable heroBg = new GradientDrawable();
        heroBg.setCornerRadius(dp(20));
        heroBg.setColor(CARD);
        hero.setBackground(heroBg);
        hero.setClipToOutline(true);
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, dp(160));
        heroLp.setMargins(0, 0, 0, dp(14));
        root.addView(hero, heroLp);

        LinearLayout nav1 = new LinearLayout(this);
        nav1.setOrientation(LinearLayout.HORIZONTAL);
        nav1.addView(rowButton("Todos", v -> {
            filter = 0;
            selectedLeagueKey = null;
            selectedLeagueLabel = null;
            favoritesOnly = false;
            render();
        }));
        nav1.addView(rowButton("Favoráveis", v -> { filter = 1; render(); }));
        nav1.addView(rowButton("Ao vivo", v -> { filter = 2; render(); }));
        root.addView(nav1);

        LinearLayout nav2 = new LinearLayout(this);
        nav2.setOrientation(LinearLayout.HORIZONTAL);
        nav2.addView(rowButton("Hoje", v -> { filter = 3; render(); }));
        nav2.addView(rowButton("Próximos", v -> loadUpcoming()));
        refreshButton = rowButton("Atualizar", v -> load(true));
        nav2.addView(refreshButton);
        root.addView(nav2);

        LinearLayout nav3 = new LinearLayout(this);
        nav3.setOrientation(LinearLayout.HORIZONTAL);
        nav3.addView(rowButton("Campeonatos", v -> showChampionshipsDialog()));
        nav3.addView(rowButton("★ Favoritos", v -> showFavoriteChampionships()));
        root.addView(nav3);

        summaryText = text("", 14, TEXT, true);
        summaryText.setPadding(0, dp(16), 0, dp(10));
        root.addView(summaryText);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Button settings = button("Configurar API / modo online", v -> showSettings());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(48));
        sp.setMargins(0, dp(16), 0, dp(8));
        root.addView(settings, sp);

        root.addView(text("As análises são probabilísticas e informativas. O app não garante resultados, não executa apostas e não acessa contas de casas de apostas.", 11, MUTED, false));
        setContentView(scroll);
    }

    private void load(boolean manual) {
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            games = demoGames();
            upcomingLoaded = true;
            statusText.setText("MODO DEMONSTRAÇÃO • configure sua API para partidas reais");
            render();
            return;
        }

        long nowMs = System.currentTimeMillis();
        if (manual && lastRefreshAt > 0 && nowMs - lastRefreshAt < 65000L) {
            long wait = (65000L - (nowMs - lastRefreshAt) + 999L) / 1000L;
            Toast.makeText(this, "Aguarde " + wait + "s para atualizar novamente.", Toast.LENGTH_SHORT).show();
            return;
        }

        statusText.setText("Carregando jogos de hoje…");
        refreshButton.setEnabled(false);
        executor.execute(() -> {
            try {
                List<Game> g = client.loadToday();
                runOnUiThread(() -> {
                    games = g;
                    upcomingLoaded = false;
                    upcomingLoading = false;
                    lastRefreshAt = System.currentTimeMillis();
                    refreshButton.setEnabled(true);
                    String now = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("ONLINE • hoje: " + games.size() + " jogos • " + now + quota + " • Campeonatos filtra sem consumir API");
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    refreshButton.setEnabled(true);
                    games = new ArrayList<>();
                    upcomingLoaded = false;
                    upcomingLoading = false;
                    statusText.setText("Falha online: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void loadUpcoming() {
        filter = 4;
        if (upcomingLoaded) {
            render();
            return;
        }
        if (upcomingLoading) {
            Toast.makeText(this, "Os próximos jogos já estão sendo carregados.", Toast.LENGTH_SHORT).show();
            return;
        }

        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            render();
            return;
        }

        upcomingLoading = true;
        statusText.setText("Carregando próximos 3 dias… pode levar alguns segundos para respeitar o limite da API.");
        executor.execute(() -> {
            try {
                List<Game> upcoming = client.loadUpcomingDays(3);
                runOnUiThread(() -> {
                    LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();
                    for (Game g : games) merged.put(g.fixtureId, g);
                    for (Game g : upcoming) if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
                    games = new ArrayList<>(merged.values());
                    upcomingLoaded = true;
                    upcomingLoading = false;
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("ONLINE • próximos 3 dias carregados: " + upcoming.size() + " jogos" + quota);
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    upcomingLoading = false;
                    statusText.setText("Falha ao carregar próximos jogos: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void analyze(Game g) {
        if (g.analyzed) {
            showDetail(g);
            return;
        }
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            Toast.makeText(this, "Configure sua API primeiro.", Toast.LENGTH_SHORT).show();
            return;
        }
        statusText.setText("Analisando " + g.home + " × " + g.away + "…");
        executor.execute(() -> {
            try {
                int[] p = client.loadPrediction(g.fixtureId);
                AnalysisEngine.Result r = AnalysisEngine.evaluate(p[0], p[1], p[2]);
                g.applyAnalysis(p[0], p[1], p[2], r);
                runOnUiThread(() -> {
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("Análise concluída" + quota);
                    render();
                    showDetail(g);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusText.setText("Não foi possível analisar: " + friendlyError(e.getMessage()));
                    new AlertDialog.Builder(this)
                            .setTitle("Análise indisponível")
                            .setMessage(friendlyError(e.getMessage()))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        });
    }

    private void render() {
        list.removeAllViews();
        List<Game> visible = new ArrayList<>();
        for (Game g : games) if (accept(g)) visible.add(g);

        int green = 0, yellow = 0, red = 0, analyzed = 0;
        for (Game g : visible) {
            if (!g.analyzed) continue;
            analyzed++;
            if (g.confidence >= 70) green++; else if (g.confidence >= 55) yellow++; else red++;
        }

        String filterText = activeFilterText();
        summaryText.setText(filterText + "Exibidos: " + visible.size() + " • Analisados: " + analyzed + "   🟢 " + green + "   🟡 " + yellow + "   🔴 " + red + "\nToque em uma partida para gerar a análise.");

        visible.sort((a, b) -> {
            if (a.analyzed != b.analyzed) return a.analyzed ? -1 : 1;
            int c = Integer.compare(b.confidence, a.confidence);
            if (c != 0) return c;
            c = leagueDisplay(a).compareToIgnoreCase(leagueDisplay(b));
            if (c != 0) return c;
            return a.time.compareTo(b.time);
        });

        for (Game g : visible) list.addView(card(g));

        if (visible.isEmpty()) {
            String message;
            if (filter == 4 && !upcomingLoaded) message = "Toque em Próximos para carregar os próximos 3 dias.";
            else if (favoritesOnly && favoriteLeagueKeys.isEmpty()) message = "Nenhum campeonato favorito. Abra Campeonatos e toque na estrela para favoritar.";
            else if (selectedLeagueKey != null) message = "Nenhuma partida deste campeonato no filtro atual.";
            else message = games.isEmpty() ? "Nenhuma partida retornada pela API agora." : "Nenhuma partida neste filtro.";
            list.addView(text(message, 14, MUTED, false));
        }
    }

    private boolean accept(Game g) {
        boolean modeOk = true;
        if (filter == 1) modeOk = g.analyzed && g.confidence >= 70;
        else if (filter == 2) modeOk = "AO VIVO".equals(g.bucket);
        else if (filter == 3) modeOk = "HOJE".equals(g.bucket) || "AO VIVO".equals(g.bucket);
        else if (filter == 4) modeOk = "PRÓXIMO".equals(g.bucket);
        if (!modeOk) return false;

        String key = leagueKey(g);
        if (selectedLeagueKey != null && !selectedLeagueKey.equals(key)) return false;
        if (favoritesOnly && !favoriteLeagueKeys.contains(key)) return false;
        return true;
    }

    private View card(Game g) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(CARD);
        bg.setStroke(dp(2), g.analyzed ? riskColor(g.confidence) : Color.rgb(70, 95, 120));
        c.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        c.setLayoutParams(cp);

        String star = favoriteLeagueKeys.contains(leagueKey(g)) ? "★ " : "";
        c.addView(text(g.bucket + " • " + star + leagueDisplay(g) + " • " + g.time + " • " + g.status, 11, MUTED, false));
        TextView teams = text(g.home + "  ×  " + g.away, 18, TEXT, true);
        teams.setPadding(0, dp(5), 0, dp(5));
        c.addView(teams);

        if (!"-".equals(g.score)) c.addView(text("Placar: " + g.score, 13, TEXT, true));

        if (!g.analyzed) {
            TextView action = text("◉ TOQUE PARA ANALISAR", 14, Color.rgb(90, 190, 255), true);
            action.setPadding(0, dp(7), 0, dp(4));
            c.addView(action);
            c.addView(text("A previsão será consultada somente para este jogo.", 12, MUTED, false));
        } else {
            c.addView(text(label(g.confidence) + "  " + g.confidence + "%", 15, riskColor(g.confidence), true));
            TextView pick = text("Palpite principal: " + g.pick, 13, TEXT, true);
            pick.setPadding(0, dp(7), 0, dp(3));
            c.addView(pick);
            c.addView(text(g.trend, 13, MUTED, false));
            TextView probs = text("Mandante " + g.homePct + "%  •  Empate " + g.drawPct + "%  •  Visitante " + g.awayPct + "%", 12, MUTED, false);
            probs.setPadding(0, dp(4), 0, 0);
            c.addView(probs);
        }

        c.setOnClickListener(v -> analyze(g));
        return c;
    }

    private void showChampionshipsDialog() {
        if (games.isEmpty()) {
            Toast.makeText(this, "Carregue os jogos primeiro.", Toast.LENGTH_SHORT).show();
            return;
        }

        LinkedHashMap<String, LeagueInfo> map = new LinkedHashMap<>();
        for (Game g : games) {
            String key = leagueKey(g);
            LeagueInfo info = map.get(key);
            if (info == null) {
                info = new LeagueInfo(key, leagueDisplay(g));
                map.put(key, info);
            }
            info.count++;
        }

        List<LeagueInfo> leagues = new ArrayList<>(map.values());
        leagues.sort((a, b) -> a.label.compareToIgnoreCase(b.label));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(6));
        final AlertDialog[] holder = new AlertDialog[1];

        TextView all = dialogRowText("Todos os campeonatos  •  " + games.size() + " jogos");
        all.setOnClickListener(v -> {
            selectedLeagueKey = null;
            selectedLeagueLabel = null;
            favoritesOnly = false;
            if (holder[0] != null) holder[0].dismiss();
            render();
        });
        box.addView(all);

        for (LeagueInfo info : leagues) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView title = dialogRowText(info.label + "  •  " + info.count + (info.count == 1 ? " jogo" : " jogos"));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            title.setLayoutParams(tp);
            title.setOnClickListener(v -> {
                selectedLeagueKey = info.key;
                selectedLeagueLabel = info.label;
                favoritesOnly = false;
                if (holder[0] != null) holder[0].dismiss();
                render();
            });
            row.addView(title);

            Button star = new Button(this);
            star.setAllCaps(false);
            star.setText(favoriteLeagueKeys.contains(info.key) ? "★" : "☆");
            star.setTextSize(20);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(60), dp(50));
            star.setLayoutParams(bp);
            star.setOnClickListener(v -> {
                if (favoriteLeagueKeys.contains(info.key)) favoriteLeagueKeys.remove(info.key);
                else favoriteLeagueKeys.add(info.key);
                saveFavoriteLeagues();
                star.setText(favoriteLeagueKeys.contains(info.key) ? "★" : "☆");
                render();
            });
            row.addView(star);
            box.addView(row);
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Campeonatos")
                .setMessage("Toque no campeonato para filtrar. Toque em ☆ para adicionar aos favoritos.")
                .setView(sv)
                .setNegativeButton("Fechar", null)
                .create();
        holder[0] = dialog;
        dialog.show();
    }

    private void showFavoriteChampionships() {
        if (favoriteLeagueKeys.isEmpty()) {
            Toast.makeText(this, "Você ainda não favoritou campeonatos. Escolha em Campeonatos.", Toast.LENGTH_LONG).show();
            showChampionshipsDialog();
            return;
        }
        selectedLeagueKey = null;
        selectedLeagueLabel = null;
        favoritesOnly = true;
        render();
    }

    private String activeFilterText() {
        StringBuilder sb = new StringBuilder();
        if (selectedLeagueKey != null && selectedLeagueLabel != null) sb.append("Campeonato: ").append(selectedLeagueLabel).append("\n");
        else if (favoritesOnly) sb.append("Campeonatos favoritos\n");
        return sb.toString();
    }

    private String leagueKey(Game g) {
        if (g.leagueId > 0) return "id:" + g.leagueId;
        return "name:" + g.leagueCountry + "|" + g.league;
    }

    private String leagueDisplay(Game g) {
        if (g.leagueCountry == null || g.leagueCountry.trim().isEmpty()) return g.league;
        return g.league + " • " + g.leagueCountry;
    }

    private void loadFavoriteLeagues() {
        Set<String> saved = getPreferences(MODE_PRIVATE).getStringSet("favorite_leagues", null);
        if (saved != null) favoriteLeagueKeys.addAll(saved);
    }

    private void saveFavoriteLeagues() {
        getPreferences(MODE_PRIVATE).edit().putStringSet("favorite_leagues", new HashSet<>(favoriteLeagueKeys)).apply();
    }

    private TextView dialogRowText(String value) {
        TextView t = text(value, 14, Color.DKGRAY, false);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12), 0, dp(8), 0);
        return t;
    }

    private void showDetail(Game g) {
        String msg = g.home + " × " + g.away + "\nCampeonato: " + leagueDisplay(g) + "\nFaixa: " + g.bucket + "\nHorário: " + g.time + "\nStatus: " + g.status + "\n" +
                ("-".equals(g.score) ? "" : ("Placar: " + g.score + "\n")) +
                "\nPalpite principal: " + g.pick + "\n" + g.trend + "\nConfiança combinada: " + g.confidence + "%\n\n" +
                g.reason + "\n\nProbabilidades: " + g.homePct + "% / " + g.drawPct + "% / " + g.awayPct + "%";
        new AlertDialog.Builder(this)
                .setTitle("Análise da partida")
                .setMessage(msg)
                .setPositiveButton("Copiar análise", (d, w) -> copy(msg))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(text("Informe sua chave da API-Football (API-Sports). Ela fica salva apenas neste aparelho.", 13, Color.DKGRAY, false));
        EditText input = new EditText(this);
        input.setHint("x-apisports-key");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setText(getPreferences(MODE_PRIVATE).getString("api_key", ""));
        box.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("Modo online")
                .setView(box)
                .setPositiveButton("Salvar e atualizar", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().putString("api_key", input.getText().toString().trim()).apply();
                    lastRefreshAt = 0L;
                    load(false);
                })
                .setNeutralButton("Usar demonstração", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().remove("api_key").apply();
                    load(false);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private List<Game> demoGames() {
        List<Game> d = new ArrayList<>();
        d.add(demo(71, "HOJE", "Brasileirão Série A", "Brazil", "Palmeiras", "Bahia", "19:30", "AGENDADO", "-", 62,22,16));
        d.add(demo(71, "HOJE", "Brasileirão Série A", "Brazil", "Flamengo", "Fortaleza", "21:30", "AGENDADO", "-", 55,26,19));
        d.add(demo(39, "AO VIVO", "Premier League", "England", "Arsenal", "Everton", "16:00", "AO VIVO 2T • 77'", "2 x 0", 69,20,11));
        d.add(new Game(4, 140, "PRÓXIMO", "La Liga", "Spain", "Real Sociedad", "Villarreal", "17:00", "AGENDADO", "-"));
        d.add(new Game(5, 135, "PRÓXIMO", "Serie A", "Italy", "Torino", "Udinese", "15:45", "AGENDADO", "-"));
        return d;
    }

    private Game demo(int leagueId, String bucket, String l, String country, String h, String a, String t, String s, String score, int hp, int dpct, int ap) {
        Game g = new Game(0, leagueId, bucket, l, country, h, a, t, s, score);
        AnalysisEngine.Result r = AnalysisEngine.evaluate(hp, dpct, ap);
        g.applyAnalysis(hp, dpct, ap, r);
        return g;
    }

    private String friendlyError(String msg) {
        if (msg == null) return "erro desconhecido da API";
        String low = msg.toLowerCase(Locale.ROOT);
        if (low.contains("next parameter") || low.contains("free plans do not have access"))
            return "parâmetro não permitido no plano gratuito.";
        if (low.contains("from field") || low.contains("to field"))
            return "a API recusou o filtro por intervalo. Esta versão usa somente consultas por data.";
        if (low.contains("too many requests") || low.contains("rate") || low.contains("429"))
            return "limite temporário de chamadas atingido. Aguarde um pouco e tente novamente.";
        return msg;
    }

    private int riskColor(int c) { return c >= 70 ? Color.rgb(39, 211, 123) : (c >= 55 ? Color.rgb(255, 193, 7) : Color.rgb(255, 82, 82)); }
    private String label(int c) { return c >= 70 ? "● FAVORÁVEL" : (c >= 55 ? "● ATENÇÃO" : "● DUVIDOSO"); }
    private void copy(String s) {
        ((android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Análise J.Pastore", s));
        Toast.makeText(this, "Análise copiada", Toast.LENGTH_SHORT).show();
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0, 1.08f);
        return t;
    }
    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }
    private Button rowButton(String s, View.OnClickListener l) {
        Button b = button(s, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.setMargins(dp(2), dp(3), dp(2), dp(3));
        b.setLayoutParams(lp);
        return b;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }

    private static class LeagueInfo {
        final String key, label;
        int count = 0;
        LeagueInfo(String key, String label) { this.key = key; this.label = label; }
    }
}
