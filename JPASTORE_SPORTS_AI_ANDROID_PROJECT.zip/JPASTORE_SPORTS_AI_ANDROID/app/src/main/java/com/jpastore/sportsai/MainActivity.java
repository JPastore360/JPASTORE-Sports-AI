package com.jpastore.sportsai;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.widget.*;import androidx.work.*;import java.util.concurrent.TimeUnit;
public class MainActivity extends Activity{
 PremiumView ui;
 @Override public void onBackPressed(){if(ui!=null&&ui.handleBack())return;super.onBackPressed();}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(2,10,14));getWindow().setNavigationBarColor(Color.rgb(2,10,14));ui=new PremiumView(this);setContentView(ui);scheduleInternetSync();}
 public void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
 public void searchDialog(){final EditText e=new EditText(this);e.setHint("Time ou campeonato");new AlertDialog.Builder(this).setTitle("Buscar futebol").setView(e).setPositiveButton("BUSCAR",(d,w)->ui.searchGlobal(e.getText().toString().trim())).setNegativeButton("CANCELAR",null).show();}
 public void aiDialog(){final EditText e=new EditText(this);e.setHint("Ex.: Quem chega melhor e por quê?");new AlertDialog.Builder(this).setTitle("Perguntar à J.Pastore AI").setView(e).setPositiveButton("ANALISAR",(d,w)->ui.askAi(e.getText().toString().trim())).setNegativeButton("CANCELAR",null).show();}
 public void infoDialog(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}
 public void shareTicket(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"J.Pastore Sports AI • Bilhete para revisão. Probabilidades são estimativas e não garantias.");startActivity(Intent.createChooser(i,"Compartilhar bilhete"));}
 public void scheduleInternetSync(){Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest r=new PeriodicWorkRequest.Builder(BackgroundSyncWorker.class,6,TimeUnit.HOURS).setConstraints(c).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("jpastore-internet-sync",ExistingPeriodicWorkPolicy.UPDATE,r);}
 public String apiKey(){return getPreferences(0).getString("api","");}
}
