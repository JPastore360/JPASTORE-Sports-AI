package com.jpastore.sportsai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 12, 22);
    private final int PANEL = Color.rgb(16, 24, 38);
    private final int CARD = Color.rgb(20, 30, 46);
    private final int TEXT = Color.rgb(244, 247, 251);
    private final int MUTED = Color.rgb(155, 169, 189);
    private final int GREEN = Color.rgb(61, 214, 135);
    private final int BLUE = Color.rgb(85, 173, 255);
    private final int YELLOW = Color.rgb(255, 193, 7);
    private final int RED = Color.rgb(255, 88, 88);

    private LinearLayout contentList, championshipTabs;
    private TextView statusText, summaryText, sectionTitle;
    private Button refreshButton;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService imageExecutor = Executors.newFixedThreadPool(3);
    private final Map<String, Bitmap> imageCache = Collections.synchronizedMap(new HashMap<>());

    private List<Game> games = new ArrayList<>();
    private int timeFilter = 0; // 0 all/today, 1 favorable, 2 live, 3 today, 4 upcoming
    private int screen = 0; // 0 home, 1 matches, 2 analyses
    private boolean upcomingLoaded = false;
    private boolean upcomingLoading = false;
    private long lastRefreshAt = 0L;
    private String selectedLeagueKey = null;
    private final Set<String> favoriteLeagueKeys = new LinkedHashSet<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        loadFavoriteLeagues();
        buildUI();
        loadToday(false);
    }

    private void buildUI() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("J.Pastore Sports AI", 25, TEXT, true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        titleRow.addView(title);
        TextView v8 = pill("V8 • RADAR IA", GREEN, BG);
        titleRow.addView(v8);
        root.addView(titleRow);
        root.addView(text("Criado e desenvolvido por J.Pastore", 12, MUTED, false));

        statusText = text("Carregando…", 12, MUTED, false);
        statusText.setPadding(0, dp(5), 0, dp(12));
        root.addView(statusText);

        ImageView hero = new ImageView(this);
        hero.setImageResource(getResources().getIdentifier("header_football", "drawable", getPackageName()));
        hero.setAdjustViewBounds(true);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.setClipToOutline(true);
        GradientDrawable heroBg = roundedGradient(new int[]{Color.rgb(10, 28, 44), Color.rgb(17, 36, 55)}, 22, 0, 0);
        hero.setBackground(heroBg);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(145));
        hp.setMargins(0, 0, 0, dp(12));
        root.addView(hero, hp);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(rowButton("Hoje", v -> { timeFilter = 3; screen = 1; render(); }));
        quick.addView(rowButton("Próximos", v -> loadUpcoming()));
        quick.addView(rowButton("Ao vivo", v -> { timeFilter = 2; screen = 1; render(); }));
        root.addView(quick);

        LinearLayout quick2 = new LinearLayout(this);
        quick2.setOrientation(LinearLayout.HORIZONTAL);
        quick2.addView(rowButton("Favoráveis", v -> { timeFilter = 1; screen = 2; render(); }));
        quick2.addView(rowButton("Todos", v -> { timeFilter = 0; selectedLeagueKey = null; screen = 1; render(); }));
        refreshButton = rowButton("Atualizar", v -> loadToday(true));
        quick2.addView(refreshButton);
        root.addView(quick2);

        TextView champLabel = text("Campeonatos", 16, TEXT, true);
        champLabel.setPadding(0, dp(16), 0, dp(7));
        root.addView(champLabel);
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        championshipTabs = new LinearLayout(this);
        championshipTabs.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(championshipTabs);
        root.addView(hsv);

        summaryText = text("", 13, MUTED, false);
        summaryText.setPadding(0, dp(14), 0, dp(4));
        root.addView(summaryText);

        sectionTitle = text("", 21, TEXT, true);
        sectionTitle.setPadding(0, dp(8), 0, dp(10));
        root.addView(sectionTitle);

        contentList = new LinearLayout(this);
        contentList.setOrientation(LinearLayout.VERTICAL);
        root.addView(contentList);

        Button settings = accentButton("Configurar API", BLUE, v -> showSettings());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(50));
        sp.setMargins(0, dp(18), 0, dp(8));
        root.addView(settings, sp);
        root.addView(text("Análises probabilísticas e informativas. Escanteios/laterais podem usar estimativas locais quando a fonte não fornece média pré-jogo direta. Não há garantia de resultado.", 11, MUTED, false));

        outer.addView(bottomNav(), new LinearLayout.LayoutParams(-1, dp(68)));
        setContentView(outer);
    }

    private View bottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(7), dp(8), dp(7));
        nav.setBackgroundColor(Color.rgb(11, 17, 28));
        nav.addView(navButton("⌂\nInício", v -> { screen = 0; timeFilter = 0; render(); }));
        nav.addView(navButton("⚽\nPartidas", v -> { screen = 1; render(); }));
        nav.addView(navButton("✦\nAnálises", v -> { screen = 2; render(); }));
        return nav;
    }

    private Button navButton(String label, View.OnClickListener l) {
        Button b = button(label, l);
        b.setTextSize(11);
        b.setTextColor(TEXT);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setPadding(0, 0, 0, 0);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1f));
        return b;
    }

    private void loadToday(boolean manual) {
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            games = demoGames();
            upcomingLoaded = true;
            statusText.setText("MODO DEMONSTRAÇÃO • configure sua API para partidas reais");
            render();
            return;
        }
        long now = System.currentTimeMillis();
        if (manual && lastRefreshAt > 0 && now - lastRefreshAt < 65000L) {
            long wait = (65000L - (now - lastRefreshAt) + 999L) / 1000L;
            Toast.makeText(this, "Aguarde " + wait + "s para atualizar novamente.", Toast.LENGTH_SHORT).show();
            return;
        }
        refreshButton.setEnabled(false);
        statusText.setText("Carregando jogos e organizando destaques…");
        executor.execute(() -> {
            try {
                List<Game> loaded = client.loadToday();
                runOnUiThread(() -> {
                    games = loaded;
                    upcomingLoaded = false;
                    lastRefreshAt = System.currentTimeMillis();
                    refreshButton.setEnabled(true);
                    String quota = client.getRemaining() >= 0 ? " • cota " + client.getRemaining() : "";
                    statusText.setText("ONLINE • " + loaded.size() + " jogos hoje" + quota + " • ranking local de relevância ativo");
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    refreshButton.setEnabled(true);
                    games = new ArrayList<>();
                    statusText.setText("Falha online: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void loadUpcoming() {
        timeFilter = 4;
        screen = 1;
        if (upcomingLoaded) { render(); return; }
        if (upcomingLoading) { Toast.makeText(this, "Próximos jogos já estão sendo carregados.", Toast.LENGTH_SHORT).show(); return; }
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) { render(); return; }
        upcomingLoading = true;
        statusText.setText("Carregando os próximos 3 dias…");
        executor.execute(() -> {
            try {
                List<Game> next = client.loadUpcomingDays(3);
                runOnUiThread(() -> {
                    LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();
                    for (Game g : games) merged.put(g.fixtureId, g);
                    for (Game g : next) if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
                    games = new ArrayList<>(merged.values());
                    upcomingLoaded = true;
                    upcomingLoading = false;
                    statusText.setText("ONLINE • próximos 3 dias: " + next.size() + " jogos carregados");
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    upcomingLoading = false;
                    statusText.setText("Falha nos próximos jogos: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void analyze(Game g) {
        if (g.analyzed && g.analysis != null) { showDeepDetail(g); return; }
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            Toast.makeText(this, "Configure a API para análise real.", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Análise aprofundada");
        pd.setMessage("Cruzando previsão, forma, ataque/defesa e estatísticas da temporada. Pode levar cerca de 15–25 segundos…");
        pd.setCancelable(false);
        pd.show();

        executor.execute(() -> {
            try {
                DeepAnalysis d = client.loadDeepAnalysis(g);
                runOnUiThread(() -> {
                    if (pd.isShowing()) pd.dismiss();
                    g.applyAnalysis(d);
                    render();
                    showDeepDetail(g);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (pd.isShowing()) pd.dismiss();
                    new AlertDialog.Builder(this).setTitle("Análise indisponível")
                            .setMessage(friendlyError(e.getMessage()))
                            .setPositiveButton("OK", null).show();
                });
            }
        });
    }

    private void render() {
        renderChampionshipTabs();
        contentList.removeAllViews();
        List<Game> visible = visibleGames();
        int analyzed = 0, favorable = 0;
        for (Game g : visible) if (g.analyzed && g.analysis != null) {
            analyzed++;
            if (g.analysis.confidence >= 70) favorable++;
        }
        summaryText.setText(visible.size() + " partidas • " + analyzed + " analisadas • " + favorable + " com sinal forte");

        if (screen == 0) renderHome(visible);
        else if (screen == 2) renderAnalyses(visible);
        else renderMatches(visible);
    }

    private void renderHome(List<Game> visible) {
        sectionTitle.setText("Melhores jogos do dia");
        List<Game> featured = new ArrayList<>(visible);
        featured.sort((a, b) -> Integer.compare(b.relevanceScore, a.relevanceScore));
        int max = Math.min(8, featured.size());
        for (int i = 0; i < max; i++) contentList.addView(matchCard(featured.get(i), true));
        if (max == 0) contentList.addView(emptyText("Nenhum jogo disponível no filtro atual."));

        if (!visible.isEmpty()) {
            TextView h = text("Por campeonato", 20, TEXT, true);
            h.setPadding(0, dp(18), 0, dp(8));
            contentList.addView(h);
            renderGrouped(visible, 4);
        }
    }

    private void renderMatches(List<Game> visible) {
        sectionTitle.setText(selectedLeagueKey == null ? "Partidas por campeonato" : "Partidas do campeonato selecionado");
        renderGrouped(visible, Integer.MAX_VALUE);
        if (visible.isEmpty()) contentList.addView(emptyText(timeFilter == 4 && !upcomingLoaded ? "Toque em Próximos para carregar os próximos 3 dias." : "Nenhuma partida neste filtro."));
    }

    private void renderAnalyses(List<Game> visible) {
        sectionTitle.setText("Radar de análises");
        List<Game> analyzed = new ArrayList<>();
        for (Game g : visible) if (g.analyzed && g.analysis != null) analyzed.add(g);
        analyzed.sort((a, b) -> Integer.compare(b.analysis.confidence, a.analysis.confidence));
        for (Game g : analyzed) contentList.addView(matchCard(g, true));
        if (analyzed.isEmpty()) contentList.addView(emptyText("Nenhuma análise gerada ainda. Toque em uma partida para criar a análise profunda."));
    }

    private void renderGrouped(List<Game> visible, int maxGroups) {
        LinkedHashMap<String, List<Game>> grouped = new LinkedHashMap<>();
        List<Game> sorted = new ArrayList<>(visible);
        sorted.sort((a, b) -> {
            int c = Integer.compare(leaguePriority(a), leaguePriority(b));
            if (c != 0) return c;
            c = Integer.compare(b.relevanceScore, a.relevanceScore);
            return c != 0 ? c : a.time.compareTo(b.time);
        });
        for (Game g : sorted) grouped.computeIfAbsent(leagueKey(g), k -> new ArrayList<>()).add(g);
        int groups = 0;
        for (List<Game> group : grouped.values()) {
            if (groups++ >= maxGroups) break;
            Game first = group.get(0);
            contentList.addView(championshipHeader(first, group.size()));
            for (Game g : group) contentList.addView(matchCard(g, false));
        }
    }

    private List<Game> visibleGames() {
        List<Game> out = new ArrayList<>();
        for (Game g : games) {
            if (timeFilter == 1 && (!g.analyzed || g.analysis == null || g.analysis.confidence < 70)) continue;
            if (timeFilter == 2 && !"AO VIVO".equals(g.bucket)) continue;
            if (timeFilter == 3 && !("HOJE".equals(g.bucket) || "AO VIVO".equals(g.bucket))) continue;
            if (timeFilter == 4 && !"PRÓXIMO".equals(g.bucket)) continue;
            if (selectedLeagueKey != null && !selectedLeagueKey.equals(leagueKey(g))) continue;
            out.add(g);
        }
        return out;
    }

    private void renderChampionshipTabs() {
        championshipTabs.removeAllViews();
        List<Game> mode = new ArrayList<>();
        for (Game g : games) {
            if (timeFilter == 2 && !"AO VIVO".equals(g.bucket)) continue;
            if (timeFilter == 3 && !("HOJE".equals(g.bucket) || "AO VIVO".equals(g.bucket))) continue;
            if (timeFilter == 4 && !"PRÓXIMO".equals(g.bucket)) continue;
            mode.add(g);
        }
        championshipTabs.addView(championshipChip((selectedLeagueKey == null ? "✓ " : "") + "Todos", v -> { selectedLeagueKey = null; render(); }));

        LinkedHashMap<String, LeagueInfo> map = new LinkedHashMap<>();
        for (Game g : mode) {
            String k = leagueKey(g);
            LeagueInfo info = map.get(k);
            if (info == null) { info = new LeagueInfo(k, leagueDisplay(g), leaguePriority(g)); map.put(k, info); }
            info.count++;
        }
        List<LeagueInfo> infos = new ArrayList<>(map.values());
        infos.sort((a, b) -> a.priority != b.priority ? Integer.compare(a.priority, b.priority) : a.label.compareToIgnoreCase(b.label));
        for (LeagueInfo info : infos) {
            String prefix = info.key.equals(selectedLeagueKey) ? "✓ " : "";
            championshipTabs.addView(championshipChip(prefix + info.label + " (" + info.count + ")", v -> { selectedLeagueKey = info.key; screen = 1; render(); }));
        }
    }

    private View matchCard(Game g, boolean premium) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        int stroke = g.analyzed && g.analysis != null ? riskColor(g.analysis.confidence) : Color.rgb(61, 78, 104);
        int[] gradient = premium ? new int[]{Color.rgb(25, 28, 42), Color.rgb(15, 28, 40)} : new int[]{CARD, CARD};
        card.setBackground(roundedGradient(gradient, 18, 1, stroke));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        String leagueLine = g.bucket + " • " + g.time + " • " + g.status;
        TextView meta = text(leagueLine, 11, MUTED, false);
        meta.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(meta);
        if (g.relevanceScore >= 120) top.addView(pill("DESTAQUE", GREEN, BG));
        card.addView(top);

        if (premium) {
            LinearLayout duel = new LinearLayout(this);
            duel.setOrientation(LinearLayout.HORIZONTAL);
            duel.setGravity(Gravity.CENTER);
            duel.setPadding(0, dp(12), 0, dp(8));
            duel.addView(teamBlock(g.home, g.homeLogo), new LinearLayout.LayoutParams(0, -2, 1f));
            TextView versus = text("VS", 14, MUTED, true);
            versus.setGravity(Gravity.CENTER);
            duel.addView(versus, new LinearLayout.LayoutParams(dp(48), -2));
            duel.addView(teamBlock(g.away, g.awayLogo), new LinearLayout.LayoutParams(0, -2, 1f));
            card.addView(duel);
        } else {
            TextView teams = text(g.home + "  ×  " + g.away, 18, TEXT, true);
            teams.setPadding(0, dp(6), 0, dp(4));
            card.addView(teams);
        }

        if (!"-".equals(g.score)) card.addView(text("Placar: " + g.score, 13, TEXT, true));

        if (!g.analyzed || g.analysis == null) {
            TextView call = text("✦ ANALISAR CONFRONTO", 13, GREEN, true);
            call.setPadding(0, dp(8), 0, dp(3));
            card.addView(call);
            card.addView(text("Previsão + forma + ataque/defesa + dados de temporada + modelo local", 11, MUTED, false));
        } else {
            DeepAnalysis a = g.analysis;
            LinearLayout signal = new LinearLayout(this);
            signal.setOrientation(LinearLayout.HORIZONTAL);
            signal.setGravity(Gravity.CENTER_VERTICAL);
            TextView pick = text(a.primaryPick, 16, TEXT, true);
            pick.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            signal.addView(pick);
            signal.addView(pill(a.confidence + "%", riskColor(a.confidence), BG));
            signal.setPadding(0, dp(8), 0, dp(4));
            card.addView(signal);
            card.addView(text(a.trend, 12, MUTED, false));
            int shown = 0;
            for (DeepAnalysis.MarketSignal m : a.markets) {
                if (shown++ >= 3) break;
                card.addView(text("• " + m.title + ": " + m.signal + "  (" + m.confidence + "%)", 12, TEXT, false));
            }
        }
        card.setOnClickListener(v -> analyze(g));
        return card;
    }

    private View teamBlock(String name, String logoUrl) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        box.addView(logo, new LinearLayout.LayoutParams(dp(58), dp(58)));
        TextView nm = text(name, 13, TEXT, true);
        nm.setGravity(Gravity.CENTER);
        nm.setMaxLines(2);
        box.addView(nm);
        loadLogo(logoUrl, logo);
        return box;
    }

    private View championshipHeader(Game g, int count) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(13), dp(10), dp(10), dp(10));
        box.setBackground(roundedGradient(new int[]{Color.rgb(13, 45, 43), Color.rgb(19, 37, 52)}, 14, 1, Color.rgb(45, 120, 105)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(9), 0, dp(8));
        box.setLayoutParams(lp);
        TextView title = text(leagueDisplay(g) + " • " + count + (count == 1 ? " jogo" : " jogos"), 15, TEXT, true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(title);
        Button star = new Button(this);
        star.setText(favoriteLeagueKeys.contains(leagueKey(g)) ? "★" : "☆");
        star.setAllCaps(false);
        star.setTextSize(18);
        star.setTextColor(YELLOW);
        star.setBackgroundColor(Color.TRANSPARENT);
        star.setOnClickListener(v -> {
            String k = leagueKey(g);
            if (favoriteLeagueKeys.contains(k)) favoriteLeagueKeys.remove(k); else favoriteLeagueKeys.add(k);
            saveFavoriteLeagues();
            render();
        });
        box.addView(star, new LinearLayout.LayoutParams(dp(52), dp(44)));
        return box;
    }

    private void showDeepDetail(Game g) {
        DeepAnalysis a = g.analysis;
        if (a == null) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(12), dp(18), dp(18));
        box.setBackgroundColor(BG);
        scroll.addView(box);

        box.addView(pill("ANÁLISE PROFUNDA • " + leagueDisplay(g), GREEN, BG));
        LinearLayout duel = new LinearLayout(this);
        duel.setOrientation(LinearLayout.HORIZONTAL);
        duel.setGravity(Gravity.CENTER);
        duel.setPadding(0, dp(18), 0, dp(12));
        duel.addView(teamBlock(g.home, g.homeLogo), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView vs = text("VS", 16, MUTED, true); vs.setGravity(Gravity.CENTER);
        duel.addView(vs, new LinearLayout.LayoutParams(dp(48), -2));
        duel.addView(teamBlock(g.away, g.awayLogo), new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(duel);

        LinearLayout headline = new LinearLayout(this);
        headline.setOrientation(LinearLayout.HORIZONTAL);
        headline.setGravity(Gravity.CENTER_VERTICAL);
        TextView mainPick = text("Sinal principal: " + a.primaryPick, 18, TEXT, true);
        mainPick.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        headline.addView(mainPick);
        headline.addView(pill(a.confidence + "%", riskColor(a.confidence), BG));
        box.addView(headline);
        box.addView(text(a.trend, 13, MUTED, false));
        if (!a.apiAdvice.isEmpty()) box.addView(infoBox("Leitura da fonte", a.apiAdvice, BLUE));

        addSection(box, "Probabilidades");
        box.addView(probabilityBar("Mandante", a.homePct, GREEN));
        box.addView(probabilityBar("Empate", a.drawPct, YELLOW));
        box.addView(probabilityBar("Visitante", a.awayPct, BLUE));

        addSection(box, "Mercados com sinal estatístico");
        for (DeepAnalysis.MarketSignal m : a.markets) box.addView(marketCard(m));

        addSection(box, "Comparativo de força");
        box.addView(compareRow("Forma", a.formHome, a.formAway));
        box.addView(compareRow("Ataque", a.attackHome, a.attackAway));
        box.addView(compareRow("Defesa", a.defenseHome, a.defenseAway));
        box.addView(compareRow("Poisson", a.poissonHome, a.poissonAway));
        box.addView(compareRow("H2H", a.h2hHome, a.h2hAway));
        box.addView(compareRow("Total", a.comparisonTotalHome, a.comparisonTotalAway));

        addSection(box, "Temporada");
        box.addView(teamSeasonCard(g.home, a.homeProfile));
        box.addView(teamSeasonCard(g.away, a.awayProfile));

        addSection(box, "Leitura do modelo J.Pastore");
        box.addView(infoBox(a.dataQuality, a.modelReading, GREEN));

        TextView disclaimer = text("Escanteios e laterais podem ser estimativas locais, com confiança menor. Use os percentuais como apoio estatístico, não como garantia de resultado.", 11, MUTED, false);
        disclaimer.setPadding(0, dp(12), 0, 0);
        box.addView(disclaimer);

        String copy = analysisText(g);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(scroll)
                .setPositiveButton("Copiar análise", (d, w) -> copy(copy))
                .setNegativeButton("Fechar", null)
                .create();
        dialog.setOnShowListener(x -> {
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            if (pos != null) pos.setTextColor(GREEN);
        });
        dialog.show();
        Window win = dialog.getWindow();
        if (win != null) win.setLayout(-1, (int)(getResources().getDisplayMetrics().heightPixels * 0.88));
    }

    private View marketCard(DeepAnalysis.MarketSignal m) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setBackground(roundedGradient(new int[]{PANEL, Color.rgb(17, 31, 39)}, 14, 1, Color.rgb(45, 62, 80)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(7));
        box.setLayoutParams(lp);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = text(m.title, 13, TEXT, true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(title);
        row.addView(pill(m.confidence + "%", riskColor(m.confidence), BG));
        box.addView(row);
        box.addView(text(m.signal, 15, GREEN, true));
        box.addView(text(m.source, 10, MUTED, false));
        return box;
    }

    private View teamSeasonCard(String name, DeepAnalysis.TeamProfile p) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setBackground(roundedGradient(new int[]{PANEL, PANEL}, 14, 1, Color.rgb(42, 58, 78)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(7)); box.setLayoutParams(lp);
        box.addView(text(name, 14, TEXT, true));
        if (!p.hasUsefulData()) {
            box.addView(text("Estatísticas de temporada indisponíveis para esta competição.", 11, MUTED, false));
            return box;
        }
        box.addView(text("Jogos " + p.played + " • Vitórias " + p.wins + " • Empates " + p.draws + " • Derrotas " + p.losses, 11, MUTED, false));
        if (p.goalsForAvg >= 0) box.addView(text(String.format(Locale.US, "Gols/jogo %.2f • Sofridos/jogo %.2f", p.goalsForAvg, p.goalsAgainstAvg), 11, MUTED, false));
        if (p.yellowCardsAvg >= 0) box.addView(text(String.format(Locale.US, "Amarelos/jogo %.2f • Vermelhos/jogo %.2f", p.yellowCardsAvg, p.redCardsAvg), 11, MUTED, false));
        if (!p.form.isEmpty()) box.addView(text("Forma: " + p.form, 11, MUTED, false));
        return box;
    }

    private View compareRow(String label, int home, int away) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(4), 0, dp(4));
        TextView h = text(home > 0 ? home + "%" : "—", 12, GREEN, true); h.setGravity(Gravity.LEFT);
        TextView l = text(label, 12, MUTED, false); l.setGravity(Gravity.CENTER);
        TextView a = text(away > 0 ? away + "%" : "—", 12, BLUE, true); a.setGravity(Gravity.RIGHT);
        row.addView(h, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(l, new LinearLayout.LayoutParams(0, -2, 1.4f));
        row.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        return row;
    }

    private View probabilityBar(String label, int pct, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(4), 0, dp(4));
        LinearLayout row = new LinearLayout(this);
        TextView l = text(label, 11, MUTED, false); l.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(l);
        row.addView(text(pct + "%", 12, color, true));
        box.addView(row);
        ProgressBar p = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        p.setMax(100); p.setProgress(pct);
        p.setProgressTintList(ColorStateList.valueOf(color));
        p.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(35, 45, 60)));
        box.addView(p, new LinearLayout.LayoutParams(-1, dp(8)));
        return box;
    }

    private View infoBox(String title, String body, int accent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setBackground(roundedGradient(new int[]{Color.rgb(15, 25, 37), Color.rgb(15, 25, 37)}, 14, 1, accent));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(8), 0, dp(4)); box.setLayoutParams(lp);
        box.addView(text(title, 12, accent, true));
        box.addView(text(body, 12, TEXT, false));
        return box;
    }

    private void addSection(LinearLayout box, String name) {
        TextView h = text(name, 16, TEXT, true);
        h.setPadding(0, dp(16), 0, dp(7));
        box.addView(h);
    }

    private String analysisText(Game g) {
        DeepAnalysis a = g.analysis;
        StringBuilder sb = new StringBuilder();
        sb.append("J.Pastore Sports AI\n").append(g.home).append(" x ").append(g.away).append("\n");
        sb.append(leagueDisplay(g)).append(" • ").append(g.time).append("\n\n");
        sb.append("Sinal principal: ").append(a.primaryPick).append(" • confiança ").append(a.confidence).append("%\n");
        sb.append("Probabilidades: ").append(a.homePct).append("% / ").append(a.drawPct).append("% / ").append(a.awayPct).append("%\n\n");
        for (DeepAnalysis.MarketSignal m : a.markets) sb.append(m.title).append(": ").append(m.signal).append(" (").append(m.confidence).append("%)\n");
        sb.append("\n").append(a.modelReading).append("\n\nAnálise probabilística; não garante resultado.");
        return sb.toString();
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        TextView help = new TextView(this);
        help.setText("Informe a chave API-Football. A chave fica salva somente neste aparelho.");
        help.setTextSize(13); help.setTextColor(Color.DKGRAY); box.addView(help);
        EditText input = new EditText(this);
        input.setHint("x-apisports-key"); input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setText(getPreferences(MODE_PRIVATE).getString("api_key", ""));
        box.addView(input);
        new AlertDialog.Builder(this).setTitle("Modo online").setView(box)
                .setPositiveButton("Salvar e atualizar", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().putString("api_key", input.getText().toString().trim()).apply();
                    loadToday(false);
                })
                .setNeutralButton("Demonstração", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().remove("api_key").apply(); loadToday(false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private String leagueKey(Game g) { return g.leagueId > 0 ? String.valueOf(g.leagueId) : (g.leagueCountry + "|" + g.league).toLowerCase(Locale.ROOT); }

    private String leagueDisplay(Game g) {
        String n = (g.league + " " + g.leagueCountry).toLowerCase(Locale.ROOT);
        if (n.contains("serie a") && n.contains("brazil")) return "🇧🇷 Brasileirão Série A";
        if (n.contains("serie b") && n.contains("brazil")) return "🇧🇷 Brasileirão Série B";
        if (n.contains("copa do brasil")) return "🇧🇷 Copa do Brasil";
        if (n.contains("libertadores")) return "🌎 Libertadores";
        if (n.contains("sudamericana") || n.contains("sul-americana")) return "🌎 Sul-Americana";
        if (n.contains("champions")) return "🇪🇺 Champions League";
        if (n.contains("europa league")) return "🇪🇺 Europa League";
        if (n.contains("premier league")) return "🏴 Premier League";
        if (n.contains("la liga")) return "🇪🇸 La Liga";
        if (n.contains("bundesliga")) return "🇩🇪 Bundesliga";
        if (n.contains("serie a") && (n.contains("italy") || n.contains("italia"))) return "🇮🇹 Serie A";
        if (n.contains("ligue 1")) return "🇫🇷 Ligue 1";
        return (g.leagueCountry.isEmpty() ? "" : countryFlag(g.leagueCountry) + " ") + g.league;
    }

    private int leaguePriority(Game g) {
        String s = leagueDisplay(g).toLowerCase(Locale.ROOT);
        if (s.contains("brasileirão série a")) return 1;
        if (s.contains("copa do brasil")) return 2;
        if (s.contains("libertadores")) return 3;
        if (s.contains("champions")) return 4;
        if (s.contains("premier")) return 5;
        if (s.contains("la liga")) return 6;
        if (s.contains("bundesliga")) return 7;
        if (s.contains("serie a")) return 8;
        if (s.contains("ligue 1")) return 9;
        if (s.contains("sul-americana")) return 10;
        return 30;
    }

    private String countryFlag(String c) {
        String x = c.toLowerCase(Locale.ROOT);
        if (x.contains("brazil")) return "🇧🇷";
        if (x.contains("england")) return "🏴";
        if (x.contains("spain")) return "🇪🇸";
        if (x.contains("italy")) return "🇮🇹";
        if (x.contains("germany")) return "🇩🇪";
        if (x.contains("france")) return "🇫🇷";
        if (x.contains("portugal")) return "🇵🇹";
        return "⚽";
    }

    private String friendlyError(String msg) {
        if (msg == null) return "erro desconhecido";
        String l = msg.toLowerCase(Locale.ROOT);
        if (l.contains("429") || l.contains("too many requests") || l.contains("rate")) return "limite temporário da API atingido; aguarde cerca de 1 minuto.";
        if (l.contains("key") || l.contains("token")) return "verifique sua chave da API.";
        return msg;
    }

    private List<Game> demoGames() {
        List<Game> d = new ArrayList<>();
        d.add(new Game(1, 71, 2026, 131, 118, "HOJE", "Serie A", "Brazil", "Corinthians", "Santos", "", "", "19:00", "AGENDADO", "-"));
        d.add(new Game(2, 140, 2026, 529, 530, "HOJE", "La Liga", "Spain", "Barcelona", "Atlético de Madrid", "", "", "16:30", "AGENDADO", "-"));
        d.add(new Game(3, 39, 2026, 42, 50, "HOJE", "Premier League", "England", "Arsenal", "Manchester City", "", "", "17:00", "AGENDADO", "-"));
        return d;
    }

    private void loadLogo(String url, ImageView target) {
        if (url == null || url.trim().isEmpty()) return;
        Bitmap cached = imageCache.get(url);
        if (cached != null) { target.setImageBitmap(cached); return; }
        imageExecutor.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(5000); c.connect();
                InputStream in = c.getInputStream(); Bitmap bm = BitmapFactory.decodeStream(in); in.close();
                if (bm != null) {
                    imageCache.put(url, bm);
                    runOnUiThread(() -> target.setImageBitmap(bm));
                }
            } catch(Exception ignored) {} finally { if (c != null) c.disconnect(); }
        });
    }

    private void loadFavoriteLeagues() {
        String raw = getPreferences(MODE_PRIVATE).getString("favorite_leagues", "");
        if (!raw.isEmpty()) for (String x : raw.split(",")) if (!x.trim().isEmpty()) favoriteLeagueKeys.add(x.trim());
    }
    private void saveFavoriteLeagues() { getPreferences(MODE_PRIVATE).edit().putString("favorite_leagues", android.text.TextUtils.join(",", favoriteLeagueKeys)).apply(); }

    private int riskColor(int c) { return c >= 70 ? GREEN : (c >= 55 ? YELLOW : RED); }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setLineSpacing(0, 1.08f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView pill(String s, int bgColor, int textColor) {
        TextView t = text(s, 10, textColor, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(9), dp(5), dp(9), dp(5));
        GradientDrawable bg = new GradientDrawable(); bg.setCornerRadius(dp(20)); bg.setColor(bgColor); t.setBackground(bg); return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this); b.setText(s); b.setTextSize(11); b.setAllCaps(false); b.setOnClickListener(l); return b;
    }
    private Button rowButton(String s, View.OnClickListener l) {
        Button b = button(s, l); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f); lp.setMargins(dp(2), dp(2), dp(2), dp(2)); b.setLayoutParams(lp); return b;
    }
    private Button championshipChip(String s, View.OnClickListener l) {
        Button b = button(s, l); b.setTextSize(11); b.setMinWidth(0); b.setMinimumWidth(0); b.setPadding(dp(12), 0, dp(12), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(42)); lp.setMargins(0, 0, dp(6), 0); b.setLayoutParams(lp); return b;
    }
    private Button accentButton(String s, int color, View.OnClickListener l) {
        Button b = button(s, l); b.setTextColor(Color.WHITE); GradientDrawable gd = new GradientDrawable(); gd.setCornerRadius(dp(14)); gd.setColor(color); b.setBackground(gd); return b;
    }
    private TextView emptyText(String s) { TextView t = text(s, 14, MUTED, false); t.setPadding(0, dp(12), 0, dp(12)); return t; }

    private GradientDrawable roundedGradient(int[] colors, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors); gd.setCornerRadius(dp(radiusDp)); if (strokeDp > 0) gd.setStroke(dp(strokeDp), strokeColor); return gd;
    }
    private void copy(String s) { ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Análise J.Pastore", s)); Toast.makeText(this, "Análise copiada", Toast.LENGTH_SHORT).show(); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static class LeagueInfo {
        final String key, label; final int priority; int count;
        LeagueInfo(String key, String label, int priority) { this.key = key; this.label = label; this.priority = priority; }
    }

    @Override protected void onDestroy() {
        super.onDestroy(); executor.shutdownNow(); imageExecutor.shutdownNow();
    }
}
