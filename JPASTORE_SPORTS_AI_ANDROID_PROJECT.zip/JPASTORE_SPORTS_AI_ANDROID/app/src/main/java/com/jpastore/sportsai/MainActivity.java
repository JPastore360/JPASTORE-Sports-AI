package com.jpastore.sportsai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView statusText, summaryText;
    private EditText searchInput;
    private String searchQuery = "";
    private Button refreshButton;
    private LinearLayout championshipTabs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private List<Game> games = new ArrayList<>();
    private int filter = 0;
    private long lastRefreshAt = 0L;
    private boolean upcomingLoaded = false;
    private boolean upcomingLoading = false;
    private String selectedLeagueKey = null;
    private String selectedLeagueLabel = null;
    private boolean favoritesOnly = false;
    private final Set<String> favoriteLeagueKeys = new LinkedHashSet<>();
    private final int BG = Color.rgb(7,17,31), CARD = Color.rgb(15,29,48), TEXT = Color.rgb(239,244,250), MUTED = Color.rgb(151,166,185);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadFavoriteLeagues();
        buildUI();
        load(false);
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        root.addView(text("J.Pastore Sports AI • V10", 26, TEXT, true));
        root.addView(text("Criado e desenvolvido por J.Pastore", 13, MUTED, false));
        statusText = text("Carregando…", 12, MUTED, false);
        statusText.setPadding(0, dp(5), 0, dp(12));
        root.addView(statusText);

        ImageView hero = new ImageView(this);
        hero.setImageResource(getResources().getIdentifier("header_football", "drawable", getPackageName()));
        hero.setAdjustViewBounds(true);
        hero.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable heroBg = new GradientDrawable();
        heroBg.setCornerRadius(dp(20));
        heroBg.setColor(CARD);
        hero.setBackground(heroBg);
        hero.setClipToOutline(true);
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, dp(160));
        heroLp.setMargins(0, 0, 0, dp(14));
        root.addView(hero, heroLp);

        searchInput = new EditText(this);
        searchInput.setHint("🔎 Buscar time ou campeonato...");
        searchInput.setHintTextColor(MUTED);
        searchInput.setTextColor(TEXT);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(15);
        searchInput.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setCornerRadius(dp(16));
        searchBg.setColor(Color.rgb(12, 27, 45));
        searchBg.setStroke(dp(1), Color.rgb(48, 83, 112));
        searchInput.setBackground(searchBg);
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(52));
        searchLp.setMargins(0, 0, 0, dp(10));
        root.addView(searchInput, searchLp);
        searchInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
                render();
            }
            public void afterTextChanged(Editable e) {}
        });

        LinearLayout nav1 = new LinearLayout(this);
        nav1.setOrientation(LinearLayout.HORIZONTAL);
        nav1.addView(rowButton("Todos", v -> {
            filter = 0;
            selectedLeagueKey = null;
            selectedLeagueLabel = null;
            favoritesOnly = false;
            render();
        }));
        nav1.addView(rowButton("Favoráveis", v -> { filter = 1; render(); }));
        nav1.addView(rowButton("Ao vivo", v -> { filter = 2; render(); }));
        root.addView(nav1);

        LinearLayout nav2 = new LinearLayout(this);
        nav2.setOrientation(LinearLayout.HORIZONTAL);
        nav2.addView(rowButton("Hoje", v -> { filter = 3; render(); }));
        nav2.addView(rowButton("Próximos", v -> loadUpcoming()));
        refreshButton = rowButton("Atualizar", v -> load(true));
        nav2.addView(refreshButton);
        root.addView(nav2);

        TextView championshipsTitle = text("Campeonatos", 16, TEXT, true);
        championshipsTitle.setPadding(0, dp(14), 0, dp(6));
        root.addView(championshipsTitle);

        HorizontalScrollView championshipScroll = new HorizontalScrollView(this);
        championshipScroll.setHorizontalScrollBarEnabled(false);
        championshipTabs = new LinearLayout(this);
        championshipTabs.setOrientation(LinearLayout.HORIZONTAL);
        championshipScroll.addView(championshipTabs);
        root.addView(championshipScroll);

        summaryText = text("", 14, TEXT, true);
        summaryText.setPadding(0, dp(16), 0, dp(10));
        root.addView(summaryText);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Button settings = button("Configurar API / modo online", v -> showSettings());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(48));
        sp.setMargins(0, dp(16), 0, dp(8));
        root.addView(settings, sp);

        root.addView(text("V10 combina previsões, comparativos, odds quando disponíveis e um motor estatístico local. As probabilidades são informativas, não garantias. O app não executa apostas nem acessa contas de casas de apostas.", 11, MUTED, false));
        setContentView(scroll);
    }

    private void load(boolean manual) {
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            games = demoGames();
            upcomingLoaded = true;
            statusText.setText("MODO DEMONSTRAÇÃO • configure sua API para partidas reais");
            render();
            return;
        }

        long nowMs = System.currentTimeMillis();
        if (manual && lastRefreshAt > 0 && nowMs - lastRefreshAt < 65000L) {
            long wait = (65000L - (nowMs - lastRefreshAt) + 999L) / 1000L;
            Toast.makeText(this, "Aguarde " + wait + "s para atualizar novamente.", Toast.LENGTH_SHORT).show();
            return;
        }

        statusText.setText("Carregando TODOS os jogos de hoje (00:00–23:59, horário de Brasília)…");
        refreshButton.setEnabled(false);
        executor.execute(() -> {
            try {
                List<Game> g = client.loadToday();
                runOnUiThread(() -> {
                    games = g;
                    upcomingLoaded = false;
                    upcomingLoading = false;
                    lastRefreshAt = System.currentTimeMillis();
                    refreshButton.setEnabled(true);
                    String now = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("ONLINE • HOJE 00:00–23:59 (Brasília): " + games.size() + " jogos • " + now + quota + " • lista completa do dia");
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    refreshButton.setEnabled(true);
                    games = new ArrayList<>();
                    upcomingLoaded = false;
                    upcomingLoading = false;
                    statusText.setText("Falha online: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void loadUpcoming() {
        filter = 4;
        if (upcomingLoaded) {
            render();
            return;
        }
        if (upcomingLoading) {
            Toast.makeText(this, "Os próximos jogos já estão sendo carregados.", Toast.LENGTH_SHORT).show();
            return;
        }

        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            render();
            return;
        }

        upcomingLoading = true;
        statusText.setText("Carregando próximos 3 dias… pode levar alguns segundos para respeitar o limite da API.");
        executor.execute(() -> {
            try {
                List<Game> upcoming = client.loadUpcomingDays(3);
                runOnUiThread(() -> {
                    LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();
                    for (Game g : games) merged.put(g.fixtureId, g);
                    for (Game g : upcoming) if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
                    games = new ArrayList<>(merged.values());
                    upcomingLoaded = true;
                    upcomingLoading = false;
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("ONLINE • próximos 3 dias carregados: " + upcoming.size() + " jogos" + quota);
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    upcomingLoading = false;
                    statusText.setText("Falha ao carregar próximos jogos: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void analyze(Game g) {
        if (g.analyzed) {
            showDetail(g);
            return;
        }
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            Toast.makeText(this, "Configure sua API primeiro.", Toast.LENGTH_SHORT).show();
            return;
        }
        statusText.setText("IA estatística analisando " + g.home + " × " + g.away + "… pode levar alguns segundos.");
        executor.execute(() -> {
            try {
                AdvancedAnalysis a = client.loadAdvancedAnalysis(g);
                g.applyAdvanced(a);
                runOnUiThread(() -> {
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("Análise concluída" + quota);
                    render();
                    showDetail(g);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusText.setText("Não foi possível analisar: " + friendlyError(e.getMessage()));
                    new AlertDialog.Builder(this)
                            .setTitle("Análise indisponível")
                            .setMessage(friendlyError(e.getMessage()))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        });
    }

    private void render() {
        list.removeAllViews();
        renderChampionshipTabs();

        List<Game> visible = new ArrayList<>();
        for (Game g : games) if (accept(g)) visible.add(g);

        int green = 0, yellow = 0, red = 0, analyzed = 0;
        for (Game g : visible) {
            if (!g.analyzed) continue;
            analyzed++;
            if (g.confidence >= 70) green++; else if (g.confidence >= 55) yellow++; else red++;
        }

        String filterText = activeFilterText();
        summaryText.setText(filterText + "Exibidos: " + visible.size() + " • Analisados: " + analyzed + "   🟢 " + green + "   🟡 " + yellow + "   🔴 " + red + "\nToque em uma partida para abrir a IA estatística e os mercados avançados.");

        visible.sort((a, b) -> {
            int c = Integer.compare(championshipPriority(leagueDisplay(a)), championshipPriority(leagueDisplay(b)));
            if (c != 0) return c;
            c = Integer.compare(teamPopularity(b), teamPopularity(a));
            if (c != 0) return c;
            c = a.time.compareTo(b.time);
            if (c != 0) return c;
            if (a.analyzed != b.analyzed) return a.analyzed ? -1 : 1;
            return Integer.compare(b.confidence, a.confidence);
        });

        LinkedHashMap<String, List<Game>> grouped = new LinkedHashMap<>();
        for (Game g : visible) {
            String key = leagueKey(g);
            List<Game> group = grouped.get(key);
            if (group == null) {
                group = new ArrayList<>();
                grouped.put(key, group);
            }
            group.add(g);
        }

        for (List<Game> group : grouped.values()) {
            if (group.isEmpty()) continue;
            Game first = group.get(0);
            list.addView(championshipHeader(first, group.size()));
            for (Game g : group) list.addView(card(g));
        }

        if (visible.isEmpty()) {
            String message;
            if (filter == 4 && !upcomingLoaded) message = "Toque em Próximos para carregar os próximos 3 dias.";
            else if (favoritesOnly && favoriteLeagueKeys.isEmpty()) message = "Nenhum campeonato favorito salvo.";
            else if (selectedLeagueKey != null) message = "Nenhuma partida deste campeonato no filtro atual.";
            else if (searchQuery != null && !searchQuery.isEmpty()) message = "Nenhum jogo encontrado para: " + searchQuery;
            else message = games.isEmpty() ? "Nenhuma partida retornada pela API agora." : "Nenhuma partida neste filtro.";
            list.addView(text(message, 14, MUTED, false));
        }
    }

    private void renderChampionshipTabs() {
        if (championshipTabs == null) return;
        championshipTabs.removeAllViews();

        List<Game> modeGames = new ArrayList<>();
        for (Game g : games) if (acceptMode(g)) modeGames.add(g);

        Button all = championshipChip((selectedLeagueKey == null && !favoritesOnly ? "✓ " : "") + "Todos (" + modeGames.size() + ")", v -> {
            selectedLeagueKey = null;
            selectedLeagueLabel = null;
            favoritesOnly = false;
            render();
        });
        championshipTabs.addView(all);

        LinkedHashMap<String, LeagueInfo> map = new LinkedHashMap<>();
        for (Game g : modeGames) {
            String key = leagueKey(g);
            LeagueInfo info = map.get(key);
            if (info == null) {
                info = new LeagueInfo(key, leagueDisplay(g));
                map.put(key, info);
            }
            info.count++;
        }

        List<LeagueInfo> leagues = new ArrayList<>(map.values());
        leagues.sort((a, b) -> championshipOrder(a.label, b.label));
        for (LeagueInfo info : leagues) {
            String prefix = info.key.equals(selectedLeagueKey) && !favoritesOnly ? "✓ " : "";
            Button chip = championshipChip(prefix + info.label + " (" + info.count + ")", v -> {
                selectedLeagueKey = info.key;
                selectedLeagueLabel = info.label;
                favoritesOnly = false;
                render();
            });
            championshipTabs.addView(chip);
        }

        if (!favoriteLeagueKeys.isEmpty()) {
            Button fav = championshipChip((favoritesOnly ? "✓ " : "") + "★ Favoritos", v -> showFavoriteChampionships());
            championshipTabs.addView(fav);
        }
    }

    private int championshipOrder(String a, String b) {
        int pa = championshipPriority(a);
        int pb = championshipPriority(b);
        if (pa != pb) return Integer.compare(pa, pb);
        return a.compareToIgnoreCase(b);
    }

    private int championshipPriority(String label) {
        String n = label.toLowerCase(Locale.ROOT);
        if (n.contains("brasileirão série a")) return 1;
        if (n.contains("brasileirão série b")) return 2;
        if (n.contains("copa do brasil")) return 3;
        if (n.contains("libertadores")) return 4;
        if (n.contains("sul-americana") || n.contains("sudamericana")) return 5;
        if (n.contains("champions")) return 6;
        if (n.contains("premier league")) return 7;
        if (n.contains("la liga")) return 8;
        if (n.contains("serie a") && n.contains("itália")) return 9;
        if (n.contains("bundesliga")) return 10;
        if (n.contains("ligue 1")) return 11;
        return 50;
    }

    private boolean acceptMode(Game g) {
        if (filter == 1) return g.analyzed && g.confidence >= 70;
        if (filter == 2) return "AO VIVO".equals(g.bucket);
        if (filter == 3) return "HOJE".equals(g.bucket) || "AO VIVO".equals(g.bucket);
        if (filter == 4) return "PRÓXIMO".equals(g.bucket);
        return true;
    }

    private boolean accept(Game g) {
        if (!acceptMode(g)) return false;
        String key = leagueKey(g);
        if (selectedLeagueKey != null && !selectedLeagueKey.equals(key)) return false;
        if (favoritesOnly && !favoriteLeagueKeys.contains(key)) return false;
        if (searchQuery != null && !searchQuery.isEmpty()) {
            String hay = (g.home + " " + g.away + " " + g.league + " " + g.leagueCountry + " " + leagueDisplay(g)).toLowerCase(Locale.ROOT);
            if (!hay.contains(searchQuery)) return false;
        }
        return true;
    }

    private View card(Game g) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(CARD);
        bg.setStroke(dp(2), g.analyzed ? riskColor(g.confidence) : Color.rgb(70, 95, 120));
        c.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        c.setLayoutParams(cp);

        c.addView(text(g.bucket + " • " + g.time + " • " + g.status, 11, MUTED, false));
        if (teamPopularity(g) >= 80) {
            TextView featured = text("★ JOGO EM DESTAQUE", 11, Color.rgb(71, 220, 144), true);
            featured.setPadding(0, dp(5), 0, 0);
            c.addView(featured);
        }
        TextView teams = text(g.home + "  ×  " + g.away, 18, TEXT, true);
        teams.setPadding(0, dp(5), 0, dp(5));
        c.addView(teams);

        if (!"-".equals(g.score)) c.addView(text("Placar: " + g.score, 13, TEXT, true));

        if (!g.analyzed) {
            TextView action = text("◉ TOQUE PARA ANALISAR", 14, Color.rgb(90, 190, 255), true);
            action.setPadding(0, dp(7), 0, dp(4));
            c.addView(action);
            c.addView(text("A previsão será consultada somente para este jogo.", 12, MUTED, false));
        } else {
            c.addView(text(label(g.confidence) + "  " + g.confidence + "%", 15, riskColor(g.confidence), true));
            TextView pick = text("Palpite principal: " + g.pick, 13, TEXT, true);
            pick.setPadding(0, dp(7), 0, dp(3));
            c.addView(pick);
            c.addView(text(g.trend, 13, MUTED, false));
            TextView probs = text("Mandante " + g.homePct + "%  •  Empate " + g.drawPct + "%  •  Visitante " + g.awayPct + "%", 12, MUTED, false);
            probs.setPadding(0, dp(4), 0, 0);
            c.addView(probs);
            if (g.advanced != null && !g.advanced.markets.isEmpty()) {
                StringBuilder quick = new StringBuilder();
                int shown = 0;
                for (AdvancedAnalysis.Market m : g.advanced.markets) {
                    if (m.probability < 58) continue;
                    if (shown++ > 0) quick.append("  •  ");
                    quick.append(m.selection).append(" ").append(m.probability).append("%");
                    if (shown >= 2) break;
                }
                if (quick.length() > 0) {
                    TextView q = text("Destaques: " + quick, 12, Color.rgb(103, 213, 178), true);
                    q.setPadding(0, dp(5), 0, 0);
                    c.addView(q);
                }
            }
        }

        c.setOnClickListener(v -> analyze(g));
        return c;
    }

    private View championshipHeader(Game g, int count) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(14), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(Color.rgb(19, 43, 62));
        bg.setStroke(dp(1), Color.rgb(51, 155, 115));
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(8));
        box.setLayoutParams(lp);

        TextView title = text(leagueDisplay(g) + "  •  " + count + (count == 1 ? " jogo" : " jogos"), 16, TEXT, true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(title);

        Button star = new Button(this);
        star.setAllCaps(false);
        star.setText(favoriteLeagueKeys.contains(leagueKey(g)) ? "★" : "☆");
        star.setTextSize(18);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(54), dp(44));
        star.setLayoutParams(sp);
        star.setOnClickListener(v -> {
            String key = leagueKey(g);
            if (favoriteLeagueKeys.contains(key)) favoriteLeagueKeys.remove(key);
            else favoriteLeagueKeys.add(key);
            saveFavoriteLeagues();
            render();
        });
        box.addView(star);
        return box;
    }

    private Button championshipChip(String label, View.OnClickListener listener) {
        Button b = button(label, listener);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44));
        lp.setMargins(0, 0, dp(6), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private void showChampionshipsDialog() {
        if (games.isEmpty()) {
            Toast.makeText(this, "Carregue os jogos primeiro.", Toast.LENGTH_SHORT).show();
            return;
        }

        LinkedHashMap<String, LeagueInfo> map = new LinkedHashMap<>();
        for (Game g : games) {
            String key = leagueKey(g);
            LeagueInfo info = map.get(key);
            if (info == null) {
                info = new LeagueInfo(key, leagueDisplay(g));
                map.put(key, info);
            }
            info.count++;
        }

        List<LeagueInfo> leagues = new ArrayList<>(map.values());
        leagues.sort((a, b) -> a.label.compareToIgnoreCase(b.label));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(6));
        final AlertDialog[] holder = new AlertDialog[1];

        TextView all = dialogRowText("Todos os campeonatos  •  " + games.size() + " jogos");
        all.setOnClickListener(v -> {
            selectedLeagueKey = null;
            selectedLeagueLabel = null;
            favoritesOnly = false;
            if (holder[0] != null) holder[0].dismiss();
            render();
        });
        box.addView(all);

        for (LeagueInfo info : leagues) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView title = dialogRowText(info.label + "  •  " + info.count + (info.count == 1 ? " jogo" : " jogos"));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            title.setLayoutParams(tp);
            title.setOnClickListener(v -> {
                selectedLeagueKey = info.key;
                selectedLeagueLabel = info.label;
                favoritesOnly = false;
                if (holder[0] != null) holder[0].dismiss();
                render();
            });
            row.addView(title);

            Button star = new Button(this);
            star.setAllCaps(false);
            star.setText(favoriteLeagueKeys.contains(info.key) ? "★" : "☆");
            star.setTextSize(20);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(60), dp(50));
            star.setLayoutParams(bp);
            star.setOnClickListener(v -> {
                if (favoriteLeagueKeys.contains(info.key)) favoriteLeagueKeys.remove(info.key);
                else favoriteLeagueKeys.add(info.key);
                saveFavoriteLeagues();
                star.setText(favoriteLeagueKeys.contains(info.key) ? "★" : "☆");
                render();
            });
            row.addView(star);
            box.addView(row);
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Campeonatos")
                .setMessage("Toque no campeonato para filtrar. Toque em ☆ para adicionar aos favoritos.")
                .setView(sv)
                .setNegativeButton("Fechar", null)
                .create();
        holder[0] = dialog;
        dialog.show();
    }

    private void showFavoriteChampionships() {
        if (favoriteLeagueKeys.isEmpty()) {
            Toast.makeText(this, "Você ainda não favoritou campeonatos. Escolha em Campeonatos.", Toast.LENGTH_LONG).show();
            showChampionshipsDialog();
            return;
        }
        selectedLeagueKey = null;
        selectedLeagueLabel = null;
        favoritesOnly = true;
        render();
    }

    private String activeFilterText() {
        StringBuilder sb = new StringBuilder();
        if (selectedLeagueKey != null && selectedLeagueLabel != null) sb.append("Campeonato: ").append(selectedLeagueLabel).append("\n");
        else if (favoritesOnly) sb.append("Campeonatos favoritos\n");
        return sb.toString();
    }

    private int teamPopularity(Game g) {
        return Math.max(teamPopularityName(g.home), teamPopularityName(g.away));
    }

    private int teamPopularityName(String team) {
        if (team == null) return 0;
        String n = java.text.Normalizer.normalize(team, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT);

        String[] elite = {
                "real madrid", "barcelona", "atletico de madrid", "manchester city", "manchester united",
                "liverpool", "arsenal", "chelsea", "tottenham", "bayern", "borussia dortmund",
                "paris saint-germain", "psg", "juventus", "milan", "inter", "napoli",
                "flamengo", "corinthians", "palmeiras", "sao paulo", "santos", "gremio",
                "internacional", "atletico-mg", "atletico mineiro", "cruzeiro", "botafogo", "fluminense", "vasco"
        };
        for (String x : elite) if (n.contains(x)) return 100;

        String[] strong = {
                "sevilla", "valencia", "athletic club", "real sociedad", "villarreal",
                "bayer leverkusen", "leverkusen", "rb leipzig", "benfica", "porto", "sporting",
                "ajax", "psv", "feyenoord", "olympiacos", "galatasaray", "fenerbahce",
                "athletico-pr", "bahia", "fortaleza", "bragantino", "ceara", "sport recife"
        };
        for (String x : strong) if (n.contains(x)) return 80;
        return 0;
    }

    private String leagueKey(Game g) {
        if (g.leagueId > 0) return "id:" + g.leagueId;
        return "name:" + g.leagueCountry + "|" + g.league;
    }

    private String leagueDisplay(Game g) {
        String name = g.league == null ? "Campeonato" : g.league.trim();
        String country = g.leagueCountry == null ? "" : g.leagueCountry.trim();

        if (g.leagueId == 71 || ("Brazil".equalsIgnoreCase(country) && "Serie A".equalsIgnoreCase(name))) return "🇧🇷 Brasileirão Série A";
        if (g.leagueId == 72 || ("Brazil".equalsIgnoreCase(country) && "Serie B".equalsIgnoreCase(name))) return "🇧🇷 Brasileirão Série B";
        if (g.leagueId == 73 || name.toLowerCase(Locale.ROOT).contains("copa do brasil")) return "🇧🇷 Copa do Brasil";
        if (g.leagueId == 13 || name.toLowerCase(Locale.ROOT).contains("libertadores")) return "🌎 Libertadores";
        if (g.leagueId == 11 || name.toLowerCase(Locale.ROOT).contains("sudamericana") || name.toLowerCase(Locale.ROOT).contains("sul-americana")) return "🌎 Sul-Americana";
        if (g.leagueId == 2 || name.toLowerCase(Locale.ROOT).contains("champions league")) return "🇪🇺 Champions League";
        if (g.leagueId == 39 || name.toLowerCase(Locale.ROOT).contains("premier league")) return "🏴 Premier League";
        if (g.leagueId == 140 || "La Liga".equalsIgnoreCase(name)) return "🇪🇸 La Liga";
        if (g.leagueId == 135 || ("Italy".equalsIgnoreCase(country) && "Serie A".equalsIgnoreCase(name))) return "🇮🇹 Serie A (Itália)";
        if (g.leagueId == 78 || name.toLowerCase(Locale.ROOT).contains("bundesliga")) return "🇩🇪 Bundesliga";
        if (g.leagueId == 61 || name.toLowerCase(Locale.ROOT).contains("ligue 1")) return "🇫🇷 Ligue 1";

        String flag = countryFlag(country);
        if (!flag.isEmpty()) return flag + " " + name;
        return name;
    }

    private String countryFlag(String country) {
        if (country == null) return "";
        String c = country.trim().toLowerCase(Locale.ROOT);
        if (c.equals("brazil")) return "🇧🇷";
        if (c.equals("england")) return "🏴";
        if (c.equals("spain")) return "🇪🇸";
        if (c.equals("italy")) return "🇮🇹";
        if (c.equals("germany")) return "🇩🇪";
        if (c.equals("france")) return "🇫🇷";
        if (c.equals("argentina")) return "🇦🇷";
        if (c.equals("portugal")) return "🇵🇹";
        if (c.equals("netherlands")) return "🇳🇱";
        if (c.equals("usa") || c.equals("united states")) return "🇺🇸";
        return "";
    }

    private void loadFavoriteLeagues() {
        Set<String> saved = getPreferences(MODE_PRIVATE).getStringSet("favorite_leagues", null);
        if (saved != null) favoriteLeagueKeys.addAll(saved);
    }

    private void saveFavoriteLeagues() {
        getPreferences(MODE_PRIVATE).edit().putStringSet("favorite_leagues", new HashSet<>(favoriteLeagueKeys)).apply();
    }

    private TextView dialogRowText(String value) {
        TextView t = text(value, 14, Color.DKGRAY, false);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12), 0, dp(8), 0);
        return t;
    }

    private void showDetail(Game g) {
        if (g.advanced == null) {
            String msg = g.home + " × " + g.away + "\n" + g.reason + "\n\nProbabilidades: " + g.homePct + "% / " + g.drawPct + "% / " + g.awayPct + "%";
            new AlertDialog.Builder(this).setTitle("Análise da partida").setMessage(msg).setNegativeButton("Fechar", null).show();
            return;
        }

        AdvancedAnalysis a = g.advanced;
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(18));
        box.setBackgroundColor(BG);
        sv.addView(box);

        TextView league = text(leagueDisplay(g) + "  •  " + g.time + "  •  " + g.status, 12, MUTED, false);
        box.addView(league);
        TextView title = text(g.home + "\n×\n" + g.away, 23, TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(10));
        box.addView(title);

        LinearLayout probCard = sectionBox();
        probCard.addView(text("PROBABILIDADES 1X2", 12, Color.rgb(103, 213, 178), true));
        probCard.addView(text(g.home + "  " + a.homePct + "%", 17, TEXT, true));
        probCard.addView(text("Empate  " + a.drawPct + "%", 17, TEXT, true));
        probCard.addView(text(g.away + "  " + a.awayPct + "%", 17, TEXT, true));
        TextView conf = text("Confiança global: " + a.confidence + "%  •  qualidade dos dados: " + a.dataQuality, 12, riskColor(a.confidence), true);
        conf.setPadding(0, dp(8), 0, 0);
        probCard.addView(conf);
        box.addView(probCard);

        LinearLayout ai = sectionBox();
        ai.addView(text("✦ IA ESTATÍSTICA J.PASTORE", 14, Color.rgb(90, 190, 255), true));
        TextView aiText = text(a.aiSummary, 14, TEXT, false);
        aiText.setPadding(0, dp(7), 0, 0);
        ai.addView(aiText);
        if (!a.apiAdvice.isEmpty()) {
            TextView adv = text("Sinal da API: " + a.apiAdvice, 12, MUTED, false);
            adv.setPadding(0, dp(7), 0, 0);
            ai.addView(adv);
        }
        ai.addView(text("Gols esperados estimados: " + one(a.expectedHomeGoals) + " × " + one(a.expectedAwayGoals), 13, TEXT, true));
        box.addView(ai);

        LinearLayout cmp = sectionBox();
        cmp.addView(text("COMPARATIVO DO CONFRONTO", 14, TEXT, true));
        addComparison(cmp, "Forma", a.formHome, a.formAway, g.home, g.away);
        addComparison(cmp, "Ataque", a.attackHome, a.attackAway, g.home, g.away);
        addComparison(cmp, "Defesa", a.defenceHome, a.defenceAway, g.home, g.away);
        addComparison(cmp, "Poisson", a.poissonHome, a.poissonAway, g.home, g.away);
        addComparison(cmp, "H2H", a.h2hHome, a.h2hAway, g.home, g.away);
        box.addView(cmp);

        LinearLayout marketBox = sectionBox();
        marketBox.addView(text("MERCADOS E PROBABILIDADES", 14, TEXT, true));
        marketBox.addView(text("Odds específicas substituem estimativas locais quando a API oferece o mercado.", 11, MUTED, false));
        String lastCategory = "";
        for (AdvancedAnalysis.Market m : a.markets) {
            if (!m.category.equals(lastCategory)) {
                TextView cat = text(m.category.toUpperCase(Locale.ROOT), 12, Color.rgb(103, 213, 178), true);
                cat.setPadding(0, dp(10), 0, dp(3));
                marketBox.addView(cat);
                lastCategory = m.category;
            }
            marketBox.addView(marketRow(m));
        }
        box.addView(marketBox);

        LinearLayout note = sectionBox();
        note.addView(text("COMO LER", 13, TEXT, true));
        note.addView(text("Probabilidade é uma estimativa, não certeza. Mercados de escanteios, cartões, chutes, laterais, faltas e impedimentos podem usar odds reais quando disponíveis; caso contrário aparecem como estimativa do modelo, com confiança menor. O app não executa apostas.", 12, MUTED, false));
        box.addView(note);

        String copyText = buildCopyText(g, a);
        new AlertDialog.Builder(this)
                .setView(sv)
                .setPositiveButton("Copiar análise", (d, w) -> copy(copyText))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private LinearLayout sectionBox() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(CARD);
        bg.setStroke(dp(1), Color.rgb(43, 73, 98));
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        v.setLayoutParams(lp);
        return v;
    }

    private void addComparison(LinearLayout parent, String label, int h, int a, String hn, String an) {
        if (h <= 0 && a <= 0) return;
        TextView t = text(label + ":  " + hn + " " + h + "%   •   " + an + " " + a + "%", 12, MUTED, false);
        t.setPadding(0, dp(5), 0, 0);
        parent.addView(t);
    }

    private View marketRow(AdvancedAnalysis.Market m) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        bg.setColor(Color.rgb(11, 24, 40));
        bg.setStroke(dp(1), m.probability >= 70 ? Color.rgb(39, 211, 123) : (m.probability >= 55 ? Color.rgb(190, 155, 61) : Color.rgb(62, 83, 105)));
        row.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(6));
        row.setLayoutParams(lp);
        row.addView(text(m.selection + "   " + m.probability + "%", 14, TEXT, true));
        row.addView(text("Confiança do dado: " + m.confidence + "%  •  " + m.source, 11, MUTED, false));
        if (!m.note.isEmpty()) row.addView(text(m.note, 11, MUTED, false));
        return row;
    }

    private String buildCopyText(Game g, AdvancedAnalysis a) {
        StringBuilder sb = new StringBuilder();
        sb.append("J.Pastore Sports AI V10\n").append(g.home).append(" × ").append(g.away).append("\n");
        sb.append(leagueDisplay(g)).append(" • ").append(g.time).append("\n\n");
        sb.append("IA: ").append(a.aiSummary).append("\n\n");
        sb.append("1X2: ").append(a.homePct).append("% / ").append(a.drawPct).append("% / ").append(a.awayPct).append("%\n");
        int n = 0;
        for (AdvancedAnalysis.Market m : a.markets) {
            if (n++ >= 8) break;
            sb.append("• ").append(m.category).append(": ").append(m.selection).append(" — ").append(m.probability).append("%\n");
        }
        sb.append("\nAnálise probabilística, sem garantia de resultado.");
        return sb.toString();
    }

    private String one(double v) { return String.format(Locale.US, "%.1f", v).replace('.', ','); }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(text("Informe sua chave da API-Football (API-Sports). Ela fica salva apenas neste aparelho.", 13, Color.DKGRAY, false));
        EditText input = new EditText(this);
        input.setHint("x-apisports-key");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setText(getPreferences(MODE_PRIVATE).getString("api_key", ""));
        box.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("Modo online")
                .setView(box)
                .setPositiveButton("Salvar e atualizar", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().putString("api_key", input.getText().toString().trim()).apply();
                    lastRefreshAt = 0L;
                    load(false);
                })
                .setNeutralButton("Usar demonstração", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().remove("api_key").apply();
                    load(false);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private List<Game> demoGames() {
        List<Game> d = new ArrayList<>();
        d.add(demo(71, "HOJE", "Brasileirão Série A", "Brazil", "Palmeiras", "Bahia", "19:30", "AGENDADO", "-", 62,22,16));
        d.add(demo(71, "HOJE", "Brasileirão Série A", "Brazil", "Flamengo", "Fortaleza", "21:30", "AGENDADO", "-", 55,26,19));
        d.add(demo(39, "AO VIVO", "Premier League", "England", "Arsenal", "Everton", "16:00", "AO VIVO 2T • 77'", "2 x 0", 69,20,11));
        d.add(new Game(4, 140, 2026, 0, 0, "PRÓXIMO", "La Liga", "Spain", "Real Sociedad", "Villarreal", "17:00", "AGENDADO", "-"));
        d.add(new Game(5, 135, 2026, 0, 0, "PRÓXIMO", "Serie A", "Italy", "Torino", "Udinese", "15:45", "AGENDADO", "-"));
        return d;
    }

    private Game demo(int leagueId, String bucket, String l, String country, String h, String a, String t, String s, String score, int hp, int dpct, int ap) {
        Game g = new Game(0, leagueId, 2026, 0, 0, bucket, l, country, h, a, t, s, score);
        AnalysisEngine.Result r = AnalysisEngine.evaluate(hp, dpct, ap);
        g.applyAnalysis(hp, dpct, ap, r);
        return g;
    }

    private String friendlyError(String msg) {
        if (msg == null) return "erro desconhecido da API";
        String low = msg.toLowerCase(Locale.ROOT);
        if (low.contains("next parameter") || low.contains("free plans do not have access"))
            return "parâmetro não permitido no plano gratuito.";
        if (low.contains("from field") || low.contains("to field"))
            return "a API recusou o filtro por intervalo. Esta versão usa somente consultas por data.";
        if (low.contains("too many requests") || low.contains("rate") || low.contains("429"))
            return "limite temporário de chamadas atingido. Aguarde um pouco e tente novamente.";
        return msg;
    }

    private int riskColor(int c) { return c >= 70 ? Color.rgb(39, 211, 123) : (c >= 55 ? Color.rgb(255, 193, 7) : Color.rgb(255, 82, 82)); }
    private String label(int c) { return c >= 70 ? "● FAVORÁVEL" : (c >= 55 ? "● ATENÇÃO" : "● DUVIDOSO"); }
    private void copy(String s) {
        ((android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Análise J.Pastore", s));
        Toast.makeText(this, "Análise copiada", Toast.LENGTH_SHORT).show();
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0, 1.08f);
        return t;
    }
    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }
    private Button rowButton(String s, View.OnClickListener l) {
        Button b = button(s, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.setMargins(dp(2), dp(3), dp(2), dp(3));
        b.setLayoutParams(lp);
        return b;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }

    private static class LeagueInfo {
        final String key, label;
        int count = 0;
        LeagueInfo(String key, String label) { this.key = key; this.label = label; }
    }
}
