package com.jpastore.sportsai;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.widget.*;import android.view.*;import androidx.work.*;import java.util.concurrent.TimeUnit;
public class MainActivity extends Activity{
 PremiumView ui;
 @Override public void onBackPressed(){if(ui!=null&&ui.handleBack())return;super.onBackPressed();}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(2,10,14));getWindow().setNavigationBarColor(Color.rgb(2,10,14));ui=new PremiumView(this);setContentView(ui);scheduleInternetSync();handleIncomingImage(getIntent());}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIncomingImage(i);}
 public void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
 public void searchDialog(){
  final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(22),dp(22),dp(20));root.setBackground(roundBg(Color.rgb(7,22,27),Color.rgb(29,232,116),22));
  TextView title=label("BUSCA MULTIESPORTE",20,Color.WHITE,true);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
  TextView sub=label("Digite time, lutador, piloto, campeonato ou confronto. A J.Pastore AI sugere nomes e usa a web quando necessário.",12,Color.rgb(166,188,194),false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(6);sp.bottomMargin=dp(16);root.addView(sub,sp);
  final AutoCompleteTextView e=new AutoCompleteTextView(this);e.setSingleLine(true);e.setThreshold(2);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.rgb(126,151,158));e.setTextSize(16);e.setHint("Ex.: corin..., lakers, panto..., verst...");e.setPadding(dp(16),0,dp(16),0);e.setBackground(roundBg(Color.rgb(12,38,44),Color.rgb(45,82,88),15));e.setDropDownBackgroundDrawable(roundBg(Color.rgb(9,29,34),Color.rgb(45,82,88),12));e.setDropDownVerticalOffset(dp(6));e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);root.addView(e,new LinearLayout.LayoutParams(-1,dp(54)));
  TextView hint=label("Sugestões a partir de 2 letras • futebol + modalidades carregadas + fallback web",10,Color.rgb(119,154,160),false);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(9);root.addView(hint,hp);
  final java.util.ArrayList<String> data=new java.util.ArrayList<>();
  final ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,data){@Override public View getView(int pos,View cv,android.view.ViewGroup parent){TextView t=(TextView)super.getView(pos,cv,parent);t.setTextColor(Color.WHITE);t.setTextSize(15);t.setPadding(dp(16),dp(12),dp(16),dp(12));t.setBackgroundColor(Color.rgb(9,29,34));return t;}@Override public View getDropDownView(int pos,View cv,android.view.ViewGroup parent){return getView(pos,cv,parent);}};
  e.setAdapter(adapter);
  final Handler h=new Handler(Looper.getMainLooper());final Runnable[] pending=new Runnable[1];
  e.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){}public void afterTextChanged(android.text.Editable ed){String q=ed.toString().trim();if(pending[0]!=null)h.removeCallbacks(pending[0]);if(q.length()<2){data.clear();adapter.notifyDataSetChanged();return;}pending[0]=()->new Thread(()->{java.util.ArrayList<String> got=ui.smartSearchSuggestions(q);runOnUiThread(()->{if(!e.getText().toString().trim().equalsIgnoreCase(q))return;data.clear();data.addAll(got);adapter.notifyDataSetChanged();if(!data.isEmpty()&&e.hasFocus())e.showDropDown();});}).start();h.postDelayed(pending[0],280);}});
  e.setOnItemClickListener((p,v,pos,id)->{String chosen=(String)p.getItemAtPosition(pos);d.dismiss();ui.searchUniversal(chosen);});
  LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(android.view.Gravity.END);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(18);root.addView(actions,ap);
  Button cancel=button("CANCELAR",Color.rgb(28,51,57),Color.WHITE);Button go=button("BUSCAR",Color.rgb(29,232,116),Color.rgb(2,17,14));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(46),1);bp.rightMargin=dp(7);actions.addView(cancel,bp);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(46),1);gp.leftMargin=dp(7);actions.addView(go,gp);cancel.setOnClickListener(v->d.dismiss());go.setOnClickListener(v->{String q=e.getText().toString().trim();if(q.length()<3){toast("Digite pelo menos 3 letras");return;}d.dismiss();ui.searchUniversal(q);});
  d.setContentView(root);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams lp=w.getAttributes();lp.width=WindowManager.LayoutParams.MATCH_PARENT;lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.72f;lp.gravity=android.view.Gravity.CENTER;w.setAttributes(lp);}d.setOnShowListener(x->{e.requestFocus();if(d.getWindow()!=null)d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});d.show();if(d.getWindow()!=null){d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),WindowManager.LayoutParams.WRAP_CONTENT);}
 }
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
 private android.graphics.drawable.GradientDrawable roundBg(int fill,int stroke,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
 private TextView label(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);return t;}
 private Button button(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setTextSize(12);b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);b.setAllCaps(false);b.setBackground(roundBg(bg,bg,13));return b;}
 public void timeFilterDialog(){
  final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(20),dp(20),dp(18));root.setBackground(roundBg(Color.rgb(5,22,27),Color.rgb(29,232,116),24));
  LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);root.addView(head,new LinearLayout.LayoutParams(-1,-2));
  LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);head.addView(titles,tp);
  titles.addView(label("HORÁRIO DOS JOGOS",19,Color.WHITE,true));TextView sub=label("Horário oficial de Brasília",10,Color.rgb(145,166,172),false);LinearLayout.LayoutParams subp=new LinearLayout.LayoutParams(-1,-2);subp.topMargin=dp(2);titles.addView(sub,subp);
  TextClock clock=new TextClock(this);clock.setTimeZone("America/Sao_Paulo");clock.setFormat24Hour("HH:mm:ss");clock.setTextSize(15);clock.setTextColor(Color.rgb(29,232,116));clock.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);clock.setGravity(Gravity.CENTER);clock.setPadding(dp(12),dp(8),dp(12),dp(8));clock.setBackground(roundBg(Color.rgb(7,48,43),Color.rgb(29,232,116),13));head.addView(clock,new LinearLayout.LayoutParams(dp(104),dp(42)));
  TextView current=label("Filtro atual: "+(ui==null||ui.timeFilter==null||ui.timeFilter.isEmpty()?"Todos os horários":ui.timeFilter),11,Color.rgb(241,190,66),true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(16);cp.bottomMargin=dp(10);root.addView(current,cp);
  java.util.ArrayList<String> actual=ui==null?new java.util.ArrayList<>():ui.availableTimes();GridLayout grid=new GridLayout(this);grid.setColumnCount(2);root.addView(grid,new LinearLayout.LayoutParams(-1,-2));
  java.util.ArrayList<String> opts=new java.util.ArrayList<>();opts.add("Todos");for(String t:actual)if(opts.size()<9)opts.add(t);
  for(String v:opts){boolean selected=("Todos".equals(v)&&(ui==null||ui.timeFilter==null||ui.timeFilter.isEmpty()))||(ui!=null&&v.equals(ui.timeFilter));Button b=button("Todos".equals(v)?"◷  TODOS":"◷  "+v,selected?Color.rgb(29,232,116):Color.rgb(12,38,44),selected?Color.rgb(2,17,14):Color.WHITE);b.setBackground(roundBg(selected?Color.rgb(29,232,116):Color.rgb(12,38,44),selected?Color.rgb(241,190,66):Color.rgb(42,76,82),13));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(46);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(4),dp(4),dp(4),dp(4));grid.addView(b,gp);b.setOnClickListener(x->{d.dismiss();ui.setTimeFilter("Todos".equals(v)?"":v);});}
  Button manual=button("◷  ESCOLHER OUTRO HORÁRIO",Color.rgb(19,58,62),Color.WHITE);manual.setBackground(roundBg(Color.rgb(19,58,62),Color.rgb(241,190,66),14));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(50));mp.topMargin=dp(12);root.addView(manual,mp);manual.setOnClickListener(v->{d.dismiss();manualTimeDialog();});
  Button clear=button("FECHAR",Color.rgb(27,45,50),Color.rgb(170,190,194));LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,dp(44));clp.topMargin=dp(8);root.addView(clear,clp);clear.setOnClickListener(v->d.dismiss());
  d.setContentView(root);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams lp=w.getAttributes();lp.width=WindowManager.LayoutParams.MATCH_PARENT;lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.78f;lp.gravity=Gravity.CENTER;w.setAttributes(lp);}d.show();if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),WindowManager.LayoutParams.WRAP_CONTENT);
 }
 public void manualTimeDialog(){
  final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(18),dp(18),dp(18),dp(16));root.setBackground(roundBg(Color.rgb(5,22,27),Color.rgb(241,190,66),24));

  TextView title=label("RELÓGIO • BRASÍLIA",18,Color.WHITE,true);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
  TextView zone=label("Horário oficial • America/Sao_Paulo",10,Color.rgb(145,166,172),false);zone.setGravity(Gravity.CENTER);LinearLayout.LayoutParams zp=new LinearLayout.LayoutParams(-1,-2);zp.topMargin=dp(3);root.addView(zone,zp);

  LinearLayout nowCard=new LinearLayout(this);nowCard.setOrientation(LinearLayout.HORIZONTAL);nowCard.setGravity(Gravity.CENTER_VERTICAL);nowCard.setPadding(dp(14),0,dp(14),0);nowCard.setBackground(roundBg(Color.rgb(7,48,43),Color.rgb(29,232,116),15));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(48));np.topMargin=dp(14);root.addView(nowCard,np);
  TextView nowLabel=label("AGORA EM BRASÍLIA",10,Color.rgb(166,188,194),true);nowCard.addView(nowLabel,new LinearLayout.LayoutParams(0,-2,1));
  TextClock live=new TextClock(this);live.setTimeZone("America/Sao_Paulo");live.setFormat24Hour("HH:mm:ss");live.setTextSize(17);live.setTextColor(Color.rgb(29,232,116));live.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);live.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);nowCard.addView(live,new LinearLayout.LayoutParams(dp(112),-1));

  TextView pickLabel=label("HORÁRIO SELECIONADO",10,Color.rgb(241,190,66),true);pickLabel.setGravity(Gravity.CENTER);LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(-1,-2);plp.topMargin=dp(18);plp.bottomMargin=dp(7);root.addView(pickLabel,plp);

  java.util.Calendar cal=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));final int[] chosen={cal.get(java.util.Calendar.HOUR_OF_DAY),cal.get(java.util.Calendar.MINUTE)};
  try{if(ui!=null&&ui.timeFilter!=null&&ui.timeFilter.matches("\\d{2}:\\d{2}")){String[] z=ui.timeFilter.split(":");chosen[0]=Integer.parseInt(z[0]);chosen[1]=Integer.parseInt(z[1]);}}catch(Exception ignored){}

  TextView digital=label(String.format(java.util.Locale.US,"%02d:%02d",chosen[0],chosen[1]),48,Color.WHITE,true);digital.setGravity(Gravity.CENTER);digital.setLetterSpacing(.05f);digital.setBackground(roundBg(Color.rgb(8,35,40),Color.rgb(29,232,116),19));LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(88));root.addView(digital,dlp);
  TextView help=label("Ajuste horas e minutos ou use um atalho rápido",10,Color.rgb(145,166,172),false);help.setGravity(Gravity.CENTER);LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2);hlp.topMargin=dp(7);hlp.bottomMargin=dp(11);root.addView(help,hlp);

  LinearLayout adjust=new LinearLayout(this);adjust.setOrientation(LinearLayout.HORIZONTAL);root.addView(adjust,new LinearLayout.LayoutParams(-1,dp(46)));
  String[] adjustNames={"− 1h","+ 1h","− 5 min","+ 5 min"};int[] dh={-60,60,-5,5};
  for(int i=0;i<adjustNames.length;i++){final int delta=dh[i];Button b=button(adjustNames[i],Color.rgb(12,38,44),Color.WHITE);b.setBackground(roundBg(Color.rgb(12,38,44),Color.rgb(42,76,82),12));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-1,1);bp.setMargins(dp(3),0,dp(3),0);adjust.addView(b,bp);b.setOnClickListener(v->{int total=(chosen[0]*60+chosen[1]+delta)%(24*60);if(total<0)total+=24*60;chosen[0]=total/60;chosen[1]=total%60;digital.setText(String.format(java.util.Locale.US,"%02d:%02d",chosen[0],chosen[1]));});}

  TextView quickLabel=label("ATALHOS",10,Color.rgb(166,188,194),true);LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(-1,-2);qlp.topMargin=dp(16);qlp.bottomMargin=dp(6);root.addView(quickLabel,qlp);
  GridLayout quick=new GridLayout(this);quick.setColumnCount(2);root.addView(quick,new LinearLayout.LayoutParams(-1,-2));
  String[] qn={"AGORA","PRÓXIMA 1H","MANHÃ • 09:00","TARDE • 14:00","NOITE • 19:00","MEIA-NOITE • 00:00"};
  for(String name:qn){Button b=button(name,Color.rgb(19,58,62),Color.WHITE);b.setTextSize(10);b.setBackground(roundBg(Color.rgb(19,58,62),Color.rgb(45,82,88),12));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(43);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(3),dp(3),dp(3),dp(3));quick.addView(b,gp);b.setOnClickListener(v->{java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));if(name.equals("AGORA")){chosen[0]=c.get(java.util.Calendar.HOUR_OF_DAY);chosen[1]=c.get(java.util.Calendar.MINUTE);}else if(name.equals("PRÓXIMA 1H")){c.add(java.util.Calendar.HOUR_OF_DAY,1);chosen[0]=c.get(java.util.Calendar.HOUR_OF_DAY);chosen[1]=c.get(java.util.Calendar.MINUTE);}else if(name.startsWith("MANHÃ")){chosen[0]=9;chosen[1]=0;}else if(name.startsWith("TARDE")){chosen[0]=14;chosen[1]=0;}else if(name.startsWith("NOITE")){chosen[0]=19;chosen[1]=0;}else{chosen[0]=0;chosen[1]=0;}digital.setText(String.format(java.util.Locale.US,"%02d:%02d",chosen[0],chosen[1]));});}

  LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,-2);alp.topMargin=dp(15);root.addView(actions,alp);
  Button cancel=button("CANCELAR",Color.rgb(27,45,50),Color.WHITE);Button apply=button("APLICAR HORÁRIO",Color.rgb(29,232,116),Color.rgb(2,17,14));apply.setBackground(roundBg(Color.rgb(29,232,116),Color.rgb(241,190,66),13));LinearLayout.LayoutParams cb=new LinearLayout.LayoutParams(0,dp(49),1);cb.rightMargin=dp(5);actions.addView(cancel,cb);LinearLayout.LayoutParams ab=new LinearLayout.LayoutParams(0,dp(49),1.45f);ab.leftMargin=dp(5);actions.addView(apply,ab);cancel.setOnClickListener(v->d.dismiss());apply.setOnClickListener(v->{ui.setTimeFilter(String.format(java.util.Locale.US,"%02d:%02d",chosen[0],chosen[1]));d.dismiss();});

  d.setContentView(root);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams x=w.getAttributes();x.width=WindowManager.LayoutParams.MATCH_PARENT;x.height=WindowManager.LayoutParams.WRAP_CONTENT;x.dimAmount=.84f;x.gravity=Gravity.CENTER;w.setAttributes(x);}d.show();if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),WindowManager.LayoutParams.WRAP_CONTENT);
 }

 public void pickVisionImage(){
  Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,9401);
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode==9401&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
   android.net.Uri u=data.getData();
   try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
   analyzeVisionImage(u);
  }
 }
 void handleIncomingImage(Intent i){
  if(i==null||!Intent.ACTION_SEND.equals(i.getAction())||i.getType()==null||!i.getType().startsWith("image/"))return;
  android.net.Uri tmp=null;
  try{tmp=(android.net.Uri)i.getParcelableExtra(Intent.EXTRA_STREAM);}catch(Exception ignored){}
  if(tmp==null&&i.getClipData()!=null&&i.getClipData().getItemCount()>0)tmp=i.getClipData().getItemAt(0).getUri();
  final android.net.Uri u=tmp;
  if(u!=null)new Handler(Looper.getMainLooper()).postDelayed(()->analyzeVisionImage(u),450);
 }
 public void analyzeVisionImage(android.net.Uri uri){
  if(uri==null)return;
  if(ui!=null)ui.setVisionLoading(true,"Lendo o print e identificando o esporte...");
  try{
   com.google.mlkit.vision.common.InputImage img=com.google.mlkit.vision.common.InputImage.fromFilePath(this,uri);
   com.google.mlkit.vision.text.TextRecognizer rec=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);
   rec.process(img)
    .addOnSuccessListener(t->{String raw=t==null?"":t.getText();if(ui!=null)ui.receiveVisionText(raw);rec.close();})
    .addOnFailureListener(e->{if(ui!=null)ui.setVisionError("Não consegui ler esse print. Tente uma imagem mais nítida ou recortada.");rec.close();});
  }catch(Exception e){if(ui!=null)ui.setVisionError("Não consegui abrir essa imagem. Escolha outro print.");}
 }

 public void aiDialog(){final EditText e=new EditText(this);e.setHint("Ex.: Quem chega melhor e por quê?");new AlertDialog.Builder(this).setTitle("Perguntar à J.Pastore AI").setView(e).setPositiveButton("ANALISAR",(d,w)->ui.askAi(e.getText().toString().trim())).setNegativeButton("CANCELAR",null).show();}
 public void visionAiDialog(){final EditText e=new EditText(this);e.setHint("Ex.: qual seleção está mais arriscada?");e.setMinLines(2);new AlertDialog.Builder(this).setTitle("Perguntar sobre o print").setMessage("A J.Pastore Vision AI usa o texto reconhecido da imagem e, quando a partida está vinculada, cruza com o motor estatístico do app.").setView(e).setPositiveButton("ANALISAR",(d,w)->{String q=e.getText().toString().trim();if(q.isEmpty()){toast("Digite uma pergunta sobre o print");return;}infoDialog("J.Pastore Vision AI",ui.askVision(q));}).setNegativeButton("CANCELAR",null).show();}
 public void sportAiDialog(){final EditText e=new EditText(this);e.setHint("Ex.: quem chega melhor? O que a web mostra?");e.setMinLines(2);new AlertDialog.Builder(this).setTitle("J.Pastore IA • Multiesportes").setMessage("A resposta usa a pesquisa web e os resultados estruturados já encontrados para este confronto.").setView(e).setPositiveButton("ANALISAR",(d,w)->{String q=e.getText().toString().trim();if(q.isEmpty()){toast("Digite uma pergunta");return;}infoDialog("J.Pastore IA",ui.askSportAi(q));}).setNegativeButton("CANCELAR",null).show();}
 public void openWebSearch(String q){try{String query=q==null?"":q.trim();android.net.Uri u=android.net.Uri.parse("https://www.google.com/search?q="+java.net.URLEncoder.encode(query,"UTF-8"));startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){toast("Não foi possível abrir a pesquisa web");}}
 public void openUrl(String url){try{if(url==null||url.trim().isEmpty()){toast("Fonte sem endereço disponível");return;}startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}catch(Exception e){toast("Não foi possível abrir esta fonte");}}
 public void infoDialog(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}
 public void shareTicket(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,ui!=null&&ui.ticketStore!=null?ui.ticketStore.copyText():"J.Pastore Sports AI • Bilhete para revisão.");startActivity(Intent.createChooser(i,"Compartilhar bilhete"));}
 public void copyText(String label,String value){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText(label,value));toast("Bilhete copiado. Agora é só colar onde quiser.");}
 public void scheduleInternetSync(){Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest r=new PeriodicWorkRequest.Builder(BackgroundSyncWorker.class,6,TimeUnit.HOURS).setConstraints(c).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("jpastore-internet-sync",ExistingPeriodicWorkPolicy.UPDATE,r);}
 private android.content.SharedPreferences persistentStore(){return getSharedPreferences("jp_persistent_v1",MODE_PRIVATE);}
 private String apiStoreKey(String source){
  if(MultiSportClient.BASKETBALL.equals(source))return "api_basketball";
  if(MultiSportClient.NBA.equals(source))return "api_nba";
  if(MultiSportClient.MMA.equals(source))return "api_mma";
  if(MultiSportClient.F1.equals(source))return "api_f1";
  if(MultiSportClient.NFL.equals(source))return "api_nfl";
  if(MultiSportClient.BASEBALL.equals(source))return "api_baseball";
  return "api_football";
 }
 public String apiKeyFor(String source){
  android.content.SharedPreferences p=persistentStore();
  String saved=p.getString(apiStoreKey(source),"");
  if(saved!=null&&!saved.isEmpty())return saved;
  if(MultiSportClient.FOOTBALL.equals(source)){
   String legacy=getPreferences(0).getString("api","");
   if(legacy!=null&&!legacy.isEmpty()){p.edit().putString("api_football",legacy).apply();return legacy;}
  }
  return "";
 }
 public String apiKey(){return apiKeyFor(MultiSportClient.FOOTBALL);}
 public boolean hasSportApi(String source){return !apiKeyFor(source).isEmpty();}
 public int configuredApiCount(){int n=0;for(String s:MultiSportClient.SOURCES)if(hasSportApi(s))n++;return n;}
 public void sportApiDialog(final String source){
  final EditText e=new EditText(this);
  e.setHint("Cole sua chave "+MultiSportClient.sourceTitle(source));
  e.setSingleLine(true);
  e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  String current=apiKeyFor(source);if(!current.isEmpty())e.setText(current);
  String extra=MultiSportClient.BASKETBALL.equals(source)||MultiSportClient.NBA.equals(source)?"O módulo Basquete pode combinar API-Basketball e API-NBA.":"Cada modalidade mantém sua configuração independente.";
  new AlertDialog.Builder(this).setTitle(MultiSportClient.sourceTitle(source)).setMessage(extra+"\n\nA chave fica salva somente neste aparelho e não é enviada ao GitHub.").setView(e)
   .setPositiveButton("SALVAR E TESTAR",(d,w)->{String k=e.getText().toString().trim();if(k.isEmpty()){toast("Digite uma chave válida");return;}persistentStore().edit().putString(apiStoreKey(source),k).apply();toast("Chave salva. Testando conexão...");new MultiSportClient(this).test(source,k,ok->runOnUiThread(()->{toast(ok?MultiSportClient.sourceTitle(source)+" conectada com sucesso":"Chave salva, mas a API recusou a conexão");if(ui!=null){ui.invalidate();if(ui.screen==18)ui.loadApiStatus();if(source.equals(ui.currentSport)||MultiSportClient.NBA.equals(source)&&MultiSportClient.BASKETBALL.equals(ui.currentSport))ui.loadSportEvents();}}));})
   .setNegativeButton("CANCELAR",null).show();
 }
 public void testSportApi(final String source){String k=apiKeyFor(source);if(k.isEmpty()){toast("Configure "+MultiSportClient.sourceTitle(source)+" primeiro");return;}toast("Testando "+MultiSportClient.sourceTitle(source)+"...");new MultiSportClient(this).test(source,k,ok->runOnUiThread(()->toast(ok?"Conexão confirmada":"Falha ao conectar. Verifique a chave e o plano.")));}
 public void clearSportApi(String source){persistentStore().edit().remove(apiStoreKey(source)).apply();if(MultiSportClient.FOOTBALL.equals(source))getPreferences(0).edit().remove("api").apply();toast("Chave de "+MultiSportClient.sourceTitle(source)+" removida deste aparelho");if(ui!=null){ui.invalidate();if(ui.screen==18)ui.loadApiStatus();if(source.equals(ui.currentSport)||MultiSportClient.NBA.equals(source)&&MultiSportClient.BASKETBALL.equals(ui.currentSport))ui.loadSportEvents();}}
 public void copyFootballKeyToSports(){
  String k=apiKey();if(k.isEmpty()){toast("Configure primeiro a API-Football");return;}
  android.content.SharedPreferences.Editor ed=persistentStore().edit();
  for(String s:MultiSportClient.SOURCES)if(!MultiSportClient.FOOTBALL.equals(s))ed.putString(apiStoreKey(s),k);ed.apply();
  toast("Chave do futebol copiada para as outras APIs. Use TESTAR em cada uma para confirmar seu plano.");if(ui!=null)ui.invalidate();
 }
 public void apiDialog(){sportApiDialog(MultiSportClient.FOOTBALL);}
 public void testApi(){testSportApi(MultiSportClient.FOOTBALL);}
 public void clearApi(){clearSportApi(MultiSportClient.FOOTBALL);if(ui!=null)ui.refreshFixtures();}
}