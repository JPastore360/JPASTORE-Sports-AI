package com.jpastore.sportsai;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.widget.*;
public class MainActivity extends Activity{
 PremiumView ui;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(4,12,18));getWindow().setNavigationBarColor(Color.rgb(4,12,18));ui=new PremiumView(this);setContentView(ui);}
 public void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
 public void apiDialog(){final EditText e=new EditText(this);e.setHint("Chave API-Football");e.setSingleLine();String old=getPreferences(0).getString("api","");e.setText(old);new AlertDialog.Builder(this).setTitle("API-Football • V1 Premium").setMessage("A chave fica salva somente neste aparelho.").setView(e).setPositiveButton("SALVAR",(d,w)->{getPreferences(0).edit().putString("api",e.getText().toString().trim()).apply();toast("Chave salva");}).setNeutralButton("TESTAR",(d,w)->new ApiClient(this).test(e.getText().toString().trim(),ok->runOnUiThread(()->toast(ok?"API conectada":"Falha na conexão")))).setNegativeButton("FECHAR",null).show();}
 public void searchDialog(){final EditText e=new EditText(this);e.setHint("Time, jogo ou campeonato");new AlertDialog.Builder(this).setTitle("Buscar futebol").setView(e).setPositiveButton("BUSCAR",(d,w)->{String q=e.getText().toString().trim();toast(q.isEmpty()?"Digite um termo":"Busca: "+q);}).setNegativeButton("CANCELAR",null).show();}
 public void infoDialog(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show();}
 public void preferencesDialog(){String[] a={"Destacar jogos principais","Feedback de carregamento","Salvar histórico local"};boolean[] c={true,true,true};new AlertDialog.Builder(this).setTitle("Preferências").setMultiChoiceItems(a,c,(d,w,v)->{}).setPositiveButton("SALVAR",(d,w)->toast("Preferências salvas")).show();}
 public void shareTicket(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"J.Pastore Sports AI • Bilhete para revisão. Probabilidades são estimativas e não garantias.");startActivity(Intent.createChooser(i,"Compartilhar bilhete"));}
 public String apiKey(){return getPreferences(0).getString("api","");}
}
