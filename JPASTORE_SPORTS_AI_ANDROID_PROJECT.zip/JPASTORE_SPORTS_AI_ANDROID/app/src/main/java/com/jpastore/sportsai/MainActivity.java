package com.jpastore.sportsai;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.widget.*;
public class MainActivity extends Activity{
 PremiumView ui;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(2,10,14));getWindow().setNavigationBarColor(Color.rgb(2,10,14));ui=new PremiumView(this);setContentView(ui);}
 public void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
 public void apiDialog(){final EditText e=new EditText(this);e.setHint("Chave API-Football");e.setSingleLine();e.setText(apiKey());new AlertDialog.Builder(this).setTitle("API-Football").setMessage("A chave fica salva somente neste aparelho.").setView(e).setPositiveButton("SALVAR",(d,w)->{getPreferences(0).edit().putString("api",e.getText().toString().trim()).apply();toast("Chave salva");ui.refreshFixtures();}).setNeutralButton("TESTAR",(d,w)->new ApiClient(this).test(e.getText().toString().trim(),ok->runOnUiThread(()->toast(ok?"API conectada":"Falha na conexão")))).setNegativeButton("FECHAR",null).show();}
 public void searchDialog(){final EditText e=new EditText(this);e.setHint("Time ou campeonato");new AlertDialog.Builder(this).setTitle("Buscar futebol").setView(e).setPositiveButton("BUSCAR",(d,w)->ui.searchGlobal(e.getText().toString().trim())).setNegativeButton("CANCELAR",null).show();}
 public void infoDialog(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}
 public void shareTicket(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"J.Pastore Sports AI • Bilhete para revisão. Probabilidades são estimativas e não garantias.");startActivity(Intent.createChooser(i,"Compartilhar bilhete"));}
 public void hubDialog(){final EditText e=new EditText(this);e.setHint("https://seu-data-hub.exemplo.com");e.setSingleLine();e.setText(hubUrl());new AlertDialog.Builder(this).setTitle("J.Pastore Data Hub").setMessage("Quando configurado, o app consulta primeiro o Data Hub e usa cache/API-Football como contingência.").setView(e).setPositiveButton("SALVAR",(d,w)->{getPreferences(0).edit().putString("hub",e.getText().toString().trim().replaceAll("/$","")).apply();toast("Data Hub salvo");ui.refreshFixtures();}).setNegativeButton("FECHAR",null).show();}
 public String hubUrl(){return getPreferences(0).getString("hub","");}
 public String apiKey(){return getPreferences(0).getString("api","");}
}
