package com.jpastore.sportsai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView statusText, summaryText;
    private EditText searchInput;
    private String searchQuery = "";
    private Button refreshButton;
    private LinearLayout championshipTabs;
    private LinearLayout pageHost;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private List<Game> games = new ArrayList<>();
    private int filter = 0;
    private long lastRefreshAt = 0L;
    private boolean upcomingLoaded = false;
    private boolean upcomingLoading = false;
    private String selectedLeagueKey = null;
    private String selectedLeagueLabel = null;
    private boolean favoritesOnly = false;
    private final Set<String> favoriteLeagueKeys = new LinkedHashSet<>();
    private final int BG = Color.rgb(7,17,31), CARD = Color.rgb(15,29,48), TEXT = Color.rgb(239,244,250), MUTED = Color.rgb(151,166,185);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadFavoriteLeagues();
        buildUI();
        load(false);
    }

    private void buildUI() {
        LinearLayout app=new LinearLayout(this); app.setOrientation(LinearLayout.VERTICAL); app.setBackgroundColor(BG);
        pageHost=new LinearLayout(this); pageHost.setOrientation(LinearLayout.VERTICAL);
        app.addView(pageHost,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(dp(4),dp(3),dp(4),dp(4));
        GradientDrawable nb=new GradientDrawable(); nb.setColor(Color.rgb(3,14,21)); nb.setStroke(dp(1),Color.rgb(17,65,70)); nav.setBackground(nb);
        nav.addView(bottomNavButton("⌂\nInício",v->showHomePage()));
        nav.addView(bottomNavButton("⚽\nJogos",v->showLivePage()));
        nav.addView(bottomNavButton("✦\nRadar IA",v->showRadarPage()));
        nav.addView(bottomNavButton("▣\nBilhetes",v->showTicketPage()));
        nav.addView(bottomNavButton("☰\nMais",v->showMorePage()));
        app.addView(nav,new LinearLayout.LayoutParams(-1,dp(64))); setContentView(app); showHomePage();
    }

    private LinearLayout newPage(String title){
        pageHost.removeAllViews(); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(16),dp(12),dp(16),dp(24)); r.setBackgroundColor(BG); sv.addView(r,new ScrollView.LayoutParams(-1,-2)); pageHost.addView(sv,new LinearLayout.LayoutParams(-1,-1));
        LinearLayout h=new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL); TextView brand=text("♛  J.PASTORE\n     SPORTS AI",18,TEXT,true); brand.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1f)); h.addView(brand); TextView t=text(title,13,Color.rgb(0,245,150),true); h.addView(t); r.addView(h); return r;
    }

    private void showHomePage(){
        LinearLayout root=newPage("PREMIUM"); statusText=text("",11,MUTED,false); statusText.setPadding(0,dp(7),0,dp(10)); root.addView(statusText);
        searchInput=new EditText(this); searchInput.setHint("⌕  Buscar time, campeonato ou jogo..."); searchInput.setHintTextColor(MUTED); searchInput.setTextColor(TEXT); searchInput.setSingleLine(true); searchInput.setTextSize(14); searchInput.setPadding(dp(14),0,dp(14),0); GradientDrawable sb=new GradientDrawable(); sb.setCornerRadius(dp(18)); sb.setColor(Color.rgb(5,24,34)); sb.setStroke(dp(1),Color.rgb(25,89,98)); searchInput.setBackground(sb); root.addView(searchInput,new LinearLayout.LayoutParams(-1,dp(50))); searchInput.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){searchQuery=s==null?"":s.toString().trim().toLowerCase(Locale.ROOT);render();} public void afterTextChanged(Editable e){}});
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout chips=new LinearLayout(this); chips.setOrientation(LinearLayout.HORIZONTAL); chips.addView(premiumChip("⚽ Futebol",v->{filter=3;render();})); chips.addView(premiumChip("◉ Hoje",v->{filter=3;render();})); chips.addView(premiumChip("● Ao vivo",v->showLivePage())); chips.addView(premiumChip("🏆 Ligas",v->showLeaguesPage())); chips.addView(premiumChip("⋯ Mais",v->showMorePage())); hs.addView(chips); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.setMargins(0,dp(10),0,dp(8)); root.addView(hs,hp);
        LinearLayout hero=sectionBox(); hero.addView(text("✦ JOGO EM DESTAQUE",12,Color.rgb(0,245,150),true)); hero.addView(text("Análise avançada • probabilidades • mercados • odds",14,TEXT,true)); hero.addView(text("Toque em um confronto para abrir a análise completa.",11,MUTED,false)); root.addView(hero);
        LinearLayout q=new LinearLayout(this); q.setOrientation(LinearLayout.HORIZONTAL); q.addView(quickAction("✦\nRadar IA",v->showRadarPage())); q.addView(quickAction("▣\nBilhete IA",v->showTicketPage())); root.addView(q);
        TextView mt=text("MELHORES JOGOS DO DIA",13,TEXT,true); mt.setPadding(0,dp(16),0,dp(6)); root.addView(mt); summaryText=text("",12,MUTED,true); root.addView(summaryText); championshipTabs=new LinearLayout(this); championshipTabs.setOrientation(LinearLayout.HORIZONTAL); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
        refreshButton=button("↻ Atualizar dados",v->load(true)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(44)); rp.setMargins(0,dp(12),0,0); root.addView(refreshButton,rp); render();
    }

    private void showLivePage(){ LinearLayout r=newPage("● AO VIVO"); r.addView(tabStrip()); r.addView(text("Jogos e placares",22,TEXT,true)); r.addView(text("Acompanhe partidas em andamento e abra a análise estatística de cada confronto.",12,MUTED,false)); for(Game g:games){ if(g.isLive()){ View c=card(g); r.addView(c); } } if(games.isEmpty()) r.addView(emptyBox("Nenhuma partida carregada. Volte ao Início e atualize os dados.")); }
    private View tabStrip(){ HorizontalScrollView hs=new HorizontalScrollView(this); LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); x.addView(premiumChip("Todos",v->{})); x.addView(premiumChip("Futebol",v->{})); x.addView(premiumChip("Ao vivo",v->{})); x.addView(premiumChip("Hoje",v->{})); hs.addView(x); return hs; }
    private TextView emptyBox(String s){ TextView t=text(s,13,MUTED,false); t.setPadding(dp(14),dp(20),dp(14),dp(20)); return t; }

    private void showLeaguesPage(){ LinearLayout r=newPage("CAMPEONATOS"); r.addView(tabStrip()); r.addView(text("Favoritos",13,Color.rgb(255,193,7),true)); String[] ls={"★ Champions League","★ Brasileirão Série A","★ Premier League","★ La Liga","★ Serie A","Ligue 1","Libertadores","Copa do Brasil","Sul-Americana","Bundesliga","Eredivisie"}; for(String x:ls) r.addView(menuRow(x,"›",v->{selectedLeagueLabel=x.replace("★ ","");showHomePage();})); }

    private void showRadarPage(){ LinearLayout r=newPage("RADAR IA"); r.addView(text("✦ Radar IA",24,TEXT,true)); r.addView(text("Encontra oportunidades estatísticas com base nos dados disponíveis.",12,MUTED,false)); r.addView(tabStrip()); List<Game> a=new ArrayList<>(); for(Game g:games) if(g.analyzed) a.add(g); Collections.sort(a,(x,y)->Integer.compare(y.confidence,x.confidence)); int n=0; for(Game g:a){ if(n++>=8)break; LinearLayout b=sectionBox(); b.addView(text(g.home+" × "+g.away,15,TEXT,true)); b.addView(text(label(g.confidence)+"  "+g.confidence+"%",15,riskColor(g.confidence),true)); b.addView(text(g.pick,13,Color.rgb(0,245,150),true)); b.setOnClickListener(v->showDetail(g)); r.addView(b);} if(a.isEmpty()) r.addView(emptyBox("Analise partidas para alimentar o Radar IA.")); }

    private void showTicketPage(){ LinearLayout r=newPage("BILHETE IA"); r.addView(text("▣ Bilhete IA",24,TEXT,true)); r.addView(text("Seleções montadas a partir das análises estatísticas.",12,MUTED,false)); r.addView(tabStrip()); List<Game>a=new ArrayList<>(); for(Game g:games)if(g.analyzed&&g.confidence>=55)a.add(g); if(a.isEmpty()){r.addView(emptyBox("Analise partidas primeiro para gerar um bilhete."));return;} StringBuilder cp=new StringBuilder("J.Pastore Sports AI — Bilhete IA\n"); double total=1; int n=0; for(Game g:a){if(n++>=5)break; LinearLayout b=sectionBox(); b.addView(text("⚽  "+g.home+" × "+g.away,14,TEXT,true)); b.addView(text(g.pick,13,Color.rgb(0,245,150),true)); b.addView(text("Confiança IA  "+g.confidence+"%",12,MUTED,false)); r.addView(b); cp.append("• ").append(g.home).append(" x ").append(g.away).append(" — ").append(g.pick).append("\n");}
        Button copy=button("▣  COPIAR BILHETE",v->copy(cp.toString())); copy.setTextColor(Color.rgb(2,25,20)); GradientDrawable gb=new GradientDrawable(); gb.setColor(Color.rgb(0,245,150)); gb.setCornerRadius(dp(10)); copy.setBackground(gb); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(50)); bp.setMargins(0,dp(8),0,dp(8)); r.addView(copy,bp); Button share=button("⌯  COMPARTILHAR BILHETE",v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,cp.toString());startActivity(Intent.createChooser(i,"Compartilhar bilhete"));});r.addView(share,new LinearLayout.LayoutParams(-1,dp(50))); r.addView(text("Envio direto para casa de apostas será ativado apenas com integração oficial autorizada.",10,MUTED,false)); }

    private void showProfilePage(){ LinearLayout r=newPage("PERFIL"); LinearLayout p=sectionBox(); p.addView(text("◉  Júlio Pastore",20,TEXT,true)); p.addView(text("♛ Usuário Premium",14,Color.rgb(255,193,7),true)); p.addView(text("Análise. Estratégia. Resultados.",11,MUTED,false)); r.addView(p); LinearLayout active=sectionBox(); active.addView(text("✓ Plano Premium Ativo",15,Color.rgb(0,245,150),true)); active.addView(text("Acesso às funcionalidades da versão premium.",11,MUTED,false)); r.addView(active); r.addView(menuRow("▥ Minhas Estatísticas","›",v->{})); r.addView(menuRow("♡ Times Favoritos","›",v->{})); r.addView(menuRow("🔔 Notificações","›",v->{})); r.addView(menuRow("⚙ Configurações","›",v->showSettings())); r.addView(menuRow("? Ajuda e Suporte","›",v->{})); }

    private void showMorePage(){ LinearLayout r=newPage("MAIS"); r.addView(menuRow("▤ Notícias","Últimas do mundo esportivo  ›",v->{})); r.addView(menuRow("◉ Dicas e Estratégias","Conteúdos educativos  ›",v->{})); r.addView(menuRow("▦ Calculadora de Probabilidades","Ferramentas estatísticas  ›",v->{})); r.addView(menuRow("↔ Comparador de Odds","Quando houver dados oficiais  ›",v->{})); r.addView(menuRow("▣ Calendário de Jogos","Próximas partidas  ›",v->loadUpcoming())); r.addView(menuRow("▥ Relatórios IA","Análises detalhadas  ›",v->{})); r.addView(menuRow("♟ Perfil","Abrir perfil premium  ›",v->showProfilePage())); r.addView(menuRow("⚙ Configurações","API e preferências  ›",v->showSettings())); r.addView(menuRow("ⓘ Sobre","J.Pastore Sports AI • V14  ›",v->{})); }

    private View menuRow(String a,String b,View.OnClickListener l){ LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); x.setGravity(Gravity.CENTER_VERTICAL); x.setPadding(dp(14),dp(12),dp(12),dp(12)); GradientDrawable gd=new GradientDrawable();gd.setColor(Color.rgb(8,27,37));gd.setCornerRadius(dp(10));gd.setStroke(dp(1),Color.rgb(18,57,68));x.setBackground(gd);TextView t=text(a,14,TEXT,true);t.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1f));x.addView(t);x.addView(text(b,11,MUTED,false));x.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,0);x.setLayoutParams(lp);return x; }

    private Button premiumChip(String label, View.OnClickListener listener){ Button b=button(label,listener); b.setTextSize(11); b.setMinWidth(0); b.setMinimumWidth(0); b.setPadding(dp(11),0,dp(11),0); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(42)); lp.setMargins(0,0,dp(6),dp(4)); b.setLayoutParams(lp); return b; }
    private Button quickAction(String label, View.OnClickListener listener){ Button b=button(label,listener); b.setTextSize(12); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(62),1f); lp.setMargins(dp(3),dp(8),dp(3),0); b.setLayoutParams(lp); return b; }

    private void load(boolean manual) {
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            games = demoGames();
            upcomingLoaded = true;
            statusText.setText("MODO DEMONSTRAÇÃO • configure sua API para partidas reais");
            render();
            return;
        }

        long nowMs = System.currentTimeMillis();
        if (manual && lastRefreshAt > 0 && nowMs - lastRefreshAt < 65000L) {
            long wait = (65000L - (nowMs - lastRefreshAt) + 999L) / 1000L;
            Toast.makeText(this, "Aguarde " + wait + "s para atualizar novamente.", Toast.LENGTH_SHORT).show();
            return;
        }

        statusText.setText("Carregando TODOS os jogos de hoje (00:00–23:59, horário de Brasília)…");
        refreshButton.setEnabled(false);
        executor.execute(() -> {
            try {
                List<Game> g = client.loadToday();
                runOnUiThread(() -> {
                    games = g;
                    upcomingLoaded = false;
                    upcomingLoading = false;
                    lastRefreshAt = System.currentTimeMillis();
                    refreshButton.setEnabled(true);
                    String now = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("ONLINE • HOJE 00:00–23:59 (Brasília): " + games.size() + " jogos • " + now + quota + " • lista completa do dia");
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    refreshButton.setEnabled(true);
                    games = new ArrayList<>();
                    upcomingLoaded = false;
                    upcomingLoading = false;
                    statusText.setText("Falha online: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void loadUpcoming() {
        filter = 4;
        if (upcomingLoaded) {
            render();
            return;
        }
        if (upcomingLoading) {
            Toast.makeText(this, "Os próximos jogos já estão sendo carregados.", Toast.LENGTH_SHORT).show();
            return;
        }

        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            render();
            return;
        }

        upcomingLoading = true;
        statusText.setText("Carregando próximos 3 dias… pode levar alguns segundos para respeitar o limite da API.");
        executor.execute(() -> {
            try {
                List<Game> upcoming = client.loadUpcomingDays(3);
                runOnUiThread(() -> {
                    LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();
                    for (Game g : games) merged.put(g.fixtureId, g);
                    for (Game g : upcoming) if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
                    games = new ArrayList<>(merged.values());
                    upcomingLoaded = true;
                    upcomingLoading = false;
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("ONLINE • próximos 3 dias carregados: " + upcoming.size() + " jogos" + quota);
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    upcomingLoading = false;
                    statusText.setText("Falha ao carregar próximos jogos: " + friendlyError(e.getMessage()));
                    render();
                });
            }
        });
    }

    private void analyze(Game g) {
        if (g.analyzed) {
            showDetail(g);
            return;
        }
        String key = getPreferences(MODE_PRIVATE).getString("api_key", "");
        ApiSportsClient client = new ApiSportsClient(key);
        if (!client.configured()) {
            Toast.makeText(this, "Configure sua API primeiro.", Toast.LENGTH_SHORT).show();
            return;
        }
        statusText.setText("IA estatística analisando " + g.home + " × " + g.away + "… pode levar alguns segundos.");
        executor.execute(() -> {
            try {
                AdvancedAnalysis a = client.loadAdvancedAnalysis(g);
                g.applyAdvanced(a);
                runOnUiThread(() -> {
                    String quota = client.getRemaining() >= 0 ? " • cota restante: " + client.getRemaining() : "";
                    statusText.setText("Análise concluída" + quota);
                    render();
                    showDetail(g);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusText.setText("Não foi possível analisar: " + friendlyError(e.getMessage()));
                    new AlertDialog.Builder(this)
                            .setTitle("Análise indisponível")
                            .setMessage(friendlyError(e.getMessage()))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        });
    }

    private void render() {
        list.removeAllViews();
        renderChampionshipTabs();

        List<Game> visible = new ArrayList<>();
        for (Game g : games) if (accept(g)) visible.add(g);

        int green = 0, yellow = 0, red = 0, analyzed = 0;
        for (Game g : visible) {
            if (!g.analyzed) continue;
            analyzed++;
            if (g.confidence >= 70) green++; else if (g.confidence >= 55) yellow++; else red++;
        }

        String filterText = activeFilterText();
        summaryText.setText(filterText + "Exibidos: " + visible.size() + " • Analisados: " + analyzed + "   🟢 " + green + "   🟡 " + yellow + "   🔴 " + red + "\nToque em uma partida para abrir a IA estatística e os mercados avançados.");

        visible.sort((a, b) -> {
            int c = Integer.compare(championshipPriority(leagueDisplay(a)), championshipPriority(leagueDisplay(b)));
            if (c != 0) return c;
            c = Integer.compare(teamPopularity(b), teamPopularity(a));
            if (c != 0) return c;
            c = a.time.compareTo(b.time);
            if (c != 0) return c;
            if (a.analyzed != b.analyzed) return a.analyzed ? -1 : 1;
            return Integer.compare(b.confidence, a.confidence);
        });

        LinkedHashMap<String, List<Game>> grouped = new LinkedHashMap<>();
        for (Game g : visible) {
            String key = leagueKey(g);
            List<Game> group = grouped.get(key);
            if (group == null) {
                group = new ArrayList<>();
                grouped.put(key, group);
            }
            group.add(g);
        }

        for (List<Game> group : grouped.values()) {
            if (group.isEmpty()) continue;
            Game first = group.get(0);
            list.addView(championshipHeader(first, group.size()));
            for (Game g : group) list.addView(card(g));
        }

        if (visible.isEmpty()) {
            String message;
            if (filter == 4 && !upcomingLoaded) message = "Toque em Próximos para carregar os próximos 3 dias.";
            else if (favoritesOnly && favoriteLeagueKeys.isEmpty()) message = "Nenhum campeonato favorito salvo.";
            else if (selectedLeagueKey != null) message = "Nenhuma partida deste campeonato no filtro atual.";
            else if (searchQuery != null && !searchQuery.isEmpty()) message = "Nenhum jogo encontrado para: " + searchQuery;
            else message = games.isEmpty() ? "Nenhuma partida retornada pela API agora." : "Nenhuma partida neste filtro.";
            list.addView(text(message, 14, MUTED, false));
        }
    }

    private void renderChampionshipTabs() {
        if (championshipTabs == null) return;
        championshipTabs.removeAllViews();

        List<Game> modeGames = new ArrayList<>();
        for (Game g : games) if (acceptMode(g)) modeGames.add(g);

        Button all = championshipChip((selectedLeagueKey == null && !favoritesOnly ? "✓ " : "") + "Todos (" + modeGames.size() + ")", v -> {
            selectedLeagueKey = null;
            selectedLeagueLabel = null;
            favoritesOnly = false;
            render();
        });
        championshipTabs.addView(all);

        LinkedHashMap<String, LeagueInfo> map = new LinkedHashMap<>();
        for (Game g : modeGames) {
            String key = leagueKey(g);
            LeagueInfo info = map.get(key);
            if (info == null) {
                info = new LeagueInfo(key, leagueDisplay(g));
                map.put(key, info);
            }
            info.count++;
        }

        List<LeagueInfo> leagues = new ArrayList<>(map.values());
        leagues.sort((a, b) -> championshipOrder(a.label, b.label));
        for (LeagueInfo info : leagues) {
            String prefix = info.key.equals(selectedLeagueKey) && !favoritesOnly ? "✓ " : "";
            Button chip = championshipChip(prefix + info.label + " (" + info.count + ")", v -> {
                selectedLeagueKey = info.key;
                selectedLeagueLabel = info.label;
                favoritesOnly = false;
                render();
            });
            championshipTabs.addView(chip);
        }

        if (!favoriteLeagueKeys.isEmpty()) {
            Button fav = championshipChip((favoritesOnly ? "✓ " : "") + "★ Favoritos", v -> showFavoriteChampionships());
            championshipTabs.addView(fav);
        }
    }

    private int championshipOrder(String a, String b) {
        int pa = championshipPriority(a);
        int pb = championshipPriority(b);
        if (pa != pb) return Integer.compare(pa, pb);
        return a.compareToIgnoreCase(b);
    }

    private int championshipPriority(String label) {
        String n = label.toLowerCase(Locale.ROOT);
        if (n.contains("brasileirão série a")) return 1;
        if (n.contains("brasileirão série b")) return 2;
        if (n.contains("copa do brasil")) return 3;
        if (n.contains("libertadores")) return 4;
        if (n.contains("sul-americana") || n.contains("sudamericana")) return 5;
        if (n.contains("champions")) return 6;
        if (n.contains("premier league")) return 7;
        if (n.contains("la liga")) return 8;
        if (n.contains("serie a") && n.contains("itália")) return 9;
        if (n.contains("bundesliga")) return 10;
        if (n.contains("ligue 1")) return 11;
        return 50;
    }

    private boolean acceptMode(Game g) {
        if (filter == 1) return g.analyzed && g.confidence >= 70;
        if (filter == 2) return "AO VIVO".equals(g.bucket);
        if (filter == 3) return "HOJE".equals(g.bucket) || "AO VIVO".equals(g.bucket);
        if (filter == 4) return "PRÓXIMO".equals(g.bucket);
        return true;
    }

    private boolean accept(Game g) {
        if (!acceptMode(g)) return false;
        String key = leagueKey(g);
        if (selectedLeagueKey != null && !selectedLeagueKey.equals(key)) return false;
        if (favoritesOnly && !favoriteLeagueKeys.contains(key)) return false;
        if (searchQuery != null && !searchQuery.isEmpty()) {
            String hay = (g.home + " " + g.away + " " + g.league + " " + g.leagueCountry + " " + leagueDisplay(g)).toLowerCase(Locale.ROOT);
            if (!hay.contains(searchQuery)) return false;
        }
        return true;
    }

    private View card(Game g) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(CARD);
        bg.setStroke(dp(2), g.analyzed ? riskColor(g.confidence) : Color.rgb(70, 95, 120));
        c.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        c.setLayoutParams(cp);

        c.addView(text(g.bucket + " • " + g.time + " • " + g.status, 11, MUTED, false));
        if (teamPopularity(g) >= 80) {
            TextView featured = text("★ JOGO EM DESTAQUE", 11, Color.rgb(71, 220, 144), true);
            featured.setPadding(0, dp(5), 0, 0);
            c.addView(featured);
        }
        TextView teams = text(g.home + "  ×  " + g.away, 18, TEXT, true);
        teams.setPadding(0, dp(5), 0, dp(5));
        c.addView(teams);

        if (!"-".equals(g.score)) c.addView(text("Placar: " + g.score, 13, TEXT, true));

        if (!g.analyzed) {
            TextView action = text("◉ TOQUE PARA ANALISAR", 14, Color.rgb(90, 190, 255), true);
            action.setPadding(0, dp(7), 0, dp(4));
            c.addView(action);
            c.addView(text("A previsão será consultada somente para este jogo.", 12, MUTED, false));
        } else {
            c.addView(text(label(g.confidence) + "  " + g.confidence + "%", 15, riskColor(g.confidence), true));
            TextView pick = text("Palpite principal: " + g.pick, 13, TEXT, true);
            pick.setPadding(0, dp(7), 0, dp(3));
            c.addView(pick);
            c.addView(text(g.trend, 13, MUTED, false));
            TextView probs = text("Mandante " + g.homePct + "%  •  Empate " + g.drawPct + "%  •  Visitante " + g.awayPct + "%", 12, MUTED, false);
            probs.setPadding(0, dp(4), 0, 0);
            c.addView(probs);
            if (g.advanced != null && !g.advanced.markets.isEmpty()) {
                StringBuilder quick = new StringBuilder();
                int shown = 0;
                for (AdvancedAnalysis.Market m : g.advanced.markets) {
                    if (m.probability < 58) continue;
                    if (shown++ > 0) quick.append("  •  ");
                    quick.append(m.selection).append(" ").append(m.probability).append("%");
                    if (shown >= 2) break;
                }
                if (quick.length() > 0) {
                    TextView q = text("Destaques: " + quick, 12, Color.rgb(103, 213, 178), true);
                    q.setPadding(0, dp(5), 0, 0);
                    c.addView(q);
                }
            }
        }

        c.setOnClickListener(v -> analyze(g));
        return c;
    }

    private View championshipHeader(Game g, int count) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(14), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(Color.rgb(19, 43, 62));
        bg.setStroke(dp(1), Color.rgb(51, 155, 115));
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(8));
        box.setLayoutParams(lp);

        TextView title = text(leagueDisplay(g) + "  •  " + count + (count == 1 ? " jogo" : " jogos"), 16, TEXT, true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(title);

        Button star = new Button(this);
        star.setAllCaps(false);
        star.setText(favoriteLeagueKeys.contains(leagueKey(g)) ? "★" : "☆");
        star.setTextSize(18);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(54), dp(44));
        star.setLayoutParams(sp);
        star.setOnClickListener(v -> {
            String key = leagueKey(g);
            if (favoriteLeagueKeys.contains(key)) favoriteLeagueKeys.remove(key);
            else favoriteLeagueKeys.add(key);
            saveFavoriteLeagues();
            render();
        });
        box.addView(star);
        return box;
    }

    private Button championshipChip(String label, View.OnClickListener listener) {
        Button b = button(label, listener);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44));
        lp.setMargins(0, 0, dp(6), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private void showChampionshipsDialog() {
        if (games.isEmpty()) {
            Toast.makeText(this, "Carregue os jogos primeiro.", Toast.LENGTH_SHORT).show();
            return;
        }

        LinkedHashMap<String, LeagueInfo> map = new LinkedHashMap<>();
        for (Game g : games) {
            String key = leagueKey(g);
            LeagueInfo info = map.get(key);
            if (info == null) {
                info = new LeagueInfo(key, leagueDisplay(g));
                map.put(key, info);
            }
            info.count++;
        }

        List<LeagueInfo> leagues = new ArrayList<>(map.values());
        leagues.sort((a, b) -> a.label.compareToIgnoreCase(b.label));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(6));
        final AlertDialog[] holder = new AlertDialog[1];

        TextView all = dialogRowText("Todos os campeonatos  •  " + games.size() + " jogos");
        all.setOnClickListener(v -> {
            selectedLeagueKey = null;
            selectedLeagueLabel = null;
            favoritesOnly = false;
            if (holder[0] != null) holder[0].dismiss();
            render();
        });
        box.addView(all);

        for (LeagueInfo info : leagues) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView title = dialogRowText(info.label + "  •  " + info.count + (info.count == 1 ? " jogo" : " jogos"));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            title.setLayoutParams(tp);
            title.setOnClickListener(v -> {
                selectedLeagueKey = info.key;
                selectedLeagueLabel = info.label;
                favoritesOnly = false;
                if (holder[0] != null) holder[0].dismiss();
                render();
            });
            row.addView(title);

            Button star = new Button(this);
            star.setAllCaps(false);
            star.setText(favoriteLeagueKeys.contains(info.key) ? "★" : "☆");
            star.setTextSize(20);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(60), dp(50));
            star.setLayoutParams(bp);
            star.setOnClickListener(v -> {
                if (favoriteLeagueKeys.contains(info.key)) favoriteLeagueKeys.remove(info.key);
                else favoriteLeagueKeys.add(info.key);
                saveFavoriteLeagues();
                star.setText(favoriteLeagueKeys.contains(info.key) ? "★" : "☆");
                render();
            });
            row.addView(star);
            box.addView(row);
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Campeonatos")
                .setMessage("Toque no campeonato para filtrar. Toque em ☆ para adicionar aos favoritos.")
                .setView(sv)
                .setNegativeButton("Fechar", null)
                .create();
        holder[0] = dialog;
        dialog.show();
    }

    private void showFavoriteChampionships() {
        if (favoriteLeagueKeys.isEmpty()) {
            Toast.makeText(this, "Você ainda não favoritou campeonatos. Escolha em Campeonatos.", Toast.LENGTH_LONG).show();
            showChampionshipsDialog();
            return;
        }
        selectedLeagueKey = null;
        selectedLeagueLabel = null;
        favoritesOnly = true;
        render();
    }

    private String activeFilterText() {
        StringBuilder sb = new StringBuilder();
        if (selectedLeagueKey != null && selectedLeagueLabel != null) sb.append("Campeonato: ").append(selectedLeagueLabel).append("\n");
        else if (favoritesOnly) sb.append("Campeonatos favoritos\n");
        return sb.toString();
    }

    private int teamPopularity(Game g) {
        return Math.max(teamPopularityName(g.home), teamPopularityName(g.away));
    }

    private int teamPopularityName(String team) {
        if (team == null) return 0;
        String n = java.text.Normalizer.normalize(team, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT);

        String[] elite = {
                "real madrid", "barcelona", "atletico de madrid", "manchester city", "manchester united",
                "liverpool", "arsenal", "chelsea", "tottenham", "bayern", "borussia dortmund",
                "paris saint-germain", "psg", "juventus", "milan", "inter", "napoli",
                "flamengo", "corinthians", "palmeiras", "sao paulo", "santos", "gremio",
                "internacional", "atletico-mg", "atletico mineiro", "cruzeiro", "botafogo", "fluminense", "vasco"
        };
        for (String x : elite) if (n.contains(x)) return 100;

        String[] strong = {
                "sevilla", "valencia", "athletic club", "real sociedad", "villarreal",
                "bayer leverkusen", "leverkusen", "rb leipzig", "benfica", "porto", "sporting",
                "ajax", "psv", "feyenoord", "olympiacos", "galatasaray", "fenerbahce",
                "athletico-pr", "bahia", "fortaleza", "bragantino", "ceara", "sport recife"
        };
        for (String x : strong) if (n.contains(x)) return 80;
        return 0;
    }

    private String leagueKey(Game g) {
        if (g.leagueId > 0) return "id:" + g.leagueId;
        return "name:" + g.leagueCountry + "|" + g.league;
    }

    private String leagueDisplay(Game g) {
        String name = g.league == null ? "Campeonato" : g.league.trim();
        String country = g.leagueCountry == null ? "" : g.leagueCountry.trim();

        if (g.leagueId == 71 || ("Brazil".equalsIgnoreCase(country) && "Serie A".equalsIgnoreCase(name))) return "🇧🇷 Brasileirão Série A";
        if (g.leagueId == 72 || ("Brazil".equalsIgnoreCase(country) && "Serie B".equalsIgnoreCase(name))) return "🇧🇷 Brasileirão Série B";
        if (g.leagueId == 73 || name.toLowerCase(Locale.ROOT).contains("copa do brasil")) return "🇧🇷 Copa do Brasil";
        if (g.leagueId == 13 || name.toLowerCase(Locale.ROOT).contains("libertadores")) return "🌎 Libertadores";
        if (g.leagueId == 11 || name.toLowerCase(Locale.ROOT).contains("sudamericana") || name.toLowerCase(Locale.ROOT).contains("sul-americana")) return "🌎 Sul-Americana";
        if (g.leagueId == 2 || name.toLowerCase(Locale.ROOT).contains("champions league")) return "🇪🇺 Champions League";
        if (g.leagueId == 39 || name.toLowerCase(Locale.ROOT).contains("premier league")) return "🏴 Premier League";
        if (g.leagueId == 140 || "La Liga".equalsIgnoreCase(name)) return "🇪🇸 La Liga";
        if (g.leagueId == 135 || ("Italy".equalsIgnoreCase(country) && "Serie A".equalsIgnoreCase(name))) return "🇮🇹 Serie A (Itália)";
        if (g.leagueId == 78 || name.toLowerCase(Locale.ROOT).contains("bundesliga")) return "🇩🇪 Bundesliga";
        if (g.leagueId == 61 || name.toLowerCase(Locale.ROOT).contains("ligue 1")) return "🇫🇷 Ligue 1";

        String flag = countryFlag(country);
        if (!flag.isEmpty()) return flag + " " + name;
        return name;
    }

    private String countryFlag(String country) {
        if (country == null) return "";
        String c = country.trim().toLowerCase(Locale.ROOT);
        if (c.equals("brazil")) return "🇧🇷";
        if (c.equals("england")) return "🏴";
        if (c.equals("spain")) return "🇪🇸";
        if (c.equals("italy")) return "🇮🇹";
        if (c.equals("germany")) return "🇩🇪";
        if (c.equals("france")) return "🇫🇷";
        if (c.equals("argentina")) return "🇦🇷";
        if (c.equals("portugal")) return "🇵🇹";
        if (c.equals("netherlands")) return "🇳🇱";
        if (c.equals("usa") || c.equals("united states")) return "🇺🇸";
        return "";
    }

    private void loadFavoriteLeagues() {
        Set<String> saved = getPreferences(MODE_PRIVATE).getStringSet("favorite_leagues", null);
        if (saved != null) favoriteLeagueKeys.addAll(saved);
    }

    private void saveFavoriteLeagues() {
        getPreferences(MODE_PRIVATE).edit().putStringSet("favorite_leagues", new HashSet<>(favoriteLeagueKeys)).apply();
    }

    private TextView dialogRowText(String value) {
        TextView t = text(value, 14, Color.DKGRAY, false);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12), 0, dp(8), 0);
        return t;
    }

    private void showDetail(Game g) {
        if (g.advanced == null) {
            String msg = g.home + " × " + g.away + "\n" + g.reason + "\n\nProbabilidades: " + g.homePct + "% / " + g.drawPct + "% / " + g.awayPct + "%";
            new AlertDialog.Builder(this).setTitle("Análise da partida").setMessage(msg).setNegativeButton("Fechar", null).show();
            return;
        }

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(12), dp(10), dp(12), dp(8));
        shell.setBackgroundColor(BG);

        TextView league = text(leagueDisplay(g) + "  •  " + g.time + "  •  " + g.status, 12, MUTED, false);
        shell.addView(league);
        TextView title = text(g.home + "  ×  " + g.away, 22, TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(8));
        shell.addView(title);

        LinearLayout teamShortcuts = new LinearLayout(this);
        teamShortcuts.setOrientation(LinearLayout.HORIZONTAL);
        teamShortcuts.addView(detailShortcut("⚽ " + g.home, v -> showTeamQuickProfile(g, true)));
        teamShortcuts.addView(detailShortcut("⚽ " + g.away, v -> showTeamQuickProfile(g, false)));
        shell.addView(teamShortcuts);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(tabs);
        shell.addView(hsv, new LinearLayout.LayoutParams(-1, dp(52)));

        ScrollView contentScroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(8), 0, dp(10));
        contentScroll.addView(content);
        LinearLayout.LayoutParams csp = new LinearLayout.LayoutParams(-1, 0, 1f);
        contentScroll.setLayoutParams(csp);
        shell.addView(contentScroll);

        String[] names = {"Resumo", "IA", "Mercados", "Estatísticas", "Escalação", "Tabela", "H2H", "Jogadores"};
        for (String name : names) {
            tabs.addView(detailTab(name, v -> renderDetailTab(g, name, content)));
        }
        renderDetailTab(g, "Resumo", content);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(shell)
                .setPositiveButton("Copiar análise", (d,w) -> copy(buildCopyText(g, g.advanced)))
                .setNegativeButton("Fechar", null)
                .create();
        dialog.setOnShowListener(x -> {
            Window w = dialog.getWindow();
            if (w != null) w.setLayout(-1, (int)(getResources().getDisplayMetrics().heightPixels * 0.90));
        });
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) w.setLayout(-1, (int)(getResources().getDisplayMetrics().heightPixels * 0.90));
    }

    private Button detailTab(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(label); b.setTextSize(12); b.setTextColor(TEXT);
        GradientDrawable bg = new GradientDrawable(); bg.setCornerRadius(dp(18)); bg.setColor(Color.rgb(18,43,68)); bg.setStroke(dp(1), Color.rgb(47,104,145)); b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(42)); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); b.setLayoutParams(lp); b.setOnClickListener(listener);
        return b;
    }

    private Button detailShortcut(String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(label); b.setTextSize(11); b.setTextColor(TEXT); b.setOnClickListener(listener);
        GradientDrawable bg = new GradientDrawable(); bg.setCornerRadius(dp(14)); bg.setColor(Color.rgb(12,31,51)); bg.setStroke(dp(1), Color.rgb(44,80,109)); b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42),1f); lp.setMargins(dp(3),dp(2),dp(3),dp(5)); b.setLayoutParams(lp); return b;
    }

    private void renderDetailTab(Game g, String tab, LinearLayout content) {
        content.removeAllViews();
        AdvancedAnalysis a = g.advanced;
        if (a == null) return;
        if ("Resumo".equals(tab)) renderSummaryTab(g,a,content);
        else if ("IA".equals(tab)) renderAiTab(g,a,content);
        else if ("Mercados".equals(tab)) renderMarketsTab(g,a,content);
        else if ("Estatísticas".equals(tab)) renderStatisticsTab(g,a,content);
        else if ("Escalação".equals(tab)) loadRemoteDetail(g,content,"lineups");
        else if ("Tabela".equals(tab)) loadRemoteDetail(g,content,"standings");
        else if ("H2H".equals(tab)) loadRemoteDetail(g,content,"h2h");
        else if ("Jogadores".equals(tab)) loadRemoteDetail(g,content,"players");
    }

    private void renderSummaryTab(Game g, AdvancedAnalysis a, LinearLayout content) {
        LinearLayout hero = sectionBox();
        hero.addView(text("✦ PAINEL PREMIUM",14,Color.rgb(80,210,170),true));
        hero.addView(text("Confiança global  " + a.confidence + "%  •  Dados " + a.dataQuality,17,riskColor(a.confidence),true));
        hero.addView(text("1X2  •  " + g.home + " " + a.homePct + "%   |   Empate " + a.drawPct + "%   |   " + g.away + " " + a.awayPct + "%",12,TEXT,true));
        hero.addView(text("Gols esperados: " + one(a.expectedHomeGoals) + " × " + one(a.expectedAwayGoals),13,MUTED,false));
        content.addView(hero);

        LinearLayout best = sectionBox();
        best.addView(text("🔥 MELHORES SINAIS",14,Color.rgb(255,184,76),true));
        int n=0;
        for (AdvancedAnalysis.Market m : bestMarkets(a,7)) { best.addView(marketRow(m)); if(++n>=7) break; }
        content.addView(best);

        LinearLayout nav=sectionBox(); nav.addView(text("EXPLORE O CONFRONTO",13,TEXT,true));
        nav.addView(text("Use as abas acima: Mercados abre linhas detalhadas; Estatísticas traz dados oficiais quando já existem; Escalação, Tabela, H2H e Jogadores são carregados somente quando você tocar, poupando a cota da API.",12,MUTED,false));
        content.addView(nav);
    }

    private void renderAiTab(Game g, AdvancedAnalysis a, LinearLayout content) {
        LinearLayout ai=sectionBox(); ai.addView(text("✦ IA ESTATÍSTICA J.PASTORE",15,Color.rgb(90,190,255),true));
        ai.addView(text(a.aiSummary,14,TEXT,false));
        if(!a.apiAdvice.isEmpty()) ai.addView(text("Sinal externo: " + a.apiAdvice,12,MUTED,false));
        content.addView(ai);
        LinearLayout cmp=sectionBox(); cmp.addView(text("MATRIZ DO CONFRONTO",14,TEXT,true));
        addComparison(cmp,"Forma",a.formHome,a.formAway,g.home,g.away); addComparison(cmp,"Ataque",a.attackHome,a.attackAway,g.home,g.away); addComparison(cmp,"Defesa",a.defenceHome,a.defenceAway,g.home,g.away); addComparison(cmp,"Poisson",a.poissonHome,a.poissonAway,g.home,g.away); addComparison(cmp,"H2H",a.h2hHome,a.h2hAway,g.home,g.away); content.addView(cmp);
        LinearLayout explain=sectionBox(); explain.addView(text("COMO A IA CHEGOU NISSO",13,Color.rgb(103,213,178),true)); explain.addView(text("O motor cruza probabilidades 1X2, forma, ataque, defesa, Poisson, H2H, médias recentes e, quando disponível, odds de mercado. Mercados sem cobertura oficial ficam identificados como estimativas estatísticas e recebem confiança menor.",12,MUTED,false)); content.addView(explain);
    }

    private void renderMarketsTab(Game g, AdvancedAnalysis a, LinearLayout content) {
        LinearLayout intro=sectionBox(); intro.addView(text("MERCADOS CLICÁVEIS",15,Color.rgb(103,213,178),true)); intro.addView(text("Toque em uma categoria para abrir todas as linhas, probabilidades, odd justa IA, odd de mercado quando disponível e indicador de valor.",12,MUTED,false)); content.addView(intro);
        LinkedHashMap<String,List<AdvancedAnalysis.Market>> groups=new LinkedHashMap<>();
        for(AdvancedAnalysis.Market m:a.markets){ if(!groups.containsKey(m.category)) groups.put(m.category,new ArrayList<>()); groups.get(m.category).add(m); }
        for(String cat:groups.keySet()){
            List<AdvancedAnalysis.Market> ms=groups.get(cat); AdvancedAnalysis.Market best=ms.get(0); for(AdvancedAnalysis.Market m:ms) if(m.probability>best.probability) best=m;
            LinearLayout card=sectionBox(); card.setClickable(true); card.setOnClickListener(v->showMarketCategory(g,a,cat));
            card.addView(text(marketIcon(cat)+"  "+cat.toUpperCase(Locale.ROOT)+"   ›",15,TEXT,true));
            card.addView(text(ms.size()+" opções • destaque: "+best.selection+"  "+best.probability+"%",12,riskColor(best.probability),true));
            card.addView(text("Odd justa "+odd(best.fairOdd)+(best.marketOdd>0?" • mercado "+odd(best.marketOdd)+" • "+best.valueLabel():" • sem odd real agora"),11,MUTED,false));
            content.addView(card);
        }
    }

    private void showMarketCategory(Game g, AdvancedAnalysis a, String category) {
        ScrollView sv=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(12),dp(14),dp(18)); box.setBackgroundColor(BG); sv.addView(box);
        box.addView(text(marketIcon(category)+"  "+category.toUpperCase(Locale.ROOT),20,TEXT,true));
        box.addView(text("Todas as linhas disponíveis na análise deste confronto",12,MUTED,false));
        for(AdvancedAnalysis.Market m:a.markets) if(category.equals(m.category)) box.addView(marketRow(m));
        new AlertDialog.Builder(this).setView(sv).setNegativeButton("Voltar",null).show();
    }

    private void renderStatisticsTab(Game g, AdvancedAnalysis a, LinearLayout content) {
        LinearLayout proj=sectionBox(); proj.addView(text("PROJEÇÕES PRÉ-JOGO",14,Color.rgb(90,190,255),true));
        proj.addView(text("Gols esperados  "+one(a.expectedHomeGoals)+" × "+one(a.expectedAwayGoals),14,TEXT,true));
        for(String cat:new String[]{"Escanteios","Cartões","Chutes","Chutes no alvo","Faltas","Laterais","Impedimentos"}){
            AdvancedAnalysis.Market m=bestInCategory(a,cat); if(m!=null) proj.addView(text(cat+": "+m.selection+" • "+m.probability+"% • odd justa "+odd(m.fairOdd),12,MUTED,false));
        }
        content.addView(proj);
        Button official=detailTab("📊 Carregar estatísticas oficiais do jogo",v->loadRemoteDetail(g,content,"stats")); content.addView(official);
        content.addView(text("Em jogos futuros, estatísticas oficiais da partida podem ainda não existir; nesse caso permanecem as projeções pré-jogo.",11,MUTED,false));
    }

    private void loadRemoteDetail(Game g, LinearLayout content, String kind) {
        content.removeAllViews(); LinearLayout loading=sectionBox(); loading.addView(text("Carregando dados…",15,TEXT,true)); loading.addView(text("Consulta sob demanda para economizar a cota diária da API.",12,MUTED,false)); content.addView(loading);
        String key=getPreferences(MODE_PRIVATE).getString("api_key",""); ApiSportsClient client=new ApiSportsClient(key);
        if(!client.configured()){ content.removeAllViews(); content.addView(remoteTextBox("MODO DEMONSTRAÇÃO","Configure a API para acessar este painel.")); return; }
        executor.execute(()->{
            String out;
            try{
                if("lineups".equals(kind)) out=client.loadLineups(g);
                else if("standings".equals(kind)) out=client.loadStandings(g);
                else if("h2h".equals(kind)) out=client.loadH2H(g);
                else if("players".equals(kind)) out=client.loadPlayersAndInjuries(g);
                else out=client.loadFixtureStatistics(g);
            }catch(Exception e){ out="Dados indisponíveis agora: "+friendlyError(e.getMessage()); }
            final String result=out; runOnUiThread(()->{ content.removeAllViews(); content.addView(remoteTextBox(remoteTitle(kind),result)); });
        });
    }

    private LinearLayout remoteTextBox(String title,String body){ LinearLayout b=sectionBox(); b.addView(text(title,15,Color.rgb(103,213,178),true)); TextView t=text(body,13,TEXT,false); t.setTextIsSelectable(true); t.setPadding(0,dp(8),0,0); b.addView(t); return b; }
    private String remoteTitle(String kind){ if("lineups".equals(kind)) return "⚽ ESCALAÇÕES"; if("standings".equals(kind)) return "🏆 TABELA DO CAMPEONATO"; if("h2h".equals(kind)) return "🔁 CONFRONTOS DIRETOS"; if("players".equals(kind)) return "👤 JOGADORES E DESFALQUES"; return "📊 ESTATÍSTICAS OFICIAIS"; }

    private void showTeamQuickProfile(Game g, boolean home) {
        String team=home?g.home:g.away;
        new AlertDialog.Builder(this).setTitle(team).setMessage("Abra a aba Jogadores para ver forma da temporada, gols pró/contra e desfalques; a aba Tabela mostra a posição atual no campeonato. Esses dados são buscados sob demanda para preservar sua cota.").setPositiveButton("OK",null).show();
    }

    private List<AdvancedAnalysis.Market> bestMarkets(AdvancedAnalysis a,int limit){ List<AdvancedAnalysis.Market> x=new ArrayList<>(a.markets); Collections.sort(x,(m1,m2)->Integer.compare((m2.probability+m2.confidence),(m1.probability+m1.confidence))); return x.subList(0,Math.min(limit,x.size())); }
    private AdvancedAnalysis.Market bestInCategory(AdvancedAnalysis a,String cat){ AdvancedAnalysis.Market b=null; for(AdvancedAnalysis.Market m:a.markets) if(cat.equals(m.category)&&(b==null||m.probability>b.probability)) b=m; return b; }
    private String marketIcon(String c){ String n=c.toLowerCase(Locale.ROOT); if(n.contains("escante"))return"🚩"; if(n.contains("cart"))return"🟨"; if(n.contains("chute"))return"🎯"; if(n.contains("gol"))return"⚽"; if(n.contains("later"))return"↔"; if(n.contains("falta"))return"⚠"; if(n.contains("imped"))return"🚫"; if(n.contains("dupla"))return"🛡"; if(n.contains("resultado"))return"🏆"; return"📈"; }
    private String odd(double v){ return v>0?String.format(Locale.US,"%.2f",v).replace('.',','):"—"; }

    private LinearLayout sectionBox() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(CARD);
        bg.setStroke(dp(1), Color.rgb(43, 73, 98));
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        v.setLayoutParams(lp);
        return v;
    }

    private void addComparison(LinearLayout parent, String label, int h, int a, String hn, String an) {
        if (h <= 0 && a <= 0) return;
        TextView t = text(label + ":  " + hn + " " + h + "%   •   " + an + " " + a + "%", 12, MUTED, false);
        t.setPadding(0, dp(5), 0, 0);
        parent.addView(t);
    }

    private View marketRow(AdvancedAnalysis.Market m) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(11),dp(9),dp(11),dp(9));
        GradientDrawable bg=new GradientDrawable(); bg.setCornerRadius(dp(12)); bg.setColor(Color.rgb(11,24,40)); bg.setStroke(dp(1),m.probability>=70?Color.rgb(39,211,123):(m.probability>=55?Color.rgb(213,156,55):Color.rgb(62,83,105))); row.setBackground(bg);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(7)); row.setLayoutParams(lp);
        row.addView(text(m.selection+"   •   "+m.probability+"%",14,TEXT,true));
        String oddsLine="Odd justa IA  "+odd(m.fairOdd);
        if(m.marketOdd>0) oddsLine+="   •   Odd mercado  "+odd(m.marketOdd)+"   •   "+m.valueLabel()+" "+(m.valuePct>=0?"+":"")+String.format(Locale.US,"%.1f",m.valuePct).replace('.',',')+"%";
        else oddsLine+="   •   odd real indisponível";
        row.addView(text(oddsLine,12,m.marketOdd>0&&m.valuePct>=6?Color.rgb(39,211,123):Color.rgb(255,184,76),true));
        row.addView(text("Confiança do dado: "+m.confidence+"%  •  "+m.source,11,MUTED,false));
        if(!m.note.isEmpty()) row.addView(text(m.note,11,MUTED,false));
        return row;
    }

    private String buildCopyText(Game g, AdvancedAnalysis a) {
        StringBuilder sb = new StringBuilder();
        sb.append("J.Pastore Sports AI V14 PREMIUM\n").append(g.home).append(" × ").append(g.away).append("\n");
        sb.append(leagueDisplay(g)).append(" • ").append(g.time).append("\n\n");
        sb.append("IA: ").append(a.aiSummary).append("\n\n");
        sb.append("1X2: ").append(a.homePct).append("% / ").append(a.drawPct).append("% / ").append(a.awayPct).append("%\n");
        int n = 0;
        for (AdvancedAnalysis.Market m : a.markets) {
            if (n++ >= 8) break;
            sb.append("• ").append(m.category).append(": ").append(m.selection).append(" — ").append(m.probability).append("%\n");
        }
        sb.append("\nAnálise probabilística, sem garantia de resultado.");
        return sb.toString();
    }

    private String one(double v) { return String.format(Locale.US, "%.1f", v).replace('.', ','); }

    private Button bottomNavButton(String label, View.OnClickListener l) {
        Button b=new Button(this); b.setAllCaps(false); b.setText(label); b.setTextSize(10); b.setTextColor(TEXT); b.setOnClickListener(l);
        GradientDrawable bg=new GradientDrawable(); bg.setCornerRadius(dp(14)); bg.setColor(Color.rgb(13,35,57)); bg.setStroke(dp(1),Color.rgb(41,83,116)); b.setBackground(bg);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1f); lp.setMargins(dp(2),dp(2),dp(2),dp(2)); b.setLayoutParams(lp); return b;
    }

    private void showRadarIa() {
        ScrollView sv=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(12),dp(14),dp(16)); box.setBackgroundColor(BG); sv.addView(box);
        box.addView(text("✦ RADAR IA DO DIA",21,TEXT,true)); box.addView(text("Destaques entre os jogos já analisados. Analise mais partidas para enriquecer este painel.",12,MUTED,false));
        List<Game> analyzed=new ArrayList<>(); for(Game g:games) if(g.analyzed&&g.advanced!=null) analyzed.add(g);
        Collections.sort(analyzed,(a,b)->Integer.compare(b.confidence,a.confidence));
        if(analyzed.isEmpty()) box.addView(remoteTextBox("Sem análises ainda","Toque nos jogos e gere análises para alimentar o Radar IA."));
        int shown=0; for(Game g:analyzed){ if(shown++>=12) break; LinearLayout c=sectionBox(); c.setOnClickListener(v->showDetail(g)); c.setClickable(true); c.addView(text(g.home+" × "+g.away,15,TEXT,true)); c.addView(text(leagueDisplay(g)+" • confiança "+g.confidence+"%",11,MUTED,false)); AdvancedAnalysis.Market best=bestMarkets(g.advanced,1).get(0); c.addView(text("🔥 "+best.category+": "+best.selection+" • "+best.probability+"% • odd justa "+odd(best.fairOdd),12,riskColor(best.probability),true)); box.addView(c); }
        new AlertDialog.Builder(this).setView(sv).setNegativeButton("Fechar",null).show();
    }

    private void showSmartTickets() {
        ScrollView sv=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(12),dp(14),dp(16)); box.setBackgroundColor(BG); sv.addView(box);
        box.addView(text("▣ BILHETES IA",21,TEXT,true)); box.addView(text("Sugestões organizadas por perfil. São combinações informativas, sem garantia de resultado.",12,MUTED,false));
        List<Game> analyzed=new ArrayList<>(); for(Game g:games) if(g.analyzed&&g.advanced!=null) analyzed.add(g); Collections.sort(analyzed,(a,b)->Integer.compare(b.confidence,a.confidence));
        if(analyzed.isEmpty()){ box.addView(remoteTextBox("Ainda vazio","Analise alguns jogos primeiro.")); }
        else { addTicketBlock(box,"🛡 CONSERVADOR",analyzed,72,3); addTicketBlock(box,"⚖ MODERADO",analyzed,63,5); addTicketBlock(box,"🔥 AGRESSIVO",analyzed,55,7); }
        new AlertDialog.Builder(this).setView(sv).setNegativeButton("Fechar",null).show();
    }

    private void addTicketBlock(LinearLayout parent,String title,List<Game> analyzed,int minProb,int maxGames){
        LinearLayout c=sectionBox(); c.addView(text(title,14,Color.rgb(255,184,76),true)); double combined=1.0; int used=0;
        for(Game g:analyzed){ AdvancedAnalysis.Market pick=null; for(AdvancedAnalysis.Market m:bestMarkets(g.advanced,8)){ if(m.probability>=minProb){ pick=m; break; } } if(pick==null) continue; c.addView(text("• "+g.home+" × "+g.away+" — "+pick.selection+" ("+pick.probability+"%, justa "+odd(pick.fairOdd)+")",12,TEXT,false)); combined*=pick.fairOdd; if(++used>=maxGames) break; }
        if(used==0)c.addView(text("Sem seleções suficientes neste perfil agora.",12,MUTED,false)); else {
            final String ticketText = title + "\nOdd justa combinada aproximada: "+odd(combined)+" • "+used+" seleções\nJ.Pastore Sports AI V14";
            c.addView(text("Odd Total  "+odd(combined)+"   •   Confiança calculada pela IA",14,Color.rgb(0,245,150),true));
            Button copyBtn=button("▣  COPIAR BILHETE",v->copy(ticketText)); c.addView(copyBtn,new LinearLayout.LayoutParams(-1,dp(48)));
            Button shareBtn=button("↗  COMPARTILHAR BILHETE",v->{ Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,ticketText); startActivity(Intent.createChooser(i,"Compartilhar bilhete")); }); c.addView(shareBtn,new LinearLayout.LayoutParams(-1,dp(48)));
            c.addView(text("Integração direta com casa de apostas: aguardando autorização oficial. O usuário sempre revisa e confirma externamente.",10,MUTED,false));
        } parent.addView(c);
    }

    private void showMoreMenu(){
        String[] items={"📰 Notícias","💡 Dicas e Estratégias","🧮 Calculadora de Apostas","◉ Comparador de Odds","📅 Calendário de Jogos","📄 Relatórios IA","👥 Comunidade","🏆 Campeonatos","★ Favoritos","👤 Perfil","⚙ Configurações","ⓘ Sobre"};
        new AlertDialog.Builder(this).setTitle("Mais").setItems(items,(d,which)->{
            if(which==7)showChampionshipsDialog(); else if(which==8)showFavoriteChampionships(); else if(which==9)showProfile(); else if(which==10)showSettings(); else if(which==11)new AlertDialog.Builder(this).setTitle("J.Pastore Sports AI V14 Premium").setMessage("Criado e desenvolvido por J.Pastore. Análise estatística, Radar IA, Bilhetes IA, mercados detalhados e dados oficiais sob demanda.").setPositiveButton("OK",null).show(); else Toast.makeText(this,"Módulo preparado para a próxima integração de dados.",Toast.LENGTH_SHORT).show();
        }).show();
    }

    private void showProfile(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackgroundColor(BG);
        TextView avatar=text("JP",26,Color.rgb(0,245,150),true); avatar.setGravity(Gravity.CENTER); box.addView(avatar,new LinearLayout.LayoutParams(-1,dp(70)));
        TextView name=text("Júlio Pastore",22,TEXT,true); name.setGravity(Gravity.CENTER); box.addView(name);
        TextView prem=text("♛ Usuário Premium",14,Color.rgb(255,190,50),true); prem.setGravity(Gravity.CENTER); box.addView(prem);
        LinearLayout active=sectionBox(); active.addView(text("✓ Plano Premium Ativo",16,Color.rgb(0,245,150),true)); active.addView(text("Acesso às funcionalidades disponíveis da V14.",11,MUTED,false)); box.addView(active);
        String[] rows={"▥ Minhas Estatísticas","▣ Histórico de Bilhetes","♥ Times Favoritos","🔔 Notificações","⚙ Configurações","? Ajuda e Suporte"}; for(String r:rows){ LinearLayout c=sectionBox(); c.addView(text(r+"   ›",14,TEXT,true)); box.addView(c); }
        ScrollView sv=new ScrollView(this); sv.addView(box); new AlertDialog.Builder(this).setView(sv).setNegativeButton("Fechar",null).show();
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(text("Informe sua chave da API-Football (API-Sports). Ela fica salva apenas neste aparelho.", 13, Color.DKGRAY, false));
        EditText input = new EditText(this);
        input.setHint("x-apisports-key");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setText(getPreferences(MODE_PRIVATE).getString("api_key", ""));
        box.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("Modo online")
                .setView(box)
                .setPositiveButton("Salvar e atualizar", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().putString("api_key", input.getText().toString().trim()).apply();
                    lastRefreshAt = 0L;
                    load(false);
                })
                .setNeutralButton("Usar demonstração", (d, w) -> {
                    getPreferences(MODE_PRIVATE).edit().remove("api_key").apply();
                    load(false);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private List<Game> demoGames() {
        List<Game> d = new ArrayList<>();
        d.add(demo(71, "HOJE", "Brasileirão Série A", "Brazil", "Palmeiras", "Bahia", "19:30", "AGENDADO", "-", 62,22,16));
        d.add(demo(71, "HOJE", "Brasileirão Série A", "Brazil", "Flamengo", "Fortaleza", "21:30", "AGENDADO", "-", 55,26,19));
        d.add(demo(39, "AO VIVO", "Premier League", "England", "Arsenal", "Everton", "16:00", "AO VIVO 2T • 77'", "2 x 0", 69,20,11));
        d.add(new Game(4, 140, 2026, 0, 0, "PRÓXIMO", "La Liga", "Spain", "Real Sociedad", "Villarreal", "17:00", "AGENDADO", "-"));
        d.add(new Game(5, 135, 2026, 0, 0, "PRÓXIMO", "Serie A", "Italy", "Torino", "Udinese", "15:45", "AGENDADO", "-"));
        return d;
    }

    private Game demo(int leagueId, String bucket, String l, String country, String h, String a, String t, String s, String score, int hp, int dpct, int ap) {
        Game g = new Game(0, leagueId, 2026, 0, 0, bucket, l, country, h, a, t, s, score);
        AnalysisEngine.Result r = AnalysisEngine.evaluate(hp, dpct, ap);
        g.applyAnalysis(hp, dpct, ap, r);
        return g;
    }

    private String friendlyError(String msg) {
        if (msg == null) return "erro desconhecido da API";
        String low = msg.toLowerCase(Locale.ROOT);
        if (low.contains("next parameter") || low.contains("free plans do not have access"))
            return "parâmetro não permitido no plano gratuito.";
        if (low.contains("from field") || low.contains("to field"))
            return "a API recusou o filtro por intervalo. Esta versão usa somente consultas por data.";
        if (low.contains("too many requests") || low.contains("rate") || low.contains("429"))
            return "limite temporário de chamadas atingido. Aguarde um pouco e tente novamente.";
        return msg;
    }

    private int riskColor(int c) { return c >= 70 ? Color.rgb(39, 211, 123) : (c >= 55 ? Color.rgb(255, 193, 7) : Color.rgb(255, 82, 82)); }
    private String label(int c) { return c >= 70 ? "● FAVORÁVEL" : (c >= 55 ? "● ATENÇÃO" : "● DUVIDOSO"); }
    private void copy(String s) {
        ((android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Análise J.Pastore", s));
        Toast.makeText(this, "Análise copiada", Toast.LENGTH_SHORT).show();
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0, 1.08f);
        return t;
    }
    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }
    private Button rowButton(String s, View.OnClickListener l) {
        Button b = button(s, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.setMargins(dp(2), dp(3), dp(2), dp(3));
        b.setLayoutParams(lp);
        return b;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }

    private static class LeagueInfo {
        final String key, label;
        int count = 0;
        LeagueInfo(String key, String label) { this.key = key; this.label = label; }
    }
}
