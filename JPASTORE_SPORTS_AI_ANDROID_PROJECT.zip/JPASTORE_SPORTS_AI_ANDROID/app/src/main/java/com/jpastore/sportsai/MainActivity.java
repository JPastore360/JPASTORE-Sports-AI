package com.jpastore.sportsai;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;

public class MainActivity extends Activity{
 PremiumView ui;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(4,12,18));getWindow().setNavigationBarColor(Color.rgb(4,12,18));ui=new PremiumView(this);setContentView(ui);}
 public void apiDialog(){ final EditText e=new EditText(this);e.setHint("Chave API-Football");e.setSingleLine();e.setText(getPreferences(0).getString("api","")); new AlertDialog.Builder(this).setTitle("API-Football • V1 Premium").setMessage("A chave fica salva somente neste aparelho.").setView(e).setPositiveButton("SALVAR",(d,w)->{getPreferences(0).edit().putString("api",e.getText().toString().trim()).apply();Toast.makeText(this,"Chave salva",Toast.LENGTH_SHORT).show();}).setNeutralButton("TESTAR",(d,w)->new ApiClient(this).test(e.getText().toString().trim(),ok->runOnUiThread(()->Toast.makeText(this,ok?"API conectada":"Falha na conexão",Toast.LENGTH_LONG).show()))).setNegativeButton("FECHAR",null).show(); }
 public String apiKey(){return getPreferences(0).getString("api","");}
}
