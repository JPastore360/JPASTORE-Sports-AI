package com.jpastore.sportsai;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.widget.*;import androidx.work.*;import java.util.concurrent.TimeUnit;
public class MainActivity extends Activity{
 PremiumView ui;
 @Override public void onBackPressed(){if(ui!=null&&ui.handleBack())return;super.onBackPressed();}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(2,10,14));getWindow().setNavigationBarColor(Color.rgb(2,10,14));ui=new PremiumView(this);setContentView(ui);scheduleInternetSync();}
 public void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
 public void searchDialog(){final EditText e=new EditText(this);e.setHint("Time ou campeonato");new AlertDialog.Builder(this).setTitle("Buscar futebol").setView(e).setPositiveButton("BUSCAR",(d,w)->ui.searchGlobal(e.getText().toString().trim())).setNegativeButton("CANCELAR",null).show();}
 public void aiDialog(){final EditText e=new EditText(this);e.setHint("Ex.: Quem chega melhor e por quê?");new AlertDialog.Builder(this).setTitle("Perguntar à J.Pastore AI").setView(e).setPositiveButton("ANALISAR",(d,w)->ui.askAi(e.getText().toString().trim())).setNegativeButton("CANCELAR",null).show();}
 public void infoDialog(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}
 public void shareTicket(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,ui!=null&&ui.ticketStore!=null?ui.ticketStore.copyText():"J.Pastore Sports AI • Bilhete para revisão.");startActivity(Intent.createChooser(i,"Compartilhar bilhete"));}
 public void copyText(String label,String value){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText(label,value));toast("Bilhete copiado. Agora é só colar onde quiser.");}
 public void scheduleInternetSync(){Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest r=new PeriodicWorkRequest.Builder(BackgroundSyncWorker.class,6,TimeUnit.HOURS).setConstraints(c).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("jpastore-internet-sync",ExistingPeriodicWorkPolicy.UPDATE,r);}
 public String apiKey(){return getPreferences(0).getString("api","");}
 public void apiDialog(){
  final EditText e=new EditText(this);
  e.setHint("Cole sua chave API-Sports / API-Football");
  e.setSingleLine(true);
  e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  String current=apiKey();if(!current.isEmpty())e.setText(current);
  new AlertDialog.Builder(this).setTitle("API-Football / API-Sports").setMessage("A chave fica salva somente neste aparelho e não é enviada ao GitHub.").setView(e)
   .setPositiveButton("SALVAR E TESTAR",(d,w)->{String k=e.getText().toString().trim();if(k.isEmpty()){toast("Digite uma chave válida");return;}getPreferences(0).edit().putString("api",k).apply();toast("Chave salva. Testando conexão...");new ApiClient(this).test(k,ok->runOnUiThread(()->{toast(ok?"API conectada com sucesso":"Chave salva, mas a API recusou a conexão");if(ui!=null){ui.refreshFixtures();ui.invalidate();}}));})
   .setNegativeButton("CANCELAR",null).show();
 }
 public void testApi(){String k=apiKey();if(k.isEmpty()){toast("Configure a chave da API primeiro");return;}toast("Testando API...");new ApiClient(this).test(k,ok->runOnUiThread(()->toast(ok?"API conectada com sucesso":"Falha ao conectar. Verifique a chave e o plano.")));}
 public void clearApi(){getPreferences(0).edit().remove("api").apply();toast("Chave da API removida deste aparelho");if(ui!=null){ui.refreshFixtures();ui.invalidate();}}
}
