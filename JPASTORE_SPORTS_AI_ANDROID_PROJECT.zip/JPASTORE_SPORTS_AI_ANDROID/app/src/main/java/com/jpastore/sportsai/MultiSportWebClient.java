package com.jpastore.sportsai;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.regex.*;

/**
 * Internet-first research layer for non-football sports.
 * Uses public web/ESPN structured pages when available, then lightweight web search snippets.
 * API-Sports remains a schedule/status source; this class enriches the event before the local AI explains it.
 */
class MultiSportWebClient {
    private final Context c;
    private static final String UA="Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36 JPASTORE-Sports-AI/5.2";

    static class SearchItem {
        String title="",snippet="",url="";
        SearchItem(String t,String s,String u){title=t;snippet=s;url=u;}
    }
    static class Research {
        String query="",source="Internet";
        String homeForm="",awayForm="";
        int homeWins=0,homeLosses=0,homeDraws=0,awayWins=0,awayLosses=0,awayDraws=0;
        ArrayList<String> recentHome=new ArrayList<>(),recentAway=new ArrayList<>(),h2h=new ArrayList<>();
        ArrayList<SearchItem> web=new ArrayList<>();
        long updatedAt=System.currentTimeMillis();
        boolean hasStructured(){return !recentHome.isEmpty()||!recentAway.isEmpty()||!h2h.isEmpty();}
    }
    static class GameRow {
        String date="",home="",away="",score="",status="";int hs=-1,as=-1;boolean completed=false;
        boolean involves(String team){return teamMatch(team,home)||teamMatch(team,away);}
        boolean homeSide(String team){return teamMatch(team,home);}
        String opponent(String team){return homeSide(team)?away:home;}
        String form(String team){if(!completed||hs<0||as<0)return "";int f=homeSide(team)?hs:as,a=homeSide(team)?as:hs;return f>a?"V":(f==a?"E":"D");}
        String row(){return date+" • "+home+" "+(hs>=0?hs:"—")+" × "+(as>=0?as:"—")+" "+away;}
    }

    MultiSportWebClient(Context c){this.c=c;}

    void research(String sport, MultiSportClient.Event ev, Consumer<Research> ok, Consumer<String> err){
        new Thread(()->{
            try{
                Research r=new Research();
                r.query=buildQuery(sport,ev);
                try{loadStructured(sport,ev,r);}catch(Exception ignored){}
                try{r.web=webSearch(r.query,6);}catch(Exception ignored){}
                if(!r.hasStructured()&&r.web.isEmpty())throw new IOException("Nenhuma fonte web respondeu agora");
                ok.accept(r);
            }catch(Exception e){err.accept(e.getMessage()==null?"Pesquisa web indisponível":e.getMessage());}
        }).start();
    }

    String buildQuery(String sport,MultiSportClient.Event e){
        String pair=e==null?"":e.matchup();
        if(MultiSportClient.MMA.equals(sport))return pair+" MMA luta estatísticas cartel últimos resultados";
        if(MultiSportClient.F1.equals(sport))return pair+" Fórmula 1 GP resultados classificação pilotos";
        if(MultiSportClient.NFL.equals(sport))return pair+" NFL matchup stats injuries recent form";
        if(MultiSportClient.BASEBALL.equals(sport))return pair+" MLB baseball matchup stats recent form";
        if(MultiSportClient.BASKETBALL.equals(sport))return pair+" basketball NBA matchup stats recent form";
        return pair+" sports matchup stats";
    }

    void loadStructured(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        String path=espnPath(sport);if(path==null||ev==null)return;
        Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("UTC"));Date end=cal.getTime();cal.add(Calendar.DAY_OF_MONTH,-210);Date start=cal.getTime();
        SimpleDateFormat f=new SimpleDateFormat("yyyyMMdd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
        String url="https://site.api.espn.com/apis/site/v2/sports/"+path+"/scoreboard?dates="+f.format(start)+"-"+f.format(end)+"&limit=1000";
        String raw=cached("ms_espn_"+sport+"_"+safe(ev.home,"x")+"_"+safe(ev.away,"y"),url,90L*60*1000L);
        ArrayList<GameRow> all=parseScoreboard(raw);Collections.sort(all,(a,b)->b.date.compareTo(a.date));
        if(ev.home!=null&&!ev.home.trim().isEmpty())fillTeam(all,ev.home,r.recentHome,true,r);
        if(ev.away!=null&&!ev.away.trim().isEmpty())fillTeam(all,ev.away,r.recentAway,false,r);
        if(ev.home!=null&&ev.away!=null&&!ev.home.isEmpty()&&!ev.away.isEmpty())for(GameRow g:all){if(g.completed&&g.involves(ev.home)&&g.involves(ev.away)){r.h2h.add(g.row());if(r.h2h.size()>=5)break;}}
        r.homeForm=formText(r.recentHome);r.awayForm=formText(r.recentAway);
        if(r.hasStructured())r.source="Internet ESPN + busca web";
    }

    void fillTeam(ArrayList<GameRow> all,String team,ArrayList<String> rows,boolean first,Research r){int n=0;for(GameRow g:all){if(!g.completed||!g.involves(team))continue;String fm=g.form(team);if("V".equals(fm)){if(first)r.homeWins++;else r.awayWins++;}else if("D".equals(fm)){if(first)r.homeLosses++;else r.awayLosses++;}else if("E".equals(fm)){if(first)r.homeDraws++;else r.awayDraws++;}rows.add(fm+" • "+g.row());if(++n>=8)break;}}
    String formText(ArrayList<String> rows){StringBuilder b=new StringBuilder();for(String s:rows){if(s==null||s.isEmpty())continue;String x=s.substring(0,1);if("VDE".contains(x))b.append(x).append(' ');}return b.toString().trim();}

    static String espnPath(String sport){
        if(MultiSportClient.BASKETBALL.equals(sport))return "basketball/nba";
        if(MultiSportClient.NFL.equals(sport))return "football/nfl";
        if(MultiSportClient.BASEBALL.equals(sport))return "baseball/mlb";
        if(MultiSportClient.MMA.equals(sport))return "mma/ufc";
        if(MultiSportClient.F1.equals(sport))return "racing/f1";
        return null;
    }

    ArrayList<GameRow> parseScoreboard(String raw){ArrayList<GameRow> out=new ArrayList<>();try{JSONArray evs=new JSONObject(raw).optJSONArray("events");if(evs==null)return out;for(int i=0;i<evs.length();i++){
        JSONObject e=evs.optJSONObject(i);if(e==null)continue;JSONArray comps=e.optJSONArray("competitions");JSONObject cp=comps==null||comps.length()==0?null:comps.optJSONObject(0);if(cp==null)continue;JSONArray ps=cp.optJSONArray("competitors");if(ps==null||ps.length()<1)continue;GameRow g=new GameRow();String iso=e.optString("date","");g.date=iso.length()>=10?iso.substring(0,10):iso;
        for(int j=0;j<ps.length();j++){JSONObject z=ps.optJSONObject(j);if(z==null)continue;JSONObject tm=z.optJSONObject("team");JSONObject ath=z.optJSONObject("athlete");String name=tm!=null?first(tm.optString("displayName",""),tm.optString("name","")):(ath!=null?first(ath.optString("displayName",""),ath.optString("fullName","")):first(z.optString("displayName",""),z.optString("name","")));String side=z.optString("homeAway","");int score=intValue(z.opt("score"));if("home".equalsIgnoreCase(side)||g.home.isEmpty()){if(g.home.isEmpty()||"home".equalsIgnoreCase(side)){g.home=name;g.hs=score;}}else{g.away=name;g.as=score;}}
        if(g.away.isEmpty()&&ps.length()>1){JSONObject z=ps.optJSONObject(1);JSONObject tm=z==null?null:z.optJSONObject("team");JSONObject ath=z==null?null:z.optJSONObject("athlete");g.away=tm!=null?first(tm.optString("displayName",""),tm.optString("name","")):(ath!=null?first(ath.optString("displayName",""),ath.optString("fullName","")):"");g.as=z==null?-1:intValue(z.opt("score"));}
        JSONObject st=e.optJSONObject("status"),tp=st==null?null:st.optJSONObject("type");g.status=tp==null?"":first(tp.optString("shortDetail",""),tp.optString("detail",""),tp.optString("name",""));g.completed=tp!=null&&(tp.optBoolean("completed",false)||"post".equalsIgnoreCase(tp.optString("state"))||tp.optString("name","").toLowerCase(Locale.ROOT).contains("final"));if(!g.home.isEmpty())out.add(g);
    }}catch(Exception ignored){}return out;}

    ArrayList<SearchItem> webSearch(String query,int limit)throws Exception{
        String enc=URLEncoder.encode(query,"UTF-8");String url="https://html.duckduckgo.com/html/?q="+enc;
        String html=fetch(url);ArrayList<SearchItem> out=new ArrayList<>();
        Pattern block=Pattern.compile("(?is)<a[^>]*class=\"[^\"]*result__a[^\"]*\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?<a[^>]*class=\"[^\"]*result__snippet[^\"]*\"[^>]*>(.*?)</a>");Matcher m=block.matcher(html);
        while(m.find()&&out.size()<limit){String u=decodeDuck(m.group(1));String t=clean(m.group(2)),s=clean(m.group(3));if(!t.isEmpty())out.add(new SearchItem(t,s,u));}
        if(out.isEmpty()){
            Pattern a=Pattern.compile("(?is)<a[^>]*class=\"[^\"]*result__a[^\"]*\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>");Matcher z=a.matcher(html);while(z.find()&&out.size()<limit){String t=clean(z.group(2));if(!t.isEmpty())out.add(new SearchItem(t,"",decodeDuck(z.group(1))));}
        }
        if(out.isEmpty())try{
            String bing=fetch("https://www.bing.com/search?q="+enc+"&setlang=pt-br");
            Pattern b=Pattern.compile("(?is)<li[^>]*class=\"b_algo\"[^>]*>.*?<h2>\\s*<a[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?(?:<p>(.*?)</p>)?.*?</li>");Matcher bm=b.matcher(bing);
            while(bm.find()&&out.size()<limit){String t=clean(bm.group(2)),sn=clean(bm.group(3));if(!t.isEmpty())out.add(new SearchItem(t,sn,bm.group(1).replace("&amp;","&")));}
        }catch(Exception ignored){}
        return out;
    }

    String cached(String key,String url,long ttl)throws Exception{String k="msw_"+Integer.toHexString(key.hashCode());android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;try{String raw=fetch(url);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception e){if(old!=null)return old;throw e;}}
    String fetch(String url)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(5500);h.setReadTimeout(6500);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept","text/html,application/json;q=0.9,*/*;q=0.8");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s).append('\n');return b.toString();}

    static String decodeDuck(String u){try{String x=u.replace("&amp;","&");int p=x.indexOf("uddg=");if(p>=0){String v=x.substring(p+5);int e=v.indexOf('&');if(e>=0)v=v.substring(0,e);return URLDecoder.decode(v,"UTF-8");}return x.startsWith("//")?"https:"+x:x;}catch(Exception e){return u;}}
    static String clean(String h){if(h==null)return "";String x=h.replaceAll("(?is)<[^>]+>"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#x27;","'").replace("&nbsp;"," ");return x.replaceAll("\\s+"," ").trim();}
    static int intValue(Object o){try{if(o==null||o==JSONObject.NULL)return -1;String s=String.valueOf(o).replaceAll("[^0-9-]","");return s.isEmpty()?-1:Integer.parseInt(s);}catch(Exception e){return -1;}}
    static String safe(String s,String d){return s==null||s.trim().isEmpty()?d:s;}
    static String first(String... a){for(String s:a)if(s!=null&&!s.trim().isEmpty()&&!"null".equalsIgnoreCase(s.trim()))return s;return "";}
    static boolean teamMatch(String a,String b){if(a==null||b==null)return false;String x=norm(a),y=norm(b);if(x.isEmpty()||y.isEmpty())return false;if(x.equals(y)||x.contains(y)||y.contains(x))return true;HashSet<String>A=tokens(a),B=tokens(b);int n=0;for(String s:A)if(B.contains(s))n++;return n>=Math.min(2,Math.min(A.size(),B.size()));}
    static String norm(String s){if(s==null)return "";String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);return x.replaceAll("[^a-z0-9]","");}
    static HashSet<String> tokens(String s){HashSet<String> o=new HashSet<>();if(s==null)return o;String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]"," ");for(String z:x.split("\\s+"))if(z.length()>2&&!Arrays.asList("the","club","team","football","basketball","baseball").contains(z))o.add(z);return o;}
}
