package com.jpastore.sportsai;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.regex.*;

/**
 * Internet-first research layer for non-football sports.
 * 5.9: public web first, with a public structured SofaScore fallback, then the configured API-Sports source as a
 * structured historical fallback when the web source cannot provide a usable sample.
 * Search cards are presented in PT-BR instead of exposing raw English snippets.
 */
class MultiSportWebClient {
    private final Context c;
    private static final String UA="Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36 JPASTORE-Sports-AI/5.9";

    static class SearchItem {
        String title="",snippet="",url="",titlePt="",snippetPt="";
        SearchItem(String t,String s,String u){title=t;snippet=s;url=u;titlePt=t;snippetPt=s;}
    }
    static class Research {
        String query="",source="Internet",diagnostic="";
        String homeForm="",awayForm="";
        int homeWins=0,homeLosses=0,homeDraws=0,awayWins=0,awayLosses=0,awayDraws=0;
        int homeSample=0,awaySample=0; double homeFor=0,homeAgainst=0,awayFor=0,awayAgainst=0;
        ArrayList<String> recentHome=new ArrayList<>(),recentAway=new ArrayList<>(),h2h=new ArrayList<>();
        ArrayList<SearchItem> web=new ArrayList<>();
        long updatedAt=System.currentTimeMillis();
        boolean hasStructured(){return !recentHome.isEmpty()||!recentAway.isEmpty()||!h2h.isEmpty();}
        int commonSample(){int a=homeWins+homeDraws+homeLosses,b=awayWins+awayDraws+awayLosses;return Math.min(a,b);}
    }
    static class GameRow {
        String date="",home="",away="",score="",status="";long homeId=0,awayId=0;int hs=-1,as=-1;boolean completed=false;
        boolean involves(String team){return teamMatch(team,home)||teamMatch(team,away);}
        boolean homeSide(String team){return teamMatch(team,home);}
        String opponent(String team){return homeSide(team)?away:home;}
        String form(String team){if(!completed||hs<0||as<0)return "";int f=homeSide(team)?hs:as,a=homeSide(team)?as:hs;return f>a?"V":(f==a?"E":"D");}
        String row(){return date+" • "+home+" "+(hs>=0?hs:"—")+" × "+(as>=0?as:"—")+" "+away;}
    }

    MultiSportWebClient(Context c){this.c=c;}

    void research(String sport, MultiSportClient.Event ev, Consumer<Research> ok, Consumer<String> err){
        new Thread(()->{
            try{
                Research r=new Research();
                r.query=buildQuery(sport,ev);

                // 1) Internet estruturada, quando a competição realmente existe na fonte.
                try{loadStructured(sport,ev,r);}catch(Exception ignored){}

                // 2) Busca pública / scraping leve vem antes da API. O conteúdo original continua
                //    acessível pelo link, mas a tela mostra resumo em português.
                try{r.web=webSearch(r.query,6);localize(r.web);}catch(Exception ignored){}

                // 3) Tenta histórico público estruturado do SofaScore quando ESPN/busca aberta não bastam.
                //    Não exige chave e ajuda em ligas como LNBP, B League, NPB e outras fora da ESPN.
                if(r.commonSample()<3)try{loadSofaHistory(sport,ev,r);}catch(Exception ignored){}

                // 4) Se ainda faltar amostra, usa a API já configurada como último fallback estruturado.
                if(r.commonSample()<3)try{loadApiHistory(sport,ev,r);}catch(Exception ex){if(r.diagnostic==null||r.diagnostic.trim().isEmpty())r.diagnostic="As fontes públicas não cobriram esta liga e o histórico complementar não respondeu agora.";}
                if(!r.hasStructured()&&r.web.isEmpty())throw new IOException("Nenhuma fonte respondeu agora");
                if(r.hasStructured()&&r.source.trim().isEmpty())r.source="Internet + histórico público";
                ok.accept(r);
            }catch(Exception e){err.accept(e.getMessage()==null?"Pesquisa indisponível":e.getMessage());}
        }).start();
    }

    String buildQuery(String sport,MultiSportClient.Event e){
        String pair=e==null?"":e.matchup();String comp=e==null?"":safe(e.competition,"");String base=(pair+" "+comp).trim();
        if(MultiSportClient.MMA.equals(sport))return base+" MMA estatísticas cartel últimos resultados luta";
        if(MultiSportClient.F1.equals(sport))return base+" Fórmula 1 resultados classificação pilotos estatísticas";
        if(MultiSportClient.NFL.equals(sport))return base+" NFL estatísticas confronto lesões forma recente resultados";
        if(MultiSportClient.BASEBALL.equals(sport))return base+" baseball estatísticas confronto forma recente resultados";
        if(MultiSportClient.BASKETBALL.equals(sport))return base+" basquete estatísticas confronto forma recente resultados";
        return base+" esporte estatísticas confronto resultados";
    }

    void loadStructured(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        String path=espnPath(sport,ev);if(path==null||ev==null)return;
        Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("UTC"));Date end=cal.getTime();cal.add(Calendar.DAY_OF_MONTH,-210);Date start=cal.getTime();
        SimpleDateFormat f=new SimpleDateFormat("yyyyMMdd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
        String url="https://site.api.espn.com/apis/site/v2/sports/"+path+"/scoreboard?dates="+f.format(start)+"-"+f.format(end)+"&limit=1000";
        String raw=cached("ms_espn_"+sport+"_"+safe(ev.home,"x")+"_"+safe(ev.away,"y"),url,90L*60*1000L);
        ArrayList<GameRow> all=parseScoreboard(raw);Collections.sort(all,(a,b)->b.date.compareTo(a.date));
        if(ev.home!=null&&!ev.home.trim().isEmpty())fillTeam(all,ev.home,r.recentHome,true,r);
        if(ev.away!=null&&!ev.away.trim().isEmpty())fillTeam(all,ev.away,r.recentAway,false,r);
        if(ev.home!=null&&ev.away!=null&&!ev.home.isEmpty()&&!ev.away.isEmpty())for(GameRow g:all){if(g.completed&&g.involves(ev.home)&&g.involves(ev.away)){r.h2h.add(g.row());if(r.h2h.size()>=5)break;}}
        finishForms(r);
        if(r.hasStructured())r.source="Internet estruturada + busca web";
    }


    /** Public structured fallback. SofaScore has no official public API contract, so failures are silent
     * and the app immediately continues to the configured provider. No missing values are invented. */
    void loadSofaHistory(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        if(ev==null||r==null||MultiSportClient.F1.equals(sport))return;
        String slug=sofaSportSlug(sport);if(slug.isEmpty())return;
        long home=sofaFindTeamId(safe(ev.home,""),slug),away=sofaFindTeamId(safe(ev.away,""),slug);
        ArrayList<GameRow> hr=new ArrayList<>(),ar=new ArrayList<>();boolean added=false;
        if(r.recentHome.isEmpty()&&home>0){hr=sofaTeamRows(home);fillTeam(hr,ev.home,r.recentHome,true,r);added|=!r.recentHome.isEmpty();}
        if(r.recentAway.isEmpty()&&away>0){ar=sofaTeamRows(away);fillTeam(ar,ev.away,r.recentAway,false,r);added|=!r.recentAway.isEmpty();}
        if(r.h2h.isEmpty()&&!hr.isEmpty())addLocalH2h(hr,ev.home,ev.away,r.h2h);
        if(r.h2h.isEmpty()&&!ar.isEmpty())addLocalH2h(ar,ev.home,ev.away,r.h2h);
        finishForms(r);
        if(added||!r.h2h.isEmpty()){
            r.source="Internet estruturada • SofaScore + busca web";
            r.diagnostic="Histórico público localizado: "+r.recentHome.size()+" jogos de "+safe(ev.home,"mandante")+", "+r.recentAway.size()+" de "+safe(ev.away,"visitante")+" e "+r.h2h.size()+" H2H.";
        }
    }

    static String sofaSportSlug(String sport){
        if(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NBA.equals(sport))return "basketball";
        if(MultiSportClient.BASEBALL.equals(sport))return "baseball";
        if(MultiSportClient.NFL.equals(sport))return "american-football";
        if(MultiSportClient.MMA.equals(sport))return "mma";
        return "";
    }

    long sofaFindTeamId(String name,String sportSlug)throws Exception{
        if(name==null||name.trim().isEmpty())return 0;
        String q=URLEncoder.encode(name.trim(),"UTF-8");
        String url="https://api.sofascore.com/api/v1/search/all/?q="+q+"&page=0";
        String raw=sofaCached("search_"+sportSlug+"_"+norm(name),url,12L*60*60*1000L);
        JSONArray results=new JSONObject(raw).optJSONArray("results");if(results==null)return 0;
        long bestId=0;double best=-1;
        for(int i=0;i<results.length();i++){
            JSONObject item=results.optJSONObject(i);if(item==null||!"team".equalsIgnoreCase(item.optString("type")))continue;
            JSONObject e=item.optJSONObject("entity");if(e==null)continue;JSONObject sp=e.optJSONObject("sport");String ss=sp==null?"":sp.optString("slug","");
            if(!sportSlug.equalsIgnoreCase(ss))continue;String n=first(e.optString("name",""),e.optString("shortName",""));if(!teamMatch(name,n))continue;
            double score=item.optDouble("score",0);if(norm(name).equals(norm(n)))score+=1_000_000_000d;else if(norm(n).contains(norm(name))||norm(name).contains(norm(n)))score+=100_000_000d;
            if(score>best){best=score;bestId=e.optLong("id",0);}
        }
        return bestId;
    }

    ArrayList<GameRow> sofaTeamRows(long teamId)throws Exception{
        ArrayList<GameRow> out=new ArrayList<>();HashSet<Long> seen=new HashSet<>();
        for(int page=0;page<2&&out.size()<16;page++){
            String url="https://api.sofascore.com/api/v1/team/"+teamId+"/events/last/"+page;
            String raw=sofaCached("team_"+teamId+"_last_"+page,url,45L*60*1000L);JSONObject root=new JSONObject(raw);JSONArray evs=root.optJSONArray("events");if(evs==null)break;
            for(int i=0;i<evs.length();i++){JSONObject e=evs.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id>0&&!seen.add(id))continue;GameRow g=sofaEvent(e);if(g!=null&&g.completed)out.add(g);}
            if(!root.optBoolean("hasNextPage",false))break;
        }
        Collections.sort(out,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));return out;
    }

    GameRow sofaEvent(JSONObject e){
        if(e==null)return null;JSONObject h=e.optJSONObject("homeTeam"),a=e.optJSONObject("awayTeam");if(h==null||a==null)return null;
        GameRow g=new GameRow();g.home=h.optString("name","");g.away=a.optString("name","");g.homeId=h.optLong("id",0);g.awayId=a.optLong("id",0);
        JSONObject hs=e.optJSONObject("homeScore"),as=e.optJSONObject("awayScore");g.hs=sofaScore(hs);g.as=sofaScore(as);
        JSONObject st=e.optJSONObject("status");String type=st==null?"":st.optString("type","");g.status=first(type,st==null?"":st.optString("description",""));g.completed="finished".equalsIgnoreCase(type)||(st!=null&&st.optInt("code",0)==100);
        long ts=e.optLong("startTimestamp",0);if(ts>0){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));g.date=f.format(new Date(ts*1000L));}
        g.score=(g.hs>=0?String.valueOf(g.hs):"—")+" × "+(g.as>=0?String.valueOf(g.as):"—");if(g.hs<0||g.as<0)g.completed=false;return g;
    }

    static int sofaScore(JSONObject s){if(s==null)return -1;int v=intValue(s.opt("current"));if(v>=0)return v;v=intValue(s.opt("display"));if(v>=0)return v;return intValue(s.opt("normaltime"));}

    String sofaCached(String key,String url,long ttl)throws Exception{
        String k="sofa_"+Integer.toHexString(key.hashCode());android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;
        try{String raw=fetchSofa(url);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception ex){if(old!=null)return old;throw ex;}
    }

    String fetchSofa(String url)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(5500);h.setReadTimeout(6500);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept","application/json");h.setRequestProperty("Referer","https://www.sofascore.com/");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader br=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String x;(x=br.readLine())!=null;)b.append(x);return b.toString();
    }

    /** Structured historical fallback using the API source that supplied the schedule card. */
    void loadApiHistory(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        if(ev==null||!(c instanceof MainActivity))return;
        if(MultiSportClient.MMA.equals(sport)||MultiSportClient.F1.equals(sport))return; // separate models required
        String source=safe(ev.apiSource,sport);
        if(MultiSportClient.BASKETBALL.equals(sport)&&!MultiSportClient.NBA.equals(source))source=MultiSportClient.BASKETBALL;
        MainActivity a=(MainActivity)c;String key=a.apiKeyFor(source);
        if(key==null||key.trim().isEmpty()){r.diagnostic="A busca pública não cobriu esta liga e não há chave da modalidade disponível para o histórico complementar.";return;}
        if(ev.homeId<=0&&ev.awayId<=0){r.diagnostic="A agenda não forneceu IDs dos participantes para recuperar o histórico estruturado.";return;}
        MultiSportClient cli=new MultiSportClient(c);
        boolean added=false;StringBuilder trace=new StringBuilder();
        ArrayList<GameRow> homeRows=new ArrayList<>(),awayRows=new ArrayList<>();

        if(r.recentHome.size()<3&&ev.homeId>0){
            homeRows=apiTeamRows(cli,source,ev.homeId,ev.leagueId,ev.season,key,trace);
            if(countCompleted(homeRows)>=3){clearTeamSample(r,true);fillTeam(homeRows,ev.home,ev.homeId,r.recentHome,true,r);}added|=!r.recentHome.isEmpty();
        }
        if(r.recentAway.size()<3&&ev.awayId>0){
            awayRows=apiTeamRows(cli,source,ev.awayId,ev.leagueId,ev.season,key,trace);
            if(countCompleted(awayRows)>=3){clearTeamSample(r,false);fillTeam(awayRows,ev.away,ev.awayId,r.recentAway,false,r);}added|=!r.recentAway.isEmpty();
        }
        // Primeiro deriva o H2H dos históricos dos próprios times. É mais portátil entre
        // API-Basketball/Baseball/NFL do que depender de um filtro H2H específico.
        if(r.h2h.isEmpty()&&!homeRows.isEmpty())addLocalH2h(homeRows,ev.home,ev.away,r.h2h);
        if(r.h2h.isEmpty()&&!awayRows.isEmpty())addLocalH2h(awayRows,ev.home,ev.away,r.h2h);
        if(r.h2h.isEmpty()&&ev.homeId>0&&ev.awayId>0){
            try{ArrayList<GameRow> rows=apiRows(cli,source,apiRaw(cli,source,"games?h2h="+ev.homeId+"-"+ev.awayId,key));Collections.sort(rows,(x,y)->y.date.compareTo(x.date));for(GameRow g:rows){if(g.completed){r.h2h.add(g.row());if(r.h2h.size()>=5)break;}}}catch(Exception ex){appendTrace(trace,"H2H indisponível");}
        }
        finishForms(r);
        if(added||!r.h2h.isEmpty()){
            r.source=r.source.startsWith("Internet estruturada")?r.source+" + histórico API-Sports":"Internet + histórico API-Sports";
            r.diagnostic="Histórico recuperado pela fonte da agenda: "+r.recentHome.size()+" jogos de "+safe(ev.home,"mandante")+", "+r.recentAway.size()+" de "+safe(ev.away,"visitante")+" e "+r.h2h.size()+" H2H.";
        }else{
            r.diagnostic="A internet encontrou contexto, mas ainda não vieram jogos finalizados suficientes da fonte estruturada"+(trace.length()>0?" ("+trace+")":"")+".";
        }
    }

    ArrayList<GameRow> apiTeamRows(MultiSportClient cli,String source,long teamId,long leagueId,String season,String key,StringBuilder trace)throws Exception{
        String base="games?team="+teamId;ArrayList<GameRow> rows=new ArrayList<>();
        ArrayList<String> attempts=new ArrayList<>();
        if(leagueId>0&&season!=null&&!season.trim().isEmpty())attempts.add(base+"&league="+leagueId+"&season="+URLEncoder.encode(season,"UTF-8"));
        if(leagueId>0)attempts.add(base+"&league="+leagueId);
        attempts.add(base);
        Exception last=null;
        for(String path:attempts){
            try{ArrayList<GameRow> got=apiRows(cli,source,apiRaw(cli,source,path,key));if(countCompleted(got)>countCompleted(rows))rows=got;if(countCompleted(rows)>=3)break;}
            catch(Exception ex){last=ex;}
        }
        if(rows.isEmpty()&&last!=null)appendTrace(trace,"time "+teamId+": "+safe(last.getMessage(),"consulta recusada"));
        Collections.sort(rows,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));return rows;
    }

    static int countCompleted(ArrayList<GameRow> rows){int n=0;if(rows!=null)for(GameRow g:rows)if(g!=null&&g.completed)n++;return n;}
    static void clearTeamSample(Research r,boolean home){if(r==null)return;if(home){r.recentHome.clear();r.homeWins=r.homeLosses=r.homeDraws=r.homeSample=0;r.homeFor=r.homeAgainst=0;}else{r.recentAway.clear();r.awayWins=r.awayLosses=r.awayDraws=r.awaySample=0;r.awayFor=r.awayAgainst=0;}}
    static void appendTrace(StringBuilder b,String s){if(b==null||s==null||s.trim().isEmpty())return;if(b.length()>0)b.append("; ");b.append(s);}
    static void addLocalH2h(ArrayList<GameRow> rows,String a,String b,ArrayList<String> out){if(rows==null||out==null)return;for(GameRow g:rows){if(g!=null&&g.completed&&g.involves(a)&&g.involves(b)){out.add(g.row());if(out.size()>=5)break;}}}

    String apiRaw(MultiSportClient cli,String source,String path,String key)throws Exception{
        String cacheKey="api_hist_"+source+"_"+path;android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String k="msw_"+Integer.toHexString(cacheKey.hashCode());String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<6L*60*60*1000L)return old;
        try{String raw=cli.get(source,path,key);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception ex){if(old!=null)return old;throw ex;}
    }

    ArrayList<GameRow> apiRows(MultiSportClient cli,String source,String raw){
        ArrayList<GameRow> out=new ArrayList<>();try{JSONArray a=new JSONObject(raw).optJSONArray("response");if(a==null)return out;for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;MultiSportClient.Event e;
            if(MultiSportClient.NBA.equals(source))e=cli.parseNba(o);else if(MultiSportClient.NFL.equals(source))e=cli.parseNfl(o);else e=cli.parseGenericGame(source,o);
            GameRow g=fromEvent(e);if(g!=null)out.add(g);
        }}catch(Exception ignored){}return out;
    }

    GameRow fromEvent(MultiSportClient.Event e){if(e==null||safe(e.home,"").isEmpty())return null;GameRow g=new GameRow();g.date=safe(e.date,"");g.home=safe(e.home,"");g.away=safe(e.away,"");g.homeId=e.homeId;g.awayId=e.awayId;g.status=safe(e.status,"");int[] sc=scorePair(e.score);g.hs=sc[0];g.as=sc[1];g.completed=(isFinal(g.status)||looksPastWithScore(g.date,g.status,g.hs,g.as))&&g.hs>=0&&g.as>=0;g.score=e.score;return g;}
    static boolean isFinal(String s){String x=s==null?"":s.toLowerCase(Locale.ROOT);return x.equals("ft")||x.equals("aot")||x.equals("end")||x.equals("ended")||x.contains("finished")||x.contains("final")||x.contains("complete")||x.contains("closed")||x.contains("after overtime")||x.contains("after extra")||x.contains("após prorrogação")||x.contains("encerrad");}
    static boolean looksPastWithScore(String date,String status,int hs,int as){if(hs<0||as<0)return false;String x=status==null?"":status.toLowerCase(Locale.ROOT);if(x.contains("live")||x.equals("ns")||x.contains("not started")||x.contains("scheduled")||x.contains("programad"))return false;if(date==null||date.length()<10)return false;String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());return date.substring(0,10).compareTo(today)<0;}
    static int[] scorePair(String s){int[] out={-1,-1};if(s==null)return out;Matcher m=Pattern.compile("(\\d{1,3})\\s*(?:×|x|-|–|:)\\s*(\\d{1,3})").matcher(s);if(m.find())try{out[0]=Integer.parseInt(m.group(1));out[1]=Integer.parseInt(m.group(2));}catch(Exception ignored){}return out;}

    void fillTeam(ArrayList<GameRow> all,String team,ArrayList<String> rows,boolean first,Research r){fillTeam(all,team,0,rows,first,r);}
    void fillTeam(ArrayList<GameRow> all,String team,long teamId,ArrayList<String> rows,boolean first,Research r){int n=0;for(GameRow g:all){if(!g.completed)continue;boolean byId=teamId>0&&(g.homeId==teamId||g.awayId==teamId);if(!byId&&!g.involves(team))continue;boolean homeSide=byId?(g.homeId==teamId):g.homeSide(team);int pf=homeSide?g.hs:g.as,pa=homeSide?g.as:g.hs;String fm=pf>pa?"V":(pf==pa?"E":"D");if("V".equals(fm)){if(first)r.homeWins++;else r.awayWins++;}else if("D".equals(fm)){if(first)r.homeLosses++;else r.awayLosses++;}else if("E".equals(fm)){if(first)r.homeDraws++;else r.awayDraws++;}if(pf>=0&&pa>=0){if(first){r.homeFor+=pf;r.homeAgainst+=pa;r.homeSample++;}else{r.awayFor+=pf;r.awayAgainst+=pa;r.awaySample++;}}rows.add(fm+" • "+g.row());if(++n>=8)break;}}
    void finishForms(Research r){r.homeForm=formText(r.recentHome);r.awayForm=formText(r.recentAway);}
    String formText(ArrayList<String> rows){StringBuilder b=new StringBuilder();for(String s:rows){if(s==null||s.isEmpty())continue;String x=s.substring(0,1);if("VDE".contains(x))b.append(x).append(' ');}return b.toString().trim();}

    static String espnPath(String sport,MultiSportClient.Event ev){
        String comp=ev==null?"":safe(ev.competition,"").toLowerCase(Locale.ROOT);
        if(MultiSportClient.BASKETBALL.equals(sport))return comp.contains("nba")?"basketball/nba":null;
        if(MultiSportClient.NFL.equals(sport))return comp.contains("nfl")?"football/nfl":null;
        if(MultiSportClient.BASEBALL.equals(sport))return comp.contains("mlb")?"baseball/mlb":null;
        if(MultiSportClient.MMA.equals(sport))return "mma/ufc";
        if(MultiSportClient.F1.equals(sport))return "racing/f1";
        return null;
    }

    ArrayList<GameRow> parseScoreboard(String raw){ArrayList<GameRow> out=new ArrayList<>();try{JSONArray evs=new JSONObject(raw).optJSONArray("events");if(evs==null)return out;for(int i=0;i<evs.length();i++){
        JSONObject e=evs.optJSONObject(i);if(e==null)continue;JSONArray comps=e.optJSONArray("competitions");JSONObject cp=comps==null||comps.length()==0?null:comps.optJSONObject(0);if(cp==null)continue;JSONArray ps=cp.optJSONArray("competitors");if(ps==null||ps.length()<1)continue;GameRow g=new GameRow();String iso=e.optString("date","");g.date=iso.length()>=10?iso.substring(0,10):iso;
        for(int j=0;j<ps.length();j++){JSONObject z=ps.optJSONObject(j);if(z==null)continue;JSONObject tm=z.optJSONObject("team");JSONObject ath=z.optJSONObject("athlete");String name=tm!=null?first(tm.optString("displayName",""),tm.optString("name","")):(ath!=null?first(ath.optString("displayName",""),ath.optString("fullName","")):first(z.optString("displayName",""),z.optString("name","")));String side=z.optString("homeAway","");int score=intValue(z.opt("score"));if("home".equalsIgnoreCase(side)||g.home.isEmpty()){if(g.home.isEmpty()||"home".equalsIgnoreCase(side)){g.home=name;g.hs=score;}}else{g.away=name;g.as=score;}}
        if(g.away.isEmpty()&&ps.length()>1){JSONObject z=ps.optJSONObject(1);JSONObject tm=z==null?null:z.optJSONObject("team");JSONObject ath=z==null?null:z.optJSONObject("athlete");g.away=tm!=null?first(tm.optString("displayName",""),tm.optString("name","")):(ath!=null?first(ath.optString("displayName",""),ath.optString("fullName","")):"");g.as=z==null?-1:intValue(z.opt("score"));}
        JSONObject st=e.optJSONObject("status"),tp=st==null?null:st.optJSONObject("type");g.status=tp==null?"":first(tp.optString("shortDetail",""),tp.optString("detail",""),tp.optString("name",""));g.completed=tp!=null&&(tp.optBoolean("completed",false)||"post".equalsIgnoreCase(tp.optString("state"))||tp.optString("name","").toLowerCase(Locale.ROOT).contains("final"));if(!g.home.isEmpty())out.add(g);
    }}catch(Exception ignored){}return out;}

    ArrayList<SearchItem> webSearch(String query,int limit)throws Exception{
        String enc=URLEncoder.encode(query,"UTF-8");String url="https://html.duckduckgo.com/html/?kl=br-pt&q="+enc;
        String html=fetch(url);ArrayList<SearchItem> out=new ArrayList<>();
        Pattern block=Pattern.compile("(?is)<a[^>]*class=\"[^\"]*result__a[^\"]*\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?<a[^>]*class=\"[^\"]*result__snippet[^\"]*\"[^>]*>(.*?)</a>");Matcher m=block.matcher(html);
        while(m.find()&&out.size()<limit){String u=decodeDuck(m.group(1));String t=clean(m.group(2)),s=clean(m.group(3));if(!t.isEmpty())out.add(new SearchItem(t,s,u));}
        if(out.isEmpty()){
            Pattern a=Pattern.compile("(?is)<a[^>]*class=\"[^\"]*result__a[^\"]*\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>");Matcher z=a.matcher(html);while(z.find()&&out.size()<limit){String t=clean(z.group(2));if(!t.isEmpty())out.add(new SearchItem(t,"",decodeDuck(z.group(1))));}
        }
        if(out.isEmpty())try{
            String bing=fetch("https://www.bing.com/search?q="+enc+"&setlang=pt-br&cc=br");
            Pattern b=Pattern.compile("(?is)<li[^>]*class=\"b_algo\"[^>]*>.*?<h2>\\s*<a[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?(?:<p>(.*?)</p>)?.*?</li>");Matcher bm=b.matcher(bing);
            while(bm.find()&&out.size()<limit){String t=clean(bm.group(2)),sn=clean(bm.group(3));if(!t.isEmpty())out.add(new SearchItem(t,sn,bm.group(1).replace("&amp;","&")));}
        }catch(Exception ignored){}
        localize(out);return out;
    }

    void localize(ArrayList<SearchItem> list){if(list==null)return;for(SearchItem it:list){it.titlePt=ptTitle(it);it.snippetPt=ptSummary(it);}}
    static String uiTitle(SearchItem it){if(it==null)return "Fonte pública";return safe(it.titlePt,safe(it.title,"Fonte pública"));}
    static String uiSnippet(SearchItem it){if(it==null)return "Conteúdo público relacionado ao confronto.";return safe(it.snippetPt,safe(it.snippet,"Conteúdo público relacionado ao confronto."));}
    static String ptTitle(SearchItem it){String all=((it==null?"":it.title)+" "+(it==null?"":it.snippet)).toLowerCase(Locale.ROOT);String host=sourceHost(it==null?"":it.url);int[] sc=findScore(all);String type;
        if(sc[0]>=0)type="Resultado e retrospecto";
        else if(hasAny(all,"player stats","estatísticas de jogadores","rebounds","assists"))type="Estatísticas de jogadores";
        else if(hasAny(all,"prediction","predictions","previsão","prognóstico"))type="Previsões e histórico";
        else if(hasAny(all,"live score","livescore","placar ao vivo"))type="Placar e estatísticas";
        else if(hasAny(all,"standings","classification","classificação","table"))type="Classificação e desempenho";
        else type="Informações do confronto";
        return type+(host.isEmpty()?"":" • "+host);
    }
    static String ptSummary(SearchItem it){String raw=((it==null?"":it.title)+" "+(it==null?"":it.snippet)).replaceAll("\\s+"," ").trim();String low=raw.toLowerCase(Locale.ROOT);int[] sc=findScore(low);ArrayList<String> parts=new ArrayList<>();
        if(sc[0]>=0)parts.add("A fonte menciona um resultado de "+sc[0]+"–"+sc[1]+" relacionado ao histórico pesquisado.");
        if(hasAny(low,"player stats","rebounds","assists","minutes played","field goals","free throws"))parts.add("Há dados de jogadores, como pontos, rebotes, assistências, minutos e aproveitamento.");
        if(hasAny(low,"live score","match results","real-time scores","livescore"))parts.add("A página oferece placar, resultados e atualização do confronto.");
        if(hasAny(low,"prediction","predictions"))parts.add("A fonte também apresenta previsões ou tendências para o confronto.");
        if(hasAny(low,"h2h","head to head","past results","recent form"))parts.add("Há referência a retrospecto, resultados anteriores ou forma recente.");
        if(parts.isEmpty())parts.add("Fonte pública encontrada com informações sobre o confronto, resultados e contexto esportivo.");
        StringBuilder b=new StringBuilder();for(String s:parts){if(b.length()>0)b.append(' ');b.append(s);if(b.length()>210)break;}return b.toString();
    }
    static int[] findScore(String s){int[] o={-1,-1};if(s==null)return o;Matcher m=Pattern.compile("(?<!\\d)(\\d{1,3})\\s*[-–:]\\s*(\\d{1,3})(?!\\d)").matcher(s);while(m.find()){int end=m.end();if(end<s.length()&&(s.charAt(end)=='-'||s.charAt(end)=='/'))continue;try{o[0]=Integer.parseInt(m.group(1));o[1]=Integer.parseInt(m.group(2));return o;}catch(Exception ignored){}}return o;}
    static boolean hasAny(String s,String... xs){if(s==null)return false;for(String x:xs)if(s.contains(x))return true;return false;}
    static String sourceHost(String u){try{String h=new URL(u).getHost().toLowerCase(Locale.ROOT);if(h.startsWith("www."))h=h.substring(4);return h;}catch(Exception e){return "";}}

    String cached(String key,String url,long ttl)throws Exception{String k="msw_"+Integer.toHexString(key.hashCode());android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;try{String raw=fetch(url);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception e){if(old!=null)return old;throw e;}}
    String fetch(String url)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(5500);h.setReadTimeout(6500);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept-Language","pt-BR,pt;q=0.9,en;q=0.6");h.setRequestProperty("Accept","text/html,application/json;q=0.9,*/*;q=0.8");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s).append('\n');return b.toString();}

    static String decodeDuck(String u){try{String x=u.replace("&amp;","&");int p=x.indexOf("uddg=");if(p>=0){String v=x.substring(p+5);int e=v.indexOf('&');if(e>=0)v=v.substring(0,e);return URLDecoder.decode(v,"UTF-8");}return x.startsWith("//")?"https:"+x:x;}catch(Exception e){return u;}}
    static String clean(String h){if(h==null)return "";String x=h.replaceAll("(?is)<[^>]+>"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#x27;","'").replace("&nbsp;"," ");return x.replaceAll("\\s+"," ").trim();}
    static int intValue(Object o){try{if(o==null||o==JSONObject.NULL)return -1;String s=String.valueOf(o).replaceAll("[^0-9-]","");return s.isEmpty()?-1:Integer.parseInt(s);}catch(Exception e){return -1;}}
    static String safe(String s,String d){return s==null||s.trim().isEmpty()?d:s;}
    static String first(String... a){for(String s:a)if(s!=null&&!s.trim().isEmpty()&&!"null".equalsIgnoreCase(s.trim()))return s;return "";}
    static boolean teamMatch(String a,String b){if(a==null||b==null)return false;String x=norm(a),y=norm(b);if(x.isEmpty()||y.isEmpty())return false;if(x.equals(y)||x.contains(y)||y.contains(x))return true;HashSet<String>A=tokens(a),B=tokens(b);int n=0;for(String s:A)if(B.contains(s))n++;return n>=Math.min(2,Math.min(A.size(),B.size()));}
    static String norm(String s){if(s==null)return "";String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);return x.replaceAll("[^a-z0-9]","");}
    static HashSet<String> tokens(String s){HashSet<String> o=new HashSet<>();if(s==null)return o;String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]"," ");for(String z:x.split("\\s+"))if(z.length()>2&&!Arrays.asList("the","club","team","football","basketball","baseball").contains(z))o.add(z);return o;}
}
