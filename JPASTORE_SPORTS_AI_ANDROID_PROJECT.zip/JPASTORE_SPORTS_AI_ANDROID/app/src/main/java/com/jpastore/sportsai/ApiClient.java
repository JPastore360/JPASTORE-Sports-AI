package com.jpastore.sportsai;

import android.content.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

public class ApiClient {
    Context c;
    ApiClient(Context c){ this.c=c; }

    static class Game {
        long fixtureId; int homeId,awayId; int leagueId,season;
        String home,away,homeLogo,awayLogo,league,time,status;
        int homeGoals=-1,awayGoals=-1,elapsed=0;
        Game(long f,int hi,int ai,int li,int se,String h,String a,String hl,String al,String l,String t,String s){
            fixtureId=f;homeId=hi;awayId=ai;leagueId=li;season=se;home=h;away=a;homeLogo=hl;awayLogo=al;league=l;time=t;status=s;
        }
    }
    static class Player {int id,num;String name,grid,photo; Player(int i,int n,String nm,String g){id=i;num=n;name=nm;grid=g;photo=i>0?"https://media.api-sports.io/football/players/"+i+".png":"";} }
    static class Lineup {String team,formation,coach;ArrayList<Player> start=new ArrayList<>(),bench=new ArrayList<>();}
    static class Stats {LinkedHashMap<String,String[]> rows=new LinkedHashMap<>();}
    static class Prediction {int home,draw,away;String advice="",winner="",underOver=""; LinkedHashMap<String,Integer> comparison=new LinkedHashMap<>(); String homeForm="",awayForm="";}
    static class H2H {ArrayList<String> rows=new ArrayList<>();int homeWins,draws,awayWins;}

    static class MetricProjection {
        String name,source=""; double home,away,total,low,high,line=-1,lineHigh=-1; int overProb=-1,overProbHigh=-1,sample=0;
        MetricProjection(String n){name=n;}
    }
    static class DeepAnalysis {
        LinkedHashMap<String,MetricProjection> metrics=new LinkedHashMap<>();
        int homeMatches=0,awayMatches=0,h2hMatches=0,homeVenueMatches=0,awayVenueMatches=0;
        String note="",sources="";
        boolean complete=false;
    }
    static class Series {
        double forSum=0,againstSum=0,weight=0; int n=0;
        void add(double f,double a,double w){ if(Double.isNaN(f)||Double.isNaN(a))return;forSum+=f*w;againstSum+=a*w;weight+=w;n++; }
        double f(){return weight>0?forSum/weight:Double.NaN;}
        double a(){return weight>0?againstSum/weight:Double.NaN;}
    }
    static class StatSample { HashMap<String,Double> team=new HashMap<>(),opp=new HashMap<>(); }

    String get(String path,String key)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL("https://v3.football.api-sports.io/"+path).openConnection();
        h.setRequestProperty("x-apisports-key",key);h.setRequestProperty("Accept","application/json");h.setConnectTimeout(6500);h.setReadTimeout(6500);
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();
        BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s);
        if(code!=200)throw new IOException("HTTP "+code);return b.toString();
    }
    void cachePut(String k,String v){c.getSharedPreferences("jp_cache",0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long maxAge){android.content.SharedPreferences p=c.getSharedPreferences("jp_cache",0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=maxAge?p.getString(k,null):null;}
    ArrayList<Game> parseGamesRoot(String raw)throws Exception{JSONObject root=new JSONObject(raw);JSONArray a=root.optJSONArray("response");if(a==null)a=root.optJSONArray("fixtures");ArrayList<Game> out=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++)out.add(parseGame(a.getJSONObject(i)));return out;}
    void test(String key,Consumer<Boolean> cb){new Thread(()->{try{get("status",key);cb.accept(true);}catch(Exception e){cb.accept(false);}}).start();}

    // Fixture list remains fast: API when configured, public web source as fallback. Deep analysis below is Internet-first.
    void fixtures(String key,String date,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{
        String ck="fixtures_"+date;
        try{
            if(key!=null&&!key.trim().isEmpty()){
                try{
                    long ttl=date.equals(today())?5*60*1000L:60*60*1000L;
                    String raw=cacheGet(ck,ttl);
                    if(raw==null){raw=get("fixtures?date="+date+"&timezone=America%2FSao_Paulo",key.trim());cachePut(ck,raw);}
                    ArrayList<Game> api=parseGamesRoot(raw);
                    if(!api.isEmpty()){sortGames(api);ok.accept(api);return;}
                }catch(Exception ignored){}
            }
            ArrayList<Game> web=new WebDataClient(c).fixtures(date);
            if(!web.isEmpty()){sortGames(web);ok.accept(web);return;}
            String stale=c.getSharedPreferences("jp_cache",0).getString(ck,null);
            if(stale!=null){ArrayList<Game> a=parseGamesRoot(stale);sortGames(a);ok.accept(a);return;}
            ok.accept(new ArrayList<>());
        }catch(Exception e){err.accept(e.getMessage());}
    }).start();}

    void fixturesWindow(String start,int days,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{try{ArrayList<Game> out=new WebDataClient(c).fixturesWindow(start,days);sortGames(out);ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}
    void live(String key,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{try{if(key==null||key.trim().isEmpty())throw new IOException("Configure a API-Football para placares ao vivo");String raw=get("fixtures?live=all&timezone=America%2FSao_Paulo",key.trim());ArrayList<Game> out=parseGamesRoot(raw);Collections.sort(out,(x,y)->x.league.compareToIgnoreCase(y.league));ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    void search(String key,String query,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{
        try{
            // Internet/public calendar first. API is only used when the public search has no result.
            ArrayList<Game> web=new WebDataClient(c).search(query);if(!web.isEmpty()){sortGames(web);ok.accept(web);return;}
            ArrayList<Game> all=new ArrayList<>();
            if(key!=null&&!key.trim().isEmpty()){try{all=searchApi(key.trim(),query);}catch(Exception ignored){}}
            sortGames(all);ok.accept(all);
        }catch(Exception e){err.accept(e.getMessage());}
    }).start();}

    ArrayList<Game> searchApi(String key,String query)throws Exception{
        String q=URLEncoder.encode(query,"UTF-8");ArrayList<Game> all=new ArrayList<>();HashSet<Long> seen=new HashSet<>();
        try{
            JSONArray teams=new JSONObject(get("teams?search="+q,key)).optJSONArray("response");
            if(teams!=null)for(int ti=0;ti<Math.min(2,teams.length());ti++){
                int id=teams.getJSONObject(ti).getJSONObject("team").optInt("id");if(id<=0)continue;
                JSONArray ar=new JSONObject(get("fixtures?team="+id+"&from="+today()+"&to="+future(120)+"&timezone=America%2FSao_Paulo",key)).optJSONArray("response");
                if(ar!=null)for(int i=0;i<ar.length();i++){Game g=parseGame(ar.getJSONObject(i));if(seen.add(g.fixtureId))all.add(g);}
            }
        }catch(Exception ignored){}
        if(!all.isEmpty())return all;
        try{
            JSONArray leagues=new JSONObject(get("leagues?search="+q,key)).optJSONArray("response");
            if(leagues!=null)for(int i=0;i<Math.min(3,leagues.length());i++){
                JSONObject item=leagues.getJSONObject(i),lg=item.optJSONObject("league");if(lg==null)continue;int lid=lg.optInt("id");int season=currentSeason(item.optJSONArray("seasons"));if(lid<=0||season<=0)continue;
                JSONArray ar=new JSONObject(get("fixtures?league="+lid+"&season="+season+"&from="+today()+"&to="+future(120)+"&timezone=America%2FSao_Paulo",key)).optJSONArray("response");
                if(ar!=null)for(int j=0;j<ar.length();j++){Game g=parseGame(ar.getJSONObject(j));if(seen.add(g.fixtureId))all.add(g);}
            }
        }catch(Exception ignored){}
        return all;
    }
    static int currentSeason(JSONArray a){int best=0;if(a==null)return 0;for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s==null)continue;int y=s.optInt("year");if(s.optBoolean("current",false))return y;if(y>best)best=y;}return best;}
    static void sortGames(ArrayList<Game> a){Collections.sort(a,(x,y)->{int t=safeStr(x.time).compareTo(safeStr(y.time));return t!=0?t:safeStr(x.league).compareToIgnoreCase(safeStr(y.league));});}
    static String safeStr(String s){return s==null?"":s;}

    static Game parseGame(JSONObject o)throws Exception{
        JSONObject f=o.getJSONObject("fixture"),teams=o.getJSONObject("teams"),lg=o.getJSONObject("league"),ho=teams.getJSONObject("home"),aw=teams.getJSONObject("away"),st=f.getJSONObject("status");
        String iso=f.optString("date","");String day=iso.length()>=10?iso.substring(0,10):"";String tm=iso.length()>=16?iso.substring(11,16):"--:--";String when=day.isEmpty()?tm:day+"|"+tm;
        Game g=new Game(f.optLong("id"),ho.optInt("id"),aw.optInt("id"),lg.optInt("id"),lg.optInt("season"),ho.optString("name"),aw.optString("name"),ho.optString("logo"),aw.optString("logo"),lg.optString("name"),when,st.optString("short"));
        JSONObject goals=o.optJSONObject("goals");if(goals!=null){g.homeGoals=goals.isNull("home")?-1:goals.optInt("home",-1);g.awayGoals=goals.isNull("away")?-1:goals.optInt("away",-1);}g.elapsed=st.optInt("elapsed",0);return g;
    }

    void enrich(String key,Game g,String date,Consumer<Game> ok){new Thread(()->{try{
        if(key==null||key.trim().isEmpty()||g==null){ok.accept(g);return;}String k=key.trim();
        // First resolve the exact fixture by the two team names. This is much more reliable
        // than resolving each club independently, especially for names such as SC Internacional.
        Game fx=findFixtureByNames(k,g,date);
        if(fx!=null){copyResolved(g,fx);ok.accept(g);return;}
        JSONObject ht=findTeam(k,g.home),at=findTeam(k,g.away);
        if(ht!=null){g.homeId=ht.optInt("id");g.homeLogo=ht.optString("logo",g.homeLogo);}if(at!=null){g.awayId=at.optInt("id");g.awayLogo=at.optString("logo",g.awayLogo);}
        if(g.homeId>0&&g.awayId>0){Game byId=findFixtureByIds(k,g.homeId,g.awayId,date);if(byId!=null)copyResolved(g,byId);}
        ok.accept(g);
    }catch(Exception e){ok.accept(g);}}).start();}

    Game findFixtureByNames(String key,Game target,String date)throws Exception{
        String d=(date!=null&&date.matches("\\d{4}-\\d{2}-\\d{2}"))?date:today();String raw=fixturesDateCached(key,d);JSONArray ar=new JSONObject(raw).optJSONArray("response");if(ar==null)return null;Game best=null;int bestScore=-1;
        for(int i=0;i<ar.length();i++){Game z=parseGame(ar.getJSONObject(i));int sc=teamScore(target.home,z.home)+teamScore(target.away,z.away);if(sc>bestScore){bestScore=sc;best=z;}if(sc>=190)return z;}return bestScore>=150?best:null;
    }
    Game findFixtureByIds(String key,int home,int away,String date)throws Exception{
        String d=(date!=null&&date.matches("\\d{4}-\\d{2}-\\d{2}"))?date:today();JSONArray ar=new JSONObject(fixturesDateCached(key,d)).optJSONArray("response");if(ar==null)return null;for(int i=0;i<ar.length();i++){Game z=parseGame(ar.getJSONObject(i));if(z.homeId==home&&z.awayId==away)return z;}return null;
    }
    String fixturesDateCached(String key,String date)throws Exception{String ck="fixtures_"+date;long ttl=date.equals(today())?5*60*1000L:60*60*1000L;String raw=cacheGet(ck,ttl);if(raw==null){raw=get("fixtures?date="+date+"&timezone=America%2FSao_Paulo",key);cachePut(ck,raw);}return raw;}
    static void copyResolved(Game g,Game z){if(g==null||z==null)return;g.fixtureId=z.fixtureId;g.homeId=z.homeId;g.awayId=z.awayId;g.leagueId=z.leagueId;g.season=z.season;g.time=z.time;g.status=z.status;g.league=z.league;g.homeLogo=z.homeLogo;g.awayLogo=z.awayLogo;if(z.homeGoals>=0)g.homeGoals=z.homeGoals;if(z.awayGoals>=0)g.awayGoals=z.awayGoals;g.elapsed=z.elapsed;}
    static String[] nearbyDates(String date){ArrayList<String> out=new ArrayList<>();if(date!=null&&date.matches("\\d{4}-\\d{2}-\\d{2}")){try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));java.util.Date base=f.parse(date);for(int off:new int[]{0,-1,1,-2,2}){java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));c.setTime(base);c.add(java.util.Calendar.DAY_OF_MONTH,off);out.add(f.format(c.getTime()));}}catch(Exception ignored){}}if(out.isEmpty())out.add(today());return out.toArray(new String[0]);}

    JSONObject findTeam(String key,String name)throws Exception{
        String target=norm(name);JSONObject best=null;int score=-1;LinkedHashSet<String> queries=new LinkedHashSet<>();queries.add(cleanTeam(name));queries.add(name==null?"":name.trim());String compact=cleanTeam(name).replace("&"," ").replaceAll("\\s+"," ").trim();queries.add(compact);
        for(String q:queries){if(q==null||q.trim().length()<3)continue;String ck="team2_"+norm(q);String raw=cacheGet(ck,7L*24*60*60*1000L);JSONArray ar=null;if(raw!=null){try{ar=new JSONObject(raw).optJSONArray("response");if(ar!=null&&ar.length()==0)raw=null;}catch(Exception ignored){raw=null;}}
            if(raw==null){raw=get("teams?search="+URLEncoder.encode(q.trim(),"UTF-8"),key);ar=new JSONObject(raw).optJSONArray("response");if(ar!=null&&ar.length()>0)cachePut(ck,raw);}else ar=new JSONObject(raw).optJSONArray("response");
            if(ar==null)continue;for(int i=0;i<ar.length();i++){JSONObject item=ar.optJSONObject(i);JSONObject t=item==null?null:item.optJSONObject("team");if(t==null)continue;int sc=teamScore(name,t.optString("name"));if(sc>score){score=sc;best=t;}}
            if(score>=95)break;
        }return score>=55?best:null;
    }
    static String cleanTeam(String n){if(n==null)return "";String x=n.trim();x=x.replaceAll("(?i)^(sc|se|ec|ac|fc|afc|ca)\\s+","");x=x.replaceAll("(?i)\\s+(fc|cf|afc|ec|sc)$","");return x.trim();}
    static String norm(String n){String x=cleanTeam(n);x=java.text.Normalizer.normalize(x,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","");return x.toLowerCase(Locale.ROOT).replace("&","and").replaceAll("[^a-z0-9]","");}
    static int teamScore(String a,String b){String x=norm(a),y=norm(b);if(x.isEmpty()||y.isEmpty())return 0;if(x.equals(y))return 100;if(x.contains(y)||y.contains(x))return 88;int pref=common(x,y);int min=Math.min(x.length(),y.length());int score=min==0?0:(pref*70/min);HashSet<String> ax=tokens(a),by=tokens(b);int hit=0;for(String t:ax)if(by.contains(t))hit++;if(!ax.isEmpty()&&!by.isEmpty())score=Math.max(score,(int)Math.round(70.0*hit/Math.max(ax.size(),by.size())));return score;}
    static HashSet<String> tokens(String s){HashSet<String> out=new HashSet<>();String x=java.text.Normalizer.normalize(cleanTeam(s),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);for(String t:x.split("[^a-z0-9]+"))if(t.length()>2&&!t.equals("club")&&!t.equals("football"))out.add(t);return out;}
    static int common(String a,String b){int n=Math.min(a.length(),b.length()),x=0;for(int i=0;i<n&&a.charAt(i)==b.charAt(i);i++)x++;return x;}

    void lineups(String key,long fixture,Consumer<ArrayList<Lineup>> ok,Consumer<String> err){lineups(key,fixture,false,ok,err);}
    void lineups(String key,long fixture,boolean force,Consumer<ArrayList<Lineup>> ok,Consumer<String> err){new Thread(()->{try{String ck="lineups_"+fixture;String raw=force?null:cacheGet(ck,5*60*1000L);if(raw==null){raw=get("fixtures/lineups?fixture="+fixture,key);cachePut(ck,raw);}JSONArray ar=new JSONObject(raw).optJSONArray("response");ArrayList<Lineup> out=new ArrayList<>();if(ar!=null)for(int i=0;i<ar.length();i++){JSONObject o=ar.getJSONObject(i);Lineup l=new Lineup();l.team=o.getJSONObject("team").optString("name");l.formation=o.optString("formation","—");l.coach=o.optJSONObject("coach")!=null?o.getJSONObject("coach").optString("name","—"):"—";parsePlayers(o.optJSONArray("startXI"),l.start);parsePlayers(o.optJSONArray("substitutes"),l.bench);if(!l.start.isEmpty()||!l.bench.isEmpty())out.add(l);}ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}
    static void parsePlayers(JSONArray a,ArrayList<Player> out)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject p=a.getJSONObject(i).getJSONObject("player");out.add(new Player(p.optInt("id"),p.optInt("number"),p.optString("name"),p.optString("grid")));}}

    void stats(String key,long fixture,Consumer<Stats> ok,Consumer<String> err){new Thread(()->{try{ok.accept(parseStats(getCachedFixtureStats(key,fixture)));}catch(Exception e){err.accept(e.getMessage());}}).start();}
    Stats parseStats(String raw)throws Exception{
        JSONArray ar=new JSONObject(raw).optJSONArray("response");Stats s=new Stats();if(ar==null||ar.length()<2)return s;JSONObject A=ar.getJSONObject(0),B=ar.getJSONObject(1);HashMap<String,String> x=mapStats(A.optJSONArray("statistics")),y=mapStats(B.optJSONArray("statistics"));
        String[][] defs={{"Ball Possession","Posse de bola"},{"Total Shots","Finalizações"},{"Shots on Goal","No alvo"},{"Shots off Goal","Fora do alvo"},{"Blocked Shots","Chutes bloqueados"},{"Corner Kicks","Escanteios"},{"Fouls","Faltas"},{"Throwins","Laterais"},{"Throw-ins","Laterais"},{"Goal Kicks","Tiros de meta"},{"Free Kicks","Tiros livres"},{"Offsides","Impedimentos"},{"Yellow Cards","Cartões amarelos"},{"Red Cards","Cartões vermelhos"},{"Goalkeeper Saves","Defesas"},{"Total passes","Passes"},{"Passes accurate","Passes certos"},{"Passes %","Precisão de passes"}};
        HashSet<String> added=new HashSet<>();for(String[] d:defs){if(added.contains(d[1]))continue;if(x.containsKey(d[0])||y.containsKey(d[0])){s.rows.put(d[1],new String[]{x.getOrDefault(d[0],"—"),y.getOrDefault(d[0],"—")});added.add(d[1]);}}
        return s;
    }
    String getCachedFixtureStats(String key,long fixture)throws Exception{String ck="fxstats_"+fixture;String raw=cacheGet(ck,14L*24*60*60*1000L);if(raw==null){raw=get("fixtures/statistics?fixture="+fixture,key);cachePut(ck,raw);}return raw;}

    void prediction(String key,long fixture,Consumer<Prediction> ok,Consumer<String> err){new Thread(()->{try{
        JSONArray ar=new JSONObject(get("predictions?fixture="+fixture,key)).getJSONArray("response");if(ar.length()==0)throw new IOException("Sem previsão disponível");
        JSONObject item=ar.getJSONObject(0),o=item.getJSONObject("predictions");Prediction p=new Prediction();JSONObject pc=o.optJSONObject("percent");
        p.home=pct(pc==null?"":pc.optString("home"));p.draw=pct(pc==null?"":pc.optString("draw"));p.away=pct(pc==null?"":pc.optString("away"));
        p.advice=o.optString("advice","");p.underOver=o.isNull("under_over")?"":o.optString("under_over","");if("null".equalsIgnoreCase(p.underOver))p.underOver="";JSONObject w=o.optJSONObject("winner");p.winner=w==null?"":w.optString("name","");
        JSONObject cmp=item.optJSONObject("comparison");if(cmp!=null){String[] ks={"form","att","def","poisson","h2h","goals","total"};String[] pt={"Forma recente","Ataque","Defesa","Poisson","Confronto direto","Gols","Índice geral"};for(int i=0;i<ks.length;i++){JSONObject q=cmp.optJSONObject(ks[i]);if(q!=null){int hv=pct(q.optString("home")),av=pct(q.optString("away"));p.comparison.put(pt[i]+"|H",hv);p.comparison.put(pt[i]+"|A",av);}}}
        JSONObject teams=item.optJSONObject("teams");if(teams!=null){JSONObject hh=teams.optJSONObject("home"),aa=teams.optJSONObject("away");if(hh!=null)p.homeForm=hh.optString("last_5","");if(aa!=null)p.awayForm=aa.optString("last_5","");}
        reconcilePrediction(p);ok.accept(p);
    }catch(Exception e){err.accept(e.getMessage());}}).start();}

    static void reconcilePrediction(Prediction p){
        if(p==null)return;int sum=p.home+p.draw+p.away;if(sum<=0)return;
        int rawH=(int)Math.round(100.0*p.home/sum),rawD=(int)Math.round(100.0*p.draw/sum),rawA=100-rawH-rawD;
        double eh=0,ea=0;int n=0;String[] labels={"Forma recente","Ataque","Defesa","Confronto direto","Gols","Índice geral"};
        for(String z:labels){Integer h=p.comparison.get(z+"|H"),a=p.comparison.get(z+"|A");if(h!=null&&a!=null&&h+a>0){eh+=h;ea+=a;n++;}}
        if(n==0){p.home=rawH;p.draw=rawD;p.away=rawA;return;}eh/=n;ea/=n;double gap=Math.abs(eh-ea);
        int evidenceDraw=gap>=25?24:(gap>=15?27:30),pool=100-evidenceDraw;double den=Math.max(1,eh+ea);int eH=(int)Math.round(pool*eh/den),eA=pool-eH;
        boolean tiedTop=(rawH==rawD&&rawH>=rawA)||(rawA==rawD&&rawA>=rawH);boolean contradict=(eh>ea+12&&rawA>rawH)||(ea>eh+12&&rawH>rawA);double blend=(tiedTop||contradict)?0.55:0.35;
        int h=(int)Math.round(rawH*(1-blend)+eH*blend),d=(int)Math.round(rawD*(1-blend)+evidenceDraw*blend),a=100-h-d;
        if(a<8){h-=8-a;a=8;}if(h<8){a-=8-h;h=8;}if(d<16){int need=16-d;d=16;if(h>=a)h-=need;else a-=need;}
        int total=h+d+a;if(total!=100)a+=100-total;p.home=Math.max(0,h);p.draw=Math.max(0,d);p.away=Math.max(0,a);
    }

    void h2h(String key,int home,int away,Consumer<H2H> ok,Consumer<String> err){new Thread(()->{try{JSONArray ar=new JSONObject(get("fixtures/headtohead?h2h="+home+"-"+away+"&last=5",key)).getJSONArray("response");H2H h=new H2H();for(int i=0;i<ar.length();i++){JSONObject o=ar.getJSONObject(i),teams=o.getJSONObject("teams"),goals=o.getJSONObject("goals"),fx=o.getJSONObject("fixture");String hn=teams.getJSONObject("home").optString("name"),an=teams.getJSONObject("away").optString("name");int hg=goals.optInt("home",-1),ag=goals.optInt("away",-1);String d=fx.optString("date","");if(d.length()>=10)d=d.substring(0,10);h.rows.add(d+"  •  "+hn+"  "+(hg<0?"—":hg)+" × "+(ag<0?"—":ag)+"  "+an);int hid=teams.getJSONObject("home").optInt("id");if(hg==ag)h.draws++;else {int win=hg>ag?hid:teams.getJSONObject("away").optInt("id");if(win==home)h.homeWins++;else if(win==away)h.awayWins++;}}ok.accept(h);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    // Deep pre-match engine.
    // Internet-first policy: 10 recent matches per team + home/away cut + up to 5 H2H.
    // Public web data is attempted first. API-Football only supplements missing/low-coverage markets.
    void deepAnalysis(String key,Game g,Consumer<DeepAnalysis> ok,Consumer<String> err){new Thread(()->{
        try{
            if(g==null)throw new IOException("Confronto inválido");
            String cacheKey="deep_v5_coherent_"+norm(g.home)+"_"+norm(g.away);
            String cached=cacheGet(cacheKey,3L*60*60*1000L);
            if(cached!=null){DeepAnalysis ready=parseDeep(cached);if(ready!=null&&!ready.metrics.isEmpty()){ok.accept(ready);return;}}

            DeepAnalysis web=null,api=null;
            try{web=new InternetStatsClient(c).analyze(g,10,6,5);}catch(Exception ignored){}

            // Resolve IDs only when an API key exists; web analysis does not depend on API IDs.
            Game resolved=g;
            if(key!=null&&!key.trim().isEmpty()&&(resolved.homeId<=0||resolved.awayId<=0)){
                try{Game fx=findFixtureByNames(key.trim(),resolved,dateOf(resolved));if(fx!=null){copyResolved(resolved,fx);}}catch(Exception ignored){}
            }

            // Save API requests when the internet layer already provides strong coverage.
            int webCoverage=coveragePercent(web);
            if(key!=null&&!key.trim().isEmpty()&&resolved.homeId>0&&resolved.awayId>0&&webCoverage<65){
                try{api=deepAnalysisApiSync(key.trim(),resolved);}catch(Exception ignored){}
            }

            DeepAnalysis merged=mergeDeep(web,api);
            if(merged==null)merged=new DeepAnalysis();
            ensureGoalFallback(merged,g,10,5);
            if(merged.metrics.isEmpty())throw new IOException("Não encontrei histórico suficiente nas fontes disponíveis");
            merged.complete=true;
            if(merged.sources==null||merged.sources.trim().isEmpty())merged.sources=api!=null?"API-Football":"Internet / OpenFootball";
            merged.note="Amostra adaptativa: até 10 jogos recentes por equipe, recorte casa/fora de até 6 jogos e até 5 H2H com peso menor. Internet é priorizada; API complementa somente lacunas. Cobertura por mercado depende das observações realmente encontradas";
            cachePut(cacheKey,deepJson(merged).toString());ok.accept(merged);
        }catch(Exception e){err.accept(e.getMessage());}
    }).start();}

    DeepAnalysis deepAnalysisApiSync(String key,Game g)throws Exception{
        final int RECENT=6,H2H=3; // supplement only: keep API usage economical
        ExecutorService lists=Executors.newFixedThreadPool(3);
        Future<ArrayList<Game>> fh=lists.submit(()->safeRecentOtherGames(key,g.homeId,g.awayId,RECENT));
        Future<ArrayList<Game>> fa=lists.submit(()->safeRecentOtherGames(key,g.awayId,g.homeId,RECENT));
        Future<ArrayList<Game>> fhh=lists.submit(()->safeH2hGames(key,g.homeId,g.awayId,H2H));
        ArrayList<Game> h=fh.get(7,TimeUnit.SECONDS),a=fa.get(7,TimeUnit.SECONDS),hh=fhh.get(7,TimeUnit.SECONDS);lists.shutdownNow();
        Series hg=new Series(),ag=new Series(),hgh=new Series(),agh=new Series();
        accumulateGoals(h,g.homeId,hg);accumulateGoals(a,g.awayId,ag);accumulateGoals(hh,g.homeId,hgh);accumulateGoals(hh,g.awayId,agh);
        DeepAnalysis d=new DeepAnalysis();d.homeMatches=h.size();d.awayMatches=a.size();d.h2hMatches=hh.size();d.sources="API-Football (complemento)";
        LinkedHashMap<String,Series> hs=new LinkedHashMap<>(),as=new LinkedHashMap<>(),hhs=new LinkedHashMap<>(),has=new LinkedHashMap<>();
        String[] metrics={"Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};
        for(String m:metrics){hs.put(m,new Series());as.put(m,new Series());hhs.put(m,new Series());has.put(m,new Series());}
        prefetchFixtureStats(key,h,a,hh);fetchSeries(key,h,g.homeId,hs);fetchSeries(key,a,g.awayId,as);fetchSeries(key,hh,g.homeId,hhs);fetchSeries(key,hh,g.awayId,has);
        addProjectionV3(d,"Gols",hg,ag,hgh,agh,2.5,3.5);markSource(d,"Gols","API");
        addProjectionV3(d,"Escanteios",hs.get("Escanteios"),as.get("Escanteios"),hhs.get("Escanteios"),has.get("Escanteios"),8.5,10.5);markSource(d,"Escanteios","API");
        addProjectionV3(d,"Laterais",hs.get("Laterais"),as.get("Laterais"),hhs.get("Laterais"),has.get("Laterais"),dynamicLineV3(hs.get("Laterais"),as.get("Laterais"),hhs.get("Laterais"),has.get("Laterais"),2),-1);markSource(d,"Laterais","API");
        addProjectionV3(d,"Tiros de meta",hs.get("Tiros de meta"),as.get("Tiros de meta"),hhs.get("Tiros de meta"),has.get("Tiros de meta"),dynamicLineV3(hs.get("Tiros de meta"),as.get("Tiros de meta"),hhs.get("Tiros de meta"),has.get("Tiros de meta"),2),-1);markSource(d,"Tiros de meta","API");
        addProjectionV3(d,"Faltas",hs.get("Faltas"),as.get("Faltas"),hhs.get("Faltas"),has.get("Faltas"),dynamicLineV3(hs.get("Faltas"),as.get("Faltas"),hhs.get("Faltas"),has.get("Faltas"),2),-1);markSource(d,"Faltas","API");
        addProjectionV3(d,"Finalizações",hs.get("Finalizações"),as.get("Finalizações"),hhs.get("Finalizações"),has.get("Finalizações"),dynamicLineV3(hs.get("Finalizações"),as.get("Finalizações"),hhs.get("Finalizações"),has.get("Finalizações"),2),-1);markSource(d,"Finalizações","API");
        addProjectionV3(d,"Chutes no alvo",hs.get("Chutes no alvo"),as.get("Chutes no alvo"),hhs.get("Chutes no alvo"),has.get("Chutes no alvo"),7.5,9.5);markSource(d,"Chutes no alvo","API");
        addProjectionV3(d,"Impedimentos",hs.get("Impedimentos"),as.get("Impedimentos"),hhs.get("Impedimentos"),has.get("Impedimentos"),3.5,5.5);markSource(d,"Impedimentos","API");
        addProjectionV3(d,"Cartões amarelos",hs.get("Cartões amarelos"),as.get("Cartões amarelos"),hhs.get("Cartões amarelos"),has.get("Cartões amarelos"),3.5,5.5);markSource(d,"Cartões amarelos","API");
        addProjectionV3(d,"Tiros livres",hs.get("Tiros livres"),as.get("Tiros livres"),hhs.get("Tiros livres"),has.get("Tiros livres"),dynamicLineV3(hs.get("Tiros livres"),as.get("Tiros livres"),hhs.get("Tiros livres"),has.get("Tiros livres"),2),-1);markSource(d,"Tiros livres","API");
        d.complete=!d.metrics.isEmpty();return d;
    }
    static void markSource(DeepAnalysis d,String name,String src){MetricProjection m=d.metrics.get(name);if(m!=null)m.source=src;}
    static DeepAnalysis mergeDeep(DeepAnalysis web,DeepAnalysis api){
        if(web==null&&api==null)return null;if(web==null)return api;if(api==null)return web;DeepAnalysis d=new DeepAnalysis();
        d.homeMatches=Math.max(web.homeMatches,api.homeMatches);d.awayMatches=Math.max(web.awayMatches,api.awayMatches);d.h2hMatches=Math.max(web.h2hMatches,api.h2hMatches);d.homeVenueMatches=Math.max(web.homeVenueMatches,api.homeVenueMatches);d.awayVenueMatches=Math.max(web.awayVenueMatches,api.awayVenueMatches);d.sources="Internet + API fallback";
        LinkedHashSet<String> names=new LinkedHashSet<>();names.addAll(web.metrics.keySet());names.addAll(api.metrics.keySet());
        for(String n:names){MetricProjection w=web.metrics.get(n),a=api.metrics.get(n);MetricProjection pick;if(w==null)pick=a;else if(a==null)pick=w;else pick=(w.sample>=Math.max(5,a.sample-1))?w:a;d.metrics.put(n,pick);}d.complete=!d.metrics.isEmpty();return d;
    }
    void ensureGoalFallback(DeepAnalysis d,Game g,int recent,int h2h){try{WebDataClient web=new WebDataClient(c);Series h=web.recentGoalSeries(g.home,g.away,recent),a=web.recentGoalSeries(g.away,g.home,recent),hh=web.h2hGoalSeries(g.home,g.away,h2h),ha=web.h2hGoalSeries(g.away,g.home,h2h),hv=web.venueGoalSeries(g.home,true,6),av=web.venueGoalSeries(g.away,false,6);d.homeMatches=Math.max(d.homeMatches,h.n);d.awayMatches=Math.max(d.awayMatches,a.n);d.homeVenueMatches=Math.max(d.homeVenueMatches,hv.n);d.awayVenueMatches=Math.max(d.awayVenueMatches,av.n);d.h2hMatches=Math.max(d.h2hMatches,Math.min(hh.n,ha.n));if(!d.metrics.containsKey("Gols")){addProjectionV3(d,"Gols",h,a,hh,ha,2.5,3.5);MetricProjection m=d.metrics.get("Gols");if(m!=null)m.source="OpenFootball";}}catch(Exception ignored){}}
    static int coveragePercent(DeepAnalysis d){if(d==null)return 0;String[] core={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};double sum=0;for(String n:core){MetricProjection m=d.metrics.get(n);if(m!=null)sum+=Math.min(100,m.sample*100.0/25.0);}return (int)Math.round(sum/core.length);}
    static String dateOf(Game g){if(g!=null&&g.time!=null&&g.time.contains("|")){String x=g.time.substring(0,g.time.indexOf('|'));if(x.matches("\\d{4}-\\d{2}-\\d{2}"))return x;}return today();}

    ArrayList<Game> safeRecentOtherGames(String key,int teamId,int excludeOpponent,int last){try{return recentOtherGames(key,teamId,excludeOpponent,last);}catch(Exception e){return new ArrayList<>();}}
    ArrayList<Game> safeH2hGames(String key,int home,int away,int last){try{return h2hGames(key,home,away,last);}catch(Exception e){return new ArrayList<>();}}

    ArrayList<Game> recentOtherGames(String key,int teamId,int excludeOpponent,int last)throws Exception{
        // Ask for more than five because H2H games are deliberately excluded from this sample.
        int request=Math.max(12,last*3);String ck="recent_other_"+teamId+"_"+excludeOpponent+"_"+last;
        String raw=cacheGet(ck,3*60*60*1000L);if(raw==null){raw=get("fixtures?team="+teamId+"&last="+request+"&timezone=America%2FSao_Paulo",key);cachePut(ck,raw);}
        ArrayList<Game> a=parseGamesRoot(raw);Collections.sort(a,(x,y)->safeStr(y.time).compareTo(safeStr(x.time)));ArrayList<Game> out=new ArrayList<>();
        for(Game z:a){if(z.homeGoals<0||z.awayGoals<0)continue;int opp=z.homeId==teamId?z.awayId:z.homeId;if(opp==excludeOpponent)continue;out.add(z);if(out.size()>=last)break;}return out;
    }
    ArrayList<Game> recentGames(String key,int teamId,int last)throws Exception{return recentOtherGames(key,teamId,-999999,last);}
    ArrayList<Game> h2hGames(String key,int home,int away,int last)throws Exception{
        String ck="h2hdeep_v3_"+home+"_"+away+"_"+last;String raw=cacheGet(ck,6*60*60*1000L);if(raw==null){raw=get("fixtures/headtohead?h2h="+home+"-"+away+"&last="+last,key);cachePut(ck,raw);}ArrayList<Game> a=parseGamesRoot(raw);ArrayList<Game> out=new ArrayList<>();for(Game z:a)if(z.homeGoals>=0&&z.awayGoals>=0){out.add(z);if(out.size()>=last)break;}return out;
    }
    void accumulateGoals(ArrayList<Game> games,int teamId,Series s){int i=0;for(Game g:games){if(g.homeGoals<0||g.awayGoals<0)continue;boolean home=g.homeId==teamId;double f=home?g.homeGoals:g.awayGoals,ag=home?g.awayGoals:g.homeGoals;s.add(f,ag,weight(i++));}}
    static void mergeMissing(Series base,Series fallback,int target){if(base==null||fallback==null||base.n>=target||fallback.weight<=0)return;if(fallback.n>base.n){base.forSum=fallback.forSum;base.againstSum=fallback.againstSum;base.weight=fallback.weight;base.n=Math.min(target,fallback.n);}}

    @SafeVarargs final void prefetchFixtureStats(String key,ArrayList<Game>... groups){
        LinkedHashSet<Long> ids=new LinkedHashSet<>();for(ArrayList<Game> g:groups)if(g!=null)for(Game x:g)if(x.fixtureId>0)ids.add(x.fixtureId);if(ids.isEmpty())return;
        ExecutorService ex=Executors.newFixedThreadPool(Math.min(6,ids.size()));ArrayList<Future<?>> fs=new ArrayList<>();for(Long id:ids)fs.add(ex.submit(()->{try{getCachedFixtureStats(key,id);}catch(Exception ignored){}}));
        long deadline=System.currentTimeMillis()+7000L;for(Future<?> f:fs){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{f.get(left,TimeUnit.MILLISECONDS);}catch(Exception ignored){}}ex.shutdownNow();
    }
    void fetchSeries(String key,ArrayList<Game> games,int teamId,LinkedHashMap<String,Series> dst)throws Exception{
        if(games==null||games.isEmpty())return;int i=0;for(Game fx:games){try{StatSample sm=statSample(key,fx.fixtureId,teamId);double w=weight(i++);for(String name:dst.keySet()){double f=metricValue(sm.team,name),a=metricValue(sm.opp,name);if(!Double.isNaN(f)&&!Double.isNaN(a))dst.get(name).add(f,a,w);}}catch(Exception ignored){i++;}}
    }
    StatSample statSample(String key,long fixture,int teamId)throws Exception{
        JSONArray ar=new JSONObject(getCachedFixtureStats(key,fixture)).optJSONArray("response");StatSample out=new StatSample();if(ar==null)return out;
        for(int i=0;i<ar.length();i++){JSONObject block=ar.optJSONObject(i);if(block==null)continue;JSONObject tm=block.optJSONObject("team");int id=tm==null?0:tm.optInt("id");HashMap<String,Double> target=id==teamId?out.team:out.opp;JSONArray st=block.optJSONArray("statistics");if(st==null)continue;for(int k=0;k<st.length();k++){JSONObject z=st.optJSONObject(k);if(z==null)continue;Object v=z.opt("value");if(v==null||v==JSONObject.NULL)continue;double n=parseNum(String.valueOf(v));if(!Double.isNaN(n))target.put(z.optString("type"),n);}}
        return out;
    }
    static double metricValue(HashMap<String,Double> m,String name){
        String[][] defs={{"Escanteios","Corner Kicks"},{"Laterais","Throwins","Throw-ins","Throw Ins","Throw In"},{"Tiros de meta","Goal Kicks","Goal kicks","Goal Kick"},{"Faltas","Fouls"},{"Finalizações","Total Shots"},{"Chutes no alvo","Shots on Goal"},{"Impedimentos","Offsides"},{"Cartões amarelos","Yellow Cards"},{"Tiros livres","Free Kicks","Free kicks"}};
        for(String[] d:defs)if(d[0].equals(name))for(int i=1;i<d.length;i++)if(m.containsKey(d[i]))return m.get(d[i]);return Double.NaN;
    }
    static double dynamicLineV3(Series home,Series away,Series hh,Series ha,int offset){double hp=projectSide(home,away,hh),ap=projectSide(away,home,ha);double total=hp+ap;if(Double.isNaN(total)||total<1)return -1;return Math.max(.5,Math.floor(total)-offset+.5);}
    static void addProjectionV3(DeepAnalysis d,String name,Series home,Series away,Series h2hHome,Series h2hAway,double line,double lineHigh){
        double hp=projectSide(home,away,h2hHome),ap=projectSide(away,home,h2hAway);if(Double.isNaN(hp)||Double.isNaN(ap))return;MetricProjection m=new MetricProjection(name);m.home=hp;m.away=ap;m.total=hp+ap;
        int recent=(home==null?0:home.n)+(away==null?0:away.n);int h2=Math.min(h2hHome==null?0:h2hHome.n,h2hAway==null?0:h2hAway.n);m.sample=recent+h2;
        m.line=line;double spread=Math.max(1.0,Math.sqrt(Math.max(.1,m.total))*1.15);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(line>0)m.overProb=poissonOver(m.total,line);m.lineHigh=lineHigh>0?lineHigh:(line>0?line+2:-1);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);d.metrics.put(name,m);
    }
    static double projectSide(Series ownRecent,Series oppRecent,Series h2h){
        double base=combine(ownRecent==null?Double.NaN:ownRecent.f(),oppRecent==null?Double.NaN:oppRecent.a());double direct=h2h==null?Double.NaN:h2h.f();
        if(Double.isNaN(base))return direct;if(Double.isNaN(direct))return base;return base*.72+direct*.28;
    }
    static double dynamicLine(Series home,Series away,int offset){if(home==null||away==null||home.n==0||away.n==0)return -1;double hp=combine(home.f(),away.a()),ap=combine(away.f(),home.a()),total=hp+ap;if(Double.isNaN(total)||total<1)return -1;return Math.max(.5,Math.floor(total)-offset+.5);}
    static void addProjection(DeepAnalysis d,String name,Series home,Series away,double line,double lineHigh){
        if(home==null||away==null||home.n==0||away.n==0)return;double hp=combine(home.f(),away.a()),ap=combine(away.f(),home.a());if(Double.isNaN(hp)||Double.isNaN(ap))return;MetricProjection m=new MetricProjection(name);m.home=hp;m.away=ap;m.total=hp+ap;m.sample=home.n+away.n;m.line=line;double spread=Math.max(1.0,Math.sqrt(Math.max(.1,m.total))*1.15);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(line>0)m.overProb=poissonOver(m.total,line);m.lineHigh=lineHigh>0?lineHigh:(line>0?line+2:-1);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);d.metrics.put(name,m);
    }
    static double combine(double a,double b){if(Double.isNaN(a))return b;if(Double.isNaN(b))return a;return (a+b)/2.0;}
    static double weight(int i){return Math.max(.38,Math.pow(.90,Math.max(0,i)));}
    static int poissonOver(double lambda,double line){int k=(int)Math.floor(line);double p=Math.exp(-lambda),sum=p;for(int i=1;i<=k;i++){p*=lambda/i;sum+=p;}return (int)Math.round(Math.max(0,Math.min(1,1-sum))*100);}
    static double parseNum(String s){try{return Double.parseDouble(s.replace("%","").trim());}catch(Exception e){return Double.NaN;}}
    JSONObject deepJson(DeepAnalysis d)throws Exception{JSONObject root=new JSONObject();root.put("hm",d.homeMatches);root.put("am",d.awayMatches);root.put("hh",d.h2hMatches);root.put("hvm",d.homeVenueMatches);root.put("avm",d.awayVenueMatches);root.put("src",d.sources);root.put("note",d.note);JSONArray ar=new JSONArray();for(MetricProjection m:d.metrics.values()){JSONObject o=new JSONObject();o.put("n",m.name);o.put("h",m.home);o.put("a",m.away);o.put("t",m.total);o.put("lo",m.low);o.put("hi",m.high);o.put("l",m.line);o.put("p",m.overProb);o.put("l2",m.lineHigh);o.put("p2",m.overProbHigh);o.put("s",m.sample);o.put("src",m.source);ar.put(o);}root.put("m",ar);return root;}
    DeepAnalysis parseDeep(String raw){try{JSONObject root=new JSONObject(raw);DeepAnalysis d=new DeepAnalysis();d.homeMatches=root.optInt("hm");d.awayMatches=root.optInt("am");d.h2hMatches=root.optInt("hh");d.homeVenueMatches=root.optInt("hvm");d.awayVenueMatches=root.optInt("avm");d.sources=root.optString("src","");d.note=root.optString("note","");JSONArray ar=root.optJSONArray("m");if(ar!=null)for(int i=0;i<ar.length();i++){JSONObject o=ar.optJSONObject(i);if(o==null)continue;MetricProjection m=new MetricProjection(o.optString("n"));m.home=o.optDouble("h");m.away=o.optDouble("a");m.total=o.optDouble("t");m.low=o.optDouble("lo");m.high=o.optDouble("hi");m.line=o.optDouble("l",-1);m.overProb=o.optInt("p",-1);m.lineHigh=o.optDouble("l2",-1);m.overProbHigh=o.optInt("p2",-1);m.sample=o.optInt("s");m.source=o.optString("src","");d.metrics.put(m.name,m);}d.complete=!d.metrics.isEmpty();return d;}catch(Exception e){return null;}}

    static String today(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(new java.util.Date());}
    static String future(int days){java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));c.add(java.util.Calendar.DAY_OF_MONTH,days);java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(c.getTime());}
    static int pct(String s){try{return Math.round(Float.parseFloat(s.replace("%","").trim()));}catch(Exception e){return 0;}}
    static HashMap<String,String> mapStats(JSONArray a)throws Exception{HashMap<String,String> m=new HashMap<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Object v=o.opt("value");if(v!=null&&v!=JSONObject.NULL)m.put(o.optString("type"),String.valueOf(v));}return m;}
}
