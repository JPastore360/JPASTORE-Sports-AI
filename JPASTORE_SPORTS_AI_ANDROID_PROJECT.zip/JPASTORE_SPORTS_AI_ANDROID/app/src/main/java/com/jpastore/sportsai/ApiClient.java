package com.jpastore.sportsai;

import android.content.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

public class ApiClient {
    Context c;
    ApiClient(Context c){ this.c=c; }

    static class Game {
        long fixtureId; int homeId,awayId; int leagueId,season;
        String home,away,homeLogo,awayLogo,league,time,status;
        int homeGoals=-1,awayGoals=-1,elapsed=0;
        Game(long f,int hi,int ai,int li,int se,String h,String a,String hl,String al,String l,String t,String s){
            fixtureId=f;homeId=hi;awayId=ai;leagueId=li;season=se;home=h;away=a;homeLogo=hl;awayLogo=al;league=l;time=t;status=s;
        }
    }
    static class Player {int id,num;String name,grid,photo; Player(int i,int n,String nm,String g){id=i;num=n;name=nm;grid=g;photo=i>0?"https://media.api-sports.io/football/players/"+i+".png":"";} }
    static class Lineup {String team,formation,coach;ArrayList<Player> start=new ArrayList<>(),bench=new ArrayList<>();}
    static class Stats {LinkedHashMap<String,String[]> rows=new LinkedHashMap<>();}
    static class Prediction {int home,draw,away;String advice="",winner="",underOver=""; LinkedHashMap<String,Integer> comparison=new LinkedHashMap<>(); String homeForm="",awayForm="";}
    static class H2H {ArrayList<String> rows=new ArrayList<>();int homeWins,draws,awayWins;}

    static class MetricProjection {
        String name; double home,away,total,low,high,line=-1,lineHigh=-1; int overProb=-1,overProbHigh=-1,sample=0;
        MetricProjection(String n){name=n;}
    }
    static class DeepAnalysis {
        LinkedHashMap<String,MetricProjection> metrics=new LinkedHashMap<>();
        int homeMatches=0,awayMatches=0,h2hMatches=0;
        String note="";
        boolean complete=false;
    }
    static class Series {
        double forSum=0,againstSum=0,weight=0; int n=0;
        void add(double f,double a,double w){ if(Double.isNaN(f)||Double.isNaN(a))return;forSum+=f*w;againstSum+=a*w;weight+=w;n++; }
        double f(){return weight>0?forSum/weight:Double.NaN;}
        double a(){return weight>0?againstSum/weight:Double.NaN;}
    }
    static class StatSample { HashMap<String,Double> team=new HashMap<>(),opp=new HashMap<>(); }

    String get(String path,String key)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL("https://v3.football.api-sports.io/"+path).openConnection();
        h.setRequestProperty("x-apisports-key",key);h.setRequestProperty("Accept","application/json");h.setConnectTimeout(6500);h.setReadTimeout(6500);
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();
        BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s);
        if(code!=200)throw new IOException("HTTP "+code);return b.toString();
    }
    void cachePut(String k,String v){c.getSharedPreferences("jp_cache",0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long maxAge){android.content.SharedPreferences p=c.getSharedPreferences("jp_cache",0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=maxAge?p.getString(k,null):null;}
    ArrayList<Game> parseGamesRoot(String raw)throws Exception{JSONObject root=new JSONObject(raw);JSONArray a=root.optJSONArray("response");if(a==null)a=root.optJSONArray("fixtures");ArrayList<Game> out=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++)out.add(parseGame(a.getJSONObject(i)));return out;}
    void test(String key,Consumer<Boolean> cb){new Thread(()->{try{get("status",key);cb.accept(true);}catch(Exception e){cb.accept(false);}}).start();}

    // API-first when configured for speed and coverage; public source remains the fallback.
    void fixtures(String key,String date,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{
        String ck="fixtures_"+date;
        try{
            if(key!=null&&!key.trim().isEmpty()){
                try{
                    long ttl=date.equals(today())?5*60*1000L:60*60*1000L;
                    String raw=cacheGet(ck,ttl);
                    if(raw==null){raw=get("fixtures?date="+date+"&timezone=America%2FSao_Paulo",key.trim());cachePut(ck,raw);}
                    ArrayList<Game> api=parseGamesRoot(raw);
                    if(!api.isEmpty()){sortGames(api);ok.accept(api);return;}
                }catch(Exception ignored){}
            }
            ArrayList<Game> web=new WebDataClient(c).fixtures(date);
            if(!web.isEmpty()){sortGames(web);ok.accept(web);return;}
            String stale=c.getSharedPreferences("jp_cache",0).getString(ck,null);
            if(stale!=null){ArrayList<Game> a=parseGamesRoot(stale);sortGames(a);ok.accept(a);return;}
            ok.accept(new ArrayList<>());
        }catch(Exception e){err.accept(e.getMessage());}
    }).start();}

    void fixturesWindow(String start,int days,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{try{ArrayList<Game> out=new WebDataClient(c).fixturesWindow(start,days);sortGames(out);ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}
    void live(String key,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{try{if(key==null||key.trim().isEmpty())throw new IOException("Configure a API-Football para placares ao vivo");String raw=get("fixtures?live=all&timezone=America%2FSao_Paulo",key.trim());ArrayList<Game> out=parseGamesRoot(raw);Collections.sort(out,(x,y)->x.league.compareToIgnoreCase(y.league));ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    void search(String key,String query,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{
        try{
            ArrayList<Game> all=new ArrayList<>();
            if(key!=null&&!key.trim().isEmpty()){
                try{all=searchApi(key.trim(),query);}catch(Exception ignored){}
                if(!all.isEmpty()){sortGames(all);ok.accept(all);return;}
            }
            ArrayList<Game> web=new WebDataClient(c).search(query);
            sortGames(web);ok.accept(web);
        }catch(Exception e){err.accept(e.getMessage());}
    }).start();}

    ArrayList<Game> searchApi(String key,String query)throws Exception{
        String q=URLEncoder.encode(query,"UTF-8");ArrayList<Game> all=new ArrayList<>();HashSet<Long> seen=new HashSet<>();
        try{
            JSONArray teams=new JSONObject(get("teams?search="+q,key)).optJSONArray("response");
            if(teams!=null)for(int ti=0;ti<Math.min(2,teams.length());ti++){
                int id=teams.getJSONObject(ti).getJSONObject("team").optInt("id");if(id<=0)continue;
                JSONArray ar=new JSONObject(get("fixtures?team="+id+"&from="+today()+"&to="+future(120)+"&timezone=America%2FSao_Paulo",key)).optJSONArray("response");
                if(ar!=null)for(int i=0;i<ar.length();i++){Game g=parseGame(ar.getJSONObject(i));if(seen.add(g.fixtureId))all.add(g);}
            }
        }catch(Exception ignored){}
        if(!all.isEmpty())return all;
        try{
            JSONArray leagues=new JSONObject(get("leagues?search="+q,key)).optJSONArray("response");
            if(leagues!=null)for(int i=0;i<Math.min(3,leagues.length());i++){
                JSONObject item=leagues.getJSONObject(i),lg=item.optJSONObject("league");if(lg==null)continue;int lid=lg.optInt("id");int season=currentSeason(item.optJSONArray("seasons"));if(lid<=0||season<=0)continue;
                JSONArray ar=new JSONObject(get("fixtures?league="+lid+"&season="+season+"&from="+today()+"&to="+future(120)+"&timezone=America%2FSao_Paulo",key)).optJSONArray("response");
                if(ar!=null)for(int j=0;j<ar.length();j++){Game g=parseGame(ar.getJSONObject(j));if(seen.add(g.fixtureId))all.add(g);}
            }
        }catch(Exception ignored){}
        return all;
    }
    static int currentSeason(JSONArray a){int best=0;if(a==null)return 0;for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s==null)continue;int y=s.optInt("year");if(s.optBoolean("current",false))return y;if(y>best)best=y;}return best;}
    static void sortGames(ArrayList<Game> a){Collections.sort(a,(x,y)->{int t=safeStr(x.time).compareTo(safeStr(y.time));return t!=0?t:safeStr(x.league).compareToIgnoreCase(safeStr(y.league));});}
    static String safeStr(String s){return s==null?"":s;}

    static Game parseGame(JSONObject o)throws Exception{
        JSONObject f=o.getJSONObject("fixture"),teams=o.getJSONObject("teams"),lg=o.getJSONObject("league"),ho=teams.getJSONObject("home"),aw=teams.getJSONObject("away"),st=f.getJSONObject("status");
        String iso=f.optString("date","");String day=iso.length()>=10?iso.substring(0,10):"";String tm=iso.length()>=16?iso.substring(11,16):"--:--";String when=day.isEmpty()?tm:day+"|"+tm;
        Game g=new Game(f.optLong("id"),ho.optInt("id"),aw.optInt("id"),lg.optInt("id"),lg.optInt("season"),ho.optString("name"),aw.optString("name"),ho.optString("logo"),aw.optString("logo"),lg.optString("name"),when,st.optString("short"));
        JSONObject goals=o.optJSONObject("goals");if(goals!=null){g.homeGoals=goals.isNull("home")?-1:goals.optInt("home",-1);g.awayGoals=goals.isNull("away")?-1:goals.optInt("away",-1);}g.elapsed=st.optInt("elapsed",0);return g;
    }

    void enrich(String key,Game g,String date,Consumer<Game> ok){new Thread(()->{try{if(key==null||key.isEmpty()){ok.accept(g);return;}JSONObject ht=findTeam(key,g.home),at=findTeam(key,g.away);if(ht!=null){g.homeId=ht.optInt("id");g.homeLogo=ht.optString("logo",g.homeLogo);}if(at!=null){g.awayId=at.optInt("id");g.awayLogo=at.optString("logo",g.awayLogo);}if(g.homeId>0&&g.awayId>0){try{JSONArray ar=new JSONObject(get("fixtures?date="+date+"&timezone=America%2FSao_Paulo",key)).getJSONArray("response");for(int i=0;i<ar.length();i++){Game z=parseGame(ar.getJSONObject(i));if((z.homeId==g.homeId&&z.awayId==g.awayId)||(z.homeId==g.awayId&&z.awayId==g.homeId)){g.fixtureId=z.fixtureId;g.leagueId=z.leagueId;g.season=z.season;g.time=z.time;g.status=z.status;g.league=z.league;g.homeLogo=z.homeLogo;g.awayLogo=z.awayLogo;break;}}}catch(Exception ignored){}}ok.accept(g);}catch(Exception e){ok.accept(g);}}).start();}
    JSONObject findTeam(String key,String name)throws Exception{String ck="team_"+name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","_");String raw=cacheGet(ck,30L*24*60*60*1000);if(raw==null){raw=get("teams?search="+URLEncoder.encode(cleanTeam(name),"UTF-8"),key);cachePut(ck,raw);}JSONArray ar=new JSONObject(raw).getJSONArray("response");if(ar.length()==0)return null;String target=norm(name);JSONObject best=null;int score=-1;for(int i=0;i<ar.length();i++){JSONObject t=ar.getJSONObject(i).getJSONObject("team");String n=norm(t.optString("name"));int sc=n.equals(target)?100:(n.contains(target)||target.contains(n)?80:common(target,n));if(sc>score){score=sc;best=t;}}return best;}
    static String cleanTeam(String n){return n.replace("SC ","").replace("SE ","").replace("EC ","").replace(" CF","").replace(" FC","").trim();}
    static String norm(String n){return cleanTeam(n).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");}
    static int common(String a,String b){int n=Math.min(a.length(),b.length()),x=0;for(int i=0;i<n&&a.charAt(i)==b.charAt(i);i++)x++;return x;}

    void lineups(String key,long fixture,Consumer<ArrayList<Lineup>> ok,Consumer<String> err){new Thread(()->{try{JSONArray ar=new JSONObject(get("fixtures/lineups?fixture="+fixture,key)).getJSONArray("response");ArrayList<Lineup> out=new ArrayList<>();for(int i=0;i<ar.length();i++){JSONObject o=ar.getJSONObject(i);Lineup l=new Lineup();l.team=o.getJSONObject("team").optString("name");l.formation=o.optString("formation","—");l.coach=o.optJSONObject("coach")!=null?o.getJSONObject("coach").optString("name","—"):"—";parsePlayers(o.optJSONArray("startXI"),l.start);parsePlayers(o.optJSONArray("substitutes"),l.bench);out.add(l);}ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}
    static void parsePlayers(JSONArray a,ArrayList<Player> out)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject p=a.getJSONObject(i).getJSONObject("player");out.add(new Player(p.optInt("id"),p.optInt("number"),p.optString("name"),p.optString("grid")));}}

    void stats(String key,long fixture,Consumer<Stats> ok,Consumer<String> err){new Thread(()->{try{ok.accept(parseStats(getCachedFixtureStats(key,fixture)));}catch(Exception e){err.accept(e.getMessage());}}).start();}
    Stats parseStats(String raw)throws Exception{
        JSONArray ar=new JSONObject(raw).optJSONArray("response");Stats s=new Stats();if(ar==null||ar.length()<2)return s;JSONObject A=ar.getJSONObject(0),B=ar.getJSONObject(1);HashMap<String,String> x=mapStats(A.optJSONArray("statistics")),y=mapStats(B.optJSONArray("statistics"));
        String[][] defs={{"Ball Possession","Posse de bola"},{"Total Shots","Finalizações"},{"Shots on Goal","No alvo"},{"Shots off Goal","Fora do alvo"},{"Blocked Shots","Chutes bloqueados"},{"Corner Kicks","Escanteios"},{"Fouls","Faltas"},{"Throwins","Laterais"},{"Throw-ins","Laterais"},{"Goal Kicks","Tiros de meta"},{"Free Kicks","Tiros livres"},{"Offsides","Impedimentos"},{"Yellow Cards","Cartões amarelos"},{"Red Cards","Cartões vermelhos"},{"Goalkeeper Saves","Defesas"},{"Total passes","Passes"},{"Passes accurate","Passes certos"},{"Passes %","Precisão de passes"}};
        HashSet<String> added=new HashSet<>();for(String[] d:defs){if(added.contains(d[1]))continue;if(x.containsKey(d[0])||y.containsKey(d[0])){s.rows.put(d[1],new String[]{x.getOrDefault(d[0],"—"),y.getOrDefault(d[0],"—")});added.add(d[1]);}}
        return s;
    }
    String getCachedFixtureStats(String key,long fixture)throws Exception{String ck="fxstats_"+fixture;String raw=cacheGet(ck,14L*24*60*60*1000L);if(raw==null){raw=get("fixtures/statistics?fixture="+fixture,key);cachePut(ck,raw);}return raw;}

    void prediction(String key,long fixture,Consumer<Prediction> ok,Consumer<String> err){new Thread(()->{try{JSONArray ar=new JSONObject(get("predictions?fixture="+fixture,key)).getJSONArray("response");if(ar.length()==0)throw new IOException("Sem previsão disponível");JSONObject o=ar.getJSONObject(0).getJSONObject("predictions");Prediction p=new Prediction();JSONObject pc=o.optJSONObject("percent");p.home=pct(pc==null?"":pc.optString("home"));p.draw=pct(pc==null?"":pc.optString("draw"));p.away=pct(pc==null?"":pc.optString("away"));p.advice=o.optString("advice","");p.underOver=o.optString("under_over","");JSONObject w=o.optJSONObject("winner");p.winner=w==null?"":w.optString("name",""); JSONObject cmp=ar.getJSONObject(0).optJSONObject("comparison"); if(cmp!=null){String[] ks={"form","att","def","poisson","h2h","goals","total"};String[] pt={"Forma recente","Ataque","Defesa","Poisson","Confronto direto","Gols","Índice geral"};for(int i=0;i<ks.length;i++){JSONObject q=cmp.optJSONObject(ks[i]);if(q!=null){int hv=pct(q.optString("home")),av=pct(q.optString("away"));p.comparison.put(pt[i]+"|H",hv);p.comparison.put(pt[i]+"|A",av);}}} JSONObject teams=ar.getJSONObject(0).optJSONObject("teams"); if(teams!=null){JSONObject hh=teams.optJSONObject("home"),aa=teams.optJSONObject("away"); if(hh!=null)p.homeForm=hh.optString("last_5",""); if(aa!=null)p.awayForm=aa.optString("last_5","");} ok.accept(p);}catch(Exception e){err.accept(e.getMessage());}}).start();}
    void h2h(String key,int home,int away,Consumer<H2H> ok,Consumer<String> err){new Thread(()->{try{JSONArray ar=new JSONObject(get("fixtures/headtohead?h2h="+home+"-"+away+"&last=8",key)).getJSONArray("response");H2H h=new H2H();for(int i=0;i<ar.length();i++){JSONObject o=ar.getJSONObject(i),teams=o.getJSONObject("teams"),goals=o.getJSONObject("goals"),fx=o.getJSONObject("fixture");String hn=teams.getJSONObject("home").optString("name"),an=teams.getJSONObject("away").optString("name");int hg=goals.optInt("home",-1),ag=goals.optInt("away",-1);String d=fx.optString("date","");if(d.length()>=10)d=d.substring(0,10);h.rows.add(d+"  •  "+hn+"  "+(hg<0?"—":hg)+" × "+(ag<0?"—":ag)+"  "+an);int hid=teams.getJSONObject("home").optInt("id");if(hg==ag)h.draws++;else {int win=hg>ag?hid:teams.getJSONObject("away").optInt("id");if(win==home)h.homeWins++;else if(win==away)h.awayWins++;}}ok.accept(h);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    // Deep pre-match engine: recent finished matches + recent H2H + real per-fixture event statistics.
    // Results are cached so reopening the same match is fast and does not repeat API calls.
    void deepAnalysis(String key,Game g,Consumer<DeepAnalysis> ok,Consumer<String> err){new Thread(()->{
        try{
            if(key==null||key.trim().isEmpty()||g==null||g.homeId<=0||g.awayId<=0)throw new IOException("API e IDs das equipes são necessários");
            String dk="deep_"+g.homeId+"_"+g.awayId;
            String cached=cacheGet(dk,2L*60*60*1000L);
            if(cached!=null){DeepAnalysis ready=parseDeep(cached);if(ready!=null&&!ready.metrics.isEmpty()){ok.accept(ready);return;}}

            ArrayList<Game> h=recentGames(key,g.homeId,4), a=recentGames(key,g.awayId,4), hh=h2hGames(key,g.homeId,g.awayId,2);
            DeepAnalysis d=new DeepAnalysis();d.homeMatches=h.size();d.awayMatches=a.size();d.h2hMatches=hh.size();
            LinkedHashMap<String,Series> hs=new LinkedHashMap<>(),as=new LinkedHashMap<>();
            String[] metrics={"Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};
            for(String m:metrics){hs.put(m,new Series());as.put(m,new Series());}
            Series hg=new Series(),ag=new Series();
            accumulateGoals(h,g.homeId,hg);accumulateGoals(a,g.awayId,ag);
            fetchSeries(key,h,g.homeId,hs);fetchSeries(key,a,g.awayId,as);
            // H2H receives a lighter weight so it refines the projection without overpowering recent form.
            if(!hh.isEmpty()){
                LinkedHashMap<String,Series> hhs=new LinkedHashMap<>(),has=new LinkedHashMap<>();for(String m:metrics){hhs.put(m,new Series());has.put(m,new Series());}
                fetchSeries(key,hh,g.homeId,hhs);fetchSeries(key,hh,g.awayId,has);
                mergeSeries(hs,hhs,.45);mergeSeries(as,has,.45);
                Series hgh=new Series(),agh=new Series();accumulateGoals(hh,g.homeId,hgh);accumulateGoals(hh,g.awayId,agh);mergeOne(hg,hgh,.45);mergeOne(ag,agh,.45);
            }
            addProjection(d,"Gols",hg,ag,2.5,3.5);
            addProjection(d,"Escanteios",hs.get("Escanteios"),as.get("Escanteios"),8.5,10.5);
            addProjection(d,"Laterais",hs.get("Laterais"),as.get("Laterais"),dynamicLine(hs.get("Laterais"),as.get("Laterais"),2),-1);
            addProjection(d,"Tiros de meta",hs.get("Tiros de meta"),as.get("Tiros de meta"),dynamicLine(hs.get("Tiros de meta"),as.get("Tiros de meta"),2),-1);
            addProjection(d,"Faltas",hs.get("Faltas"),as.get("Faltas"),dynamicLine(hs.get("Faltas"),as.get("Faltas"),2),-1);
            addProjection(d,"Finalizações",hs.get("Finalizações"),as.get("Finalizações"),dynamicLine(hs.get("Finalizações"),as.get("Finalizações"),2),-1);
            addProjection(d,"Chutes no alvo",hs.get("Chutes no alvo"),as.get("Chutes no alvo"),7.5,9.5);
            addProjection(d,"Impedimentos",hs.get("Impedimentos"),as.get("Impedimentos"),3.5,5.5);
            addProjection(d,"Cartões amarelos",hs.get("Cartões amarelos"),as.get("Cartões amarelos"),3.5,5.5);
            addProjection(d,"Tiros livres",hs.get("Tiros livres"),as.get("Tiros livres"),dynamicLine(hs.get("Tiros livres"),as.get("Tiros livres"),2),-1);
            d.complete=!d.metrics.isEmpty();d.note="Base: até 4 jogos recentes por equipe + até 2 H2H; eventos reais da API quando a competição fornece a estatística";
            cachePut(dk,deepJson(d).toString());ok.accept(d);
        }catch(Exception e){err.accept(e.getMessage());}
    }).start();}

    ArrayList<Game> recentGames(String key,int teamId,int last)throws Exception{
        String ck="recent_"+teamId+"_"+last;String raw=cacheGet(ck,3*60*60*1000L);if(raw==null){raw=get("fixtures?team="+teamId+"&last="+last+"&timezone=America%2FSao_Paulo",key);cachePut(ck,raw);}ArrayList<Game> a=parseGamesRoot(raw);ArrayList<Game> out=new ArrayList<>();for(Game g:a)if(g.homeGoals>=0&&g.awayGoals>=0)out.add(g);Collections.sort(out,(x,y)->safeStr(y.time).compareTo(safeStr(x.time)));return out;
    }
    ArrayList<Game> h2hGames(String key,int home,int away,int last)throws Exception{
        String ck="h2hdeep_"+home+"_"+away+"_"+last;String raw=cacheGet(ck,6*60*60*1000L);if(raw==null){raw=get("fixtures/headtohead?h2h="+home+"-"+away+"&last="+last,key);cachePut(ck,raw);}ArrayList<Game> a=parseGamesRoot(raw);ArrayList<Game> out=new ArrayList<>();for(Game g:a)if(g.homeGoals>=0&&g.awayGoals>=0)out.add(g);return out;
    }
    void accumulateGoals(ArrayList<Game> games,int teamId,Series s){int i=0;for(Game g:games){if(g.homeGoals<0||g.awayGoals<0)continue;boolean home=g.homeId==teamId;double f=home?g.homeGoals:g.awayGoals,ag=home?g.awayGoals:g.homeGoals;s.add(f,ag,weight(i++));}}
    void fetchSeries(String key,ArrayList<Game> games,int teamId,LinkedHashMap<String,Series> dst)throws Exception{
        ExecutorService ex=Executors.newFixedThreadPool(Math.min(5,Math.max(1,games.size())));ArrayList<Future<StatSample>> fs=new ArrayList<>();ArrayList<Integer> idx=new ArrayList<>();int i=0;
        for(Game g:games){final Game fx=g;final int order=i++;fs.add(ex.submit(()->statSample(key,fx.fixtureId,teamId)));idx.add(order);}
        for(int j=0;j<fs.size();j++)try{StatSample sm=fs.get(j).get(7,TimeUnit.SECONDS);double w=weight(idx.get(j));for(String name:dst.keySet()){double f=metricValue(sm.team,name),a=metricValue(sm.opp,name);if(!Double.isNaN(f)&&!Double.isNaN(a))dst.get(name).add(f,a,w);}}catch(Exception ignored){}
        ex.shutdownNow();
    }
    StatSample statSample(String key,long fixture,int teamId)throws Exception{
        JSONArray ar=new JSONObject(getCachedFixtureStats(key,fixture)).optJSONArray("response");StatSample out=new StatSample();if(ar==null)return out;
        for(int i=0;i<ar.length();i++){JSONObject block=ar.optJSONObject(i);if(block==null)continue;JSONObject tm=block.optJSONObject("team");int id=tm==null?0:tm.optInt("id");HashMap<String,Double> target=id==teamId?out.team:out.opp;JSONArray st=block.optJSONArray("statistics");if(st==null)continue;for(int k=0;k<st.length();k++){JSONObject z=st.optJSONObject(k);if(z==null)continue;Object v=z.opt("value");if(v==null||v==JSONObject.NULL)continue;double n=parseNum(String.valueOf(v));if(!Double.isNaN(n))target.put(z.optString("type"),n);}}
        return out;
    }
    static double metricValue(HashMap<String,Double> m,String name){
        String[][] defs={{"Escanteios","Corner Kicks"},{"Laterais","Throwins","Throw-ins","Throw Ins"},{"Tiros de meta","Goal Kicks","Goal kicks"},{"Faltas","Fouls"},{"Finalizações","Total Shots"},{"Chutes no alvo","Shots on Goal"},{"Impedimentos","Offsides"},{"Cartões amarelos","Yellow Cards"},{"Tiros livres","Free Kicks"}};
        for(String[] d:defs)if(d[0].equals(name))for(int i=1;i<d.length;i++)if(m.containsKey(d[i]))return m.get(d[i]);return Double.NaN;
    }
    static void mergeSeries(LinkedHashMap<String,Series> base,LinkedHashMap<String,Series> extra,double factor){for(String k:base.keySet()){Series b=base.get(k),e=extra.get(k);mergeOne(b,e,factor);}}
    static void mergeOne(Series b,Series e,double factor){if(b==null||e==null||e.weight<=0)return;b.forSum+=e.forSum*factor;b.againstSum+=e.againstSum*factor;b.weight+=e.weight*factor;b.n+=e.n;}
    static double dynamicLine(Series home,Series away,int offset){if(home==null||away==null||home.n==0||away.n==0)return -1;double hp=combine(home.f(),away.a()),ap=combine(away.f(),home.a()),total=hp+ap;if(Double.isNaN(total)||total<1)return -1;return Math.max(.5,Math.floor(total)-offset+.5);}
    static void addProjection(DeepAnalysis d,String name,Series home,Series away,double line,double lineHigh){
        if(home==null||away==null||home.n==0||away.n==0)return;double hp=combine(home.f(),away.a()),ap=combine(away.f(),home.a());if(Double.isNaN(hp)||Double.isNaN(ap))return;MetricProjection m=new MetricProjection(name);m.home=hp;m.away=ap;m.total=hp+ap;m.sample=home.n+away.n;m.line=line;double spread=Math.max(1.0,Math.sqrt(Math.max(.1,m.total))*1.15);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(line>0)m.overProb=poissonOver(m.total,line);m.lineHigh=lineHigh>0?lineHigh:(line>0?line+2:-1);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);d.metrics.put(name,m);
    }
    static double combine(double a,double b){if(Double.isNaN(a))return b;if(Double.isNaN(b))return a;return (a+b)/2.0;}
    static double weight(int i){return i==0?1.0:(i==1?.88:(i==2?.76:.66));}
    static int poissonOver(double lambda,double line){int k=(int)Math.floor(line);double p=Math.exp(-lambda),sum=p;for(int i=1;i<=k;i++){p*=lambda/i;sum+=p;}return (int)Math.round(Math.max(0,Math.min(1,1-sum))*100);}
    static double parseNum(String s){try{return Double.parseDouble(s.replace("%","").trim());}catch(Exception e){return Double.NaN;}}
    JSONObject deepJson(DeepAnalysis d)throws Exception{JSONObject root=new JSONObject();root.put("hm",d.homeMatches);root.put("am",d.awayMatches);root.put("hh",d.h2hMatches);root.put("note",d.note);JSONArray ar=new JSONArray();for(MetricProjection m:d.metrics.values()){JSONObject o=new JSONObject();o.put("n",m.name);o.put("h",m.home);o.put("a",m.away);o.put("t",m.total);o.put("lo",m.low);o.put("hi",m.high);o.put("l",m.line);o.put("p",m.overProb);o.put("l2",m.lineHigh);o.put("p2",m.overProbHigh);o.put("s",m.sample);ar.put(o);}root.put("m",ar);return root;}
    DeepAnalysis parseDeep(String raw){try{JSONObject root=new JSONObject(raw);DeepAnalysis d=new DeepAnalysis();d.homeMatches=root.optInt("hm");d.awayMatches=root.optInt("am");d.h2hMatches=root.optInt("hh");d.note=root.optString("note","");JSONArray ar=root.optJSONArray("m");if(ar!=null)for(int i=0;i<ar.length();i++){JSONObject o=ar.optJSONObject(i);if(o==null)continue;MetricProjection m=new MetricProjection(o.optString("n"));m.home=o.optDouble("h");m.away=o.optDouble("a");m.total=o.optDouble("t");m.low=o.optDouble("lo");m.high=o.optDouble("hi");m.line=o.optDouble("l",-1);m.overProb=o.optInt("p",-1);m.lineHigh=o.optDouble("l2",-1);m.overProbHigh=o.optInt("p2",-1);m.sample=o.optInt("s");d.metrics.put(m.name,m);}d.complete=!d.metrics.isEmpty();return d;}catch(Exception e){return null;}}

    static String today(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(new java.util.Date());}
    static String future(int days){java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));c.add(java.util.Calendar.DAY_OF_MONTH,days);java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(c.getTime());}
    static int pct(String s){try{return Math.round(Float.parseFloat(s.replace("%","").trim()));}catch(Exception e){return 0;}}
    static HashMap<String,String> mapStats(JSONArray a)throws Exception{HashMap<String,String> m=new HashMap<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Object v=o.opt("value");if(v!=null&&v!=JSONObject.NULL)m.put(o.optString("type"),String.valueOf(v));}return m;}
}
