package com.jpastore.sportsai;
import android.content.*;import java.net.*;import java.io.*;import java.util.function.Consumer;
public class ApiClient{
 Context c; ApiClient(Context c){this.c=c;}
 void test(String key, Consumer<Boolean> cb){new Thread(()->{boolean ok=false;try{HttpURLConnection h=(HttpURLConnection)new URL("https://v3.football.api-sports.io/status").openConnection();h.setRequestProperty("x-apisports-key",key);h.setConnectTimeout(8000);h.setReadTimeout(8000);ok=h.getResponseCode()==200;}catch(Exception ignored){}cb.accept(ok);}).start();}
}
