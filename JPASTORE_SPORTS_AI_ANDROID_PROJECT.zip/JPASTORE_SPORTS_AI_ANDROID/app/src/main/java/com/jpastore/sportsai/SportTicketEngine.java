package com.jpastore.sportsai;

import java.util.*;

/**
 * Bilhete IA for non-football sports. It only uses structured recent results already
 * collected by MultiSportWebClient. It never invents bookmaker odds or missing stats.
 */
class SportTicketEngine {
    static final String CONSERVADOR="CONSERVADOR", EQUILIBRADO="EQUILIBRADO", AGRESSIVO="AGRESSIVO";

    static class Pick {
        String market="",pick="",detail="",risk="";
        int confidence=0,sample=0;
        Pick(String market,String pick,int confidence,int sample,String risk,String detail){
            this.market=market;this.pick=pick;this.confidence=confidence;this.sample=sample;this.risk=risk;this.detail=detail;
        }
    }
    static class Result {
        ArrayList<Pick> picks=new ArrayList<>();
        int sample=0,coverage=0;
        String quality="COBERTURA LIMITADA",note="";
        boolean ready(){return !picks.isEmpty();}
    }

    static Result build(String sport, MultiSportClient.Event e, MultiSportWebClient.Research r, String mode){
        Result out=new Result();
        if(e==null){out.note="Selecione um confronto.";return out;}
        if(r==null||!r.hasStructured()){
            out.note="Ainda não há histórico estruturado suficiente para gerar um bilhete automático. A J.Pastore IA não cria mercados sem base de dados.";
            return out;
        }
        int hs=r.homeWins+r.homeDraws+r.homeLosses, as=r.awayWins+r.awayDraws+r.awayLosses;
        out.sample=Math.min(hs,as);
        out.coverage=coverage(hs,as,r.homeSample,r.awaySample);
        out.quality=out.coverage>=80?"COBERTURA FORTE":(out.coverage>=55?"COBERTURA MODERADA":"COBERTURA LIMITADA");

        if(MultiSportClient.F1.equals(sport)){
            out.note="Fórmula 1 exige dados por piloto (treinos, classificação e grid). Este evento ainda não traz uma dupla de pilotos comparável; por isso o app não inventa vencedor/pódio.";
            return out;
        }

        int min=minSample(mode);
        if(hs>=min&&as>=min&&!safe(e.home).isEmpty()&&!safe(e.away).isEmpty()){
            double h=strength(r.homeWins,r.homeDraws,r.homeLosses,r.homeFor,r.homeAgainst,r.homeSample);
            double a=strength(r.awayWins,r.awayDraws,r.awayLosses,r.awayFor,r.awayAgainst,r.awaySample);
            double gap=Math.abs(h-a);
            String lead=h>=a?e.home:e.away;
            int conf=calibrateWinner(gap,out.sample,mode);
            if(conf>=winnerThreshold(mode)){
                String market=winnerMarket(sport);
                String detail="Forma recente + aproveitamento + saldo médio na amostra localizada";
                out.picks.add(new Pick(market,lead,conf,out.sample,risk(conf),detail));
            }
        }

        if((MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NFL.equals(sport)||MultiSportClient.BASEBALL.equals(sport)) && r.homeSample>=min && r.awaySample>=min){
            double ht=(r.homeFor+r.homeAgainst)/Math.max(1,r.homeSample);
            double at=(r.awayFor+r.awayAgainst)/Math.max(1,r.awaySample);
            double avg=(ht+at)/2.0;
            if(avg>0){
                double line=referenceLine(sport,avg,mode);
                int conf=totalConfidence(mode,Math.min(r.homeSample,r.awaySample));
                String unit=MultiSportClient.BASEBALL.equals(sport)?"corridas":"pontos";
                String detail="Linha de referência IA baseada na média recente (~"+fmt(avg)+" "+unit+"). Confirme se a linha existe na casa antes de usar.";
                out.picks.add(new Pick("Total da partida","Mais de "+fmtHalf(line)+" "+unit,conf,Math.min(r.homeSample,r.awaySample),risk(conf),detail));
            }
        }

        if(MultiSportClient.MMA.equals(sport)&&out.picks.size()>1){
            while(out.picks.size()>1)out.picks.remove(out.picks.size()-1);
        }

        int max=CONSERVADOR.equals(mode)?1:(EQUILIBRADO.equals(mode)?2:3);
        Collections.sort(out.picks,(x,y)->Integer.compare(y.confidence,x.confidence));
        while(out.picks.size()>max)out.picks.remove(out.picks.size()-1);

        if(out.picks.isEmpty())out.note="A amostra existe, mas ainda não atingiu o nível mínimo do modo "+mode+". Tente outro modo ou aguarde mais dados; nenhuma seleção foi forçada.";
        else out.note="Sugestões estatísticas para revisão. Não são garantia de resultado e não usam cotação real da casa.";
        return out;
    }


    /** Multi-confronto: tenta o modo solicitado e, sem forçar dados, usa um limiar adaptativo
     * quando há pelo menos 3 jogos válidos de cada lado. Isso evita terminar em bilhete vazio
     * apenas porque o modo conservador exigia 5 partidas. */
    static Result buildForMulti(String sport, MultiSportClient.Event e, MultiSportWebClient.Research r, String mode){
        Result out=build(sport,e,r,mode);
        if(out.ready()||e==null||r==null||MultiSportClient.F1.equals(sport))return out;
        int hs=r.homeWins+r.homeDraws+r.homeLosses,as=r.awayWins+r.awayDraws+r.awayLosses;
        int common=Math.min(hs,as),scoreSample=Math.min(r.homeSample,r.awaySample);
        if(common<3||scoreSample<3){
            out.note="Histórico localizado, mas faltam pelo menos 3 resultados válidos de cada participante para o bilhete múltiplo.";
            return out;
        }
        out.sample=common;out.coverage=coverage(hs,as,r.homeSample,r.awaySample);
        out.quality=out.coverage>=80?"COBERTURA FORTE":(out.coverage>=55?"COBERTURA MODERADA":"COBERTURA LIMITADA");
        double h=strength(r.homeWins,r.homeDraws,r.homeLosses,r.homeFor,r.homeAgainst,r.homeSample);
        double a=strength(r.awayWins,r.awayDraws,r.awayLosses,r.awayFor,r.awayAgainst,r.awaySample);
        double gap=Math.abs(h-a);
        if(gap>=0.06&&!safe(e.home).isEmpty()&&!safe(e.away).isEmpty()){
            String lead=h>=a?e.home:e.away;
            int conf=Math.max(57,Math.min(68,(int)Math.round(56+gap*38+Math.min(5,common-3))));
            out.picks.add(new Pick(winnerMarket(sport),lead,conf,common,risk(conf),"Seleção adaptativa do bilhete múltiplo • forma recente + saldo médio • revisar antes de usar"));
        }
        if(out.picks.isEmpty()&&(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NFL.equals(sport)||MultiSportClient.BASEBALL.equals(sport))){
            double ht=(r.homeFor+r.homeAgainst)/Math.max(1,r.homeSample);
            double at=(r.awayFor+r.awayAgainst)/Math.max(1,r.awaySample);
            double avg=(ht+at)/2.0;
            if(avg>0){
                double line=referenceLine(sport,avg,mode);
                int conf=Math.min(66,58+Math.min(6,scoreSample));
                String unit=MultiSportClient.BASEBALL.equals(sport)?"corridas":"pontos";
                out.picks.add(new Pick("Total da partida","Mais de "+fmtHalf(line)+" "+unit,conf,scoreSample,risk(conf),"Linha de referência IA com amostra reduzida (~"+fmt(avg)+" "+unit+"). Confirme a linha real na casa."));
            }
        }
        if(out.picks.isEmpty())out.note="A amostra existe, mas não mostrou vantagem suficiente para uma seleção responsável neste confronto.";
        else out.note="Seleção adaptativa para bilhete múltiplo; cobertura menor que o modo padrão. Revise antes de finalizar.";
        return out;
    }

    static double strength(int w,int d,int l,double pf,double pa,int sample){
        int n=Math.max(1,w+d+l);double win=w/(double)n,draw=d/(double)n;double margin=sample>0?(pf-pa)/sample:0;
        return win*.72+draw*.18+clamp(margin,-20,20)/100.0;
    }
    static int minSample(String mode){return CONSERVADOR.equals(mode)?5:(EQUILIBRADO.equals(mode)?4:3);}
    static int winnerThreshold(String mode){return CONSERVADOR.equals(mode)?66:(EQUILIBRADO.equals(mode)?61:57);}
    static int calibrateWinner(double gap,int sample,String mode){
        int base=(int)Math.round(54+Math.min(.42,gap)*48);int bonus=Math.min(8,Math.max(0,sample-3));int v=base+bonus;
        int cap=CONSERVADOR.equals(mode)?78:(EQUILIBRADO.equals(mode)?75:72);return Math.max(51,Math.min(cap,v));
    }
    static int totalConfidence(String mode,int sample){int b=CONSERVADOR.equals(mode)?65:(EQUILIBRADO.equals(mode)?61:58);return Math.min(72,b+Math.max(0,Math.min(5,sample-3)));}
    static double referenceLine(String sport,double avg,String mode){
        double offset;
        if(MultiSportClient.BASEBALL.equals(sport))offset=CONSERVADOR.equals(mode)?1.5:(EQUILIBRADO.equals(mode)?.5:-.5);
        else if(MultiSportClient.NFL.equals(sport))offset=CONSERVADOR.equals(mode)?7.5:(EQUILIBRADO.equals(mode)?3.5:-.5);
        else offset=CONSERVADOR.equals(mode)?12.5:(EQUILIBRADO.equals(mode)?6.5:-.5);
        return Math.max(.5,roundHalf(avg-offset));
    }
    static String winnerMarket(String sport){
        if(MultiSportClient.NFL.equals(sport))return "Moneyline";
        if(MultiSportClient.MMA.equals(sport))return "Vencedor da luta";
        return "Vencedor da partida";
    }
    static int coverage(int hs,int as,int hp,int ap){int n=Math.min(hs,as);int p=Math.min(hp,ap);if(n>=7&&p>=5)return 88;if(n>=5&&p>=4)return 72;if(n>=3)return 56;return 35;}
    static String risk(int c){return c>=70?"RISCO MENOR":(c>=62?"RISCO MODERADO":"RISCO ALTO");}
    static String fmt(double x){return String.format(new Locale("pt","BR"),"%.1f",x);}
    static String fmtHalf(double x){return String.format(new Locale("pt","BR"),"%.1f",roundHalf(x));}
    static double roundHalf(double x){return Math.round(x*2.0)/2.0;}
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    static String safe(String s){return s==null?"":s.trim();}
}
