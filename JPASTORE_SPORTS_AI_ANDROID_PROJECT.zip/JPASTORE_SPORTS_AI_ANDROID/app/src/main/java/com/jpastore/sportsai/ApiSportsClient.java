package com.jpastore.sportsai;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApiSportsClient {
    private static final long MIN_GAP_MS = 7000L;
    private static long lastRequestAt = 0L;
    private static final Map<Long, int[]> predictionCache = new HashMap<>();

    private final String key;
    private volatile int remaining = -1;
    private volatile int limit = -1;

    public ApiSportsClient(String key) { this.key = key == null ? "" : key.trim(); }
    public boolean configured() { return !key.isEmpty(); }
    public int getRemaining() { return remaining; }
    public int getLimit() { return limit; }

    /**
     * Carrega apenas os jogos da data atual. O parâmetro `date` funciona sozinho
     * no endpoint /fixtures e evita as restrições de `next` e de `from/to` do plano Free.
     */
    public List<Game> loadToday() throws Exception {
        String date = datePlus(0);
        return loadFixturesByDate(date, "HOJE");
    }

    /**
     * Carrega os próximos dias usando UMA chamada por data. Assim usamos apenas
     * `date=YYYY-MM-DD`, sem `next` e sem `from/to`.
     */
    public List<Game> loadUpcomingDays(int days) throws Exception {
        LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();
        String firstError = null;
        int successCalls = 0;

        for (int d = 1; d <= days; d++) {
            try {
                List<Game> dayGames = loadFixturesByDate(datePlus(d), "PRÓXIMO");
                successCalls++;
                for (Game g : dayGames) if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
            } catch (Exception e) {
                if (firstError == null) firstError = e.getMessage();
            }
        }

        if (successCalls == 0 && firstError != null) throw new IOException(firstError);
        return new ArrayList<>(merged.values());
    }

    public int[] loadPrediction(long fixtureId) throws Exception {
        synchronized (predictionCache) {
            int[] cached = predictionCache.get(fixtureId);
            if (cached != null) return new int[]{cached[0], cached[1], cached[2]};
        }

        JSONObject root = get("https://v3.football.api-sports.io/predictions?fixture=" + fixtureId, true);
        JSONArray arr = root.optJSONArray("response");
        if (arr == null || arr.length() == 0) {
            throw new IOException("A API não possui previsão estatística para esta partida.");
        }
        JSONObject predictions = arr.getJSONObject(0).optJSONObject("predictions");
        if (predictions == null || predictions.optJSONObject("percent") == null) {
            throw new IOException("Previsão indisponível para esta partida.");
        }
        JSONObject percent = predictions.getJSONObject("percent");
        int[] result = new int[]{
                pct(percent.optString("home", "0%")),
                pct(percent.optString("draw", "0%")),
                pct(percent.optString("away", "0%"))
        };
        synchronized (predictionCache) { predictionCache.put(fixtureId, result); }
        return result;
    }

    /**
     * Carrega TODOS os jogos de uma data no fuso de São Paulo.
     * Não existe limite artificial de 50/60 partidas: lemos toda a resposta e,
     * se a API informar mais páginas, buscamos as páginas seguintes.
     */
    private List<Game> loadFixturesByDate(String date, String bucket) throws Exception {
        LinkedHashMap<Long, Game> all = new LinkedHashMap<>();
        String baseUrl = "https://v3.football.api-sports.io/fixtures?date=" + date + "&timezone=America%2FSao_Paulo";

        JSONObject first = get(baseUrl, true);
        appendFixtures(first, bucket, all);

        JSONObject paging = first.optJSONObject("paging");
        int current = paging != null ? paging.optInt("current", 1) : 1;
        int total = paging != null ? paging.optInt("total", 1) : 1;
        for (int page = current + 1; page <= total; page++) {
            JSONObject extra = get(baseUrl + "&page=" + page, true);
            appendFixtures(extra, bucket, all);
        }

        return new ArrayList<>(all.values());
    }

    private void appendFixtures(JSONObject root, String bucket, LinkedHashMap<Long, Game> out) throws Exception {
        JSONArray response = root.optJSONArray("response");
        if (response == null) return;

        for (int i = 0; i < response.length(); i++) {
            JSONObject f = response.getJSONObject(i);
            JSONObject fixture = f.optJSONObject("fixture");
            JSONObject teams = f.optJSONObject("teams");
            JSONObject league = f.optJSONObject("league");
            JSONObject goals = f.optJSONObject("goals");
            if (fixture == null || teams == null) continue;

            long id = fixture.optLong("id", 0);
            if (id == 0 || out.containsKey(id)) continue;
            JSONObject statusObj = fixture.optJSONObject("status");
            String time = timeFromIso(fixture.optString("date", ""));
            int homeGoals = goals != null && !goals.isNull("home") ? goals.optInt("home", -1) : -1;
            int awayGoals = goals != null && !goals.isNull("away") ? goals.optInt("away", -1) : -1;
            String score = (homeGoals >= 0 && awayGoals >= 0) ? (homeGoals + " x " + awayGoals) : "-";

            String shortStatus = statusObj != null ? statusObj.optString("short", "NS") : "NS";
            String resolvedBucket = isLiveStatus(shortStatus) ? "AO VIVO" : bucket;

            JSONObject homeObj = teams.optJSONObject("home");
            JSONObject awayObj = teams.optJSONObject("away");
            Game game = new Game(
                    id,
                    league != null ? league.optInt("id", 0) : 0,
                    resolvedBucket,
                    league != null ? league.optString("name", "Liga") : "Liga",
                    league != null ? league.optString("country", "") : "",
                    homeObj != null ? homeObj.optString("name", "Mandante") : "Mandante",
                    awayObj != null ? awayObj.optString("name", "Visitante") : "Visitante",
                    time,
                    statusLong(statusObj),
                    score
            );
            out.put(id, game);
        }
    }

    private boolean isLiveStatus(String s) {
        return "1H".equals(s) || "2H".equals(s) || "HT".equals(s) || "ET".equals(s) ||
               "BT".equals(s) || "P".equals(s) || "LIVE".equals(s) || "INT".equals(s);
    }

    private String statusLong(JSONObject statusObj) {
        if (statusObj == null) return "AGENDADO";
        String shortCode = statusObj.optString("short", "NS");
        String elapsed = statusObj.has("elapsed") && !statusObj.isNull("elapsed") ? " • " + statusObj.optInt("elapsed", 0) + "'" : "";
        String map;
        switch (shortCode) {
            case "1H": map = "AO VIVO 1T"; break;
            case "2H": map = "AO VIVO 2T"; break;
            case "HT": map = "INTERVALO"; break;
            case "ET": map = "PRORROGAÇÃO"; break;
            case "BT": case "P": map = "PÊNALTIS"; break;
            case "FT": map = "ENCERRADO"; break;
            case "AET": map = "ENCERRADO APÓS PRORROGAÇÃO"; break;
            case "PEN": map = "ENCERRADO NOS PÊNALTIS"; break;
            case "NS": map = "AGENDADO"; break;
            case "PST": map = "ADIADO"; break;
            case "CANC": map = "CANCELADO"; break;
            case "SUSP": map = "SUSPENSO"; break;
            default: map = shortCode; break;
        }
        return map + elapsed;
    }

    private String timeFromIso(String iso) {
        return iso != null && iso.length() >= 16 ? iso.substring(11, 16) : "--:--";
    }

    private String datePlus(int days) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));
        cal.add(Calendar.DAY_OF_MONTH, days);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));
        return fmt.format(cal.getTime());
    }

    private int pct(String s) {
        try { return Integer.parseInt(s.replace("%", "").trim()); } catch(Exception e){ return 0; }
    }

    private JSONObject get(String urlString, boolean allowRetry) throws Exception {
        throttle();
        HttpURLConnection c = (HttpURLConnection)new URL(urlString).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestMethod("GET");
        c.setRequestProperty("x-apisports-key", key);
        c.setRequestProperty("Accept", "application/json");

        int code = c.getResponseCode();
        captureRateHeaders(c);
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(in);

        if (code == 429) {
            if (allowRetry) {
                Thread.sleep(retryAfterMs(c));
                return get(urlString, false);
            }
            throw new IOException("Limite por minuto atingido. Aguarde cerca de 1 minuto e tente novamente.");
        }
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + text);

        JSONObject root = new JSONObject(text);
        JSONObject errors = root.optJSONObject("errors");
        if (errors != null && errors.length() > 0) {
            Iterator<String> it = errors.keys();
            String k = it.hasNext() ? it.next() : "api";
            String msg = errors.optString(k, "Erro da API");
            if (("rateLimit".equalsIgnoreCase(k) || msg.toLowerCase(Locale.ROOT).contains("too many requests")) && allowRetry) {
                Thread.sleep(65000L);
                return get(urlString, false);
            }
            throw new IOException(msg);
        }
        return root;
    }

    private static synchronized void throttle() throws InterruptedException {
        long now = System.currentTimeMillis();
        long wait = MIN_GAP_MS - (now - lastRequestAt);
        if (wait > 0) Thread.sleep(wait);
        lastRequestAt = System.currentTimeMillis();
    }

    private void captureRateHeaders(HttpURLConnection c) {
        String rem = firstNonNull(c.getHeaderField("x-ratelimit-requests-remaining"), c.getHeaderField("X-RateLimit-Remaining"));
        String lim = firstNonNull(c.getHeaderField("x-ratelimit-requests-limit"), c.getHeaderField("X-RateLimit-Limit"));
        try { if (rem != null) remaining = Integer.parseInt(rem.trim()); } catch (Exception ignored) {}
        try { if (lim != null) limit = Integer.parseInt(lim.trim()); } catch (Exception ignored) {}
    }

    private String firstNonNull(String a, String b) { return a != null ? a : b; }

    private long retryAfterMs(HttpURLConnection c) {
        String v = c.getHeaderField("Retry-After");
        if (v == null) return 65000L;
        try { return Math.max(7000L, Math.min(65000L, Long.parseLong(v.trim()) * 1000L)); }
        catch(Exception e) { return 65000L; }
    }

    private String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
