package com.jpastore.sportsai;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApiSportsClient {
    private static final long MIN_GAP_MS = 7000L;
    private static long lastRequestAt = 0L;
    private static final Map<Long, int[]> predictionCache = new HashMap<>();
    private static final Map<Long, AdvancedAnalysis> advancedCache = new HashMap<>();

    private final String key;
    private volatile int remaining = -1;
    private volatile int limit = -1;

    public ApiSportsClient(String key) { this.key = key == null ? "" : key.trim(); }
    public boolean configured() { return !key.isEmpty(); }
    public int getRemaining() { return remaining; }
    public int getLimit() { return limit; }

    /**
     * Carrega apenas os jogos da data atual. O parâmetro `date` funciona sozinho
     * no endpoint /fixtures e evita as restrições de `next` e de `from/to` do plano Free.
     */
    public List<Game> loadToday() throws Exception {
        String date = datePlus(0);
        return loadFixturesByDate(date, "HOJE");
    }

    /**
     * Carrega os próximos dias usando UMA chamada por data. Assim usamos apenas
     * `date=YYYY-MM-DD`, sem `next` e sem `from/to`.
     */
    public List<Game> loadUpcomingDays(int days) throws Exception {
        LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();
        String firstError = null;
        int successCalls = 0;

        for (int d = 1; d <= days; d++) {
            try {
                List<Game> dayGames = loadFixturesByDate(datePlus(d), "PRÓXIMO");
                successCalls++;
                for (Game g : dayGames) if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
            } catch (Exception e) {
                if (firstError == null) firstError = e.getMessage();
            }
        }

        if (successCalls == 0 && firstError != null) throw new IOException(firstError);
        return new ArrayList<>(merged.values());
    }

    public int[] loadPrediction(long fixtureId) throws Exception {
        synchronized (predictionCache) {
            int[] cached = predictionCache.get(fixtureId);
            if (cached != null) return new int[]{cached[0], cached[1], cached[2]};
        }

        JSONObject root = get("https://v3.football.api-sports.io/predictions?fixture=" + fixtureId, true);
        JSONArray arr = root.optJSONArray("response");
        if (arr == null || arr.length() == 0) {
            throw new IOException("A API não possui previsão estatística para esta partida.");
        }
        JSONObject predictions = arr.getJSONObject(0).optJSONObject("predictions");
        if (predictions == null || predictions.optJSONObject("percent") == null) {
            throw new IOException("Previsão indisponível para esta partida.");
        }
        JSONObject percent = predictions.getJSONObject("percent");
        int[] result = new int[]{
                pct(percent.optString("home", "0%")),
                pct(percent.optString("draw", "0%")),
                pct(percent.optString("away", "0%"))
        };
        synchronized (predictionCache) { predictionCache.put(fixtureId, result); }
        return result;
    }

    /**
     * Análise V10: usa predictions como núcleo e tenta odds pré-jogo como
     * enriquecimento. Falha de odds não derruba a análise.
     */
    public AdvancedAnalysis loadAdvancedAnalysis(Game game) throws Exception {
        synchronized (advancedCache) {
            AdvancedAnalysis cached = advancedCache.get(game.fixtureId);
            if (cached != null) return cached;
        }

        JSONObject root = get("https://v3.football.api-sports.io/predictions?fixture=" + game.fixtureId, true);
        JSONArray arr = root.optJSONArray("response");
        if (arr == null || arr.length() == 0) throw new IOException("A API não possui previsão estatística para esta partida.");

        JSONObject item = arr.getJSONObject(0);
        JSONObject predictions = item.optJSONObject("predictions");
        if (predictions == null) throw new IOException("Previsão avançada indisponível para esta partida.");

        JSONObject percent = predictions.optJSONObject("percent");
        if (percent == null) throw new IOException("Probabilidades 1X2 indisponíveis para esta partida.");

        int hp = pct(percent.optString("home", "0%"));
        int dp = pct(percent.optString("draw", "0%"));
        int ap = pct(percent.optString("away", "0%"));

        JSONObject comparison = item.optJSONObject("comparison");
        int[] form = pairPct(comparison, "form");
        int[] att = pairPct(comparison, "att");
        int[] def = pairPct(comparison, "def");
        int[] poisson = pairPct(comparison, "poisson_distribution");
        int[] h2h = pairPct(comparison, "h2h");
        int[] goals = pairPct(comparison, "goals");

        JSONObject winnerObj = predictions.optJSONObject("winner");
        String winner = winnerObj != null ? winnerObj.optString("name", "") : "";
        String underOver = predictions.optString("under_over", "");
        String advice = predictions.optString("advice", "");

        double[] recentHome = recentGoalAverages(item, "home");
        double[] recentAway = recentGoalAverages(item, "away");

        List<AdvancedAnalysis.Market> oddsMarkets = new ArrayList<>();
        try {
            if (remaining < 0 || remaining > 15) {
                JSONObject odds = get("https://v3.football.api-sports.io/odds?fixture=" + game.fixtureId, true);
                oddsMarkets = parseOddsMarkets(odds);
            }
        } catch (Exception ignored) {
            // Odds são opcionais. Mantemos a análise estatística sem elas.
        }

        AdvancedAnalysis result = AdvancedAnalysisEngine.build(
                game, hp, dp, ap,
                form[0], form[1], att[0], att[1], def[0], def[1],
                poisson[0], poisson[1], h2h[0], h2h[1], goals[0], goals[1],
                recentHome[0], recentHome[1], recentAway[0], recentAway[1],
                winner, underOver, advice, oddsMarkets
        );

        synchronized (advancedCache) { advancedCache.put(game.fixtureId, result); }
        synchronized (predictionCache) { predictionCache.put(game.fixtureId, new int[]{hp, dp, ap}); }
        return result;
    }

    private int[] pairPct(JSONObject comparison, String key) {
        if (comparison == null) return new int[]{0,0};
        JSONObject o = comparison.optJSONObject(key);
        if (o == null) return new int[]{0,0};
        return new int[]{pct(o.optString("home", "0%")), pct(o.optString("away", "0%"))};
    }

    private double[] recentGoalAverages(JSONObject item, String side) {
        try {
            JSONObject teams = item.optJSONObject("teams");
            JSONObject team = teams != null ? teams.optJSONObject(side) : null;
            JSONObject last5 = team != null ? team.optJSONObject("last_5") : null;
            JSONObject goals = last5 != null ? last5.optJSONObject("goals") : null;
            JSONObject gf = goals != null ? goals.optJSONObject("for") : null;
            JSONObject ga = goals != null ? goals.optJSONObject("against") : null;
            double forAvg = gf != null ? toDouble(gf.opt("average")) : 0;
            double againstAvg = ga != null ? toDouble(ga.opt("average")) : 0;
            return new double[]{forAvg, againstAvg};
        } catch (Exception e) {
            return new double[]{0,0};
        }
    }

    private double toDouble(Object v) {
        if (v == null || v == JSONObject.NULL) return 0;
        try { return Double.parseDouble(String.valueOf(v).replace(",", ".").replace("%", "").trim()); }
        catch (Exception e) { return 0; }
    }

    private List<AdvancedAnalysis.Market> parseOddsMarkets(JSONObject root) {
        List<AdvancedAnalysis.Market> out = new ArrayList<>();
        JSONArray response = root.optJSONArray("response");
        if (response == null || response.length() == 0) return out;

        JSONObject first = response.optJSONObject(0);
        JSONArray bookmakers = first != null ? first.optJSONArray("bookmakers") : null;
        if (bookmakers == null) return out;

        Map<String, AdvancedAnalysis.Market> best = new LinkedHashMap<>();
        int bookmakerLimit = Math.min(3, bookmakers.length());
        for (int b = 0; b < bookmakerLimit; b++) {
            JSONObject bookmaker = bookmakers.optJSONObject(b);
            if (bookmaker == null) continue;
            String bookmakerName = bookmaker.optString("name", "mercado");
            JSONArray bets = bookmaker.optJSONArray("bets");
            if (bets == null) continue;

            for (int i = 0; i < bets.length(); i++) {
                JSONObject bet = bets.optJSONObject(i);
                if (bet == null) continue;
                String category = oddsCategory(bet.optString("name", ""));
                if (category == null) continue;
                JSONArray values = bet.optJSONArray("values");
                if (values == null) continue;

                for (OddsCandidate c : normalizedCandidates(values)) {
                    String selection = localizedSelection(c.selection);
                    String k = category + "|" + selection;
                    AdvancedAnalysis.Market m = new AdvancedAnalysis.Market(
                            category, selection, c.probability, 78,
                            "Odds API • " + bookmakerName,
                            "Probabilidade implícita normalizada a partir das cotações disponíveis."
                    );
                    if (!best.containsKey(k)) best.put(k, m);
                }
            }
        }
        out.addAll(best.values());
        return out;
    }

    private String oddsCategory(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.contains("corner")) return "Escanteios";
        if (n.contains("card") || n.contains("booking")) return "Cartões";
        if (n.contains("shot")) return n.contains("target") ? "Chutes no alvo" : "Chutes";
        if (n.contains("throw")) return "Laterais";
        if (n.contains("offside")) return "Impedimentos";
        if (n.contains("foul")) return "Faltas";
        if (n.contains("both teams") || n.contains("btts")) return "Ambas marcam";
        if (n.contains("goals over") || n.contains("over/under") || n.contains("total goals")) return "Gols";
        return null;
    }

    private List<OddsCandidate> normalizedCandidates(JSONArray values) {
        Map<String, Double> over = new LinkedHashMap<>();
        Map<String, Double> under = new LinkedHashMap<>();
        Map<String, Double> yesno = new LinkedHashMap<>();
        for (int i = 0; i < values.length(); i++) {
            JSONObject v = values.optJSONObject(i);
            if (v == null) continue;
            double odd = toDouble(v.opt("odd"));
            if (odd <= 1.01) continue;
            String value = String.valueOf(v.opt("value"));
            String handicap = v.has("handicap") && !v.isNull("handicap") ? String.valueOf(v.opt("handicap")) : "";
            String line = numberFrom(value);
            if (line.isEmpty()) line = numberFrom(handicap);
            String n = value.toLowerCase(Locale.ROOT);
            if (n.contains("over")) over.put(line, odd);
            else if (n.contains("under")) under.put(line, odd);
            else if (n.equals("yes") || n.equals("no")) yesno.put(n, odd);
        }

        List<OddsCandidate> out = new ArrayList<>();
        for (String line : over.keySet()) {
            if (line.isEmpty() || !under.containsKey(line)) continue;
            double io = 1.0 / over.get(line), iu = 1.0 / under.get(line);
            int po = (int)Math.round(100.0 * io / (io + iu));
            out.add(new OddsCandidate("Over " + line, po));
            out.add(new OddsCandidate("Under " + line, 100 - po));
        }
        if (yesno.containsKey("yes") && yesno.containsKey("no")) {
            double iy = 1.0 / yesno.get("yes"), in = 1.0 / yesno.get("no");
            int py = (int)Math.round(100.0 * iy / (iy + in));
            out.add(new OddsCandidate("Yes", py));
            out.add(new OddsCandidate("No", 100 - py));
        }
        return out;
    }

    private String localizedSelection(String s) {
        if (s == null) return "";
        if (s.startsWith("Over ")) return "Mais de " + s.substring(5);
        if (s.startsWith("Under ")) return "Menos de " + s.substring(6);
        if ("Yes".equalsIgnoreCase(s)) return "Sim";
        if ("No".equalsIgnoreCase(s)) return "Não";
        return s;
    }

    private String numberFrom(String s) {
        if (s == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+(?:[.,]\\d+)?)").matcher(s);
        return m.find() ? m.group(1).replace(',', '.') : "";
    }

    private static class OddsCandidate {
        final String selection;
        final int probability;
        OddsCandidate(String selection, int probability) { this.selection = selection; this.probability = probability; }
    }

    /**
     * Carrega TODOS os jogos de uma data no fuso de São Paulo.
     * Não existe limite artificial de 50/60 partidas: lemos toda a resposta e,
     * se a API informar mais páginas, buscamos as páginas seguintes.
     */
    private List<Game> loadFixturesByDate(String date, String bucket) throws Exception {
        LinkedHashMap<Long, Game> all = new LinkedHashMap<>();
        String baseUrl = "https://v3.football.api-sports.io/fixtures?date=" + date + "&timezone=America%2FSao_Paulo";

        JSONObject first = get(baseUrl, true);
        appendFixtures(first, bucket, all);

        JSONObject paging = first.optJSONObject("paging");
        int current = paging != null ? paging.optInt("current", 1) : 1;
        int total = paging != null ? paging.optInt("total", 1) : 1;
        for (int page = current + 1; page <= total; page++) {
            JSONObject extra = get(baseUrl + "&page=" + page, true);
            appendFixtures(extra, bucket, all);
        }

        return new ArrayList<>(all.values());
    }

    private void appendFixtures(JSONObject root, String bucket, LinkedHashMap<Long, Game> out) throws Exception {
        JSONArray response = root.optJSONArray("response");
        if (response == null) return;

        for (int i = 0; i < response.length(); i++) {
            JSONObject f = response.getJSONObject(i);
            JSONObject fixture = f.optJSONObject("fixture");
            JSONObject teams = f.optJSONObject("teams");
            JSONObject league = f.optJSONObject("league");
            JSONObject goals = f.optJSONObject("goals");
            if (fixture == null || teams == null) continue;

            long id = fixture.optLong("id", 0);
            if (id == 0 || out.containsKey(id)) continue;
            JSONObject statusObj = fixture.optJSONObject("status");
            String time = timeFromIso(fixture.optString("date", ""));
            int homeGoals = goals != null && !goals.isNull("home") ? goals.optInt("home", -1) : -1;
            int awayGoals = goals != null && !goals.isNull("away") ? goals.optInt("away", -1) : -1;
            String score = (homeGoals >= 0 && awayGoals >= 0) ? (homeGoals + " x " + awayGoals) : "-";

            String shortStatus = statusObj != null ? statusObj.optString("short", "NS") : "NS";
            String resolvedBucket = isLiveStatus(shortStatus) ? "AO VIVO" : bucket;

            JSONObject homeObj = teams.optJSONObject("home");
            JSONObject awayObj = teams.optJSONObject("away");
            Game game = new Game(
                    id,
                    league != null ? league.optInt("id", 0) : 0,
                    league != null ? league.optInt("season", 0) : 0,
                    homeObj != null ? homeObj.optInt("id", 0) : 0,
                    awayObj != null ? awayObj.optInt("id", 0) : 0,
                    resolvedBucket,
                    league != null ? league.optString("name", "Liga") : "Liga",
                    league != null ? league.optString("country", "") : "",
                    homeObj != null ? homeObj.optString("name", "Mandante") : "Mandante",
                    awayObj != null ? awayObj.optString("name", "Visitante") : "Visitante",
                    time,
                    statusLong(statusObj),
                    score
            );
            out.put(id, game);
        }
    }

    private boolean isLiveStatus(String s) {
        return "1H".equals(s) || "2H".equals(s) || "HT".equals(s) || "ET".equals(s) ||
               "BT".equals(s) || "P".equals(s) || "LIVE".equals(s) || "INT".equals(s);
    }

    private String statusLong(JSONObject statusObj) {
        if (statusObj == null) return "AGENDADO";
        String shortCode = statusObj.optString("short", "NS");
        String elapsed = statusObj.has("elapsed") && !statusObj.isNull("elapsed") ? " • " + statusObj.optInt("elapsed", 0) + "'" : "";
        String map;
        switch (shortCode) {
            case "1H": map = "AO VIVO 1T"; break;
            case "2H": map = "AO VIVO 2T"; break;
            case "HT": map = "INTERVALO"; break;
            case "ET": map = "PRORROGAÇÃO"; break;
            case "BT": case "P": map = "PÊNALTIS"; break;
            case "FT": map = "ENCERRADO"; break;
            case "AET": map = "ENCERRADO APÓS PRORROGAÇÃO"; break;
            case "PEN": map = "ENCERRADO NOS PÊNALTIS"; break;
            case "NS": map = "AGENDADO"; break;
            case "PST": map = "ADIADO"; break;
            case "CANC": map = "CANCELADO"; break;
            case "SUSP": map = "SUSPENSO"; break;
            default: map = shortCode; break;
        }
        return map + elapsed;
    }

    private String timeFromIso(String iso) {
        return iso != null && iso.length() >= 16 ? iso.substring(11, 16) : "--:--";
    }

    private String datePlus(int days) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));
        cal.add(Calendar.DAY_OF_MONTH, days);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));
        return fmt.format(cal.getTime());
    }

    private int pct(String s) {
        try { return Integer.parseInt(s.replace("%", "").trim()); } catch(Exception e){ return 0; }
    }

    private JSONObject get(String urlString, boolean allowRetry) throws Exception {
        throttle();
        HttpURLConnection c = (HttpURLConnection)new URL(urlString).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestMethod("GET");
        c.setRequestProperty("x-apisports-key", key);
        c.setRequestProperty("Accept", "application/json");

        int code = c.getResponseCode();
        captureRateHeaders(c);
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(in);

        if (code == 429) {
            if (allowRetry) {
                Thread.sleep(retryAfterMs(c));
                return get(urlString, false);
            }
            throw new IOException("Limite por minuto atingido. Aguarde cerca de 1 minuto e tente novamente.");
        }
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + text);

        JSONObject root = new JSONObject(text);
        JSONObject errors = root.optJSONObject("errors");
        if (errors != null && errors.length() > 0) {
            Iterator<String> it = errors.keys();
            String k = it.hasNext() ? it.next() : "api";
            String msg = errors.optString(k, "Erro da API");
            if (("rateLimit".equalsIgnoreCase(k) || msg.toLowerCase(Locale.ROOT).contains("too many requests")) && allowRetry) {
                Thread.sleep(65000L);
                return get(urlString, false);
            }
            throw new IOException(msg);
        }
        return root;
    }

    private static synchronized void throttle() throws InterruptedException {
        long now = System.currentTimeMillis();
        long wait = MIN_GAP_MS - (now - lastRequestAt);
        if (wait > 0) Thread.sleep(wait);
        lastRequestAt = System.currentTimeMillis();
    }

    private void captureRateHeaders(HttpURLConnection c) {
        String rem = firstNonNull(c.getHeaderField("x-ratelimit-requests-remaining"), c.getHeaderField("X-RateLimit-Remaining"));
        String lim = firstNonNull(c.getHeaderField("x-ratelimit-requests-limit"), c.getHeaderField("X-RateLimit-Limit"));
        try { if (rem != null) remaining = Integer.parseInt(rem.trim()); } catch (Exception ignored) {}
        try { if (lim != null) limit = Integer.parseInt(lim.trim()); } catch (Exception ignored) {}
    }

    private String firstNonNull(String a, String b) { return a != null ? a : b; }

    private long retryAfterMs(HttpURLConnection c) {
        String v = c.getHeaderField("Retry-After");
        if (v == null) return 65000L;
        try { return Math.max(7000L, Math.min(65000L, Long.parseLong(v.trim()) * 1000L)); }
        catch(Exception e) { return 65000L; }
    }

    private String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
