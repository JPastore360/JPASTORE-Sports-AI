package com.jpastore.sportsai;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApiSportsClient {
    private final String key;
    public ApiSportsClient(String key) { this.key = key == null ? "" : key.trim(); }

    public boolean configured() { return !key.isEmpty(); }

    public List<Game> loadDashboard() throws Exception {
        LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();

        addAll(merged, loadFixtures("https://v3.football.api-sports.io/fixtures?live=all&timezone=America%2FSao_Paulo", "AO VIVO", 8));

        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        addAll(merged, loadFixtures("https://v3.football.api-sports.io/fixtures?date=" + date + "&timezone=America%2FSao_Paulo", "HOJE", 14));

        addAll(merged, loadFixtures("https://v3.football.api-sports.io/fixtures?next=12&timezone=America%2FSao_Paulo", "PRÓXIMO", 12));

        return new ArrayList<>(merged.values());
    }

    private void addAll(LinkedHashMap<Long, Game> merged, List<Game> items) {
        for (Game g : items) {
            if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
        }
    }

    private List<Game> loadFixtures(String url, String bucket, int limit) throws Exception {
        JSONObject root = get(url);
        ensureNoErrors(root);
        JSONArray response = root.optJSONArray("response");
        List<Game> out = new ArrayList<>();
        if (response == null) return out;

        for (int i = 0; i < response.length() && out.size() < limit; i++) {
            JSONObject f = response.getJSONObject(i);
            JSONObject fixture = f.optJSONObject("fixture");
            JSONObject teams = f.optJSONObject("teams");
            JSONObject league = f.optJSONObject("league");
            JSONObject goals = f.optJSONObject("goals");
            if (fixture == null || teams == null) continue;

            long id = fixture.optLong("id", 0);
            JSONObject statusObj = fixture.optJSONObject("status");
            String status = statusObj != null ? statusObj.optString("short", "NS") : "NS";
            String time = timeFromIso(fixture.optString("date", ""));
            int homeGoals = goals != null ? goals.optInt("home", -1) : -1;
            int awayGoals = goals != null ? goals.optInt("away", -1) : -1;
            String score = (homeGoals >= 0 && awayGoals >= 0) ? (homeGoals + " x " + awayGoals) : "-";

            int[] p = prediction(id);
            AnalysisEngine.Result ar = AnalysisEngine.evaluate(p[0], p[1], p[2]);
            out.add(new Game(
                    id,
                    bucket,
                    league != null ? league.optString("name", "Liga") : "Liga",
                    teams.optJSONObject("home") != null ? teams.getJSONObject("home").optString("name", "Mandante") : "Mandante",
                    teams.optJSONObject("away") != null ? teams.getJSONObject("away").optString("name", "Visitante") : "Visitante",
                    time,
                    statusLong(statusObj),
                    score,
                    p[0], p[1], p[2],
                    ar.confidence,
                    ar.trend,
                    ar.reason,
                    ar.pick
            ));
        }
        return out;
    }

    private String statusLong(JSONObject statusObj) {
        if (statusObj == null) return "AGENDADO";
        String shortCode = statusObj.optString("short", "NS");
        String elapsed = statusObj.has("elapsed") && !statusObj.isNull("elapsed") ? " • " + statusObj.optInt("elapsed", 0) + "'" : "";
        String map;
        switch (shortCode) {
            case "1H": map = "AO VIVO 1T"; break;
            case "2H": map = "AO VIVO 2T"; break;
            case "HT": map = "INTERVALO"; break;
            case "ET": map = "PRORROGAÇÃO"; break;
            case "BT": map = "PÊNALTIS"; break;
            case "FT": map = "ENCERRADO"; break;
            case "NS": map = "AGENDADO"; break;
            default: map = shortCode; break;
        }
        return map + elapsed;
    }

    private String timeFromIso(String iso) {
        return iso != null && iso.length() >= 16 ? iso.substring(11, 16) : "--:--";
    }

    private int[] prediction(long fixtureId) {
        try {
            JSONObject root = get("https://v3.football.api-sports.io/predictions?fixture=" + fixtureId);
            ensureNoErrors(root);
            JSONArray arr = root.optJSONArray("response");
            if (arr == null || arr.length() == 0) return new int[]{34, 33, 33};
            JSONObject percent = arr.getJSONObject(0).getJSONObject("predictions").getJSONObject("percent");
            return new int[]{
                    pct(percent.optString("home", "34%")),
                    pct(percent.optString("draw", "33%")),
                    pct(percent.optString("away", "33%"))
            };
        } catch (Exception e) {
            return new int[]{34, 33, 33};
        }
    }

    private int pct(String s) {
        try { return Integer.parseInt(s.replace("%", "").trim()); } catch(Exception e){ return 0; }
    }

    private void ensureNoErrors(JSONObject root) throws IOException {
        JSONObject errors = root.optJSONObject("errors");
        if (errors != null && errors.length() > 0) {
            Iterator<String> it = errors.keys();
            if (it.hasNext()) {
                String k = it.next();
                throw new IOException(errors.optString(k, "Erro da API"));
            }
            throw new IOException("Erro retornado pela API");
        }
    }

    private JSONObject get(String urlString) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(urlString).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestMethod("GET");
        c.setRequestProperty("x-apisports-key", key);
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(in);
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + text);
        return new JSONObject(text);
    }

    private String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
