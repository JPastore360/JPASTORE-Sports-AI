package com.jpastore.sportsai;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApiSportsClient {
    private static final long MIN_GAP_MS = 7000L;
    private static long lastRequestAt = 0L;
    private static final Map<Long, DeepAnalysis> analysisCache = new HashMap<>();
    private static final Map<String, DeepAnalysis.TeamProfile> teamStatsCache = new HashMap<>();

    private final String key;
    private volatile int remaining = -1;
    private volatile int limit = -1;

    public ApiSportsClient(String key) { this.key = key == null ? "" : key.trim(); }
    public boolean configured() { return !key.isEmpty(); }
    public int getRemaining() { return remaining; }
    public int getLimit() { return limit; }

    public List<Game> loadToday() throws Exception {
        return loadFixturesByDate(datePlus(0), "HOJE", 120);
    }

    public List<Game> loadUpcomingDays(int days) throws Exception {
        LinkedHashMap<Long, Game> merged = new LinkedHashMap<>();
        String firstError = null;
        int successCalls = 0;
        for (int d = 1; d <= days; d++) {
            try {
                List<Game> dayGames = loadFixturesByDate(datePlus(d), "PRÓXIMO", 100);
                successCalls++;
                for (Game g : dayGames) if (!merged.containsKey(g.fixtureId)) merged.put(g.fixtureId, g);
            } catch (Exception e) {
                if (firstError == null) firstError = e.getMessage();
            }
        }
        if (successCalls == 0 && firstError != null) throw new IOException(firstError);
        return new ArrayList<>(merged.values());
    }

    public DeepAnalysis loadDeepAnalysis(Game game) throws Exception {
        synchronized (analysisCache) {
            DeepAnalysis cached = analysisCache.get(game.fixtureId);
            if (cached != null) return cached;
        }

        DeepAnalysis d = loadPredictionBlock(game.fixtureId);

        if (game.leagueId > 0 && game.season > 0) {
            d.homeProfile = loadTeamProfileSafe(game.leagueId, game.season, game.homeTeamId);
            d.awayProfile = loadTeamProfileSafe(game.leagueId, game.season, game.awayTeamId);
        }

        AnalysisEngine.finalizeDeepAnalysis(d);
        synchronized (analysisCache) { analysisCache.put(game.fixtureId, d); }
        return d;
    }

    private DeepAnalysis loadPredictionBlock(long fixtureId) throws Exception {
        JSONObject root = get("https://v3.football.api-sports.io/predictions?fixture=" + fixtureId, true);
        JSONArray arr = root.optJSONArray("response");
        if (arr == null || arr.length() == 0) throw new IOException("A API não possui previsão estatística para esta partida.");

        JSONObject item = arr.getJSONObject(0);
        JSONObject predictions = item.optJSONObject("predictions");
        if (predictions == null) throw new IOException("Previsão indisponível para esta partida.");

        DeepAnalysis d = new DeepAnalysis();
        JSONObject percent = predictions.optJSONObject("percent");
        if (percent != null) {
            d.homePct = pct(percent.optString("home", "0%"));
            d.drawPct = pct(percent.optString("draw", "0%"));
            d.awayPct = pct(percent.optString("away", "0%"));
        }

        d.apiAdvice = predictions.optString("advice", "");
        d.apiUnderOver = predictions.optString("under_over", "");
        JSONObject goals = predictions.optJSONObject("goals");
        if (goals != null) {
            d.predictedHomeGoals = goals.optString("home", "");
            d.predictedAwayGoals = goals.optString("away", "");
        }
        JSONObject winner = predictions.optJSONObject("winner");
        if (winner != null) d.winnerComment = winner.optString("comment", "");

        JSONObject cmp = item.optJSONObject("comparison");
        if (cmp != null) {
            int[] v;
            v = pair(cmp.optJSONObject("form")); d.formHome = v[0]; d.formAway = v[1];
            v = pair(cmp.optJSONObject("att")); d.attackHome = v[0]; d.attackAway = v[1];
            v = pair(cmp.optJSONObject("def")); d.defenseHome = v[0]; d.defenseAway = v[1];
            v = pair(cmp.optJSONObject("poisson_distribution")); d.poissonHome = v[0]; d.poissonAway = v[1];
            v = pair(cmp.optJSONObject("h2h")); d.h2hHome = v[0]; d.h2hAway = v[1];
            v = pair(cmp.optJSONObject("total")); d.comparisonTotalHome = v[0]; d.comparisonTotalAway = v[1];
        }

        if (d.homePct + d.drawPct + d.awayPct <= 0) {
            d.homePct = 34; d.drawPct = 33; d.awayPct = 33;
        }
        return d;
    }

    private DeepAnalysis.TeamProfile loadTeamProfileSafe(int leagueId, int season, int teamId) {
        if (teamId <= 0) return new DeepAnalysis.TeamProfile();
        String cacheKey = leagueId + ":" + season + ":" + teamId;
        synchronized (teamStatsCache) {
            DeepAnalysis.TeamProfile p = teamStatsCache.get(cacheKey);
            if (p != null) return p;
        }
        try {
            JSONObject root = get("https://v3.football.api-sports.io/teams/statistics?league=" + leagueId + "&season=" + season + "&team=" + teamId, true);
            JSONObject r = root.optJSONObject("response");
            DeepAnalysis.TeamProfile p = parseTeamProfile(r);
            synchronized (teamStatsCache) { teamStatsCache.put(cacheKey, p); }
            return p;
        } catch (Exception e) {
            return new DeepAnalysis.TeamProfile();
        }
    }

    private DeepAnalysis.TeamProfile parseTeamProfile(JSONObject r) {
        DeepAnalysis.TeamProfile p = new DeepAnalysis.TeamProfile();
        if (r == null) return p;
        p.form = r.optString("form", "");
        JSONObject fixtures = r.optJSONObject("fixtures");
        if (fixtures != null) {
            p.played = nestedInt(fixtures, "played", "total");
            p.wins = nestedInt(fixtures, "wins", "total");
            p.draws = nestedInt(fixtures, "draws", "total");
            p.losses = nestedInt(fixtures, "loses", "total");
        }
        JSONObject goals = r.optJSONObject("goals");
        if (goals != null) {
            JSONObject gf = goals.optJSONObject("for");
            JSONObject ga = goals.optJSONObject("against");
            if (gf != null) p.goalsForAvg = nestedDouble(gf, "average", "total");
            if (ga != null) p.goalsAgainstAvg = nestedDouble(ga, "average", "total");
        }
        JSONObject clean = r.optJSONObject("clean_sheet");
        if (clean != null && p.played > 0) p.cleanSheetPct = 100.0 * clean.optInt("total", 0) / p.played;
        JSONObject fail = r.optJSONObject("failed_to_score");
        if (fail != null && p.played > 0) p.failedToScorePct = 100.0 * fail.optInt("total", 0) / p.played;
        JSONObject cards = r.optJSONObject("cards");
        if (cards != null && p.played > 0) {
            int yellow = sumCardBuckets(cards.optJSONObject("yellow"));
            int red = sumCardBuckets(cards.optJSONObject("red"));
            p.yellowCardsAvg = (double)yellow / p.played;
            p.redCardsAvg = (double)red / p.played;
        }
        return p;
    }

    private int sumCardBuckets(JSONObject obj) {
        if (obj == null) return 0;
        int total = 0;
        Iterator<String> it = obj.keys();
        while (it.hasNext()) {
            JSONObject bucket = obj.optJSONObject(it.next());
            if (bucket != null && !bucket.isNull("total")) total += bucket.optInt("total", 0);
        }
        return total;
    }

    private int nestedInt(JSONObject obj, String a, String b) {
        JSONObject x = obj.optJSONObject(a);
        return x == null ? 0 : x.optInt(b, 0);
    }

    private double nestedDouble(JSONObject obj, String a, String b) {
        JSONObject x = obj.optJSONObject(a);
        if (x == null) return -1;
        Object v = x.opt(b);
        if (v == null || JSONObject.NULL.equals(v)) return -1;
        try { return Double.parseDouble(String.valueOf(v).replace(',', '.')); }
        catch(Exception e) { return -1; }
    }

    private int[] pair(JSONObject obj) {
        if (obj == null) return new int[]{0, 0};
        return new int[]{pct(obj.optString("home", "0%")), pct(obj.optString("away", "0%"))};
    }

    private List<Game> loadFixturesByDate(String date, String bucket, int maxItems) throws Exception {
        String url = "https://v3.football.api-sports.io/fixtures?date=" + date + "&timezone=America%2FSao_Paulo";
        JSONObject root = get(url, true);
        JSONArray response = root.optJSONArray("response");
        List<Game> out = new ArrayList<>();
        if (response == null) return out;

        for (int i = 0; i < response.length() && out.size() < maxItems; i++) {
            JSONObject f = response.getJSONObject(i);
            JSONObject fixture = f.optJSONObject("fixture");
            JSONObject teams = f.optJSONObject("teams");
            JSONObject league = f.optJSONObject("league");
            JSONObject goals = f.optJSONObject("goals");
            if (fixture == null || teams == null) continue;

            long id = fixture.optLong("id", 0);
            JSONObject statusObj = fixture.optJSONObject("status");
            String time = timeFromIso(fixture.optString("date", ""));
            int homeGoals = goals != null && !goals.isNull("home") ? goals.optInt("home", -1) : -1;
            int awayGoals = goals != null && !goals.isNull("away") ? goals.optInt("away", -1) : -1;
            String score = (homeGoals >= 0 && awayGoals >= 0) ? (homeGoals + " x " + awayGoals) : "-";
            String shortStatus = statusObj != null ? statusObj.optString("short", "NS") : "NS";
            String resolvedBucket = isLiveStatus(shortStatus) ? "AO VIVO" : bucket;

            JSONObject homeObj = teams.optJSONObject("home");
            JSONObject awayObj = teams.optJSONObject("away");
            out.add(new Game(
                    id,
                    league != null ? league.optInt("id", 0) : 0,
                    league != null ? league.optInt("season", 0) : 0,
                    homeObj != null ? homeObj.optInt("id", 0) : 0,
                    awayObj != null ? awayObj.optInt("id", 0) : 0,
                    resolvedBucket,
                    league != null ? league.optString("name", "Liga") : "Liga",
                    league != null ? league.optString("country", "") : "",
                    homeObj != null ? homeObj.optString("name", "Mandante") : "Mandante",
                    awayObj != null ? awayObj.optString("name", "Visitante") : "Visitante",
                    homeObj != null ? homeObj.optString("logo", "") : "",
                    awayObj != null ? awayObj.optString("logo", "") : "",
                    time,
                    statusLong(statusObj),
                    score
            ));
        }
        out.sort((a, b) -> {
            int c = Integer.compare(b.relevanceScore, a.relevanceScore);
            if (c != 0) return c;
            return a.time.compareTo(b.time);
        });
        return out;
    }

    private boolean isLiveStatus(String s) {
        return "1H".equals(s) || "2H".equals(s) || "HT".equals(s) || "ET".equals(s) ||
                "BT".equals(s) || "P".equals(s) || "LIVE".equals(s) || "INT".equals(s);
    }

    private String statusLong(JSONObject statusObj) {
        if (statusObj == null) return "AGENDADO";
        String shortCode = statusObj.optString("short", "NS");
        String elapsed = statusObj.has("elapsed") && !statusObj.isNull("elapsed") ? " • " + statusObj.optInt("elapsed", 0) + "'" : "";
        String map;
        switch (shortCode) {
            case "1H": map = "AO VIVO 1T"; break;
            case "2H": map = "AO VIVO 2T"; break;
            case "HT": map = "INTERVALO"; break;
            case "ET": map = "PRORROGAÇÃO"; break;
            case "BT": case "P": map = "PÊNALTIS"; break;
            case "FT": map = "ENCERRADO"; break;
            case "AET": map = "ENCERRADO APÓS PRORROGAÇÃO"; break;
            case "PEN": map = "ENCERRADO NOS PÊNALTIS"; break;
            case "NS": map = "AGENDADO"; break;
            case "PST": map = "ADIADO"; break;
            case "CANC": map = "CANCELADO"; break;
            case "SUSP": map = "SUSPENSO"; break;
            default: map = shortCode; break;
        }
        return map + elapsed;
    }

    private String timeFromIso(String iso) {
        return iso != null && iso.length() >= 16 ? iso.substring(11, 16) : "--:--";
    }

    private String datePlus(int days) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));
        cal.add(Calendar.DAY_OF_MONTH, days);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));
        return fmt.format(cal.getTime());
    }

    private int pct(String s) {
        try { return Integer.parseInt(s.replace("%", "").trim()); }
        catch(Exception e) { return 0; }
    }

    private JSONObject get(String urlString, boolean allowRetry) throws Exception {
        throttle();
        HttpURLConnection c = (HttpURLConnection)new URL(urlString).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestMethod("GET");
        c.setRequestProperty("x-apisports-key", key);
        c.setRequestProperty("Accept", "application/json");

        int code = c.getResponseCode();
        captureRateHeaders(c);
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(in);

        if (code == 429) {
            if (allowRetry) {
                Thread.sleep(retryAfterMs(c));
                return get(urlString, false);
            }
            throw new IOException("Limite por minuto atingido. Aguarde cerca de 1 minuto e tente novamente.");
        }
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + text);

        JSONObject root = new JSONObject(text);
        JSONObject errors = root.optJSONObject("errors");
        if (errors != null && errors.length() > 0) {
            Iterator<String> it = errors.keys();
            String k = it.hasNext() ? it.next() : "api";
            String msg = errors.optString(k, "Erro da API");
            if (("rateLimit".equalsIgnoreCase(k) || msg.toLowerCase(Locale.ROOT).contains("too many requests")) && allowRetry) {
                Thread.sleep(65000L);
                return get(urlString, false);
            }
            throw new IOException(msg);
        }
        return root;
    }

    private static synchronized void throttle() throws InterruptedException {
        long now = System.currentTimeMillis();
        long wait = MIN_GAP_MS - (now - lastRequestAt);
        if (wait > 0) Thread.sleep(wait);
        lastRequestAt = System.currentTimeMillis();
    }

    private void captureRateHeaders(HttpURLConnection c) {
        String rem = firstNonNull(c.getHeaderField("x-ratelimit-requests-remaining"), c.getHeaderField("X-RateLimit-Remaining"));
        String lim = firstNonNull(c.getHeaderField("x-ratelimit-requests-limit"), c.getHeaderField("X-RateLimit-Limit"));
        try { if (rem != null) remaining = Integer.parseInt(rem.trim()); } catch (Exception ignored) {}
        try { if (lim != null) limit = Integer.parseInt(lim.trim()); } catch (Exception ignored) {}
    }

    private String firstNonNull(String a, String b) { return a != null ? a : b; }

    private long retryAfterMs(HttpURLConnection c) {
        String v = c.getHeaderField("Retry-After");
        if (v == null) return 65000L;
        try { return Math.max(7000L, Math.min(65000L, Long.parseLong(v.trim()) * 1000L)); }
        catch(Exception e) { return 65000L; }
    }

    private String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
