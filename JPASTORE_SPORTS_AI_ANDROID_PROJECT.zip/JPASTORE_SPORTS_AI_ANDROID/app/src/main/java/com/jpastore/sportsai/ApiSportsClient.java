package com.jpastore.sportsai;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApiSportsClient {
    private final String key;
    public ApiSportsClient(String key) { this.key = key == null ? "" : key.trim(); }

    public boolean configured() { return !key.isEmpty(); }

    public List<Game> loadToday() throws Exception {
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        JSONObject root = get("https://v3.football.api-sports.io/fixtures?date=" + date + "&timezone=America%2FSao_Paulo");
        JSONArray response = root.optJSONArray("response");
        List<Game> out = new ArrayList<>();
        if (response == null) return out;
        int limit = Math.min(12, response.length());
        for (int i=0; i<limit; i++) {
            JSONObject f = response.getJSONObject(i);
            JSONObject fixture = f.getJSONObject("fixture");
            JSONObject teams = f.getJSONObject("teams");
            JSONObject league = f.getJSONObject("league");
            long id = fixture.getLong("id");
            String status = fixture.getJSONObject("status").optString("short", "NS");
            String iso = fixture.optString("date", "");
            String time = iso.length() >= 16 ? iso.substring(11,16) : "--:--";
            int[] p = prediction(id);
            AnalysisEngine.Result ar = AnalysisEngine.evaluate(p[0], p[1], p[2]);
            out.add(new Game(id, league.optString("name", "Liga"),
                    teams.getJSONObject("home").optString("name", "Mandante"),
                    teams.getJSONObject("away").optString("name", "Visitante"),
                    time, status, p[0], p[1], p[2], ar.confidence, ar.trend, ar.reason));
        }
        return out;
    }

    private int[] prediction(long fixtureId) {
        try {
            JSONObject root = get("https://v3.football.api-sports.io/predictions?fixture=" + fixtureId);
            JSONArray arr = root.optJSONArray("response");
            if (arr == null || arr.length()==0) return new int[]{34,33,33};
            JSONObject percent = arr.getJSONObject(0).getJSONObject("predictions").getJSONObject("percent");
            return new int[]{pct(percent.optString("home","34%")), pct(percent.optString("draw","33%")), pct(percent.optString("away","33%"))};
        } catch(Exception e) { return new int[]{34,33,33}; }
    }

    private int pct(String s) {
        try { return Integer.parseInt(s.replace("%","").trim()); } catch(Exception e){ return 0; }
    }

    private JSONObject get(String urlString) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(urlString).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(12000); c.setRequestMethod("GET");
        c.setRequestProperty("x-apisports-key", key);
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(in);
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + text);
        return new JSONObject(text);
    }
    private String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close(); return sb.toString();
    }
}
