package com.jpastore.sportsai;

public class Game {
    public final long fixtureId;
    public final int leagueId, season, homeTeamId, awayTeamId;
    public final String bucket, league, leagueCountry, home, away, time, status, score;
    public final String homeLogo, awayLogo;
    public final int relevanceScore;

    public DeepAnalysis analysis;
    public boolean analyzed;

    public Game(long fixtureId, int leagueId, int season,
                int homeTeamId, int awayTeamId,
                String bucket, String league, String leagueCountry,
                String home, String away, String homeLogo, String awayLogo,
                String time, String status, String score) {
        this.fixtureId = fixtureId;
        this.leagueId = leagueId;
        this.season = season;
        this.homeTeamId = homeTeamId;
        this.awayTeamId = awayTeamId;
        this.bucket = bucket;
        this.league = league;
        this.leagueCountry = leagueCountry == null ? "" : leagueCountry;
        this.home = home;
        this.away = away;
        this.homeLogo = homeLogo == null ? "" : homeLogo;
        this.awayLogo = awayLogo == null ? "" : awayLogo;
        this.time = time;
        this.status = status;
        this.score = score;
        this.relevanceScore = RelevanceEngine.score(home, away, league, leagueCountry);
        this.analyzed = false;
    }

    public void applyAnalysis(DeepAnalysis analysis) {
        this.analysis = analysis;
        this.analyzed = analysis != null;
    }
}
