package com.jpastore.sportsai;

public class Game {
    public final long fixtureId;
    public final int leagueId, season, homeTeamId, awayTeamId;
    public final String bucket, league, leagueCountry, home, away, time, status, score;
    public int homePct, drawPct, awayPct;
    public int confidence;
    public String trend, reason, pick;
    public boolean analyzed;
    public AdvancedAnalysis advanced;

    public Game(long fixtureId, int leagueId, int season, int homeTeamId, int awayTeamId,
                String bucket, String league, String leagueCountry,
                String home, String away, String time, String status, String score) {
        this.fixtureId = fixtureId;
        this.leagueId = leagueId;
        this.season = season;
        this.homeTeamId = homeTeamId;
        this.awayTeamId = awayTeamId;
        this.bucket = bucket;
        this.league = league;
        this.leagueCountry = leagueCountry == null ? "" : leagueCountry;
        this.home = home;
        this.away = away;
        this.time = time;
        this.status = status;
        this.score = score;
        this.homePct = 0;
        this.drawPct = 0;
        this.awayPct = 0;
        this.confidence = 0;
        this.trend = "Toque para gerar a análise";
        this.reason = "A análise avançada é carregada sob demanda para preservar a cota da API.";
        this.pick = "Aguardando análise";
        this.analyzed = false;
        this.advanced = null;
    }

    public boolean isLive() {
        String s = status == null ? "" : status.trim().toUpperCase();
        String b = bucket == null ? "" : bucket.trim().toUpperCase();
        return "AO VIVO".equals(b) || s.equals("1H") || s.equals("2H") || s.equals("HT") ||
               s.equals("ET") || s.equals("BT") || s.equals("P") || s.equals("LIVE") ||
               s.equals("INT") || s.equals("BREAK");
    }

    public void applyAnalysis(int homePct, int drawPct, int awayPct, AnalysisEngine.Result result) {
        this.homePct = homePct;
        this.drawPct = drawPct;
        this.awayPct = awayPct;
        this.confidence = result.confidence;
        this.trend = result.trend;
        this.reason = result.reason;
        this.pick = result.pick;
        this.analyzed = true;
    }

    public void applyAdvanced(AdvancedAnalysis a) {
        this.advanced = a;
        this.homePct = a.homePct;
        this.drawPct = a.drawPct;
        this.awayPct = a.awayPct;
        AnalysisEngine.Result r = AnalysisEngine.evaluate(a.homePct, a.drawPct, a.awayPct);
        this.pick = r.pick;
        this.trend = r.trend;
        this.reason = a.aiSummary;
        this.confidence = a.confidence;
        this.analyzed = true;
    }
}
