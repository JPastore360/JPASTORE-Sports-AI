package com.jpastore.sportsai;

public class Game {
    public final long fixtureId;
    public final String bucket, league, home, away, time, status, score;
    public int homePct, drawPct, awayPct;
    public int confidence;
    public String trend, reason, pick;
    public boolean analyzed;

    public Game(long fixtureId, String bucket, String league, String home, String away,
                String time, String status, String score) {
        this.fixtureId = fixtureId;
        this.bucket = bucket;
        this.league = league;
        this.home = home;
        this.away = away;
        this.time = time;
        this.status = status;
        this.score = score;
        this.homePct = 0;
        this.drawPct = 0;
        this.awayPct = 0;
        this.confidence = 0;
        this.trend = "Toque para gerar a análise";
        this.reason = "A análise estatística é carregada sob demanda para evitar bloqueios por excesso de requisições.";
        this.pick = "Aguardando análise";
        this.analyzed = false;
    }

    public void applyAnalysis(int homePct, int drawPct, int awayPct, AnalysisEngine.Result result) {
        this.homePct = homePct;
        this.drawPct = drawPct;
        this.awayPct = awayPct;
        this.confidence = result.confidence;
        this.trend = result.trend;
        this.reason = result.reason;
        this.pick = result.pick;
        this.analyzed = true;
    }
}
