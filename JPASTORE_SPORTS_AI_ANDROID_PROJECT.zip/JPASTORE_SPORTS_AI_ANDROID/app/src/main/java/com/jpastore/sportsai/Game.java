package com.jpastore.sportsai;

public class Game {
    public final long fixtureId;
    public final String bucket, league, home, away, time, status, score;
    public final int homePct, drawPct, awayPct;
    public final int confidence;
    public final String trend, reason, pick;

    public Game(long fixtureId, String bucket, String league, String home, String away,
                String time, String status, String score,
                int homePct, int drawPct, int awayPct,
                int confidence, String trend, String reason, String pick) {
        this.fixtureId = fixtureId;
        this.bucket = bucket;
        this.league = league;
        this.home = home;
        this.away = away;
        this.time = time;
        this.status = status;
        this.score = score;
        this.homePct = homePct;
        this.drawPct = drawPct;
        this.awayPct = awayPct;
        this.confidence = confidence;
        this.trend = trend;
        this.reason = reason;
        this.pick = pick;
    }
}
