package com.jpastore.sportsai;

public class Game {
    public final long fixtureId;
    public final String league, home, away, time, status;
    public final int homePct, drawPct, awayPct;
    public final int confidence;
    public final String trend, reason;

    public Game(long fixtureId, String league, String home, String away, String time, String status,
                int homePct, int drawPct, int awayPct, int confidence, String trend, String reason) {
        this.fixtureId = fixtureId; this.league = league; this.home = home; this.away = away;
        this.time = time; this.status = status; this.homePct = homePct; this.drawPct = drawPct;
        this.awayPct = awayPct; this.confidence = confidence; this.trend = trend; this.reason = reason;
    }
}
