package com.jpastore.sportsai;

import android.content.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

/**
 * Internet-first historical statistics adapter.
 *
 * Current no-key adapter uses ESPN's public web JSON responses as a best-effort source.
 * The parser is label-based rather than position-based, so small schema/HTML changes do not
 * automatically break every metric. OpenFootball remains the score-history fallback and
 * API-Football is used by ApiClient only when the web layer cannot provide enough coverage.
 */
class InternetStatsClient {
    private final Context c;
    private static final String UA="J.Pastore-Sports-AI/3.9 (Android; Internet-First)";
    private static final String[] METRICS={"Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};

    InternetStatsClient(Context c){this.c=c;}

    static class Event {
        String id,date,home,away; int hg=-1,ag=-1; boolean completed;
        Event(String i,String d,String h,String a,int x,int y,boolean done){id=i;date=d;home=h;away=a;hg=x;ag=y;completed=done;}
        boolean involves(String team){return teamMatch(team,home)||teamMatch(team,away);}
        boolean isHome(String team){return teamMatch(team,home);}
        String opponent(String team){return isHome(team)?away:home;}
    }
    static class PairStats {HashMap<String,Double> home=new HashMap<>(),away=new HashMap<>();}

    String fetch(String url)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();
        h.setConnectTimeout(3200);h.setReadTimeout(3800);h.setUseCaches(true);h.setInstanceFollowRedirects(true);
        h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept","application/json,text/html;q=0.9,*/*;q=0.8");
        int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);
        BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();
        for(String s;(s=r.readLine())!=null;)b.append(s);return b.toString();
    }
    String cached(String key,String url,long ttl)throws Exception{
        SharedPreferences p=c.getSharedPreferences("jp_internet_stats",0);long ts=p.getLong(key+"_ts",0);String old=p.getString(key,null);
        if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;
        try{String raw=fetch(url);p.edit().putString(key,raw).putLong(key+"_ts",System.currentTimeMillis()).apply();return raw;}
        catch(Exception e){if(old!=null)return old;throw e;}
    }

    ApiClient.DeepAnalysis analyze(ApiClient.Game g,int recentTarget,int venueTarget,int h2hTarget)throws Exception{
        String slug=leagueSlug(g);if(g==null||slug==null)return null;
        String from=daysAgo(300),to=ApiClient.today();
        String range=from.replace("-","")+"-"+to.replace("-","");
        String scoreUrl="https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/scoreboard?dates="+range+"&limit=1000";
        String raw=cached("espn_board_"+slug+"_"+range,scoreUrl,2L*60*60*1000L);
        ArrayList<Event> all=parseScoreboard(raw);if(all.isEmpty())return null;
        Collections.sort(all,(x,y)->y.date.compareTo(x.date));

        ArrayList<Event> hr=selectRecent(all,g.home,g.away,recentTarget,false,false);
        ArrayList<Event> ar=selectRecent(all,g.away,g.home,recentTarget,false,false);
        ArrayList<Event> hv=selectRecent(all,g.home,g.away,venueTarget,true,true);
        ArrayList<Event> av=selectRecent(all,g.away,g.home,venueTarget,true,false);
        ArrayList<Event> hh=selectH2H(all,g.home,g.away,h2hTarget);
        if(hr.size()<3&&ar.size()<3)return null;

        LinkedHashMap<String,ApiClient.Series> hs=seriesMap(),as=seriesMap(),hvs=seriesMap(),avs=seriesMap(),hhs=seriesMap(),has=seriesMap();
        ApiClient.Series hg=new ApiClient.Series(),ag=new ApiClient.Series(),hvg=new ApiClient.Series(),avg=new ApiClient.Series(),hgh=new ApiClient.Series(),agh=new ApiClient.Series();
        addGoalEvents(hr,g.home,hg);addGoalEvents(ar,g.away,ag);addGoalEvents(hv,g.home,hvg);addGoalEvents(av,g.away,avg);addGoalEvents(hh,g.home,hgh);addGoalEvents(hh,g.away,agh);

        LinkedHashSet<Event> union=new LinkedHashSet<>();union.addAll(hr);union.addAll(ar);union.addAll(hv);union.addAll(av);union.addAll(hh);
        ConcurrentHashMap<String,PairStats> summaries=new ConcurrentHashMap<>();
        ExecutorService ex=Executors.newFixedThreadPool(Math.min(8,Math.max(2,union.size())));ArrayList<Future<?>> fs=new ArrayList<>();
        for(Event e:union)fs.add(ex.submit(()->{try{PairStats ps=summary(slug,e);if(ps!=null)summaries.put(e.id,ps);}catch(Exception ignored){}}));
        long deadline=System.currentTimeMillis()+6500L;for(Future<?> f:fs){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{f.get(left,TimeUnit.MILLISECONDS);}catch(Exception ignored){}}ex.shutdownNow();

        addStatEvents(hr,g.home,hs,summaries);addStatEvents(ar,g.away,as,summaries);addStatEvents(hv,g.home,hvs,summaries);addStatEvents(av,g.away,avs,summaries);addStatEvents(hh,g.home,hhs,summaries);addStatEvents(hh,g.away,has,summaries);

        ApiClient.DeepAnalysis d=new ApiClient.DeepAnalysis();d.homeMatches=hr.size();d.awayMatches=ar.size();d.homeVenueMatches=hv.size();d.awayVenueMatches=av.size();d.h2hMatches=hh.size();d.sources="Internet (web estruturada)";
        addAdaptiveProjection(d,"Gols",hg,ag,hvg,avg,hgh,agh,2.5,3.5,"Internet");
        addAdaptiveProjection(d,"Escanteios",hs.get("Escanteios"),as.get("Escanteios"),hvs.get("Escanteios"),avs.get("Escanteios"),hhs.get("Escanteios"),has.get("Escanteios"),8.5,10.5,"Internet");
        addAdaptiveProjection(d,"Laterais",hs.get("Laterais"),as.get("Laterais"),hvs.get("Laterais"),avs.get("Laterais"),hhs.get("Laterais"),has.get("Laterais"),adaptiveLine(hs.get("Laterais"),as.get("Laterais"),2),-1,"Internet");
        addAdaptiveProjection(d,"Tiros de meta",hs.get("Tiros de meta"),as.get("Tiros de meta"),hvs.get("Tiros de meta"),avs.get("Tiros de meta"),hhs.get("Tiros de meta"),has.get("Tiros de meta"),adaptiveLine(hs.get("Tiros de meta"),as.get("Tiros de meta"),2),-1,"Internet");
        addAdaptiveProjection(d,"Faltas",hs.get("Faltas"),as.get("Faltas"),hvs.get("Faltas"),avs.get("Faltas"),hhs.get("Faltas"),has.get("Faltas"),adaptiveLine(hs.get("Faltas"),as.get("Faltas"),2),-1,"Internet");
        addAdaptiveProjection(d,"Finalizações",hs.get("Finalizações"),as.get("Finalizações"),hvs.get("Finalizações"),avs.get("Finalizações"),hhs.get("Finalizações"),has.get("Finalizações"),adaptiveLine(hs.get("Finalizações"),as.get("Finalizações"),2),-1,"Internet");
        addAdaptiveProjection(d,"Chutes no alvo",hs.get("Chutes no alvo"),as.get("Chutes no alvo"),hvs.get("Chutes no alvo"),avs.get("Chutes no alvo"),hhs.get("Chutes no alvo"),has.get("Chutes no alvo"),7.5,9.5,"Internet");
        addAdaptiveProjection(d,"Impedimentos",hs.get("Impedimentos"),as.get("Impedimentos"),hvs.get("Impedimentos"),avs.get("Impedimentos"),hhs.get("Impedimentos"),has.get("Impedimentos"),3.5,5.5,"Internet");
        addAdaptiveProjection(d,"Cartões amarelos",hs.get("Cartões amarelos"),as.get("Cartões amarelos"),hvs.get("Cartões amarelos"),avs.get("Cartões amarelos"),hhs.get("Cartões amarelos"),has.get("Cartões amarelos"),3.5,5.5,"Internet");
        addAdaptiveProjection(d,"Tiros livres",hs.get("Tiros livres"),as.get("Tiros livres"),hvs.get("Tiros livres"),avs.get("Tiros livres"),hhs.get("Tiros livres"),has.get("Tiros livres"),adaptiveLine(hs.get("Tiros livres"),as.get("Tiros livres"),2),-1,"Internet");
        d.complete=!d.metrics.isEmpty();return d;
    }

    PairStats summary(String slug,Event e)throws Exception{
        String k="espn_sum_"+slug+"_"+e.id;String u="https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/summary?event="+URLEncoder.encode(e.id,"UTF-8");
        String raw;
        try{raw=cached(k,u,24L*60*60*1000L);PairStats p=parseSummaryJson(raw,e);if(p!=null&&!p.home.isEmpty()&&!p.away.isEmpty())return p;}catch(Exception ignored){}
        // HTML fallback: if the structured endpoint changes, use the public match page and
        // a label-driven parser instead of relying on brittle CSS selectors.
        try{String html=cached(k+"_html","https://www.espn.com/soccer/match/_/gameId/"+e.id,24L*60*60*1000L);return parseLooseHtml(html);}catch(Exception ignored){return null;}
    }
    PairStats parseSummaryJson(String raw,Event e){try{
        JSONObject root=new JSONObject(raw);JSONObject box=root.optJSONObject("boxscore");JSONArray teams=box==null?null:box.optJSONArray("teams");if(teams==null)return null;PairStats p=new PairStats();
        for(int i=0;i<teams.length();i++){JSONObject b=teams.optJSONObject(i);if(b==null)continue;JSONObject tm=b.optJSONObject("team");String name=tm==null?"":tm.optString("displayName",tm.optString("name",""));HashMap<String,Double> dst=teamMatch(name,e.home)?p.home:(teamMatch(name,e.away)?p.away:null);if(dst==null)continue;JSONArray st=b.optJSONArray("statistics");if(st==null)continue;for(int j=0;j<st.length();j++){JSONObject z=st.optJSONObject(j);if(z==null)continue;String metric=metricName(z.optString("name")+" "+z.optString("displayName")+" "+z.optString("label"));if(metric==null)continue;double v=num(z.opt("value"));if(Double.isNaN(v))v=num(z.opt("displayValue"));if(!Double.isNaN(v))dst.put(metric,v);}}
        return p;
    }catch(Exception x){return null;}}
    PairStats parseLooseHtml(String html){if(html==null||html.isEmpty())return null;PairStats p=new PairStats();String plain=html.replaceAll("(?is)<script[^>]*>.*?</script>"," ").replaceAll("(?is)<style[^>]*>.*?</style>"," ").replaceAll("(?is)<[^>]+>"," ").replace("&nbsp;"," ");
        for(String m:METRICS){String[] labels=labels(m);for(String label:labels){Pattern q=Pattern.compile("(?i)"+Pattern.quote(label)+"\\s*[:\\-]?\\s*(\\d+(?:[.,]\\d+)?)\\s+.*?(\\d+(?:[.,]\\d+)?)");Matcher z=q.matcher(plain);if(z.find()){p.home.put(m,parseDouble(z.group(1)));p.away.put(m,parseDouble(z.group(2)));break;}}}return p.home.isEmpty()?null:p;}

    static ArrayList<Event> parseScoreboard(String raw){ArrayList<Event> out=new ArrayList<>();try{JSONArray ev=new JSONObject(raw).optJSONArray("events");if(ev==null)return out;for(int i=0;i<ev.length();i++){JSONObject o=ev.optJSONObject(i);if(o==null)continue;JSONArray comps=o.optJSONArray("competitions");JSONObject cp=comps==null||comps.length()==0?null:comps.optJSONObject(0);if(cp==null)continue;JSONArray c=cp.optJSONArray("competitors");if(c==null||c.length()<2)continue;String h="",a="";int hg=-1,ag=-1;for(int j=0;j<c.length();j++){JSONObject z=c.optJSONObject(j),tm=z==null?null:z.optJSONObject("team");if(z==null||tm==null)continue;String n=tm.optString("displayName",tm.optString("name",""));int sc=(int)Math.round(num(z.opt("score")));if("home".equalsIgnoreCase(z.optString("homeAway"))){h=n;hg=sc;}else{a=n;ag=sc;}}JSONObject st=o.optJSONObject("status"),type=st==null?null:st.optJSONObject("type");boolean done=type!=null&&type.optBoolean("completed",false);String date=o.optString("date","");if(date.length()>10)date=date.substring(0,10);if(!h.isEmpty()&&!a.isEmpty())out.add(new Event(o.optString("id"),date,h,a,hg,ag,done));}}catch(Exception ignored){}return out;}
    static ArrayList<Event> selectRecent(ArrayList<Event> all,String team,String exclude,int n,boolean venueOnly,boolean homeVenue){ArrayList<Event> out=new ArrayList<>();for(Event e:all){if(!e.completed||!e.involves(team))continue;if(exclude!=null&&teamMatch(e.opponent(team),exclude))continue;if(venueOnly&&e.isHome(team)!=homeVenue)continue;out.add(e);if(out.size()>=n)break;}return out;}
    static ArrayList<Event> selectH2H(ArrayList<Event> all,String a,String b,int n){ArrayList<Event> out=new ArrayList<>();for(Event e:all)if(e.completed&&e.involves(a)&&e.involves(b)){out.add(e);if(out.size()>=n)break;}return out;}
    static LinkedHashMap<String,ApiClient.Series> seriesMap(){LinkedHashMap<String,ApiClient.Series> m=new LinkedHashMap<>();for(String x:METRICS)m.put(x,new ApiClient.Series());return m;}
    static void addGoalEvents(ArrayList<Event> ev,String team,ApiClient.Series s){int i=0;for(Event e:ev){if(e.hg<0||e.ag<0)continue;boolean home=e.isHome(team);s.add(home?e.hg:e.ag,home?e.ag:e.hg,ApiClient.weight(i++));}}
    static void addStatEvents(ArrayList<Event> ev,String team,LinkedHashMap<String,ApiClient.Series> dst,Map<String,PairStats> summaries){int i=0;for(Event e:ev){PairStats p=summaries.get(e.id);if(p==null){i++;continue;}boolean home=e.isHome(team);HashMap<String,Double> own=home?p.home:p.away,opp=home?p.away:p.home;double w=ApiClient.weight(i++);for(String name:METRICS){Double f=own.get(name),a=opp.get(name);if(f!=null&&a!=null)dst.get(name).add(f,a,w);}}}

    static void addAdaptiveProjection(ApiClient.DeepAnalysis d,String name,ApiClient.Series home,ApiClient.Series away,ApiClient.Series homeVenue,ApiClient.Series awayVenue,ApiClient.Series h2hHome,ApiClient.Series h2hAway,double line,double lineHigh,String source){
        double hp=side(home,away,homeVenue,awayVenue,h2hHome),ap=side(away,home,awayVenue,homeVenue,h2hAway);if(Double.isNaN(hp)||Double.isNaN(ap))return;ApiClient.MetricProjection m=new ApiClient.MetricProjection(name);m.home=hp;m.away=ap;m.total=hp+ap;m.sample=(home==null?0:home.n)+(away==null?0:away.n)+Math.min(h2hHome==null?0:h2hHome.n,h2hAway==null?0:h2hAway.n);m.source=source;
        m.line=line;double spread=Math.max(1.0,Math.sqrt(Math.max(.1,m.total))*1.15);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(line>0)m.overProb=ApiClient.poissonOver(m.total,line);m.lineHigh=lineHigh>0?lineHigh:(line>0?line+2:-1);if(m.lineHigh>0)m.overProbHigh=ApiClient.poissonOver(m.total,m.lineHigh);d.metrics.put(name,m);
    }
    static double side(ApiClient.Series own,ApiClient.Series opp,ApiClient.Series ownVenue,ApiClient.Series oppVenue,ApiClient.Series h2h){double recent=ApiClient.combine(own==null?Double.NaN:own.f(),opp==null?Double.NaN:opp.a());double venue=ApiClient.combine(ownVenue==null?Double.NaN:ownVenue.f(),oppVenue==null?Double.NaN:oppVenue.a());double base=Double.isNaN(venue)?recent:(Double.isNaN(recent)?venue:recent*.72+venue*.28);double direct=h2h==null?Double.NaN:h2h.f();if(Double.isNaN(base))return direct;if(Double.isNaN(direct))return base;return base*.84+direct*.16;}
    static double adaptiveLine(ApiClient.Series h,ApiClient.Series a,int offset){if(h==null||a==null||h.n<2||a.n<2)return -1;double total=ApiClient.combine(h.f(),a.a())+ApiClient.combine(a.f(),h.a());if(Double.isNaN(total)||total<1)return -1;return Math.max(.5,Math.floor(total)-offset+.5);}

    static String metricName(String raw){String x=normLabel(raw);if(x.contains("shotsontarget")||x.contains("shotontarget"))return "Chutes no alvo";if(x.contains("totalshots")||x.equals("shots")||x.contains("shotstotal"))return "Finalizações";if(x.contains("corner"))return "Escanteios";if(x.contains("throwin"))return "Laterais";if(x.contains("goalkick"))return "Tiros de meta";if(x.contains("foul"))return "Faltas";if(x.contains("offside"))return "Impedimentos";if(x.contains("yellowcard"))return "Cartões amarelos";if(x.contains("freekick"))return "Tiros livres";return null;}
    static String normLabel(String s){if(s==null)return "";String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);return x.replaceAll("[^a-z0-9]","");}
    static String[] labels(String metric){if("Escanteios".equals(metric))return new String[]{"Corners","Corner Kicks","Escanteios"};if("Laterais".equals(metric))return new String[]{"Throw-ins","Throw Ins","Laterais"};if("Tiros de meta".equals(metric))return new String[]{"Goal Kicks","Goal Kick","Tiros de meta"};if("Faltas".equals(metric))return new String[]{"Fouls","Fouls Committed","Faltas"};if("Finalizações".equals(metric))return new String[]{"Total Shots","Shots","Finalizações"};if("Chutes no alvo".equals(metric))return new String[]{"Shots on Target","Chutes no alvo"};if("Impedimentos".equals(metric))return new String[]{"Offsides","Impedimentos"};if("Cartões amarelos".equals(metric))return new String[]{"Yellow Cards","Cartões amarelos"};return new String[]{"Free Kicks","Tiros livres"};}
    static double num(Object o){if(o==null||o==JSONObject.NULL)return Double.NaN;return parseDouble(String.valueOf(o));}
    static double parseDouble(String s){try{String x=s.replace("%","").replace(",",".").replaceAll("[^0-9.\\-]","");return x.isEmpty()?Double.NaN:Double.parseDouble(x);}catch(Exception e){return Double.NaN;}}
    static boolean teamMatch(String a,String b){if(a==null||b==null)return false;String x=ApiClient.norm(a),y=ApiClient.norm(b);if(x.equals(y)||x.contains(y)||y.contains(x))return true;HashSet<String> A=ApiClient.tokens(a),B=ApiClient.tokens(b);if(A.isEmpty()||B.isEmpty())return false;int n=0;for(String z:A)if(B.contains(z))n++;return n>=Math.min(2,Math.min(A.size(),B.size()));}
    static String daysAgo(int days){Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));cal.add(Calendar.DAY_OF_MONTH,-days);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(cal.getTime());}
    static String leagueSlug(ApiClient.Game g){if(g==null)return null;String l=ApiClient.norm(g.league);if(l.equals("seriea")&&isBrazilianClub(g.home+" "+g.away))return "bra.1";return leagueSlug(g.league);}
    static boolean isBrazilianClub(String teams){String x=ApiClient.norm(teams);String[] b={"flamengo","palmeiras","corinthians","saopaulo","santos","gremio","internacional","cruzeiro","atleticomineiro","botafogo","fluminense","vasco","bahia","bragantino","vitoria","athleticoparanaense","atleticoparanaense","fortaleza","ceara","sportrecife","juventude","mirassol"};for(String z:b)if(x.contains(z))return true;return false;}
    static String leagueSlug(String league){if(league==null)return null;String x=ApiClient.norm(league);if(x.contains("premierleague"))return "eng.1";if(x.equals("championship")||x.contains("eflchampionship"))return "eng.2";if(x.contains("laliga2")||x.contains("segunda"))return "esp.2";if(x.contains("laliga")||x.contains("primeradivision"))return "esp.1";if(x.contains("bundesliga")&&!x.contains("2bundesliga"))return "ger.1";if(x.contains("2bundesliga"))return "ger.2";if(x.equals("seriea")||x.contains("serieaitaliana"))return "ita.1";if(x.contains("ligue1"))return "fra.1";if(x.contains("primeiraliga"))return "por.1";if(x.contains("eredivisie"))return "ned.1";if(x.contains("brasileirao")||x.contains("serieabrasil"))return "bra.1";if(x.contains("libertadores"))return "conmebol.libertadores";if(x.contains("sulamericana")||x.contains("sudamericana"))return "conmebol.sudamericana";if(x.contains("championsleague"))return "uefa.champions";if(x.contains("europaleague"))return "uefa.europa";if(x.contains("conferenceleague"))return "uefa.europa.conf";if(x.equals("mls")||x.contains("majorsoccer"))return "usa.1";if(x.contains("ligamx"))return "mex.1";if(x.contains("ligaargentina"))return "arg.1";return null;}
}
