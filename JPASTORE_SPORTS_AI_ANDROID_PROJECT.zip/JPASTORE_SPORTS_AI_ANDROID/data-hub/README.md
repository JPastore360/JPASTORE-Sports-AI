# J.Pastore Data Hub
Backend opcional para o modo híbrido do app. Mantém a chave da API fora do APK, centraliza cache e permite acrescentar fontes licenciadas/públicas no servidor sem atualizar o aplicativo.

## Variáveis
- `API_FOOTBALL_KEY`: chave da API-Football no servidor.
- `PORT`: opcional (padrão 8080).

## Rotas
- `/health`
- `/v1/fixtures?date=YYYY-MM-DD&timezone=America/Sao_Paulo`
- `/v1/window?from=YYYY-MM-DD&to=YYYY-MM-DD`

O app usa: Data Hub → cache local → API-Football. Não faça scraping de sites sem autorização; novos provedores devem ser integrados conforme seus termos/licenças.
