const http=require('http'); const {URL}=require('url');
const PORT=process.env.PORT||8080, KEY=process.env.API_FOOTBALL_KEY||'';
const cache=new Map(); const TTL=6*60*60*1000;
async function api(path){if(!KEY) throw Error('API_FOOTBALL_KEY ausente'); const r=await fetch('https://v3.football.api-sports.io/'+path,{headers:{'x-apisports-key':KEY}}); if(!r.ok)throw Error('API '+r.status); return await r.json();}
async function cached(k,fn,ttl=TTL){const x=cache.get(k);if(x&&Date.now()-x.t<ttl)return x.v;const v=await fn();cache.set(k,{t:Date.now(),v});return v;}
function send(res,code,obj){res.writeHead(code,{'content-type':'application/json; charset=utf-8','access-control-allow-origin':'*','cache-control':'public, max-age=300'});res.end(JSON.stringify(obj));}
http.createServer(async(req,res)=>{try{const u=new URL(req.url,'http://x'); if(u.pathname==='/health')return send(res,200,{ok:true,service:'J.Pastore Data Hub'});
 if(u.pathname==='/v1/fixtures'){const date=u.searchParams.get('date'); if(!/^\\d{4}-\\d{2}-\\d{2}$/.test(date||''))return send(res,400,{error:'date obrigatório'});const tz=encodeURIComponent(u.searchParams.get('timezone')||'America/Sao_Paulo');const v=await cached('f:'+date,()=>api(`fixtures?date=${date}&timezone=${tz}`));return send(res,200,v);}
 if(u.pathname==='/v1/window'){const from=u.searchParams.get('from'),to=u.searchParams.get('to');const v=await cached('w:'+from+':'+to,()=>api(`fixtures?from=${from}&to=${to}&timezone=America%2FSao_Paulo`));return send(res,200,v);}
 return send(res,404,{error:'not found'});}catch(e){send(res,502,{error:e.message});}}).listen(PORT,()=>console.log('J.Pastore Data Hub :'+PORT));
