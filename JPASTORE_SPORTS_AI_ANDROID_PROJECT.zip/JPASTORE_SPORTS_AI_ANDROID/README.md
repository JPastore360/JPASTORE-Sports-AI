# J.Pastore Sports AI — V8

Versão V8 com ranking local de relevância, destaque para clubes populares, campeonatos organizados e análise aprofundada sob demanda.

A análise combina a previsão da API-Football, comparação de forma/ataque/defesa, estatísticas de temporada e um modelo local para gerar sinais de resultado, dupla chance, gols, ambas marcam, cartões, escanteios, laterais e finalizações.

Escanteios/laterais podem ser estimativas locais quando a fonte não oferece média pré-jogo direta. As análises são probabilísticas e não garantem resultados.
