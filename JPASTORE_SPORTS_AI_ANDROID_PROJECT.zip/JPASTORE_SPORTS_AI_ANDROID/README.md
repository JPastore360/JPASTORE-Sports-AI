# J.Pastore Sports AI — V6

Aplicativo Android criado e desenvolvido por J.Pastore.

## Novidades da V6
- filtro dinâmico por campeonatos usando os dados que já vêm em `/fixtures`;
- campeonatos identificados por ID da liga, nome e país;
- botão **Campeonatos** mostra somente competições com jogos carregados;
- estrela ☆/★ para favoritar campeonatos;
- botão **★ Favoritos** mostra somente jogos dos campeonatos favoritos;
- favoritos ficam salvos no aparelho;
- o filtro por campeonatos não faz chamadas extras à API;
- mantém Hoje, Próximos, Ao vivo, Favoráveis, análise sob demanda e proteção de rate limit da V5.

As análises são probabilísticas e informativas. Não há garantia de resultado e o app não executa apostas.
