# J.Pastore Sports AI V11 Premium

Criado e desenvolvido por J.Pastore.

## Destaques da V11
- Interface Premium em tema escuro com navegação por abas clicáveis.
- Busca por time ou campeonato.
- Tela de jogo com abas: Resumo, IA, Mercados, Estatísticas, Escalação, Tabela, H2H e Jogadores.
- Mercados clicáveis com várias linhas de gols, escanteios, cartões, chutes, chutes no alvo, faltas, laterais e impedimentos.
- Probabilidade IA, odd justa IA, odd de mercado quando disponível e indicador de possível valor.
- Estatísticas oficiais da partida sob demanda.
- Escalações, classificação do campeonato, confrontos diretos, perfis de times e desfalques sob demanda.
- Radar IA e Bilhetes IA por perfil conservador, moderado e agressivo.
- Cache e carregamento sob demanda para preservar a cota da API-Football.

As probabilidades são estimativas estatísticas e não garantem resultados. O app não executa apostas nem acessa contas de casas de apostas.
