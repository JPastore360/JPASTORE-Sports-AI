# J.Pastore Sports AI — V10

Aplicativo Android criado e desenvolvido por J.Pastore.

## V10 — Análise avançada
- campo de busca por time ou campeonato;
- análise sob demanda mais aprofundada, usando o endpoint oficial de Predictions como núcleo;
- leitura de forma, ataque, defesa, Poisson, H2H e comparação de gols;
- motor de IA estatística local para produzir uma síntese específica do confronto;
- probabilidades para resultado, dupla chance, gols, ambas marcam, escanteios, cartões, chutes, chutes no alvo, faltas, laterais e impedimentos;
- tentativa de usar odds pré-jogo para recalibrar mercados avançados quando a API fornecer linhas específicas;
- fallback transparente para estimativa estatística quando um mercado não tiver odds/dados suficientes;
- nova tela de análise em cards, com qualidade dos dados e origem de cada probabilidade;
- mantém Hoje completo (00:00–23:59 Brasília), campeonatos, próximos jogos, favoritos e proteção de rate limit.

## Observação
Probabilidades são estimativas informativas, não garantia de resultado. O aplicativo não executa apostas e não acessa contas de casas de apostas.
