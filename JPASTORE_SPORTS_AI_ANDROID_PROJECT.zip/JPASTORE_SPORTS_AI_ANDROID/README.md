# J.Pastore Sports AI — V12 Premium

Interface premium aprovada incorporada ao projeto.

## V12
- Identidade visual preto/navy + verde neon + detalhes premium.
- Início, Jogos, Radar IA, Bilhetes e Mais.
- Busca por time/campeonato.
- Análises clicáveis e mercados detalhados.
- Odds e probabilidades informativas.
- Escalação, tabela, H2H e jogadores sob demanda.
- Asset de referência visual: `res/drawable-nodpi/v12_interface_reference.png`.
- Integração direta com casas permanece desativada até autorização/credenciais oficiais.

Criado e desenvolvido por J.Pastore.
