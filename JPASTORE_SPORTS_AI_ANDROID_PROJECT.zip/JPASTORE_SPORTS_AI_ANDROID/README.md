# J.Pastore Sports AI — V7

Aplicativo Android criado e desenvolvido por J.Pastore.

## Novidades da V7
- campeonatos ficam visíveis diretamente na tela, sem depender de uma janela só com estrelas;
- cada competição vira uma aba/botão com nome e quantidade de jogos;
- partidas são agrupadas em blocos separados por campeonato;
- nomes principais são padronizados, como Brasileirão Série A, Brasileirão Série B, Copa do Brasil, Libertadores, Sul-Americana, Champions League, Premier League, La Liga, Serie A italiana, Bundesliga e Ligue 1;
- um jogo aparece no campeonato informado pela própria API (por exemplo, Corinthians aparece em Brasileirão quando a partida for do Brasileirão; se for Copa do Brasil ou Libertadores, aparece na competição correta);
- estrela continua disponível apenas como recurso opcional de favoritos;
- nenhum consumo extra de API é necessário para separar os campeonatos.

Mantém os recursos estáveis da V5/V6: Hoje, Próximos, Ao vivo, Favoráveis, análise sob demanda, cota e proteção de rate limit.
