# J.Pastore Sports AI — V5

Criado e desenvolvido por J.Pastore.

## Correções da V5

- Remove completamente `next`, `from` e `to` das consultas de partidas.
- A tela inicial usa somente `/fixtures?date=YYYY-MM-DD`, compatível com a consulta global por data.
- Os próximos jogos são carregados sob demanda, usando uma chamada `date=` para cada um dos próximos 3 dias.
- Mantém espaçamento entre chamadas para reduzir HTTP 429.
- Predictions continuam sob demanda, apenas quando o usuário toca em uma partida.
- Mantém cache de previsões durante a execução do app.
- Mantém identidade visual de futebol e crédito “Criado e desenvolvido por J.Pastore”.

As análises são probabilísticas e informativas; não garantem resultados e o app não executa apostas.
