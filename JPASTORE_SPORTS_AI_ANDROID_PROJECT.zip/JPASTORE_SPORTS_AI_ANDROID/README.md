# J.Pastore Sports AI — Android nativo

Aplicativo Android de análise esportiva com classificação visual de confiança.

## Recursos
- Verde: confiança alta (>=70)
- Amarelo: confiança moderada (55–69)
- Vermelho: cenário incerto (<55)
- Duas camadas: probabilidade-base + consistência matemática
- Ordenação automática por confiança
- Tela detalhada e cópia da análise
- Modo demonstração claramente identificado
- Modo online via API-Football / API-Sports
- Chave de API salva apenas no aparelho (SharedPreferences)
- Identidade: “Criado e desenvolvido por J.Pastore”

## Segurança / escopo
O aplicativo faz análise informativa. Não executa apostas, não faz login em casas de apostas e não promete ganhos.

## Compilação
Projeto Android Gradle. Abra no Android Studio ou execute `./gradlew assembleDebug` após instalar o Android SDK e Gradle wrapper.
