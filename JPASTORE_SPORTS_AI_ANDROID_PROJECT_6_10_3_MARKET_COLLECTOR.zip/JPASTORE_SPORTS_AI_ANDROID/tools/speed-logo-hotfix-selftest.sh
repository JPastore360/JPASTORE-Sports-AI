#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
SRC="$ROOT/app/src/main/java/com/jpastore/sportsai"
API="$SRC/ApiClient.java"
UI="$SRC/PremiumView.java"
FIVE="$SRC/FiveDollarFootballClient.java"
pass(){ echo "PASS: $1"; }
grep -Fq 'forceDeep?15000L:4200L' "$API" && pass 'análise automática limitada a ~4,2 s'
grep -Fq 'forceDeep?7000L:2200L' "$API" && pass 'fontes rápidas limitadas a ~2,2 s'
grep -Fq 'forceDeep?6200L:850L' "$API" && pass 'consenso web normal limitado a ~0,85 s'
grep -Fq 'forceDeep?5000L:550L' "$API" && pass 'API-Football fallback normal limitado a ~0,55 s'
grep -Fq 'forceDeep?2500L:450L' "$API" && pass 'fallback de gols respeita orçamento'
grep -Fq 'forceDeep?1100L:450L' "$API" && pass 'odds normais limitadas a ~0,45 s'
grep -Fq 'resolveSofaBadge' "$UI" && grep -Fq 'api.sofascore.com/api/v1/search/all/' "$UI" && pass 'SofaScore prioritário no resolvedor de logos'
grep -Fq 'setConnectTimeout(900)' "$UI" && grep -Fq 'setReadTimeout(1100)' "$UI" && pass 'busca de logo SofaScore tem timeout curto'
grep -Fq 'teamLogo(ho)' "$FIVE" && grep -Fq 'teamLogo(aw)' "$FIVE" && pass 'logos da 5Dollar são preservados quando fornecidos'
grep -Fq 'JP-SPEED-LOGO-HOTFIX-6.10.1' "$UI" && pass 'marcador interno 6.10.1 presente'
echo 'ALL SPEED + LOGO HOTFIX TESTS PASSED: 10'
