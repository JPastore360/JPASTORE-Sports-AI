# J.Pastore Sports AI 6.10.3 — Relatório do Market Collector

## Problema corrigido
A agenda pode vir de SofaScore, ESPN, TheSportsDB, Highlightly ou API-Sports. Antes, o `id` genérico do evento podia pertencer a uma fonte pública. O código corretamente evitava enviar esse ID para API-Sports, mas encerrava a coleta em vez de localizar o mesmo confronto na API de odds. O resultado era “MERCADO INDISPONÍVEL” mesmo quando havia mercado externo.

## Implementação
1. `MultiSportClient.Event` agora preserva `sofaId` e `apiSportsId` além do ID genérico e dos IDs Highlightly.
2. `MarketCollector` consulta fontes em paralelo dentro de um orçamento total de tempo.
3. Para API-Sports, quando `apiSportsId` não existe, o coletor busca a agenda do dia com timeout curto, compara mandante/visitante, data, horário e competição e rejeita correspondências ambíguas.
4. O resolvedor de nomes trata prefixos/sufixos comuns de basquete (`BC`, `BK`, `Basket`, `Basketball`) sem liberar mistura de feminino/masculino ou categorias de idade.
5. O caminho SofaScore usa o ID específico da fonte, nunca o ID genérico de outra origem.
6. `MarketOddsBook` registra o estado da coleta e não descarta silenciosamente mercados com apenas uma odd válida; esses casos passam a ser classificados como parciais.
7. O bilhete informa o motivo quando não há probabilidade de mercado para a seleção, em vez de chamar tudo de “indisponível”.

## O que não mudou
- Motor de probabilidade estatística.
- Limiares de seleção dos modos.
- Confidence Score.
- Regras de risco.
- Cálculo de calibração com mercado quando uma probabilidade no-vig válida existe.

## Testes
- Motor estatístico: 20/20.
- Production Tuning: 10/10.
- Market Collector: 9/9.
- Verificações estruturais: 6/6.

## Compilação
O projeto foi preparado como `versionCode 66` / `6.10.3-market-collector`. O ambiente local não possui Gradle/Android SDK; por isso a compilação APK final fica a cargo do workflow GitHub Actions incluído.
