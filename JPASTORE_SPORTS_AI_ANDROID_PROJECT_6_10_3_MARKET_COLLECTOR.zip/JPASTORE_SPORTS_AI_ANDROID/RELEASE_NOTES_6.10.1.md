# J.PASTORE Sports AI 6.10.1 Speed + Logo Hotfix

- Análise automática com orçamento total aproximado de 4,2 s.
- Fontes rápidas com janela normal aproximada de 2,2 s.
- Consenso web normal limitado a ~0,85 s quando necessário.
- API-Football complementar só entra no modo normal quando a base ainda não é utilizável, com teto ~0,55 s.
- Fallback OpenFootball também respeita o orçamento de tempo.
- Odds normais limitadas a ~0,45 s; Análise Profunda mantém orçamento maior.
- Logos: SofaScore por nome + esporte vira resolvedor prioritário antes de TheSportsDB/Wikipedia.
- Download de imagem também usa timeout menor para não ocupar o pool de logos por vários segundos.
- Logos fornecidos pela 5Dollar são preservados quando existirem.
- Cache, APIs configuráveis e funções existentes preservados.
