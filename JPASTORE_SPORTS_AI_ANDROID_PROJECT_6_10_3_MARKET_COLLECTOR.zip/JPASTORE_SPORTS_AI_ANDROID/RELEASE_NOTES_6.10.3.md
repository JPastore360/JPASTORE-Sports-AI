# J.Pastore Sports AI 6.10.3 — Market Collector

## Correção principal
- Corrige o caminho que tratava IDs de agenda pública como incompatíveis com API-Sports e encerrava a coleta antes de resolver o mesmo evento no provedor de odds.
- Adiciona IDs específicos por provedor (`sofaId` e `apiSportsId`) para impedir mistura de IDs entre fontes após deduplicação.
- Adiciona `MarketCollector` central com coleta concorrente e orçamento de tempo, preservando a rapidez da análise.
- Usa mercado público SofaScore quando disponível e mantém API-Sports/Highlightly como fontes complementares configuradas.

## Normalização e segurança
- Mantém remoção de margem (no-vig) por mercado/casa.
- Preserva sinais de handicap e linhas de total.
- Rejeita correspondência entre categorias incompatíveis (ex.: feminino/masculino, categorias de idade).
- Melhora aliases de basquete (`BC`, `BK`, `Basket`, `Basketball`) para confrontos como Neptūnas e Fyllingen.
- Cache de odds pré-jogo reduzido para 10 minutos; ao vivo permanece curto.

## Estados de mercado
O app deixa de transformar todos os problemas em “MERCADO INDISPONÍVEL”. Agora diferencia:
- disponível;
- parcial — odds incompletas para remover margem;
- não encontrado nas fontes consultadas;
- não confirmado — falha de coleta;
- não confirmado — evento não resolvido na fonte de odds.

## Motor estatístico
A lógica principal de IA/calibração não foi alterada. Odds continuam sendo evidência de calibração e não substituem o motor estatístico.

## Testes locais
- 20/20 testes do motor estatístico calibrado;
- 10/10 testes Production Tuning;
- 9/9 testes do Market Collector;
- 6/6 verificações estruturais do caminho de odds.

A compilação Android completa permanece destinada ao workflow GitHub Actions incluído, pois o ambiente local desta revisão não contém Gradle/Android SDK.
