package com.jpastore.sportsai;

import android.content.*;
import org.json.*;
import java.util.*;
import java.util.regex.*;
import java.io.*;
import java.net.*;

/** Optional bookmaker calibration source. Never gates the statistical engine. */
final class MarketOddsClient {
    private final Context c;
    MarketOddsClient(Context c){this.c=c;}

    MarketOddsBook football(String key,ApiClient.Game g){
        MarketOddsBook out=new MarketOddsBook();if(g==null||g.fixtureId<=0||key==null||key.trim().isEmpty())return out;out.markAttempt("API-Sports");
        try{
            String ck="odds_football_"+g.fixtureId,raw=cacheGet(ck,10L*60*1000L);
            if(raw==null){raw=new ApiClient(c).get("odds?fixture="+g.fixtureId,key.trim());cachePut(ck,raw);}
            out=parse(raw,g.home,g.away);if(out.isEmpty()){if(out.partialObserved())out.markPartial("API-Sports");else out.markNoMarket("API-Sports");}else out.markSuccess("API-Sports");return out;
        }catch(Exception ignored){out.markFailure("API-Sports");return out;}
    }

    MarketOddsBook footballLive(String key,ApiClient.Game g){
        MarketOddsBook out=new MarketOddsBook();if(g==null||g.fixtureId<=0||key==null||key.trim().isEmpty())return out;out.markAttempt("API-Sports");
        try{
            MultiSportClient guard=new MultiSportClient(c);if(guard.apiCircuitOpen(MultiSportClient.FOOTBALL)){out.markFailure("API-Sports/limite");return out;}
            String ck="odds_live_football_"+g.fixtureId,raw=cacheGet(ck,45L*1000L);
            if(raw==null){raw=new ApiClient(c).get("odds/live?fixture="+g.fixtureId,key.trim());cachePut(ck,raw);}
            out=parse(raw,g.home,g.away);if(out.isEmpty()){if(out.partialObserved())out.markPartial("API-Sports");else out.markNoMarket("API-Sports");}else out.markSuccess("API-Sports");return out;
        }catch(Exception ignored){out.markFailure("API-Sports");return out;}
    }

    MarketOddsBook sport(String source,String key,MultiSportClient.Event e){
        MarketOddsBook out=new MarketOddsBook();if(e==null||e.id<=0||key==null||key.trim().isEmpty()||source==null)return out;out.markAttempt("API-Sports");
        try{
            MultiSportClient cli=new MultiSportClient(c);if(cli.apiCircuitOpen(source)){out.markFailure("API-Sports/limite");return out;}
            long ttl=StatisticalCalibrationEngine.isPregameStatus(e.status)?10L*60*1000L:45L*1000L;String ck="odds_"+source+"_"+e.id,raw=cacheGet(ck,ttl);
            if(raw==null){raw=fastSportGet(source,"odds?game="+e.id,key.trim());cachePut(ck,raw);}
            out=parse(raw,e.home,e.away);if(out.isEmpty()){if(out.partialObserved())out.markPartial("API-Sports");else out.markNoMarket("API-Sports");}else out.markSuccess("API-Sports");return out;
        }catch(Exception ignored){out.markFailure("API-Sports");return out;}
    }

    MarketOddsBook parse(String raw,String home,String away)throws Exception{
        MarketOddsBook book=new MarketOddsBook();if(raw==null||raw.trim().isEmpty())return book;
        JSONObject root=new JSONObject(raw);Object response=root.opt("response");walk(response,home,away,book,0);return book;
    }

    void walk(Object node,String home,String away,MarketOddsBook book,int depth){
        if(node==null||depth>6)return;
        if(node instanceof JSONArray){JSONArray a=(JSONArray)node;for(int i=0;i<a.length();i++)walk(a.opt(i),home,away,book,depth+1);return;}
        if(!(node instanceof JSONObject))return;JSONObject o=(JSONObject)node;
        JSONArray bets=o.optJSONArray("bets");if(bets!=null){String bookmaker=first(o.optString("name",""),o.optString("bookmaker",""),"Bookmaker");for(int i=0;i<bets.length();i++){JSONObject bet=bets.optJSONObject(i);if(bet!=null)parseBet(bet,bookmaker,home,away,book);}return;}
        Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next();Object v=o.opt(k);if(v instanceof JSONObject||v instanceof JSONArray)walk(v,home,away,book,depth+1);}
    }

    void parseBet(JSONObject bet,String bookmaker,String home,String away,MarketOddsBook book){
        String name=first(bet.optString("name",""),bet.optString("label",""),bet.optString("type",""));String n=norm(name);JSONArray values=bet.optJSONArray("values");if(values==null||values.length()==0)return;
        LinkedHashMap<String,LinkedHashMap<String,Double>> groups=new LinkedHashMap<>();
        for(int i=0;i<values.length();i++){
            JSONObject v=values.optJSONObject(i);if(v==null)continue;double odd=decimal(v.opt("odd"));if(Double.isNaN(odd)||odd<=1.0001)continue;
            String label=first(v.optString("value",""),v.optString("name",""),v.optString("label",""));double handicap=number(first(v.optString("handicap",""),v.optString("line",""),label));
            if(has(n,"double chance")){
                String key=doubleChanceKey(label,home,away);if(key!=null)put(groups,"DC",key,odd);continue;
            }
            if(has(n,"draw no bet","dnb","empate anula")){
                Boolean hs=side(label,home,away);if(hs!=null)put(groups,"DNB",hs?MarketOddsBook.DNB_HOME:MarketOddsBook.DNB_AWAY,odd);continue;
            }
            if(has(n,"over/under","over under","total","goals over","points over","total points","total goals")){
                boolean over=has(norm(label),"over","mais");boolean under=has(norm(label),"under","menos");if((over||under)&&!Double.isNaN(handicap))put(groups,"TOTAL_"+MarketOddsBook.lineKey(handicap),MarketOddsBook.totalKey(over,handicap),odd);continue;
            }
            if(has(n,"handicap","spread","run line","point spread")){
                Boolean hs=side(label,home,away);if(hs!=null&&!Double.isNaN(handicap)){double line=signedLine(label,v,handicap);put(groups,"HANDI_"+MarketOddsBook.lineKey(Math.abs(line)),MarketOddsBook.handicapKey(hs,line),odd);}continue;
            }
            if(has(n,"match winner","winner","moneyline","home/away","1x2","fulltime result","full time result","to win")){
                String key=winnerKey(label,home,away);if(key!=null)put(groups,"WIN",key,odd);
            }
        }
        for(Map.Entry<String,LinkedHashMap<String,Double>> g:groups.entrySet())book.addBookmakerMarket(g.getValue(),bookmaker,name);
    }

    static String winnerKey(String label,String home,String away){String x=norm(label);if(has(x,"draw","empate")||x.equals("x"))return MarketOddsBook.DRAW;Boolean s=side(label,home,away);return s==null?null:(s?MarketOddsBook.HOME:MarketOddsBook.AWAY);}
    static String doubleChanceKey(String label,String home,String away){String x=norm(label).replace(" ","");if(x.equals("1x")||has(x,"home/draw","homeordraw","casa/empate"))return MarketOddsBook.DC_1X;if(x.equals("x2")||has(x,"draw/away","draworaway","empate/fora"))return MarketOddsBook.DC_X2;if(x.equals("12")||has(x,"home/away","homeoraway"))return MarketOddsBook.DC_12;Boolean s=side(label,home,away);if(s!=null&&has(norm(label),"draw","empate"))return s?MarketOddsBook.DC_1X:MarketOddsBook.DC_X2;return null;}
    static Boolean side(String label,String home,String away){String x=norm(label),h=norm(home),a=norm(away);if(x.equals("1")||x.equals("home")||x.equals("casa")||(!h.isEmpty()&&(x.equals(h)||x.contains(h))))return Boolean.TRUE;if(x.equals("2")||x.equals("away")||x.equals("fora")||(!a.isEmpty()&&(x.equals(a)||x.contains(a))))return Boolean.FALSE;return null;}
    static double signedLine(String label,JSONObject v,double fallback){String raw=first(v.optString("handicap",""),v.optString("line",""));Matcher m=Pattern.compile("([+-]?\\d+(?:[.,]\\d+)?)").matcher(raw.isEmpty()?label:raw);if(m.find())try{return Double.parseDouble(m.group(1).replace(',','.'));}catch(Exception ignored){}return fallback;}
    static double decimal(Object x){if(x==null||x==JSONObject.NULL)return Double.NaN;try{return Double.parseDouble(String.valueOf(x).trim().replace(',','.'));}catch(Exception e){return Double.NaN;}}
    static double number(String s){if(s==null)return Double.NaN;Matcher m=Pattern.compile("([+-]?\\d+(?:[.,]\\d+)?)").matcher(s);if(!m.find())return Double.NaN;try{return Math.abs(Double.parseDouble(m.group(1).replace(',','.')));}catch(Exception e){return Double.NaN;}}
    static void put(Map<String,LinkedHashMap<String,Double>> groups,String group,String key,double odd){groups.computeIfAbsent(group,k->new LinkedHashMap<>()).put(key,odd);}
    static boolean has(String s,String... parts){for(String p:parts)if(s.contains(p))return true;return false;}
    static String norm(String s){return s==null?"":java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9+./ -]"," ").replaceAll("\\s+"," ").trim();}
    static String first(String... v){for(String s:v)if(s!=null&&!s.trim().isEmpty())return s.trim();return "";}

    String fastSportGet(String source,String path,String key)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(MultiSportClient.base(source)+path).openConnection();h.setRequestProperty("x-apisports-key",key);h.setRequestProperty("Accept","application/json");h.setRequestProperty("User-Agent","J.Pastore-Sports-AI/6.10.3 Android");h.setConnectTimeout(1600);h.setReadTimeout(2400);int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();StringBuilder b=new StringBuilder();if(in!=null){BufferedReader r=new BufferedReader(new InputStreamReader(in));for(String line;(line=r.readLine())!=null;)b.append(line);}if(code==429)new MultiSportClient(c).markApiCircuit(source);if(code<200||code>=300)throw new IOException("HTTP "+code);return b.toString();}

    void cachePut(String k,String v){c.getSharedPreferences("jp_market_odds",0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long maxAge){android.content.SharedPreferences p=c.getSharedPreferences("jp_market_odds",0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=maxAge?p.getString(k,null):null;}
}
