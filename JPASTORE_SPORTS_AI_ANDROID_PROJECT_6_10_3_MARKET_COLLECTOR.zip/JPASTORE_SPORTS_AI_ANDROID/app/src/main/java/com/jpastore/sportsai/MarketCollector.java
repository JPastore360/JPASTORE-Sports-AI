package com.jpastore.sportsai;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

/**
 * Central market collector. It only supplies bookmaker evidence to the existing
 * statistical engine; it never changes model probabilities, thresholds or picks.
 */
final class MarketCollector {
    private static final String SOFA_SOURCE="SofaScore";
    private static final String API_SOURCE="API-Sports";
    private static final String PREF="jp_market_collector_v1";
    private static final String UA="Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36";
    private final Context c;

    MarketCollector(Context c){this.c=c;}

    MarketOddsBook collect(String sport,MultiSportClient.Event ev){
        MarketOddsBook out=new MarketOddsBook();if(ev==null)return out;
        ArrayList<Callable<MarketOddsBook>> tasks=new ArrayList<>();
        if(ev.sofaId>0||(ev.apiSource!=null&&ev.apiSource.equals("public-sofa")&&ev.id>0))tasks.add(()->sofaBook(ev));
        if(MultiSportClient.BASKETBALL.equals(sport)&&HighlightlyBasketballClient.configured(c))tasks.add(()->highlightlyBook(ev));
        if(c instanceof MainActivity&&!MultiSportClient.MMA.equals(sport)&&!MultiSportClient.F1.equals(sport))tasks.add(()->apiSportsBook(sport,ev));
        if(tasks.isEmpty())return out;
        long started=System.currentTimeMillis(),deadline=started+4200L;ExecutorService ex=Executors.newFixedThreadPool(Math.min(3,tasks.size()));ArrayList<Future<MarketOddsBook>> fs=new ArrayList<>();
        for(Callable<MarketOddsBook> task:tasks)fs.add(ex.submit(task));
        for(Future<MarketOddsBook> f:fs){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{MarketOddsBook b=f.get(left,TimeUnit.MILLISECONDS);if(b!=null)out.merge(b);}catch(TimeoutException te){f.cancel(true);out.markFailure("coletor/timeout");}catch(Exception e){out.markFailure("coletor");}}
        ex.shutdownNow();
        System.out.println("[JP_MARKET] event="+safe(ev.home)+" x "+safe(ev.away)+" sofaId="+ev.sofaId+" apiSportsId="+ev.apiSportsId+" result="+out.availabilityLabel()+" sources="+out.sourceSummary()+" keys="+out.keys()+" elapsedMs="+(System.currentTimeMillis()-started));
        return out;
    }

    private MarketOddsBook highlightlyBook(MultiSportClient.Event ev){
        MarketOddsBook out=new MarketOddsBook();out.markAttempt("Highlightly");
        try{
            String key=HighlightlyBasketballClient.key(c);HighlightlyBasketballClient hc=new HighlightlyBasketballClient(c);hc.resolve(key,ev);
            if(ev.highlightlyId<=0){out.markUnresolved("Highlightly");return out;}
            MarketOddsBook b=hc.odds(key,ev);if(b!=null)out.merge(b);
            if(out.isEmpty()&&!out.hasOutcomeState())out.markNoMarket("Highlightly");else if(!out.isEmpty())out.markSuccess("Highlightly");
        }catch(Exception e){out.markFailure("Highlightly");System.out.println("[JP_MARKET] Highlightly fail "+shortError(e));}
        return out;
    }

    private MarketOddsBook apiSportsBook(String sport,MultiSportClient.Event target){
        MarketOddsBook out=new MarketOddsBook();String source=apiSourceFor(sport,target);if(source==null)return out;
        MainActivity a=(MainActivity)c;String key=a.apiKeyFor(source);if(key==null||key.trim().isEmpty())return out;
        out.markAttempt(API_SOURCE);
        try{
            MultiSportClient cli=new MultiSportClient(c);if(cli.apiCircuitOpen(source)){out.markFailure(API_SOURCE+"/limite");return out;}
            MultiSportClient.Event provider=null;
            if(target.apiSportsId>0){provider=new MultiSportClient.Event(sport);provider.apiSource=source;provider.id=target.apiSportsId;provider.apiSportsId=target.apiSportsId;provider.home=target.home;provider.away=target.away;provider.status=target.status;provider.date=target.date;}
            else provider=resolveApiEvent(cli,source,key.trim(),target);
            if(provider==null||provider.id<=0){out.markUnresolved(API_SOURCE);return out;}
            target.apiSportsId=provider.id;
            MarketOddsBook b=new MarketOddsClient(c).sport(source,key.trim(),provider);if(b!=null)out.merge(b);
            if(out.isEmpty()&&!out.hasOutcomeState())out.markNoMarket(API_SOURCE);else if(!out.isEmpty())out.markSuccess(API_SOURCE);
            System.out.println("[JP_MARKET] API-Sports resolved "+safe(target.home)+" x "+safe(target.away)+" -> game="+provider.id+" source="+source);
        }catch(Exception e){out.markFailure(API_SOURCE);System.out.println("[JP_MARKET] API-Sports fail "+shortError(e));}
        return out;
    }

    private MultiSportClient.Event resolveApiEvent(MultiSportClient cli,String source,String key,MultiSportClient.Event target)throws Exception{
        String date=safe(target.date);if(date.length()>10)date=date.substring(0,10);if(date.length()!=10)date=localDay();
        ArrayList<MultiSportClient.Event> candidates=shortApiEvents(cli,source,date,key);double best=-1,second=-1;MultiSportClient.Event win=null;
        for(MultiSportClient.Event e:candidates){double s=matchScore(target,e);if(s<0)continue;if(s>best){second=best;best=s;win=e;}else if(s>second)second=s;}
        if(win==null||best<130)return null;
        if(second>=0&&best-second<12){System.out.println("[JP_MARKET] API-Sports ambiguous event best="+fmt(best)+" second="+fmt(second)+" target="+safe(target.home)+" x "+safe(target.away));return null;}
        return win;
    }

    private ArrayList<MultiSportClient.Event> shortApiEvents(MultiSportClient cli,String source,String date,String key)throws Exception{
        String ck="v1_"+source+"_"+date;String raw=cli.cacheGet(ck,8L*60*1000L);
        if(raw==null){String path="games?date="+date+"&timezone=America%2FSao_Paulo";HttpURLConnection h=(HttpURLConnection)new URL(MultiSportClient.base(source)+path).openConnection();h.setRequestProperty("x-apisports-key",key);h.setRequestProperty("Accept","application/json");h.setRequestProperty("User-Agent","J.Pastore-Sports-AI/6.10.3 Android");h.setConnectTimeout(1600);h.setReadTimeout(2300);int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();raw=read(in);if(code==429){cli.markApiCircuit(source);throw new IOException("HTTP 429");}if(code<200||code>=300)throw new IOException("HTTP "+code);cli.cachePut(ck,raw);}
        JSONArray a=new JSONObject(raw).optJSONArray("response");ArrayList<MultiSportClient.Event> out=new ArrayList<>();if(a==null)return out;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;MultiSportClient.Event e=MultiSportClient.NFL.equals(source)?cli.parseNfl(o):cli.parseGenericGame(source,o);if(e!=null)out.add(e);}return out;
    }

    static double matchScore(MultiSportClient.Event target,MultiSportClient.Event candidate){
        if(target==null||candidate==null)return -1;
        if(!TeamIdentityResolver.matches(target.home,candidate.home)||!TeamIdentityResolver.matches(target.away,candidate.away))return -1;
        double hs=TeamIdentityResolver.similarity(target.home,candidate.home),as=TeamIdentityResolver.similarity(target.away,candidate.away);double score=(hs+as)*100.0;
        if(!safe(target.date).isEmpty()&&safe(target.date).equals(safe(candidate.date)))score+=20;
        if(!safe(target.competition).isEmpty()&&!safe(candidate.competition).isEmpty())score+=TeamIdentityResolver.similarity(target.competition,candidate.competition)*8.0;
        int dt=timeDistanceMinutes(target.time,candidate.time);if(dt>=0&&dt<=45)score+=8;else if(dt>180)score-=12;
        return score;
    }

    private MarketOddsBook sofaBook(MultiSportClient.Event ev){
        MarketOddsBook out=new MarketOddsBook();long id=ev.sofaId>0?ev.sofaId:(("public-sofa".equals(ev.apiSource))?ev.id:0);if(id<=0)return out;out.markAttempt(SOFA_SOURCE);
        try{
            String raw=sofaCached(id,StatisticalCalibrationEngine.isPregameStatus(ev.status)?5L*60*1000L:45L*1000L);parseSofa(raw,ev.home,ev.away,out);
            if(out.isEmpty()){if(out.partialObserved())out.markPartial(SOFA_SOURCE);else out.markNoMarket(SOFA_SOURCE);}else out.markSuccess(SOFA_SOURCE);
        }catch(Exception e){out.markFailure(SOFA_SOURCE);System.out.println("[JP_MARKET] SofaScore fail id="+id+" "+shortError(e));}
        return out;
    }

    static void parseSofa(String raw,String home,String away,MarketOddsBook out)throws Exception{
        if(out==null||raw==null||raw.trim().isEmpty())return;JSONObject root=new JSONObject(raw);JSONArray markets=root.optJSONArray("markets");if(markets==null){JSONObject data=root.optJSONObject("data");if(data!=null)markets=data.optJSONArray("markets");}if(markets==null)return;
        for(int i=0;i<markets.length();i++){
            JSONObject m=markets.optJSONObject(i);if(m==null||m.optBoolean("suspended",false))continue;String name=first(m.optString("marketName",""),m.optString("name",""),m.optString("market",""));String n=norm(name);if(!wholeGame(n))continue;JSONArray choices=m.optJSONArray("choices");if(choices==null||choices.length()==0)continue;LinkedHashMap<String,Double> odds=new LinkedHashMap<>();
            boolean winner=has(n,"winner","moneyline","1x2","match result","full time result");boolean total=has(n,"total","over/under","over under");boolean handicap=has(n,"handicap","spread");
            for(int j=0;j<choices.length();j++){
                JSONObject ch=choices.optJSONObject(j);if(ch==null)continue;String label=first(ch.optString("name",""),ch.optString("label",""),ch.optString("choiceName",""));double odd=sofaDecimal(ch);if(Double.isNaN(odd)||odd<=1.0001)continue;
                if(winner){String k=MarketOddsClient.winnerKey(label,home,away);if(k!=null)odds.put(k,odd);continue;}
                if(total){String ln=first(ch.optString("line",""),ch.optString("handicap",""));if(ln.isEmpty())ln=label+" "+name;double line=extractNumber(ln);String x=norm(label);if(!Double.isNaN(line)){if(has(x,"over","mais"))odds.put(MarketOddsBook.totalKey(true,line),odd);else if(has(x,"under","menos"))odds.put(MarketOddsBook.totalKey(false,line),odd);}continue;}
                if(handicap){Boolean side=sofaSide(label,home,away);double line=extractSigned(first(ch.optString("handicap",""),ch.optString("line",""),label));if(side!=null&&!Double.isNaN(line))odds.put(MarketOddsBook.handicapKey(side,line),odd);}
            }
            if(!odds.isEmpty())out.addBookmakerMarket(odds,SOFA_SOURCE,name);
        }
    }

    private String sofaCached(long id,long ttl)throws Exception{
        String k="sofa_odds_"+id;SharedPreferences p=c.getSharedPreferences(PREF,0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;
        HttpURLConnection h=(HttpURLConnection)new URL("https://api.sofascore.com/api/v1/event/"+id+"/odds/1/all").openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(2400);h.setReadTimeout(3000);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept","application/json");h.setRequestProperty("Referer","https://www.sofascore.com/");int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();String body=read(in);if(code<200||code>=300){if(old!=null)return old;throw new IOException("HTTP "+code);}p.edit().putString(k,body).putLong(k+"_ts",System.currentTimeMillis()).apply();return body;
    }

    private static String apiSourceFor(String sport,MultiSportClient.Event ev){if(MultiSportClient.BASKETBALL.equals(sport))return MultiSportClient.BASKETBALL;if(MultiSportClient.NFL.equals(sport))return MultiSportClient.NFL;if(MultiSportClient.BASEBALL.equals(sport))return MultiSportClient.BASEBALL;return null;}
    private String localDay(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(new Date());}
    private static boolean wholeGame(String n){return !has(n,"quarter","1st quarter","2nd quarter","3rd quarter","4th quarter","first quarter","second quarter","third quarter","fourth quarter","1st half","2nd half","first half","second half","team total","home total","away total");}
    private static double sofaDecimal(JSONObject ch){Object[] vals={ch.opt("decimalValue"),ch.opt("decimalOdds"),ch.opt("fractionalValue"),ch.opt("initialFractionalValue")};for(Object v:vals){if(v==null||v==JSONObject.NULL)continue;String s=String.valueOf(v).trim();try{double d=Double.parseDouble(s.replace(',','.'));if(d>1)return d;}catch(Exception ignored){}Matcher m=Pattern.compile("(-?\\d+(?:\\.\\d+)?)\\s*/\\s*(\\d+(?:\\.\\d+)?)").matcher(s);if(m.find())try{double a=Double.parseDouble(m.group(1)),b=Double.parseDouble(m.group(2));if(a>=0&&b>0)return 1.0+a/b;}catch(Exception ignored){}}return Double.NaN;}
    static double extractNumber(String s){Matcher m=Pattern.compile("([+-]?\\d+(?:[.,]\\d+)?)").matcher(s==null?"":s);if(!m.find())return Double.NaN;try{return Math.abs(Double.parseDouble(m.group(1).replace(',','.')));}catch(Exception e){return Double.NaN;}}
    static double extractSigned(String s){Matcher m=Pattern.compile("([+-]?\\d+(?:[.,]\\d+)?)").matcher(s==null?"":s);String last=null;while(m.find())last=m.group(1);if(last==null)return Double.NaN;try{return Double.parseDouble(last.replace(',','.'));}catch(Exception e){return Double.NaN;}}
    static Boolean sofaSide(String label,String home,String away){String x=norm(label);if(x.matches("^1(?:\\s|\\(|$).*")||x.startsWith("home "))return Boolean.TRUE;if(x.matches("^2(?:\\s|\\(|$).*")||x.startsWith("away "))return Boolean.FALSE;return MarketOddsClient.side(label,home,away);}
    static int timeDistanceMinutes(String a,String b){try{String[] x=a.split(":"),y=b.split(":");if(x.length<2||y.length<2)return -1;return Math.abs((Integer.parseInt(x[0])*60+Integer.parseInt(x[1]))-(Integer.parseInt(y[0])*60+Integer.parseInt(y[1])));}catch(Exception e){return -1;}}
    private static String read(InputStream in)throws Exception{if(in==null)return "";BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s);return b.toString();}
    private static String shortError(Exception e){String s=e==null?"":String.valueOf(e.getMessage());return s.length()>120?s.substring(0,120):s;}
    private static String fmt(double d){return String.format(Locale.US,"%.1f",d);}
    private static boolean has(String s,String... p){for(String x:p)if(s.contains(x))return true;return false;}
    private static String norm(String s){return MarketOddsClient.norm(s);}
    private static String first(String... xs){for(String x:xs)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}
    private static String safe(String s){return s==null?"":s.trim();}
}
