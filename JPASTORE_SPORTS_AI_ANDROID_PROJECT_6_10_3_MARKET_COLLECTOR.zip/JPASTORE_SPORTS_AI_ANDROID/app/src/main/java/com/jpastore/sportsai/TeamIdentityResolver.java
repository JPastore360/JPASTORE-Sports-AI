package com.jpastore.sportsai;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/**
 * Resolves team/participant aliases without silently joining different categories.
 * Learned aliases are local-only and only stored when names are already sufficiently similar.
 */
final class TeamIdentityResolver {
    private static final String PREF="jp_team_alias_v64";
    private static final Pattern AGE=Pattern.compile("(?:^|\\s)(?:u|sub)[- ]?(\\d{2})(?:$|\\s)",Pattern.CASE_INSENSITIVE);

    static ArrayList<String> variants(Context c,String raw){
        LinkedHashSet<String> out=new LinkedHashSet<>();
        if(raw==null||raw.trim().isEmpty())return new ArrayList<>();
        String x=cleanSpaces(raw);out.add(x);
        String noClub=x.replaceAll("(?i)\\b(fc|cf|sc|ac|bc|bk|club|clube|basket|baskets|basketball|basquete|football|futebol|team)\\b"," ");
        noClub=cleanSpaces(noClub);if(noClub.length()>=3)out.add(noClub);
        String ascii=ascii(x);if(!ascii.equalsIgnoreCase(x))out.add(ascii);
        String simple=cleanSpaces(ascii.replaceAll("[^A-Za-z0-9 ]"," "));if(simple.length()>=3)out.add(simple);
        if(c!=null){SharedPreferences p=c.getSharedPreferences(PREF,0);String learned=p.getString("v_"+norm(raw),"");for(String v:learned.split("\\|"))if(v.trim().length()>=3)out.add(v.trim());}
        return new ArrayList<>(out);
    }

    static void remember(Context c,String canonical,String alias){
        if(c==null||canonical==null||alias==null)return;
        canonical=cleanSpaces(canonical);alias=cleanSpaces(alias);
        if(canonical.length()<3||alias.length()<3||canonical.equalsIgnoreCase(alias))return;
        if(genderMismatch(canonical,alias)||ageMismatch(canonical,alias)||similarity(canonical,alias)<.55)return;
        SharedPreferences p=c.getSharedPreferences(PREF,0);String k="v_"+norm(canonical),old=p.getString(k,"");LinkedHashSet<String>s=new LinkedHashSet<>();if(!old.isEmpty())Collections.addAll(s,old.split("\\|"));s.add(alias);StringBuilder b=new StringBuilder();for(String v:s){if(b.length()>0)b.append('|');b.append(v);}p.edit().putString(k,b.toString()).apply();
    }

    static boolean matches(String a,String b){
        if(a==null||b==null||a.trim().isEmpty()||b.trim().isEmpty())return false;
        if(genderMismatch(a,b)||ageMismatch(a,b))return false;
        String na=norm(a),nb=norm(b);if(na.equals(nb))return true;
        if(na.length()>=5&&nb.length()>=5&&(na.contains(nb)||nb.contains(na)))return true;
        return similarity(a,b)>=.60;
    }

    static double similarity(String a,String b){
        String na=norm(a),nb=norm(b);if(na.isEmpty()||nb.isEmpty())return 0;if(na.equals(nb))return 1;
        Set<String> sa=new LinkedHashSet<>(Arrays.asList(na.split(" "))),sb=new LinkedHashSet<>(Arrays.asList(nb.split(" ")));
        sa.removeAll(Arrays.asList("fc","cf","sc","ac","bc","bk","club","clube","team","basket","baskets","basketball","basquete","football","futebol"));
        sb.removeAll(Arrays.asList("fc","cf","sc","ac","bc","bk","club","clube","team","basket","baskets","basketball","basquete","football","futebol"));
        if(sa.isEmpty()||sb.isEmpty())return 0;
        int hit=0;for(String x:sa)if(sb.contains(x))hit++;double j=hit/(double)Math.max(sa.size(),sb.size());
        if(firstUseful(sa).equals(firstUseful(sb)))j=Math.min(1,j+.18);return j;
    }

    static String norm(String s){String x=ascii(s==null?"":s).toLowerCase(Locale.ROOT).replace('&',' ');x=x.replaceAll("[^a-z0-9 ]"," ");return cleanSpaces(x);}
    static String ascii(String s){return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}+","");}
    static String cleanSpaces(String s){return s==null?"":s.trim().replaceAll("\\s+"," ");}
    static String firstUseful(Set<String>s){for(String x:s)if(x.length()>2)return x;return "";}
    static boolean female(String s){String n=" "+norm(s)+" ";return n.contains(" women ")||n.contains(" woman ")||n.contains(" feminino ")||n.contains(" feminina ")||n.contains(" ladies ")||n.matches(".*\\sw\\s.*");}
    static boolean genderMismatch(String a,String b){return female(a)!=female(b);}
    static String age(String s){Matcher m=AGE.matcher(" "+(s==null?"":s)+" ");return m.find()?m.group(1):"";}
    static boolean ageMismatch(String a,String b){String x=age(a),y=age(b);return (!x.isEmpty()||!y.isEmpty())&&!x.equals(y);}
    private TeamIdentityResolver(){}
}
