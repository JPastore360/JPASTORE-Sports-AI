package com.jpastore.sportsai;

import java.util.*;

/**
 * Bookmaker market snapshot after removing the overround per bookmaker/market.
 * It stores probabilities, not predictions. Missing markets remain unavailable.
 */
final class MarketOddsBook {
    static final String HOME="1X2_HOME", DRAW="1X2_DRAW", AWAY="1X2_AWAY";
    static final String DC_1X="DC_1X", DC_12="DC_12", DC_X2="DC_X2";
    static final String DNB_HOME="DNB_HOME", DNB_AWAY="DNB_AWAY";

    static final class Quote {
        String key="", market="";
        double probability=Double.NaN, fairOdd=Double.NaN;
        int bookmakerCount=0;
        boolean available(){return !Double.isNaN(probability)&&probability>0&&probability<100.0001;}
    }
    static final class HandicapQuote {
        boolean home;
        double line, probability;
        int bookmakerCount;
        String key;
    }
    private static final class Bucket {
        final ArrayList<Double> probabilities=new ArrayList<>();
        final LinkedHashSet<String> bookmakers=new LinkedHashSet<>();
        String market="";
    }

    private final LinkedHashMap<String,Bucket> data=new LinkedHashMap<>();
    private final LinkedHashSet<String> attemptedSources=new LinkedHashSet<>(), successfulSources=new LinkedHashSet<>(), noMarketSources=new LinkedHashSet<>(), failedSources=new LinkedHashSet<>(), unresolvedSources=new LinkedHashSet<>();
    private boolean partialObserved=false;

    void markAttempt(String source){if(source!=null&&!source.trim().isEmpty())attemptedSources.add(source.trim());}
    void markSuccess(String source){markAttempt(source);if(source!=null&&!source.trim().isEmpty())successfulSources.add(source.trim());}
    void markNoMarket(String source){markAttempt(source);if(source!=null&&!source.trim().isEmpty())noMarketSources.add(source.trim());}
    void markFailure(String source){markAttempt(source);if(source!=null&&!source.trim().isEmpty())failedSources.add(source.trim());}
    void markUnresolved(String source){markAttempt(source);if(source!=null&&!source.trim().isEmpty())unresolvedSources.add(source.trim());}
    void markPartial(String source){markAttempt(source);partialObserved=true;}
    boolean partialObserved(){return partialObserved;}
    boolean hasOutcomeState(){return partialObserved||!successfulSources.isEmpty()||!noMarketSources.isEmpty()||!failedSources.isEmpty()||!unresolvedSources.isEmpty();}
    String availabilityLabel(){
        if(!data.isEmpty())return "disponível";
        if(partialObserved)return failedSources.isEmpty()?"parcial — odds incompletas para remover a margem":"parcial — odds incompletas e falha em outra fonte";
        if(!unresolvedSources.isEmpty()&&failedSources.isEmpty()&&noMarketSources.isEmpty())return "não confirmado — evento não resolvido na fonte de odds";
        if(!failedSources.isEmpty()&&!noMarketSources.isEmpty())return "não confirmado — coleta parcial";
        if(!failedSources.isEmpty())return "não confirmado — falha de coleta";
        if(!noMarketSources.isEmpty()&&!unresolvedSources.isEmpty())return "não encontrado em uma fonte; evento não resolvido em outra";
        if(!noMarketSources.isEmpty())return "não encontrado nas fontes consultadas";
        if(!attemptedSources.isEmpty())return "não confirmado";
        return "não consultado";
    }
    String sourceSummary(){LinkedHashSet<String> all=new LinkedHashSet<>();all.addAll(successfulSources);all.addAll(noMarketSources);all.addAll(failedSources);all.addAll(unresolvedSources);all.addAll(attemptedSources);if(all.isEmpty())return "nenhuma";StringBuilder b=new StringBuilder();for(String x:all){if(b.length()>0)b.append(", ");b.append(x);}return b.toString();}
    String availabilityFor(double marketProbability){if(valid(marketProbability))return "disponível";if(!data.isEmpty())return "mercado selecionado não encontrado — outras odds disponíveis";return availabilityLabel();}

    void addBookmakerMarket(Map<String,Double> decimalOdds,String bookmaker,String market){
        if(decimalOdds==null||decimalOdds.isEmpty())return;
        double sum=0;LinkedHashMap<String,Double> inv=new LinkedHashMap<>();
        for(Map.Entry<String,Double> e:decimalOdds.entrySet()){
            double odd=e.getValue()==null?Double.NaN:e.getValue();
            if(Double.isNaN(odd)||odd<=1.0001)continue;
            double p=1.0/odd;inv.put(e.getKey(),p);sum+=p;
        }
        if(inv.size()<2||sum<=0){if(!inv.isEmpty())partialObserved=true;return;}
        for(Map.Entry<String,Double> e:inv.entrySet())addNormalized(e.getKey(),e.getValue()/sum*100.0,bookmaker,market);
    }

    void addNormalized(String key,double probability,String bookmaker,String market){
        if(key==null||key.trim().isEmpty()||Double.isNaN(probability)||probability<=0||probability>=100.0001)return;
        Bucket b=data.computeIfAbsent(key,k->new Bucket());
        b.probabilities.add(probability);if(bookmaker!=null&&!bookmaker.trim().isEmpty())b.bookmakers.add(bookmaker.trim());if(market!=null&&!market.trim().isEmpty())b.market=market.trim();
    }

    /** Reconstructs a cached consensus quote without pretending it came from fresh bookmakers. */
    void addConsensus(String key,double probability,int bookmakerCount,String market){
        if(Double.isNaN(probability)||probability<=0||probability>=100.0001)return;
        Bucket b=data.computeIfAbsent(key,k->new Bucket());b.probabilities.add(probability);b.market=market==null?"":market;
        for(int i=0;i<Math.max(0,bookmakerCount);i++)b.bookmakers.add("cached-"+i);
    }

    Quote quote(String key){
        Quote q=new Quote();q.key=key==null?"":key;Bucket b=data.get(key);if(b==null||b.probabilities.isEmpty())return q;
        q.probability=median(b.probabilities);q.fairOdd=q.probability>0?100.0/q.probability:Double.NaN;q.bookmakerCount=b.bookmakers.size();q.market=b.market;return q;
    }
    double probability(String key){return quote(key).probability;}
    int bookmakerCount(String key){return quote(key).bookmakerCount;}
    boolean isEmpty(){return data.isEmpty();}
    Set<String> keys(){return new LinkedHashSet<>(data.keySet());}

    double doubleChance(boolean homeSide){
        Quote direct=quote(homeSide?DC_1X:DC_X2);if(direct.available())return direct.probability;
        double h=probability(HOME),d=probability(DRAW),a=probability(AWAY);
        if(!valid(h)||!valid(d)||!valid(a))return Double.NaN;
        return homeSide?h+d:d+a;
    }
    double drawNoBet(boolean homeSide){
        Quote direct=quote(homeSide?DNB_HOME:DNB_AWAY);if(direct.available())return direct.probability;
        double h=probability(HOME),a=probability(AWAY);if(!valid(h)||!valid(a)||h+a<=0)return Double.NaN;
        return (homeSide?h:a)/(h+a)*100.0;
    }
    double total(boolean over,double line){return probability(totalKey(over,line));}
    ArrayList<Double> totalLines(){
        LinkedHashSet<Double> seen=new LinkedHashSet<>();
        for(String k:data.keySet()){
            if(k.startsWith("TOTAL_OVER_")){double line=parseLine(k.substring("TOTAL_OVER_".length()));if(!Double.isNaN(line)&&quote(totalKey(false,line)).available())seen.add(line);}
            else if(k.startsWith("TOTAL_UNDER_")){double line=parseLine(k.substring("TOTAL_UNDER_".length()));if(!Double.isNaN(line)&&quote(totalKey(true,line)).available())seen.add(line);}
        }
        ArrayList<Double> out=new ArrayList<>(seen);Collections.sort(out);return out;
    }

    double mainTotalLine(){
        double best=Double.NaN;int bestBooks=-1;double bestBalance=Double.POSITIVE_INFINITY;
        for(String k:data.keySet()){if(!k.startsWith("TOTAL_OVER_"))continue;double line=parseLine(k.substring("TOTAL_OVER_".length()));if(Double.isNaN(line))continue;Quote over=quote(k),under=quote(totalKey(false,line));if(!over.available()||!under.available())continue;int books=Math.min(over.bookmakerCount,under.bookmakerCount);double balance=Math.abs(over.probability-50.0);if(books>bestBooks||(books==bestBooks&&balance<bestBalance)){best=line;bestBooks=books;bestBalance=balance;}}
        return best;
    }

    ArrayList<HandicapQuote> positiveHandicaps(boolean homeSide){
        ArrayList<HandicapQuote> out=new ArrayList<>();String prefix=homeSide?"HANDICAP_HOME_":"HANDICAP_AWAY_";
        for(String k:data.keySet()){
            if(!k.startsWith(prefix))continue;double line=parseLine(k.substring(prefix.length()));if(Double.isNaN(line)||line<=0)continue;Quote q=quote(k);if(!q.available())continue;
            HandicapQuote h=new HandicapQuote();h.home=homeSide;h.line=line;h.probability=q.probability;h.bookmakerCount=q.bookmakerCount;h.key=k;out.add(h);
        }
        Collections.sort(out,(x,y)->Double.compare(x.line,y.line));return out;
    }

    void merge(MarketOddsBook other){
        if(other==null)return;for(String k:other.data.keySet()){Quote q=other.quote(k);if(q.available())addConsensus(k,q.probability,q.bookmakerCount,q.market);}
        attemptedSources.addAll(other.attemptedSources);successfulSources.addAll(other.successfulSources);noMarketSources.addAll(other.noMarketSources);failedSources.addAll(other.failedSources);unresolvedSources.addAll(other.unresolvedSources);partialObserved|=other.partialObserved;
    }

    static String totalKey(boolean over,double line){return (over?"TOTAL_OVER_":"TOTAL_UNDER_")+lineKey(line);}
    static String handicapKey(boolean home,double line){return (home?"HANDICAP_HOME_":"HANDICAP_AWAY_")+lineKey(line);}
    static String lineKey(double line){return String.format(Locale.US,"%.2f",line);}
    static double parseLine(String s){try{return Double.parseDouble(s);}catch(Exception e){return Double.NaN;}}
    static boolean valid(double p){return !Double.isNaN(p)&&p>0&&p<100.0001;}
    static double median(Collection<Double> values){ArrayList<Double> v=new ArrayList<>();for(Double x:values)if(x!=null&&!Double.isNaN(x))v.add(x);if(v.isEmpty())return Double.NaN;Collections.sort(v);int n=v.size();return n%2==1?v.get(n/2):(v.get(n/2-1)+v.get(n/2))/2.0;}
}
