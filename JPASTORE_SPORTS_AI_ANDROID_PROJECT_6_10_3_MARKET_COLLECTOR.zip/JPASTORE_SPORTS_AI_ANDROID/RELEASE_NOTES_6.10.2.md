# 6.10.2 — Tela inicial e cache

- Agenda inicial independente da lista de busca/ao vivo.
- Todos os confrontos carregados são exibidos, respeitando o filtro de horário; ativos primeiro.
- Respostas antigas de troca de data são ignoradas.
- Agendas com menos de 12 jogos voltam a consultar fontes; API complementar, quando configurada, é tentada também nessas agendas curtas. Isso não garante 12 jogos por dia.
- Endereços dos escudos preservados no cache e na combinação das fontes.
- Correções de prazo e busca de logos da 6.10.1 preservadas; latência real não medida aqui.
- versionCode 65; applicationId e assinatura existentes preservados.

## Instalação pelo GitHub
Substituir o ZIP da raiz por JPASTORE_SPORTS_AI_ANDROID_PROJECT.zip e o workflow por .github/workflows/build-apk.yml. Executar Gerar APK J.Pastore Sports AI. O APK só estará disponível após assembleDebug concluir.

## Limites da validação
Conferências estruturais, scripts existentes de logos/velocidade e sintaxe YAML/Bash executados. Compilação Android e teste no aparelho pendentes.
