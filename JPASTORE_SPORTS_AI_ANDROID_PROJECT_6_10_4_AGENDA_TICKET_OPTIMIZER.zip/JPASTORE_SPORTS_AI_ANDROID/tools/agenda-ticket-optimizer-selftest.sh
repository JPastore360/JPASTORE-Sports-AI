#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
SRC="$ROOT/app/src/main/java/com/jpastore/sportsai"
pass=0
check(){ local text="$1" file="$2" label="$3"; grep -Fq "$text" "$file" || { echo "FAIL: $label"; exit 1; }; pass=$((pass+1)); echo "PASS $pass: $label"; }

test -f "$ROOT/FULL_ANALYSIS_BUILD_6_10_4" || { echo 'FAIL: marcador 6.10.4'; exit 1; }
pass=$((pass+1)); echo "PASS $pass: marcador 6.10.4"
check 'versionCode 67' "$ROOT/app/build.gradle" 'versionCode 67'
check "6.10.4-agenda-ticket-optimizer" "$ROOT/app/build.gradle" 'versionName 6.10.4'
check 'expandFixtures' "$SRC/ApiClient.java" 'segunda passagem da agenda'
check 'soccer/bra.1' "$SRC/MultiSportClient.java" 'ESPN futebol ampliada'
check 'soccer/uefa.champions' "$SRC/MultiSportClient.java" 'competições internacionais ESPN'
check 'buildSportMultiTicketBatch' "$SRC/PremiumView.java" 'bilhete múltiplo em lote'
check 'Math.min(4,queue.size())' "$SRC/PremiumView.java" 'limite de 4 pesquisas paralelas'
check 'marketOnlyFallback' "$SRC/SportTicketEngine.java" 'fallback de mercado real'
check 'rescue.marketOdds' "$SRC/PremiumView.java" 'resgate direto de odds quando histórico falha'
check 'pickLimit=multi?Math.min(1' "$SRC/TicketStore.java" 'uma seleção por confronto'
check 'marketEvidence' "$SRC/MultiSportWebClient.java" 'odds reais contam como evidência'
check 'JP-AGENDA-TICKET-OPTIMIZER-6.10.4' "$SRC/PremiumView.java" 'marcador interno da otimização'
echo "AGENDA + TICKET OPTIMIZER: $pass/$pass PASS"
