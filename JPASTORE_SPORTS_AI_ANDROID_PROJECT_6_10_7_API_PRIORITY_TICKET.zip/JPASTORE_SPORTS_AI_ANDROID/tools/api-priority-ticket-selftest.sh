#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/app/src/main/java/com/jpastore/sportsai"
TMP="${TMPDIR:-/tmp}/jpastore-api-priority-ticket"
rm -rf "$TMP" && mkdir -p "$TMP/out" "$TMP/src/com/jpastore/sportsai"
cat > "$TMP/src/com/jpastore/sportsai/ApiPriorityTicketSelfTest.java" <<'JAVA'
package com.jpastore.sportsai;
import java.util.*;
public class ApiPriorityTicketSelfTest {
 static int n=0;static void ok(boolean v,String m){if(!v)throw new RuntimeException("FAIL: "+m);n++;System.out.println("PASS: "+m);}
 public static void main(String[] args){
  ok(ResearchRoutePolicy.fiveDollarBudget(false)>ResearchRoutePolicy.internetBudget(false),"5Dollar tem janela maior que internet na análise normal");
  ok(ResearchRoutePolicy.fiveDollarBudget(true)>=10000L,"análise profunda dá tempo real para a 5Dollar concluir lote");
  ok(ResearchRoutePolicy.useApiFootball(true,95,3),"análise profunda força API-Football mesmo com boa cobertura");
  ok(ResearchRoutePolicy.useApiFootball(false,40,1),"API-Football complementa cobertura curta");
  ok(!ResearchRoutePolicy.useApiFootball(false,90,2),"API-Football pode ser poupada quando a 5Dollar já entregou base forte");
  ok(ResearchRoutePolicy.useInternet(false,60,2),"internet confirma quando cobertura estruturada ainda é curta");
  ArrayList<TicketBatchGenerator.Candidate> pool=new ArrayList<>();
  pool.addAll(InitialPredictionTicketFactory.football("e1","A × B","Liga","2026-09-24 18:00","A","B",21,37,42));
  pool.addAll(InitialPredictionTicketFactory.football("e2","C × D","Liga","2026-09-24 20:00","C","D",48,28,24));
  ok(pool.size()==16,"dois confrontos sem análise profunda mantêm 16 alternativas de revisão reais");
  TicketBatchGenerator.BatchResult b=TicketBatchGenerator.generate(12,pool,"EQUILIBRADO",707L);
  ok(b.generated==12,"pedido de 12 gera 12 quando há combinações derivadas suficientes");
  HashSet<String> sig=new HashSet<>();for(TicketBatchGenerator.Ticket t:b.tickets)sig.add(t.signature);ok(sig.size()==12,"12 bilhetes gerados são distintos");
  TicketBatchGenerator.BatchResult c=TicketBatchGenerator.generate(12,pool,"CONSERVADOR",707L);ok(c.generated==0,"fallback continua proibido no conservador");
  System.out.println("ALL API PRIORITY + TICKET TESTS PASSED: "+n);
 }
}
JAVA
javac -encoding UTF-8 -d "$TMP/out" \
 "$SRC/ResearchRoutePolicy.java" \
 "$SRC/EventStandards.java" \
 "$SRC/StatisticalCalibrationEngine.java" \
 "$SRC/TicketBatchGenerator.java" \
 "$SRC/InitialPredictionTicketFactory.java" \
 "$TMP/src/com/jpastore/sportsai/ApiPriorityTicketSelfTest.java"
java -cp "$TMP/out" com.jpastore.sportsai.ApiPriorityTicketSelfTest

# Structural route assertions.
FIVE="$SRC/FiveDollarFootballClient.java"; API="$SRC/ApiClient.java"; WEB="$SRC/MultiSportWebClient.java"; UI="$SRC/PremiumView.java"
grep -Fq 'budgetAvailable(c,4)' "$API"
grep -Fq 'safeHourlyLimit' "$FIVE"
grep -Fq 'reserveRequestSlot' "$FIVE"
grep -Fq 'researchFootballPriority' "$WEB"
grep -Fq 'researchFootballPriority(ev,false,null)' "$UI"
grep -Fq 'batchInitialPrediction' "$UI"
grep -Fq 'MultiSportClient.FOOTBALL.equals(sportMultiBuildSport)?2:4' "$UI"
grep -Fq 'JP-API-PRIORITY-TICKET-6.10.7' "$UI"
python3 - "$API" <<'PY'
import sys
s=open(sys.argv[1],encoding='utf-8').read()
a=s.index('5Dollar primária')
b=s.index('API-Football • segunda camada estruturada')
c=s.index('Internet • terceira camada de confirmação')
assert a<b<c,(a,b,c)
print('PASS: ordem estrutural 5Dollar -> API-Football -> internet')
PY
echo 'ANDROID API PRIORITY CHECKS PASSED: 9'
