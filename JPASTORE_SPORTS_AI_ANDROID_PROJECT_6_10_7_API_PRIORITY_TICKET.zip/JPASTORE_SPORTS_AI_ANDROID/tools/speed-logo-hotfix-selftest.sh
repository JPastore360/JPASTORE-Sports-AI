#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
SRC="$ROOT/app/src/main/java/com/jpastore/sportsai"
API="$SRC/ApiClient.java"
POLICY="$SRC/ResearchRoutePolicy.java"
UI="$SRC/PremiumView.java"
FIVE="$SRC/FiveDollarFootballClient.java"
pass(){ echo "PASS: $1"; }
grep -Fq 'totalBudget(boolean deep)' "$POLICY" && pass 'orçamento total da análise centralizado'
grep -Fq 'fiveDollarBudget(boolean deep)' "$POLICY" && grep -Fq '5Dollar primária' "$API" && pass '5Dollar recebe janela primária suficiente'
grep -Fq 'apiFootballBudget(boolean deep)' "$POLICY" && grep -Fq 'API-Football • segunda camada estruturada' "$API" && pass 'API-Football é segunda camada'
grep -Fq 'internetBudget(boolean deep)' "$POLICY" && grep -Fq 'Internet • terceira camada de confirmação' "$API" && pass 'internet é terceira camada'
grep -Fq 'safeHourlyLimit' "$FIVE" && grep -Fq 'reserveRequestSlot' "$FIVE" && pass '5Dollar protege cota horária com reserva local'
grep -Fq 'estimatedSafeRemaining' "$FIVE" && pass 'saldo seguro 5Dollar é auditável'
grep -Fq 'resolveSofaBadge' "$UI" && grep -Fq 'api.sofascore.com/api/v1/search/all/' "$UI" && pass 'SofaScore prioritário no resolvedor de logos'
grep -Fq 'setConnectTimeout(900)' "$UI" && grep -Fq 'setReadTimeout(1100)' "$UI" && pass 'busca de logo SofaScore tem timeout curto'
grep -Fq 'teamLogo(ho)' "$FIVE" && grep -Fq 'teamLogo(aw)' "$FIVE" && pass 'logos da 5Dollar são preservados quando fornecidos'
grep -Fq 'JP-SPEED-LOGO-HOTFIX-6.10.1' "$UI" && pass 'marcador interno 6.10.1 presente'
echo 'ALL SPEED + LOGO/ROUTE TESTS PASSED: 10'
