package com.jpastore.sportsai;
import java.util.*;
public class InitialPredictionTicketFactorySelfTest {
 static int n=0;static void ok(boolean v,String s){if(!v)throw new RuntimeException("FAIL: "+s);n++;System.out.println("PASS: "+s);}
 public static void main(String[] args){
  ArrayList<TicketBatchGenerator.Candidate> a=InitialPredictionTicketFactory.football("e1","South Korea × Ecuador","Friendlies","2026-09-24 18:00","South Korea","Ecuador",21,37,42);
  ok(a.size()==8,"predição inicial produz 8 alternativas matematicamente derivadas do 1X2");
  ok("Empate ou Ecuador".equals(a.get(0).pick),"dupla chance segue a tendência 21/37/42");
  for(TicketBatchGenerator.Candidate c:a){ok(c.status.contains("REVISÃO NECESSÁRIA"),"fallback fica em revisão");ok(c.risk.contains("RISCO ALTO"),"fallback mantém risco alto");ok(Double.isNaN(c.marketProbability),"fallback não inventa mercado");}
  ArrayList<TicketBatchGenerator.Candidate> pool=new ArrayList<>(a);pool.addAll(InitialPredictionTicketFactory.football("e2","Team A × Team B","Liga","2026-09-24 20:00","Team A","Team B",48,28,24));
  TicketBatchGenerator.BatchResult b=TicketBatchGenerator.generate(10,pool,"EQUILIBRADO",999L);
  ok(b.generated==10,"2 confrontos com predição inicial geram 10 bilhetes distintos quando solicitado");
  HashSet<String> sig=new HashSet<>();for(TicketBatchGenerator.Ticket t:b.tickets)sig.add(t.signature);ok(sig.size()==10,"os 10 bilhetes são diferentes");
  TicketBatchGenerator.BatchResult c=TicketBatchGenerator.generate(10,pool,"CONSERVADOR",999L);ok(c.generated==0,"conservador continua bloqueando revisão necessária");
  System.out.println("ALL INITIAL FALLBACK TESTS PASSED: "+n);
 }
}
