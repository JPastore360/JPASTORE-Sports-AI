#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="${TMPDIR:-/tmp}/jpastore-initial-ticket-fallback"
rm -rf "$TMP" && mkdir -p "$TMP/out"
javac -encoding UTF-8 -d "$TMP/out" \
 "$ROOT/app/src/main/java/com/jpastore/sportsai/EventStandards.java" \
 "$ROOT/app/src/main/java/com/jpastore/sportsai/StatisticalCalibrationEngine.java" \
 "$ROOT/app/src/main/java/com/jpastore/sportsai/TicketBatchGenerator.java" \
 "$ROOT/app/src/main/java/com/jpastore/sportsai/InitialPredictionTicketFactory.java" \
 "$ROOT/tools/InitialPredictionTicketFactorySelfTest.java"
java -cp "$TMP/out" com.jpastore.sportsai.InitialPredictionTicketFactorySelfTest
