# J.PASTORE AI 6.10.7 — API Priority + Ticket Guarantee

- 5DollarFootballAPI becomes the primary structured football research source.
- API-Football is the second layer, forced in explicit deep analysis and used when primary coverage is short.
- Public internet is the third confirmation/enrichment layer.
- 5Dollar local safe budget preserves roughly 10% of the hourly allowance and honors provider Retry-After/remaining headers.
- Football multi-ticket generation uses the prioritized research route and API-Football prediction fallback.
- Initial 1X2 fallback exposes all eight legitimate derived review alternatives (3 double chance, 2 DNB, 3 result), never inventing odds/history.
- Batch football concurrency is capped at two analyses to reduce provider burst pressure.
- Statistical calibration formulas remain unchanged.
