# J.PASTORE AI 6.10.6 — Ticket Fallback

- Bilhete manual não depende mais da conclusão da análise aprofundada.
- Predição inicial pode gerar seleção claramente marcada como REVISÃO NECESSÁRIA / RISCO ALTO.
- Gerador em lote usa predição inicial de futebol quando a pesquisa aprofundada não entrega seleção.
- Modo padrão do gerador em lote passa a EQUILIBRADO; CONSERVADOR continua exigindo evidência forte.
- Mantém o motor estatístico principal sem alteração de fórmulas.
