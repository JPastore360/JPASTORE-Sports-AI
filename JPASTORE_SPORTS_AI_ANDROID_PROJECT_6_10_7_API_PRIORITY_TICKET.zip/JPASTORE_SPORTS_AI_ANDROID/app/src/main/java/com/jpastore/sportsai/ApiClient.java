package com.jpastore.sportsai;

import android.content.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

public class ApiClient {
    Context c;
    ApiClient(Context c){ this.c=c; }

    static class Game {
        long fixtureId,fiveId,fiveHomeId,fiveAwayId,fiveLeagueId; int homeId,awayId; int leagueId,season;
        String home,away,homeLogo,awayLogo,league,time,status;
        int homeGoals=-1,awayGoals=-1,elapsed=0;
        Game(long f,int hi,int ai,int li,int se,String h,String a,String hl,String al,String l,String t,String s){
            fixtureId=f;homeId=hi;awayId=ai;leagueId=li;season=se;home=h;away=a;homeLogo=hl;awayLogo=al;league=l;time=t;status=s;
        }
    }
    static class Player {int id,num;String name,grid,photo; Player(int i,int n,String nm,String g){id=i;num=n;name=nm;grid=g;photo=i>0?"https://media.api-sports.io/football/players/"+i+".png":"";} }
    static class Lineup {String team,formation,coach;ArrayList<Player> start=new ArrayList<>(),bench=new ArrayList<>();}
    static class Stats {LinkedHashMap<String,String[]> rows=new LinkedHashMap<>();}
    static class Prediction {int home,draw,away;String advice="",winner="",underOver=""; LinkedHashMap<String,Integer> comparison=new LinkedHashMap<>(); String homeForm="",awayForm="";}
    static class H2H {ArrayList<String> rows=new ArrayList<>();int homeWins,draws,awayWins;}

    static class MetricProjection {
        String name,source="",projectionStatus="NORMAL",projectionReason="";
        double home,away,total,rawTotal=Double.NaN,recentMean=Double.NaN,recentMedian=Double.NaN,leagueMean=Double.NaN,stdDev=Double.NaN,marketLine=Double.NaN,low,high,line=-1,lineHigh=-1;
        int overProb=-1,overProbHigh=-1,sample=0;
        boolean projectionDivergent=false;
        MetricProjection(String n){name=n;}
    }
    static class DeepAnalysis {
        LinkedHashMap<String,MetricProjection> metrics=new LinkedHashMap<>();
        int homeMatches=0,awayMatches=0,h2hMatches=0,homeVenueMatches=0,awayVenueMatches=0;
        int sourceCount=0,sourceQuality=0,agreement=0;
        MarketOddsBook marketOdds=new MarketOddsBook();
        String note="",sources="";
        boolean complete=false;
    }
    static class Series {
        double forSum=0,againstSum=0,weight=0; int n=0;ArrayList<Double> totals=new ArrayList<>(),forValues=new ArrayList<>(),againstValues=new ArrayList<>();
        void add(double f,double a,double w){ if(Double.isNaN(f)||Double.isNaN(a))return;forSum+=f*w;againstSum+=a*w;weight+=w;n++;forValues.add(f);againstValues.add(a);totals.add(f+a); }
        double f(){return weight>0?forSum/weight:Double.NaN;}
        double a(){return weight>0?againstSum/weight:Double.NaN;}
        double totalMean(){return meanList(totals);}
        double totalMedian(){return medianList(totals);}
        double totalStd(){return stdList(totals);}
    }
    static class StatSample { HashMap<String,Double> team=new HashMap<>(),opp=new HashMap<>(); }

    String get(String path,String key)throws Exception{
        MultiSportClient guard=new MultiSportClient(c);if(guard.apiCircuitOpen(MultiSportClient.FOOTBALL))throw new IOException("API-Football complementar pausada até amanhã por limite diário");
        HttpURLConnection h=(HttpURLConnection)new URL("https://v3.football.api-sports.io/"+path).openConnection();
        h.setRequestProperty("x-apisports-key",key);h.setRequestProperty("Accept","application/json");h.setConnectTimeout(6500);h.setReadTimeout(6500);
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();StringBuilder b=new StringBuilder();if(in!=null){BufferedReader r=new BufferedReader(new InputStreamReader(in));for(String z;(z=r.readLine())!=null;)b.append(z);}
        String body=b.toString();String remaining=h.getHeaderField("x-ratelimit-requests-remaining");if("0".equals(remaining)||code==429||MultiSportClient.quotaText(body))guard.markApiCircuit(MultiSportClient.FOOTBALL);
        if(code!=200)throw new IOException(code==429?"Limite diário da API atingido • modo web continua ativo":"HTTP "+code);return body;
    }
    void cachePut(String k,String v){c.getSharedPreferences("jp_cache",0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long maxAge){android.content.SharedPreferences p=c.getSharedPreferences("jp_cache",0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=maxAge?p.getString(k,null):null;}
    ArrayList<Game> parseGamesRoot(String raw)throws Exception{JSONObject root=new JSONObject(raw);JSONArray a=root.optJSONArray("response");if(a==null)a=root.optJSONArray("fixtures");ArrayList<Game> out=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++)out.add(parseGame(a.getJSONObject(i)));return out;}
    void test(String key,Consumer<Boolean> cb){new Thread(()->{try{get("status",key);cb.accept(true);}catch(Exception e){cb.accept(false);}}).start();}

    // 6.9: agenda multi-source com orçamento de tempo. Fontes rápidas são fundidas em paralelo;
    // nenhuma fonte lenta consegue travar a tela inteira.
    void fixtures(String key,String date,Consumer<ArrayList<Game>> ok,Consumer<String> err){fixtures(key,date,null,ok,err);}
    void fixtures(String key,String date,ResearchProgress progress,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{
        String ck="fixtures_v6105_"+date;try{
            ArrayList<Game> warm=readCachedPublicGames(ck,date.equals(today())?75L*1000L:12L*60*1000L);if(!warm.isEmpty()){sortGames(warm);System.out.println("[JP_HOME] stage=cache rawEvents="+warm.size()+" afterDedup="+warm.size()+" date="+date+" timezone=America/Sao_Paulo");report(progress,100,"Agenda instantânea • cache multi-fonte • "+warm.size()+" jogos");ok.accept(warm);return;}
            report(progress,5,"Agenda rápida • iniciando fontes públicas em paralelo");String fastKey=FiveDollarFootballClient.key(c);int workers=fastKey.isEmpty()?2:3;ExecutorService ex=Executors.newFixedThreadPool(workers);CompletionService<ArrayList<Game>> cs=new ExecutorCompletionService<>(ex);
            if(!fastKey.isEmpty())cs.submit(()->{try{return new FiveDollarFootballClient(c).fixtures(fastKey,date);}catch(Exception e){return new ArrayList<>();}});
            cs.submit(()->{try{ArrayList<Game> pub=new ArrayList<>();for(MultiSportClient.Event e:new MultiSportClient(c).loadPublicSchedule(MultiSportClient.FOOTBALL,date))pub.add(publicFootballGame(e));return pub;}catch(Exception e){return new ArrayList<>();}});
            cs.submit(()->{try{return new WebDataClient(c).fixtures(date);}catch(Exception e){return new ArrayList<>();}});
            ArrayList<Game> out=new ArrayList<>();long deadline=System.currentTimeMillis()+4300L;int received=0,rawEvents=0;while(received<workers){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{Future<ArrayList<Game>> f=cs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;ArrayList<Game> got=f.get();if(got!=null){rawEvents+=got.size();out=mergeGames(out,got);}received++;report(progress,18+Math.min(58,received*18),"Cruzando fontes públicas • "+out.size()+" jogos");}catch(Exception ignored){received++;}}ex.shutdownNow();
            if(out.isEmpty()){ArrayList<Game> stale=readCachedPublicGames(ck,7L*24*60*60*1000L);if(!stale.isEmpty()){out=stale;report(progress,88,"Usando última agenda válida salva no aparelho");}}
            sortGames(out);if(!out.isEmpty())cachePublicGames(ck,out);System.out.println("[JP_HOME] stage=quick rawEvents="+rawEvents+" validEvents="+out.size()+" afterDedup="+out.size()+" date="+date+" timezone=America/Sao_Paulo");report(progress,100,"Agenda rápida pronta • "+out.size()+" jogos");ok.accept(out);
        }catch(Exception e){report(progress,100,"Agenda concluída com cobertura limitada");err.accept(e.getMessage());}
    }).start();}
    /** 6.10.5: exhaustive second-pass expansion. The fast list is already on screen;
     * every configured source gets a chance here, regardless of how many items the fast pass returned. */
    void expandFixtures(String key,String date,ArrayList<Game> seed,Consumer<ArrayList<Game>> ok){new Thread(()->{
        try{
            ArrayList<Game> out=seed==null?new ArrayList<>():new ArrayList<>(seed);MultiSportClient multi=new MultiSportClient(c);String fastKey=FiveDollarFootballClient.key(c);
            int workers=4+(fastKey.isEmpty()?0:1)+((key==null||key.trim().isEmpty())?0:1);ExecutorService ex=Executors.newFixedThreadPool(Math.min(6,Math.max(1,workers)));CompletionService<ArrayList<Game>> cs=new ExecutorCompletionService<>(ex);
            cs.submit(()->{ArrayList<Game> z=new ArrayList<>();try{for(MultiSportClient.Event e:multi.loadSofaSchedule(MultiSportClient.FOOTBALL,date))z.add(publicFootballGame(e));}catch(Exception ignored){}return z;});
            cs.submit(()->{ArrayList<Game> z=new ArrayList<>();try{for(MultiSportClient.Event e:multi.loadEspnSchedule(MultiSportClient.FOOTBALL,date))z.add(publicFootballGame(e));}catch(Exception ignored){}return z;});
            cs.submit(()->{ArrayList<Game> z=new ArrayList<>();try{for(MultiSportClient.Event e:multi.loadSportsDbSchedule(MultiSportClient.FOOTBALL,date))z.add(publicFootballGame(e));}catch(Exception ignored){}return z;});
            cs.submit(()->{try{return new WebDataClient(c).fixtures(date);}catch(Exception e){return new ArrayList<>();}});
            if(!fastKey.isEmpty())cs.submit(()->{try{return new FiveDollarFootballClient(c).fixtures(fastKey,date);}catch(Exception e){return new ArrayList<>();}});
            if(key!=null&&!key.trim().isEmpty())cs.submit(()->{try{return fetchApiFootballFixtures(date,key.trim());}catch(Exception e){return new ArrayList<>();}});
            long deadline=System.currentTimeMillis()+7200L;int received=0,rawEvents=seed==null?0:seed.size();while(received<workers){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{Future<ArrayList<Game>> f=cs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;ArrayList<Game> got=f.get();if(got!=null){rawEvents+=got.size();out=mergeGames(out,got);}received++;}catch(Exception ignored){received++;}}ex.shutdownNow();sortGames(out);if(!out.isEmpty())cachePublicGames("fixtures_v6105_"+date,out);System.out.println("[JP_HOME] stage=expanded rawEvents="+rawEvents+" validEvents="+out.size()+" afterDedup="+out.size()+" displayedEvents="+out.size()+" sourcesReceived="+received+"/"+workers+" date="+date+" timezone=America/Sao_Paulo");ok.accept(out);
        }catch(Exception ignored){ok.accept(seed==null?new ArrayList<>():seed);}
    }).start();}

    /** Reads API-Football pagination when the provider advertises more than one page. */
    ArrayList<Game> fetchApiFootballFixtures(String date,String key)throws Exception{
        String base="fixtures?date="+date+"&timezone=America%2FSao_Paulo";String raw=get(base,key);ArrayList<Game> out=parseGamesRoot(raw);int current=1,total=1;try{JSONObject root=new JSONObject(raw),paging=root.optJSONObject("paging");if(paging!=null){current=Math.max(1,paging.optInt("current",1));total=Math.max(current,paging.optInt("total",current));}}catch(Exception ignored){}int pagesRead=1;for(int page=current+1;page<=total;page++){String next=get(base+"&page="+page,key);ArrayList<Game> got=parseGamesRoot(next);out=mergeGames(out,got);pagesRead++;}System.out.println("[JP_HOME] api=API-Football pagination="+pagesRead+"/"+total+" rawEvents="+out.size()+" date="+date);return out;
    }

    static void report(ResearchProgress p,int percent,String stage){if(p!=null)try{p.onProgress(Math.max(0,Math.min(100,percent)),stage);}catch(Exception ignored){}}
    Game publicFootballGame(MultiSportClient.Event e){Game g=new Game(e==null?0:e.id,0,0,0,0,e==null?"":e.home,e==null?"":e.away,e==null?"":e.homeLogo,e==null?"":e.awayLogo,e==null?"":e.competition,(e==null?"":e.date)+"|"+(e==null?"":e.time),e==null?"NS":safeStatus(e.status));if(e!=null){int[] sc=scorePair(e.score);g.homeGoals=sc[0];g.awayGoals=sc[1];}return g;}
    static String safeStatus(String s){if(s==null||s.trim().isEmpty())return "NS";String x=s.toLowerCase(Locale.ROOT);if(x.contains("notstarted")||x.contains("not started")||x.contains("scheduled"))return "NS";if(x.contains("finished")||x.contains("final"))return "FT";if(x.contains("inprogress")||x.contains("live"))return "LIVE";return s;}
    static int[] scorePair(String s){int[] z={-1,-1};if(s==null)return z;java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{1,3})\\s*(?:×|x|-|–|:)\\s*(\\d{1,3})").matcher(s);if(m.find())try{z[0]=Integer.parseInt(m.group(1));z[1]=Integer.parseInt(m.group(2));}catch(Exception ignored){}return z;}
    static ArrayList<Game> mergeGames(ArrayList<Game> a,ArrayList<Game> b){LinkedHashMap<String,Game> m=new LinkedHashMap<>();if(a!=null)for(Game g:a)mergeGameInto(m,g);if(b!=null)for(Game g:b)mergeGameInto(m,g);return new ArrayList<>(m.values());}
    static void mergeGameInto(LinkedHashMap<String,Game> m,Game g){if(g==null)return;String k=gameKey(g);Game old=m.get(k);if(old==null){m.put(k,g);return;}mergeProviderIds(old,g);if(old.fixtureId<=0&&g.fixtureId>0){mergeProviderIds(g,old);m.put(k,g);}}
    static void mergeProviderIds(Game dst,Game src){if(dst==null||src==null)return;if((dst.homeLogo==null||dst.homeLogo.isEmpty())&&src.homeLogo!=null)dst.homeLogo=src.homeLogo;if((dst.awayLogo==null||dst.awayLogo.isEmpty())&&src.awayLogo!=null)dst.awayLogo=src.awayLogo;if(dst.fiveId<=0&&src.fiveId>0)dst.fiveId=src.fiveId;if(dst.fiveHomeId<=0&&src.fiveHomeId>0)dst.fiveHomeId=src.fiveHomeId;if(dst.fiveAwayId<=0&&src.fiveAwayId>0)dst.fiveAwayId=src.fiveAwayId;if(dst.fiveLeagueId<=0&&src.fiveLeagueId>0)dst.fiveLeagueId=src.fiveLeagueId;if(dst.homeGoals<0&&src.homeGoals>=0)dst.homeGoals=src.homeGoals;if(dst.awayGoals<0&&src.awayGoals>=0)dst.awayGoals=src.awayGoals;if((dst.status==null||dst.status.isEmpty()||"NS".equals(dst.status))&&src.status!=null&&!src.status.isEmpty())dst.status=src.status;}
    static String gameKey(Game g){return g==null?"":norm(g.home)+"|"+norm(g.away)+"|"+(g.time==null?"":g.time.length()>=10?g.time.substring(0,10):g.time);}
    void cachePublicGames(String key,ArrayList<Game> gs){try{JSONArray a=new JSONArray();for(Game g:gs){JSONObject o=new JSONObject();o.put("homeLogo",g.homeLogo);o.put("awayLogo",g.awayLogo);o.put("home",g.home);o.put("away",g.away);o.put("league",g.league);o.put("time",g.time);o.put("status",g.status);o.put("hg",g.homeGoals);o.put("ag",g.awayGoals);o.put("five",g.fiveId);o.put("fiveH",g.fiveHomeId);o.put("fiveA",g.fiveAwayId);o.put("fiveL",g.fiveLeagueId);a.put(o);}c.getSharedPreferences("jp_cache",0).edit().putString(key+"_public",a.toString()).putLong(key+"_public_ts",System.currentTimeMillis()).apply();}catch(Exception ignored){}}
    ArrayList<Game> readCachedPublicGames(String key,long maxAge){try{android.content.SharedPreferences p=c.getSharedPreferences("jp_cache",0);String raw=p.getString(key+"_public",null);long ts=p.getLong(key+"_public_ts",0);if(raw==null||ts<=0||System.currentTimeMillis()-ts>maxAge)return new ArrayList<>();return parsePublicGames(raw);}catch(Exception e){return new ArrayList<>();}}
    ArrayList<Game> parsePublicGames(String raw)throws Exception{ArrayList<Game> out=new ArrayList<>();JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Game g=new Game(0,0,0,0,0,o.optString("home"),o.optString("away"),o.optString("homeLogo",""),o.optString("awayLogo",""),o.optString("league"),o.optString("time"),o.optString("status","NS"));g.homeGoals=o.optInt("hg",-1);g.awayGoals=o.optInt("ag",-1);g.fiveId=o.optLong("five",0);g.fiveHomeId=o.optLong("fiveH",0);g.fiveAwayId=o.optLong("fiveA",0);g.fiveLeagueId=o.optLong("fiveL",0);out.add(g);}return out;}

    void prefetchPublicHistory(List<Game> gs){if(gs==null||gs.isEmpty())return;ArrayList<MultiSportClient.Event> evs=new ArrayList<>();for(int i=0;i<Math.min(4,gs.size());i++)evs.add(footballEvent(gs.get(i)));new MultiSportWebClient(c).prefetch(MultiSportClient.FOOTBALL,evs);}

    // Agenda pública reutilizável para live, busca e pré-carregamento. 6.10: fontes independentes
    // rodam em paralelo e nenhuma resposta lenta pode segurar a agenda inteira.
    ArrayList<Game> publicFootballGames(String date){
        final String d=(date==null||date.trim().isEmpty())?today():date.trim();ArrayList<Game> out=new ArrayList<>();
        ExecutorService ex=Executors.newFixedThreadPool(2);CompletionService<ArrayList<Game>> cs=new ExecutorCompletionService<>(ex);
        cs.submit(()->{ArrayList<Game> z=new ArrayList<>();try{for(MultiSportClient.Event e:new MultiSportClient(c).loadPublicSchedule(MultiSportClient.FOOTBALL,d))z.add(publicFootballGame(e));}catch(Exception ignored){}return z;});
        cs.submit(()->{try{return new WebDataClient(c).fixtures(d);}catch(Exception e){return new ArrayList<>();}});
        long deadline=System.currentTimeMillis()+3200L;int received=0;while(received<2){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{Future<ArrayList<Game>> f=cs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;out=mergeGames(out,f.get());received++;}catch(Exception ignored){received++;}}ex.shutdownNow();
        if(out.isEmpty())out=readCachedPublicGames("public_football_v610_"+d,7L*24*60*60*1000L);sortGames(out);if(!out.isEmpty())cachePublicGames("public_football_v610_"+d,out);return out;
    }

    void fixturesWindow(String start,int days,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{try{ArrayList<Game> out=new WebDataClient(c).fixturesWindow(start,days);sortGames(out);ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}
    void live(String key,Consumer<ArrayList<Game>> ok,Consumer<String> err){live(key,null,ok,err);}
    void live(String key,ResearchProgress progress,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{try{
        report(progress,8,"Consultando placares ao vivo em paralelo");ArrayList<Game> out=new ArrayList<>();String fastKey=FiveDollarFootballClient.key(c);int workers=fastKey.isEmpty()?1:2;ExecutorService ex=Executors.newFixedThreadPool(workers);CompletionService<ArrayList<Game>> cs=new ExecutorCompletionService<>(ex);
        cs.submit(()->{ArrayList<Game> z=new ArrayList<>();try{for(Game g:publicFootballGames(today()))if(isLiveStatus(g.status))z.add(g);}catch(Exception ignored){}return z;});
        if(!fastKey.isEmpty())cs.submit(()->{try{return new FiveDollarFootballClient(c).live(fastKey);}catch(Exception e){return new ArrayList<>();}});
        long deadline=System.currentTimeMillis()+3500L;int received=0;while(received<workers){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{Future<ArrayList<Game>> f=cs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;out=mergeGames(out,f.get());received++;}catch(Exception ignored){received++;}}ex.shutdownNow();
        report(progress,62,"Placares públicos + FAST cruzados");if(out.isEmpty()&&key!=null&&!key.trim().isEmpty()){report(progress,76,"Sem live rápido • API complementar");ExecutorService ax=Executors.newSingleThreadExecutor();Future<ArrayList<Game>> af=ax.submit(()->{try{return parseGamesRoot(get("fixtures?live=all&timezone=America%2FSao_Paulo",key.trim()));}catch(Exception e){return new ArrayList<>();}});try{out=mergeGames(out,af.get(1800,TimeUnit.MILLISECONDS));}catch(Exception ignored){af.cancel(true);}ax.shutdownNow();}
        Collections.sort(out,(x,y)->safeStr(x.league).compareToIgnoreCase(safeStr(y.league)));report(progress,100,"Ao vivo atualizado • "+out.size()+" jogos");ok.accept(out);
    }catch(Exception e){report(progress,100,"Ao vivo concluído com cobertura parcial");err.accept(e.getMessage());}}).start();}
    static boolean isLiveStatus(String s){String x=safeStr(s).toLowerCase(Locale.ROOT);return x.contains("live")||x.contains("inprogress")||x.equals("1h")||x.equals("2h")||x.equals("ht")||x.equals("et")||x.equals("p")||x.equals("int");}

    void search(String key,String query,Consumer<ArrayList<Game>> ok,Consumer<String> err){search(key,query,null,ok,err);}
    void search(String key,String query,ResearchProgress progress,Consumer<ArrayList<Game>> ok,Consumer<String> err){new Thread(()->{
        try{
            report(progress,8,"Resolvendo aliases e nomes alternativos");ArrayList<String> vars=TeamIdentityResolver.variants(c,query);if(vars.isEmpty())vars.add(query);ArrayList<Game> web=new ArrayList<>();
            int count=Math.min(4,vars.size());ExecutorService sx=Executors.newFixedThreadPool(Math.max(1,count));CompletionService<ArrayList<Game>> scs=new ExecutorCompletionService<>(sx);for(int i=0;i<count;i++){final String v=vars.get(i);scs.submit(()->{try{return new WebDataClient(c).search(v);}catch(Exception e){return new ArrayList<>();}});}long sdl=System.currentTimeMillis()+2800L;int got=0;while(got<count){long left=sdl-System.currentTimeMillis();if(left<=0)break;try{Future<ArrayList<Game>> f=scs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;web=mergeGames(web,f.get());got++;report(progress,18+Math.min(22,got*7),"Catálogo público • "+web.size()+" resultados");if(web.size()>=4)break;}catch(Exception ignored){got++;}}sx.shutdownNow();
            if(web.isEmpty())try{web=new WebDataClient(c).search(query);}catch(Exception ignored){}
            // Se o catálogo não achou, varre agenda pública futura antes de gastar API.
            if(web.isEmpty()){report(progress,46,"Busca ampliada • agenda pública futura");ExecutorService ex=Executors.newFixedThreadPool(5);ArrayList<Future<ArrayList<Game>>> fs=new ArrayList<>();for(int d=0;d<10;d++){final int off=d;fs.add(ex.submit(()->{try{return publicFootballGames(future(off));}catch(Exception e){return new ArrayList<>();}}));}for(Future<ArrayList<Game>> f:fs)try{for(Game g:f.get(7,TimeUnit.SECONDS))if(searchGameMatches(query,vars,g))web=mergeGames(web,new ArrayList<>(Collections.singletonList(g)));}catch(Exception ignored){}ex.shutdownNow();}
            if(!web.isEmpty()){sortGames(web);report(progress,100,"Busca pública concluída • "+web.size()+" confrontos");ok.accept(web);return;}
            ArrayList<Game> all=new ArrayList<>();if(key!=null&&!key.trim().isEmpty()){report(progress,78,"Internet sem confronto • API complementar");for(String v:vars){try{all=searchApi(key.trim(),v);if(!all.isEmpty())break;}catch(Exception ignored){}}}
            sortGames(all);report(progress,100,"Busca concluída • "+all.size()+" confrontos");ok.accept(all);
        }catch(Exception e){report(progress,100,"Busca concluída com cobertura parcial");err.accept(e.getMessage());}
    }).start();}
    static boolean searchGameMatches(String query,List<String> vars,Game g){if(g==null)return false;String hay=safeStr(g.home)+" "+safeStr(g.away)+" "+safeStr(g.league);if(teamScore(query,hay)>=55||norm(hay).contains(norm(query)))return true;for(String v:vars)if(TeamIdentityResolver.matches(v,g.home)||TeamIdentityResolver.matches(v,g.away)||norm(hay).contains(norm(v)))return true;return false;}

    ArrayList<Game> searchApi(String key,String query)throws Exception{
        String q=URLEncoder.encode(query,"UTF-8");ArrayList<Game> all=new ArrayList<>();HashSet<Long> seen=new HashSet<>();
        try{
            JSONArray teams=new JSONObject(get("teams?search="+q,key)).optJSONArray("response");
            if(teams!=null)for(int ti=0;ti<Math.min(2,teams.length());ti++){
                int id=teams.getJSONObject(ti).getJSONObject("team").optInt("id");if(id<=0)continue;
                JSONArray ar=new JSONObject(get("fixtures?team="+id+"&from="+today()+"&to="+future(120)+"&timezone=America%2FSao_Paulo",key)).optJSONArray("response");
                if(ar!=null)for(int i=0;i<ar.length();i++){Game g=parseGame(ar.getJSONObject(i));if(seen.add(g.fixtureId))all.add(g);}
            }
        }catch(Exception ignored){}
        if(!all.isEmpty())return all;
        try{
            JSONArray leagues=new JSONObject(get("leagues?search="+q,key)).optJSONArray("response");
            if(leagues!=null)for(int i=0;i<Math.min(3,leagues.length());i++){
                JSONObject item=leagues.getJSONObject(i),lg=item.optJSONObject("league");if(lg==null)continue;int lid=lg.optInt("id");int season=currentSeason(item.optJSONArray("seasons"));if(lid<=0||season<=0)continue;
                JSONArray ar=new JSONObject(get("fixtures?league="+lid+"&season="+season+"&from="+today()+"&to="+future(120)+"&timezone=America%2FSao_Paulo",key)).optJSONArray("response");
                if(ar!=null)for(int j=0;j<ar.length();j++){Game g=parseGame(ar.getJSONObject(j));if(seen.add(g.fixtureId))all.add(g);}
            }
        }catch(Exception ignored){}
        return all;
    }
    static int currentSeason(JSONArray a){int best=0;if(a==null)return 0;for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s==null)continue;int y=s.optInt("year");if(s.optBoolean("current",false))return y;if(y>best)best=y;}return best;}
    static void sortGames(ArrayList<Game> a){Collections.sort(a,(x,y)->{int t=safeStr(x.time).compareTo(safeStr(y.time));return t!=0?t:safeStr(x.league).compareToIgnoreCase(safeStr(y.league));});}
    static String safeStr(String s){return s==null?"":s;}

    static Game parseGame(JSONObject o)throws Exception{
        JSONObject f=o.getJSONObject("fixture"),teams=o.getJSONObject("teams"),lg=o.getJSONObject("league"),ho=teams.getJSONObject("home"),aw=teams.getJSONObject("away"),st=f.getJSONObject("status");
        String iso=f.optString("date","");String day=iso.length()>=10?iso.substring(0,10):"";String tm=iso.length()>=16?iso.substring(11,16):"--:--";String when=day.isEmpty()?tm:day+"|"+tm;
        Game g=new Game(f.optLong("id"),ho.optInt("id"),aw.optInt("id"),lg.optInt("id"),lg.optInt("season"),ho.optString("name"),aw.optString("name"),ho.optString("logo"),aw.optString("logo"),lg.optString("name"),when,st.optString("short"));
        JSONObject goals=o.optJSONObject("goals");if(goals!=null){g.homeGoals=goals.isNull("home")?-1:goals.optInt("home",-1);g.awayGoals=goals.isNull("away")?-1:goals.optInt("away",-1);}g.elapsed=st.optInt("elapsed",0);return g;
    }

    void enrich(String key,Game g,String date,Consumer<Game> ok){new Thread(()->{try{
        if(key==null||key.trim().isEmpty()||g==null){ok.accept(g);return;}String k=key.trim();
        // First resolve the exact fixture by the two team names. This is much more reliable
        // than resolving each club independently, especially for names such as SC Internacional.
        Game fx=findFixtureByNames(k,g,date);
        if(fx!=null){copyResolved(g,fx);ok.accept(g);return;}
        JSONObject ht=findTeam(k,g.home),at=findTeam(k,g.away);
        if(ht!=null){g.homeId=ht.optInt("id");g.homeLogo=ht.optString("logo",g.homeLogo);}if(at!=null){g.awayId=at.optInt("id");g.awayLogo=at.optString("logo",g.awayLogo);}
        if(g.homeId>0&&g.awayId>0){Game byId=findFixtureByIds(k,g.homeId,g.awayId,date);if(byId!=null)copyResolved(g,byId);}
        ok.accept(g);
    }catch(Exception e){ok.accept(g);}}).start();}

    Game findFixtureByNames(String key,Game target,String date)throws Exception{
        String d=(date!=null&&date.matches("\\d{4}-\\d{2}-\\d{2}"))?date:today();String raw=fixturesDateCached(key,d);JSONArray ar=new JSONObject(raw).optJSONArray("response");if(ar==null)return null;Game best=null;int bestScore=-1;
        for(int i=0;i<ar.length();i++){Game z=parseGame(ar.getJSONObject(i));int sc=teamScore(target.home,z.home)+teamScore(target.away,z.away);if(sc>bestScore){bestScore=sc;best=z;}if(sc>=190)return z;}return bestScore>=150?best:null;
    }
    Game findFixtureByIds(String key,int home,int away,String date)throws Exception{
        String d=(date!=null&&date.matches("\\d{4}-\\d{2}-\\d{2}"))?date:today();JSONArray ar=new JSONObject(fixturesDateCached(key,d)).optJSONArray("response");if(ar==null)return null;for(int i=0;i<ar.length();i++){Game z=parseGame(ar.getJSONObject(i));if(z.homeId==home&&z.awayId==away)return z;}return null;
    }
    String fixturesDateCached(String key,String date)throws Exception{String ck="fixtures_"+date;long ttl=date.equals(today())?5*60*1000L:60*60*1000L;String raw=cacheGet(ck,ttl);if(raw==null){raw=get("fixtures?date="+date+"&timezone=America%2FSao_Paulo",key);cachePut(ck,raw);}return raw;}
    static void copyResolved(Game g,Game z){if(g==null||z==null)return;g.fixtureId=z.fixtureId;g.homeId=z.homeId;g.awayId=z.awayId;g.leagueId=z.leagueId;g.season=z.season;g.time=z.time;g.status=z.status;g.league=z.league;g.homeLogo=z.homeLogo;g.awayLogo=z.awayLogo;if(z.homeGoals>=0)g.homeGoals=z.homeGoals;if(z.awayGoals>=0)g.awayGoals=z.awayGoals;g.elapsed=z.elapsed;}
    static String[] nearbyDates(String date){ArrayList<String> out=new ArrayList<>();if(date!=null&&date.matches("\\d{4}-\\d{2}-\\d{2}")){try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));java.util.Date base=f.parse(date);for(int off:new int[]{0,-1,1,-2,2}){java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));c.setTime(base);c.add(java.util.Calendar.DAY_OF_MONTH,off);out.add(f.format(c.getTime()));}}catch(Exception ignored){}}if(out.isEmpty())out.add(today());return out.toArray(new String[0]);}

    JSONObject findTeam(String key,String name)throws Exception{
        String target=norm(name);JSONObject best=null;int score=-1;LinkedHashSet<String> queries=new LinkedHashSet<>();queries.add(cleanTeam(name));queries.add(name==null?"":name.trim());String compact=cleanTeam(name).replace("&"," ").replaceAll("\\s+"," ").trim();queries.add(compact);
        for(String q:queries){if(q==null||q.trim().length()<3)continue;String ck="team2_"+norm(q);String raw=cacheGet(ck,7L*24*60*60*1000L);JSONArray ar=null;if(raw!=null){try{ar=new JSONObject(raw).optJSONArray("response");if(ar!=null&&ar.length()==0)raw=null;}catch(Exception ignored){raw=null;}}
            if(raw==null){raw=get("teams?search="+URLEncoder.encode(q.trim(),"UTF-8"),key);ar=new JSONObject(raw).optJSONArray("response");if(ar!=null&&ar.length()>0)cachePut(ck,raw);}else ar=new JSONObject(raw).optJSONArray("response");
            if(ar==null)continue;for(int i=0;i<ar.length();i++){JSONObject item=ar.optJSONObject(i);JSONObject t=item==null?null:item.optJSONObject("team");if(t==null)continue;int sc=teamScore(name,t.optString("name"));if(sc>score){score=sc;best=t;}}
            if(score>=95)break;
        }return score>=55?best:null;
    }
    static String cleanTeam(String n){if(n==null)return "";String x=n.trim();x=x.replaceAll("(?i)^(sc|se|ec|ac|fc|afc|ca)\\s+","");x=x.replaceAll("(?i)\\s+(fc|cf|afc|ec|sc)$","");return x.trim();}
    static String norm(String n){String x=cleanTeam(n);x=java.text.Normalizer.normalize(x,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","");return x.toLowerCase(Locale.ROOT).replace("&","and").replaceAll("[^a-z0-9]","");}
    static int teamScore(String a,String b){String x=norm(a),y=norm(b);if(x.isEmpty()||y.isEmpty())return 0;if(x.equals(y))return 100;if(x.contains(y)||y.contains(x))return 88;int pref=common(x,y);int min=Math.min(x.length(),y.length());int score=min==0?0:(pref*70/min);HashSet<String> ax=tokens(a),by=tokens(b);int hit=0;for(String t:ax)if(by.contains(t))hit++;if(!ax.isEmpty()&&!by.isEmpty())score=Math.max(score,(int)Math.round(70.0*hit/Math.max(ax.size(),by.size())));return score;}
    static HashSet<String> tokens(String s){HashSet<String> out=new HashSet<>();String x=java.text.Normalizer.normalize(cleanTeam(s),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);for(String t:x.split("[^a-z0-9]+"))if(t.length()>2&&!t.equals("club")&&!t.equals("football"))out.add(t);return out;}
    static int common(String a,String b){int n=Math.min(a.length(),b.length()),x=0;for(int i=0;i<n&&a.charAt(i)==b.charAt(i);i++)x++;return x;}

    void lineups(String key,long fixture,Consumer<ArrayList<Lineup>> ok,Consumer<String> err){lineups(key,fixture,false,ok,err);}
    void lineups(String key,long fixture,boolean force,Consumer<ArrayList<Lineup>> ok,Consumer<String> err){new Thread(()->{try{String ck="lineups_"+fixture;String raw=force?null:cacheGet(ck,5*60*1000L);if(raw==null){raw=get("fixtures/lineups?fixture="+fixture,key);cachePut(ck,raw);}JSONArray ar=new JSONObject(raw).optJSONArray("response");ArrayList<Lineup> out=new ArrayList<>();if(ar!=null)for(int i=0;i<ar.length();i++){JSONObject o=ar.getJSONObject(i);Lineup l=new Lineup();l.team=o.getJSONObject("team").optString("name");l.formation=o.optString("formation","—");l.coach=o.optJSONObject("coach")!=null?o.getJSONObject("coach").optString("name","—"):"—";parsePlayers(o.optJSONArray("startXI"),l.start);parsePlayers(o.optJSONArray("substitutes"),l.bench);if(!l.start.isEmpty()||!l.bench.isEmpty())out.add(l);}ok.accept(out);}catch(Exception e){err.accept(e.getMessage());}}).start();}
    static void parsePlayers(JSONArray a,ArrayList<Player> out)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject p=a.getJSONObject(i).getJSONObject("player");out.add(new Player(p.optInt("id"),p.optInt("number"),p.optString("name"),p.optString("grid")));}}

    void stats(String key,long fixture,Consumer<Stats> ok,Consumer<String> err){new Thread(()->{try{ok.accept(parseStats(getCachedFixtureStats(key,fixture)));}catch(Exception e){err.accept(e.getMessage());}}).start();}
    Stats parseStats(String raw)throws Exception{
        JSONArray ar=new JSONObject(raw).optJSONArray("response");Stats s=new Stats();if(ar==null||ar.length()<2)return s;JSONObject A=ar.getJSONObject(0),B=ar.getJSONObject(1);HashMap<String,String> x=mapStats(A.optJSONArray("statistics")),y=mapStats(B.optJSONArray("statistics"));
        String[][] defs={{"Ball Possession","Posse de bola"},{"Total Shots","Finalizações"},{"Shots on Goal","Chutes no alvo"},{"Shots off Goal","Fora do alvo"},{"Blocked Shots","Chutes bloqueados"},{"Corner Kicks","Escanteios"},{"Fouls","Faltas"},{"Throwins","Laterais"},{"Throw-ins","Laterais"},{"Goal Kicks","Tiros de meta"},{"Free Kicks","Tiros livres"},{"Offsides","Impedimentos"},{"Yellow Cards","Cartões amarelos"},{"Red Cards","Cartões vermelhos"},{"Goalkeeper Saves","Defesas"},{"Total passes","Passes"},{"Passes accurate","Passes certos"},{"Passes %","Precisão de passes"}};
        HashSet<String> added=new HashSet<>();for(String[] d:defs){if(added.contains(d[1]))continue;if(x.containsKey(d[0])||y.containsKey(d[0])){s.rows.put(d[1],new String[]{x.getOrDefault(d[0],"—"),y.getOrDefault(d[0],"—")});added.add(d[1]);}}
        return s;
    }
    String getCachedFixtureStats(String key,long fixture)throws Exception{String ck="fxstats_"+fixture;String raw=cacheGet(ck,14L*24*60*60*1000L);if(raw==null){raw=get("fixtures/statistics?fixture="+fixture,key);cachePut(ck,raw);}return raw;}

    Prediction predictionSync(String key,long fixture)throws Exception{
        JSONArray ar=new JSONObject(get("predictions?fixture="+fixture,key)).getJSONArray("response");if(ar.length()==0)throw new IOException("Sem previsão disponível");
        JSONObject item=ar.getJSONObject(0),o=item.getJSONObject("predictions");Prediction p=new Prediction();JSONObject pc=o.optJSONObject("percent");
        p.home=pct(pc==null?"":pc.optString("home"));p.draw=pct(pc==null?"":pc.optString("draw"));p.away=pct(pc==null?"":pc.optString("away"));
        p.advice=o.optString("advice","");p.underOver=o.isNull("under_over")?"":o.optString("under_over","");if("null".equalsIgnoreCase(p.underOver))p.underOver="";p.underOver=ptGoalLine(p.underOver);JSONObject w=o.optJSONObject("winner");p.winner=w==null?"":w.optString("name","");
        JSONObject cmp=item.optJSONObject("comparison");if(cmp!=null){String[] ks={"form","att","def","poisson","h2h","goals","total"};String[] pt={"Forma recente","Ataque","Defesa","Poisson","Confronto direto","Gols","Índice geral"};for(int i=0;i<ks.length;i++){JSONObject q=cmp.optJSONObject(ks[i]);if(q!=null){int hv=pct(q.optString("home")),av=pct(q.optString("away"));p.comparison.put(pt[i]+"|H",hv);p.comparison.put(pt[i]+"|A",av);}}}
        JSONObject teams=item.optJSONObject("teams");if(teams!=null){JSONObject hh=teams.optJSONObject("home"),aa=teams.optJSONObject("away");if(hh!=null)p.homeForm=hh.optString("last_5","");if(aa!=null)p.awayForm=aa.optString("last_5","");}
        reconcilePrediction(p);return p;
    }
    void prediction(String key,long fixture,Consumer<Prediction> ok,Consumer<String> err){new Thread(()->{try{ok.accept(predictionSync(key,fixture));}catch(Exception e){err.accept(e.getMessage());}}).start();}

    static String ptGoalLine(String raw){
        if(raw==null)return "";String x=raw.trim();if(x.isEmpty()||"null".equalsIgnoreCase(x))return "";
        String low=x.toLowerCase(Locale.ROOT);String n=x.replaceAll("[^0-9.,]","").replace('.',',');
        if(low.contains("over"))return "Mais de "+(n.isEmpty()?"2,5":n)+" gols";
        if(low.contains("under"))return "Menos de "+(n.isEmpty()?"2,5":n)+" gols";
        return x.replace("Over","Mais de").replace("Under","Menos de");
    }

    static void reconcilePrediction(Prediction p){
        if(p==null)return;int sum=p.home+p.draw+p.away;if(sum<=0)return;
        int rawH=(int)Math.round(100.0*p.home/sum),rawD=(int)Math.round(100.0*p.draw/sum),rawA=100-rawH-rawD;
        double eh=0,ea=0;int n=0;String[] labels={"Forma recente","Ataque","Defesa","Confronto direto","Gols","Índice geral"};
        for(String z:labels){Integer h=p.comparison.get(z+"|H"),a=p.comparison.get(z+"|A");if(h!=null&&a!=null&&h+a>0){eh+=h;ea+=a;n++;}}
        if(n==0){p.home=rawH;p.draw=rawD;p.away=rawA;return;}eh/=n;ea/=n;double gap=Math.abs(eh-ea);
        int evidenceDraw=gap>=25?24:(gap>=15?27:30),pool=100-evidenceDraw;double den=Math.max(1,eh+ea);int eH=(int)Math.round(pool*eh/den),eA=pool-eH;
        boolean tiedTop=(rawH==rawD&&rawH>=rawA)||(rawA==rawD&&rawA>=rawH);boolean contradict=(eh>ea+12&&rawA>rawH)||(ea>eh+12&&rawH>rawA);double blend=(tiedTop||contradict)?0.55:0.35;
        int h=(int)Math.round(rawH*(1-blend)+eH*blend),d=(int)Math.round(rawD*(1-blend)+evidenceDraw*blend),a=100-h-d;
        if(a<8){h-=8-a;a=8;}if(h<8){a-=8-h;h=8;}if(d<16){int need=16-d;d=16;if(h>=a)h-=need;else a-=need;}
        int total=h+d+a;if(total!=100)a+=100-total;p.home=Math.max(0,h);p.draw=Math.max(0,d);p.away=Math.max(0,a);
    }

    void h2h(String key,int home,int away,Consumer<H2H> ok,Consumer<String> err){new Thread(()->{try{JSONArray ar=new JSONObject(get("fixtures/headtohead?h2h="+home+"-"+away+"&last=5",key)).getJSONArray("response");H2H h=new H2H();for(int i=0;i<ar.length();i++){JSONObject o=ar.getJSONObject(i),teams=o.getJSONObject("teams"),goals=o.getJSONObject("goals"),fx=o.getJSONObject("fixture");String hn=teams.getJSONObject("home").optString("name"),an=teams.getJSONObject("away").optString("name");int hg=goals.optInt("home",-1),ag=goals.optInt("away",-1);String d=fx.optString("date","");if(d.length()>=10)d=d.substring(0,10);h.rows.add(d+"  •  "+hn+"  "+(hg<0?"—":hg)+" × "+(ag<0?"—":ag)+"  "+an);int hid=teams.getJSONObject("home").optInt("id");if(hg==ag)h.draws++;else {int win=hg>ag?hid:teams.getJSONObject("away").optInt("id");if(win==home)h.homeWins++;else if(win==away)h.awayWins++;}}ok.accept(h);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    // Unified Research Engine 2.0 for football. 6.9 adds a hard time budget to the normal analysis.
    void deepAnalysis(String key,Game g,Consumer<DeepAnalysis> ok,Consumer<String> err){deepAnalysis(key,g,false,null,ok,err);}
    void deepAnalysis(String key,Game g,ResearchProgress progress,Consumer<DeepAnalysis> ok,Consumer<String> err){deepAnalysis(key,g,false,progress,ok,err);}
    void deepAnalysis(String key,Game g,boolean forceDeep,ResearchProgress progress,Consumer<DeepAnalysis> ok,Consumer<String> err){new Thread(()->{
        try{
            if(g==null)throw new IOException("Confronto inválido");boolean liveNow=isLiveStatus(g.status);String cacheKey="deep_v6107_priority_"+(forceDeep?"deep_":"normal_")+(g.fixtureId>0?g.fixtureId+"_":"")+norm(g.home)+"_"+norm(g.away)+"_"+safeStr(g.status);
            String cached=cacheGet(cacheKey,liveNow?35L*1000L:(forceDeep?8L*60*1000L:35L*60*1000L));if(cached!=null){DeepAnalysis ready=parseDeep(cached);if(ready!=null&&!ready.metrics.isEmpty()){report(progress,100,"Análise instantânea • cache da rota prioritária");ok.accept(ready);return;}}
            long totalDeadline=System.currentTimeMillis()+ResearchRoutePolicy.totalBudget(forceDeep);DeepAnalysis merged=null,fast=null,api=null,web=null,consensus=null;String fastKey=FiveDollarFootballClient.key(c);

            // CAMADA 1 — 5Dollar: primary structured provider. The old 2.2 s window was too short for its batched deep call.
            if(!fastKey.isEmpty()&&FiveDollarFootballClient.budgetAvailable(c,4)&&System.currentTimeMillis()<totalDeadline-800){
                report(progress,6,"5Dollar primária • histórico + odds");ExecutorService fx=Executors.newSingleThreadExecutor();Future<DeepAnalysis> ff=fx.submit(()->{try{return new FiveDollarFootballClient(c).deep(fastKey,g,forceDeep);}catch(Exception e){System.out.println("[JP_API_ROUTE] source=5Dollar status=failed reason="+safeStr(e.getMessage()));return null;}});
                try{long left=Math.min(ResearchRoutePolicy.fiveDollarBudget(forceDeep),totalDeadline-System.currentTimeMillis());if(left>0)fast=ff.get(left,TimeUnit.MILLISECONDS);}catch(Exception ignored){ff.cancel(true);}fx.shutdownNow();merged=mergeDeep(merged,fast);System.out.println("[JP_API_ROUTE] source=5Dollar status="+(fast==null?"empty":"ok")+" coverage="+coveragePercent(merged)+" safeRemaining="+FiveDollarFootballClient.estimatedSafeRemaining(c));
            }else if(!fastKey.isEmpty())System.out.println("[JP_API_ROUTE] source=5Dollar status=reserved safeRemaining="+FiveDollarFootballClient.estimatedSafeRemaining(c));
            else System.out.println("[JP_API_ROUTE] source=5Dollar status=not_configured");

            // CAMADA 2 — API-Football: complement 5Dollar when coverage is short, and always in explicit deep mode.
            int afterFive=coveragePercent(merged),fiveSources=merged==null?0:merged.sourceCount;
            if(key!=null&&!key.trim().isEmpty()&&ResearchRoutePolicy.useApiFootball(forceDeep,afterFive,fiveSources)&&System.currentTimeMillis()<totalDeadline-900){
                report(progress,43,"API-Football • segunda camada estruturada");ExecutorService ax=Executors.newSingleThreadExecutor();Future<DeepAnalysis> af=ax.submit(()->{try{Game resolved=g;if(resolved.homeId<=0||resolved.awayId<=0){Game fx=findFixtureByNames(key.trim(),resolved,dateOf(resolved));if(fx!=null)copyResolved(resolved,fx);}return resolved.homeId>0&&resolved.awayId>0?deepAnalysisApiSync(key.trim(),resolved):null;}catch(Exception e){System.out.println("[JP_API_ROUTE] source=API-Football status=failed reason="+safeStr(e.getMessage()));return null;}});
                try{long left=Math.min(ResearchRoutePolicy.apiFootballBudget(forceDeep),totalDeadline-System.currentTimeMillis());if(left>0)api=af.get(left,TimeUnit.MILLISECONDS);}catch(Exception ignored){af.cancel(true);}ax.shutdownNow();merged=mergeDeep(merged,api);System.out.println("[JP_API_ROUTE] source=API-Football status="+(api==null?"empty":"ok")+" coverage="+coveragePercent(merged));
            }else if(key==null||key.trim().isEmpty())System.out.println("[JP_API_ROUTE] source=API-Football status=not_configured");
            else System.out.println("[JP_API_ROUTE] source=API-Football status=skipped coverage="+afterFive);

            // CAMADA 3 — internet/public consensus. It enriches, but no longer races ahead of the configured APIs.
            int structuredCoverage=coveragePercent(merged),structuredSources=merged==null?0:merged.sourceCount;
            if(ResearchRoutePolicy.useInternet(forceDeep,structuredCoverage,structuredSources)&&System.currentTimeMillis()<totalDeadline-650){
                report(progress,70,"Internet • terceira camada de confirmação");ExecutorService wx=Executors.newFixedThreadPool(2);CompletionService<DeepAnalysis> cs=new ExecutorCompletionService<>(wx);
                cs.submit(()->{try{return new InternetStatsClient(c).analyze(g,forceDeep?14:10,forceDeep?8:6,forceDeep?7:5);}catch(Exception e){return null;}});
                cs.submit(()->{try{MultiSportClient.Event ev=footballEvent(g);MultiSportWebClient.Research rr=new MultiSportWebClient(c).researchPublicOnly(MultiSportClient.FOOTBALL,ev,forceDeep,null);return rr==null?null:footballConsensusToDeep(ev,rr);}catch(Exception e){return null;}});
                long internetDeadline=Math.min(totalDeadline,System.currentTimeMillis()+ResearchRoutePolicy.internetBudget(forceDeep));int got=0;while(got<2){long left=internetDeadline-System.currentTimeMillis();if(left<=0)break;try{Future<DeepAnalysis> f=cs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;DeepAnalysis d=f.get();if(d!=null){if(web==null)web=d;else consensus=d;}got++;}catch(Exception ignored){got++;}}wx.shutdownNow();merged=mergeDeep(merged,web);merged=mergeDeep(merged,consensus);System.out.println("[JP_API_ROUTE] source=Internet status="+((web!=null||consensus!=null)?"ok":"empty")+" coverage="+coveragePercent(merged));
            }else System.out.println("[JP_API_ROUTE] source=Internet status=skipped coverage="+structuredCoverage);

            if(merged==null)merged=new DeepAnalysis();if(!merged.metrics.containsKey("Gols")&&System.currentTimeMillis()<totalDeadline-120){final DeepAnalysis goalTarget=merged;ExecutorService gx=Executors.newSingleThreadExecutor();Future<?> gf=gx.submit(()->ensureGoalFallback(goalTarget,g,forceDeep?14:10,forceDeep?7:5));try{long left=Math.min(forceDeep?2200L:650L,totalDeadline-System.currentTimeMillis());if(left>0)gf.get(left,TimeUnit.MILLISECONDS);}catch(Exception ignored){}gx.shutdownNow();}
            if(merged.metrics.isEmpty())throw new IOException("Não encontrei histórico suficiente nas fontes disponíveis");
            if((merged.marketOdds==null||merged.marketOdds.isEmpty())&&key!=null&&!key.trim().isEmpty()&&g.fixtureId>0&&System.currentTimeMillis()<totalDeadline-350){final DeepAnalysis target=merged;ExecutorService ox=Executors.newSingleThreadExecutor();Future<MarketOddsBook> of=ox.submit(()->{try{return StatisticalCalibrationEngine.isPregameStatus(g.status)?new MarketOddsClient(c).football(key.trim(),g):(isLiveStatus(g.status)?new MarketOddsClient(c).footballLive(key.trim(),g):new MarketOddsBook());}catch(Exception e){return new MarketOddsBook();}});try{long left=Math.min(forceDeep?1200L:550L,totalDeadline-System.currentTimeMillis());if(left>0){MarketOddsBook mb=of.get(left,TimeUnit.MILLISECONDS);if(mb!=null&&!mb.isEmpty())target.marketOdds=mb;}}catch(Exception ignored){}ox.shutdownNow();}
            applyMarketSanity(merged);merged.complete=true;if(merged.sources==null||merged.sources.trim().isEmpty())merged.sources="Internet pública";merged.note="Research 6.10.7: 5Dollar primária → API-Football complementar → internet de confirmação. Cache e reserva horária protegem a cota sem reduzir a profundidade disponível.";cachePut(cacheKey,deepJson(merged).toString());report(progress,100,forceDeep?"Análise Profunda concluída":"Análise prioritária concluída");ok.accept(merged);
        }catch(Exception e){report(progress,100,"Análise concluída com cobertura limitada");err.accept(e.getMessage());}
    }).start();}
    MultiSportClient.Event footballEvent(Game g){MultiSportClient.Event e=new MultiSportClient.Event(MultiSportClient.FOOTBALL);e.apiSource=(g.homeId>0&&g.awayId>0)?MultiSportClient.FOOTBALL:"public-football";e.id=g.fixtureId;e.homeId=g.homeId;e.awayId=g.awayId;e.leagueId=g.leagueId;e.season=String.valueOf(g.season);e.home=g.home;e.away=g.away;e.homeLogo=g.homeLogo;e.awayLogo=g.awayLogo;e.competition=g.league;e.status=g.status;e.date=dateOf(g);String t=g.time;if(t!=null&&t.contains("|")){String[] z=t.split("\\|",-1);if(z.length>1)e.time=z[1];}return e;}
    DeepAnalysis footballConsensusToDeep(MultiSportClient.Event ev,MultiSportWebClient.Research r){
        SportConsensusEngine.Consensus cc=SportConsensusEngine.analyze(MultiSportClient.FOOTBALL,ev,r);if(cc==null||!cc.usable())return null;DeepAnalysis d=new DeepAnalysis();
        Series h=publicSeries(r==null?null:r.mergedHome,ev.home,ev.homeId,null),a=publicSeries(r==null?null:r.mergedAway,ev.away,ev.awayId,null);
        Series hv=publicSeries(r==null?null:r.mergedHome,ev.home,ev.homeId,Boolean.TRUE),av=publicSeries(r==null?null:r.mergedAway,ev.away,ev.awayId,Boolean.FALSE);
        Series hh=publicSeries(r==null?null:r.mergedH2h,ev.home,ev.homeId,null),ha=publicSeries(r==null?null:r.mergedH2h,ev.away,ev.awayId,null);
        addGoalProjection(d,h,a,hv,av,hh,ha,2.5,3.5,(cc.sourceCount<=1?"Fonte única":"Consensus público")+" • "+cc.sourceCount+" fonte"+(cc.sourceCount==1?"":"s")+" • "+cc.agreement+"% convergência");
        if(!d.metrics.containsKey("Gols")){MetricProjection m=new MetricProjection("Gols");m.home=Double.isNaN(cc.homeFor)?0:cc.homeFor;m.away=Double.isNaN(cc.awayFor)?0:cc.awayFor;m.rawTotal=Double.isNaN(cc.totalMean)?m.home+m.away:cc.totalMean;m.recentMean=cc.totalMean;m.recentMedian=cc.totalMedian;m.stdDev=cc.totalStd;StatisticalCalibrationEngine.GoalSanity gs=StatisticalCalibrationEngine.goalSanity(m.rawTotal,m.recentMean,m.recentMedian,Double.NaN,m.stdDev);m.total=gs.adjustedProjection;m.projectionDivergent=gs.divergent;m.projectionStatus=gs.status;m.projectionReason=gs.reason;m.low=Math.max(0,m.total-(Double.isNaN(cc.totalStd)?1:cc.totalStd));m.high=m.total+(Double.isNaN(cc.totalStd)?1:cc.totalStd);m.line=2.5;m.overProb=poissonOver(m.total,2.5);m.lineHigh=3.5;m.overProbHigh=poissonOver(m.total,3.5);m.sample=cc.homeGames+cc.awayGames;m.source=(cc.sourceCount<=1?"Fonte única":"Consensus público")+" • "+cc.sourceCount+" fonte"+(cc.sourceCount==1?"":"s")+" • "+cc.agreement+"% convergência";d.metrics.put("Gols",m);}
        d.homeMatches=cc.homeGames;d.awayMatches=cc.awayGames;d.homeVenueMatches=hv.n;d.awayVenueMatches=av.n;d.h2hMatches=r==null?0:r.h2h.size();d.sourceCount=cc.sourceCount;d.sourceQuality=cc.sourceQuality;d.agreement=cc.agreement;d.sources="Internet pública + "+cc.sources;d.complete=true;return d;
    }
    static Series publicSeries(List<MultiSportWebClient.GameRow> rows,String team,long id,Boolean homeOnly){Series out=new Series();if(rows==null)return out;int i=0;for(MultiSportWebClient.GameRow g:rows){if(g==null||!g.completed||g.hs<0||g.as<0)continue;boolean home=id>0?g.homeId==id:g.homeSide(team);boolean away=id>0?g.awayId==id:(g.involves(team)&&!g.homeSide(team));if(!home&&!away)continue;if(Boolean.TRUE.equals(homeOnly)&&!home)continue;if(Boolean.FALSE.equals(homeOnly)&&!away)continue;double f=home?g.hs:g.as,a=home?g.as:g.hs;double confirm=1.0+Math.min(.18,Math.max(0,g.confirmations()-1)*.06);double conflict=g.sourceConflict?.60:1.0;out.add(f,a,weight(i++)*confirm*conflict);}return out;}

    DeepAnalysis deepAnalysisApiSync(String key,Game g)throws Exception{
        final int RECENT=6,H2H=3; // supplement only: keep API usage economical
        ExecutorService lists=Executors.newFixedThreadPool(3);
        Future<ArrayList<Game>> fh=lists.submit(()->safeRecentOtherGames(key,g.homeId,g.awayId,RECENT));
        Future<ArrayList<Game>> fa=lists.submit(()->safeRecentOtherGames(key,g.awayId,g.homeId,RECENT));
        Future<ArrayList<Game>> fhh=lists.submit(()->safeH2hGames(key,g.homeId,g.awayId,H2H));
        ArrayList<Game> h=fh.get(7,TimeUnit.SECONDS),a=fa.get(7,TimeUnit.SECONDS),hh=fhh.get(7,TimeUnit.SECONDS);lists.shutdownNow();
        Series hg=new Series(),ag=new Series(),hgh=new Series(),agh=new Series();
        accumulateGoals(h,g.homeId,hg);accumulateGoals(a,g.awayId,ag);accumulateGoals(hh,g.homeId,hgh);accumulateGoals(hh,g.awayId,agh);
        DeepAnalysis d=new DeepAnalysis();d.homeMatches=h.size();d.awayMatches=a.size();d.h2hMatches=hh.size();d.sourceCount=1;d.sourceQuality=90;d.agreement=45;d.sources="API-Football (complemento)";
        LinkedHashMap<String,Series> hs=new LinkedHashMap<>(),as=new LinkedHashMap<>(),hhs=new LinkedHashMap<>(),has=new LinkedHashMap<>();
        String[] metrics={"Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};
        for(String m:metrics){hs.put(m,new Series());as.put(m,new Series());hhs.put(m,new Series());has.put(m,new Series());}
        prefetchFixtureStats(key,h,a,hh);fetchSeries(key,h,g.homeId,hs);fetchSeries(key,a,g.awayId,as);fetchSeries(key,hh,g.homeId,hhs);fetchSeries(key,hh,g.awayId,has);
        addProjectionV3(d,"Gols",hg,ag,hgh,agh,2.5,3.5);markSource(d,"Gols","API");
        addProjectionV3(d,"Escanteios",hs.get("Escanteios"),as.get("Escanteios"),hhs.get("Escanteios"),has.get("Escanteios"),8.5,10.5);markSource(d,"Escanteios","API");
        addProjectionV3(d,"Laterais",hs.get("Laterais"),as.get("Laterais"),hhs.get("Laterais"),has.get("Laterais"),dynamicLineV3(hs.get("Laterais"),as.get("Laterais"),hhs.get("Laterais"),has.get("Laterais"),2),-1);markSource(d,"Laterais","API");
        addProjectionV3(d,"Tiros de meta",hs.get("Tiros de meta"),as.get("Tiros de meta"),hhs.get("Tiros de meta"),has.get("Tiros de meta"),dynamicLineV3(hs.get("Tiros de meta"),as.get("Tiros de meta"),hhs.get("Tiros de meta"),has.get("Tiros de meta"),2),-1);markSource(d,"Tiros de meta","API");
        addProjectionV3(d,"Faltas",hs.get("Faltas"),as.get("Faltas"),hhs.get("Faltas"),has.get("Faltas"),dynamicLineV3(hs.get("Faltas"),as.get("Faltas"),hhs.get("Faltas"),has.get("Faltas"),2),-1);markSource(d,"Faltas","API");
        addProjectionV3(d,"Finalizações",hs.get("Finalizações"),as.get("Finalizações"),hhs.get("Finalizações"),has.get("Finalizações"),dynamicLineV3(hs.get("Finalizações"),as.get("Finalizações"),hhs.get("Finalizações"),has.get("Finalizações"),2),-1);markSource(d,"Finalizações","API");
        addProjectionV3(d,"Chutes no alvo",hs.get("Chutes no alvo"),as.get("Chutes no alvo"),hhs.get("Chutes no alvo"),has.get("Chutes no alvo"),7.5,9.5);markSource(d,"Chutes no alvo","API");
        addProjectionV3(d,"Impedimentos",hs.get("Impedimentos"),as.get("Impedimentos"),hhs.get("Impedimentos"),has.get("Impedimentos"),3.5,5.5);markSource(d,"Impedimentos","API");
        addProjectionV3(d,"Cartões amarelos",hs.get("Cartões amarelos"),as.get("Cartões amarelos"),hhs.get("Cartões amarelos"),has.get("Cartões amarelos"),3.5,5.5);markSource(d,"Cartões amarelos","API");
        addProjectionV3(d,"Tiros livres",hs.get("Tiros livres"),as.get("Tiros livres"),hhs.get("Tiros livres"),has.get("Tiros livres"),dynamicLineV3(hs.get("Tiros livres"),as.get("Tiros livres"),hhs.get("Tiros livres"),has.get("Tiros livres"),2),-1);markSource(d,"Tiros livres","API");
        d.complete=!d.metrics.isEmpty();return d;
    }
    static void markSource(DeepAnalysis d,String name,String src){MetricProjection m=d.metrics.get(name);if(m!=null)m.source=src;}
    static DeepAnalysis mergeDeep(DeepAnalysis web,DeepAnalysis api){
        if(web==null&&api==null)return null;if(web==null)return api;if(api==null)return web;DeepAnalysis d=new DeepAnalysis();
        d.homeMatches=Math.max(web.homeMatches,api.homeMatches);d.awayMatches=Math.max(web.awayMatches,api.awayMatches);d.h2hMatches=Math.max(web.h2hMatches,api.h2hMatches);d.homeVenueMatches=Math.max(web.homeVenueMatches,api.homeVenueMatches);d.awayVenueMatches=Math.max(web.awayVenueMatches,api.awayVenueMatches);d.sourceCount=Math.max(2,web.sourceCount+api.sourceCount);d.sourceQuality=Math.max(web.sourceQuality,api.sourceQuality);d.agreement=Math.max(web.agreement,api.agreement);d.sources=mergeSourceNames(web.sources,api.sources);
        LinkedHashSet<String> names=new LinkedHashSet<>();names.addAll(web.metrics.keySet());names.addAll(api.metrics.keySet());
        for(String n:names){MetricProjection w=web.metrics.get(n),a=api.metrics.get(n);MetricProjection pick;if(w==null)pick=a;else if(a==null)pick=w;else pick=(w.sample>=Math.max(5,a.sample-1))?w:a;d.metrics.put(n,pick);}d.marketOdds.merge(web.marketOdds);d.marketOdds.merge(api.marketOdds);d.complete=!d.metrics.isEmpty();return d;
    }
    static String mergeSourceNames(String a,String b){String x=safeStr(a).trim(),y=safeStr(b).trim();if(x.isEmpty())return y;if(y.isEmpty())return x;if(norm(x).contains(norm(y)))return x;if(norm(y).contains(norm(x)))return y;return x+" + "+y;}
    static void applyMarketSanity(DeepAnalysis d){if(d==null||d.marketOdds==null||d.marketOdds.isEmpty())return;MetricProjection m=d.metrics.get("Gols");if(m==null)return;double line=d.marketOdds.mainTotalLine();if(Double.isNaN(line))return;m.marketLine=line;StatisticalCalibrationEngine.GoalSanity gs=StatisticalCalibrationEngine.goalSanity(Double.isNaN(m.rawTotal)?m.total:m.rawTotal,m.recentMean,m.recentMedian,line,m.stdDev);m.total=gs.adjustedProjection;m.projectionDivergent=m.projectionDivergent||gs.divergent;if(gs.divergent){m.projectionStatus=gs.status;m.projectionReason=gs.reason;}if(m.line>0)m.overProb=poissonOver(m.total,m.line);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);}

    void ensureGoalFallback(DeepAnalysis d,Game g,int recent,int h2h){try{WebDataClient web=new WebDataClient(c);Series h=web.recentGoalSeries(g.home,g.away,recent),a=web.recentGoalSeries(g.away,g.home,recent),hh=web.h2hGoalSeries(g.home,g.away,h2h),ha=web.h2hGoalSeries(g.away,g.home,h2h),hv=web.venueGoalSeries(g.home,true,6),av=web.venueGoalSeries(g.away,false,6);d.homeMatches=Math.max(d.homeMatches,h.n);d.awayMatches=Math.max(d.awayMatches,a.n);d.homeVenueMatches=Math.max(d.homeVenueMatches,hv.n);d.awayVenueMatches=Math.max(d.awayVenueMatches,av.n);d.h2hMatches=Math.max(d.h2hMatches,Math.min(hh.n,ha.n));if(!d.metrics.containsKey("Gols")){addGoalProjection(d,h,a,hv,av,hh,ha,2.5,3.5,"OpenFootball");}applyLeagueGoalBaseline(d,web.leagueGoalMean(g.league));}catch(Exception ignored){}}
    static void applyLeagueGoalBaseline(DeepAnalysis d,double leagueTotal){if(d==null||Double.isNaN(leagueTotal)||leagueTotal<1.2||leagueTotal>5.5)return;MetricProjection m=d.metrics.get("Gols");if(m==null)return;m.leagueMean=leagueTotal;double current=m.total>0?m.total:(Double.isNaN(m.rawTotal)?Double.NaN:m.rawTotal);if(Double.isNaN(current)||current<=0)return;double adjusted=current*.85+leagueTotal*.15;double scale=adjusted/current;m.home*=scale;m.away*=scale;m.total=adjusted;StatisticalCalibrationEngine.GoalSanity gs=StatisticalCalibrationEngine.goalSanity(m.total,m.recentMean,m.recentMedian,m.marketLine,m.stdDev);m.total=gs.adjustedProjection;double sum=m.home+m.away;if(sum>0){double rescale=m.total/sum;m.home*=rescale;m.away*=rescale;}m.projectionDivergent=m.projectionDivergent||gs.divergent;if(gs.divergent){m.projectionStatus=gs.status;m.projectionReason=gs.reason;}double spread=Math.max(.75,Double.isNaN(m.stdDev)?Math.sqrt(Math.max(.1,m.total)):m.stdDev);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(m.line>0)m.overProb=poissonOver(m.total,m.line);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);}
    static int coveragePercent(DeepAnalysis d){if(d==null)return 0;String[] core={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};double sum=0;for(String n:core){MetricProjection m=d.metrics.get(n);if(m!=null)sum+=Math.min(100,m.sample*100.0/25.0);}return (int)Math.round(sum/core.length);}
    static String dateOf(Game g){if(g!=null&&g.time!=null&&g.time.contains("|")){String x=g.time.substring(0,g.time.indexOf('|'));if(x.matches("\\d{4}-\\d{2}-\\d{2}"))return x;}return today();}

    ArrayList<Game> safeRecentOtherGames(String key,int teamId,int excludeOpponent,int last){try{return recentOtherGames(key,teamId,excludeOpponent,last);}catch(Exception e){return new ArrayList<>();}}
    ArrayList<Game> safeH2hGames(String key,int home,int away,int last){try{return h2hGames(key,home,away,last);}catch(Exception e){return new ArrayList<>();}}

    ArrayList<Game> recentOtherGames(String key,int teamId,int excludeOpponent,int last)throws Exception{
        // Ask for more than five because H2H games are deliberately excluded from this sample.
        int request=Math.max(12,last*3);String ck="recent_other_"+teamId+"_"+excludeOpponent+"_"+last;
        String raw=cacheGet(ck,3*60*60*1000L);if(raw==null){raw=get("fixtures?team="+teamId+"&last="+request+"&timezone=America%2FSao_Paulo",key);cachePut(ck,raw);}
        ArrayList<Game> a=parseGamesRoot(raw);Collections.sort(a,(x,y)->safeStr(y.time).compareTo(safeStr(x.time)));ArrayList<Game> out=new ArrayList<>();
        for(Game z:a){if(z.homeGoals<0||z.awayGoals<0)continue;int opp=z.homeId==teamId?z.awayId:z.homeId;if(opp==excludeOpponent)continue;out.add(z);if(out.size()>=last)break;}return out;
    }
    ArrayList<Game> recentGames(String key,int teamId,int last)throws Exception{return recentOtherGames(key,teamId,-999999,last);}
    ArrayList<Game> h2hGames(String key,int home,int away,int last)throws Exception{
        String ck="h2hdeep_v3_"+home+"_"+away+"_"+last;String raw=cacheGet(ck,6*60*60*1000L);if(raw==null){raw=get("fixtures/headtohead?h2h="+home+"-"+away+"&last="+last,key);cachePut(ck,raw);}ArrayList<Game> a=parseGamesRoot(raw);ArrayList<Game> out=new ArrayList<>();for(Game z:a)if(z.homeGoals>=0&&z.awayGoals>=0){out.add(z);if(out.size()>=last)break;}return out;
    }
    void accumulateGoals(ArrayList<Game> games,int teamId,Series s){int i=0;for(Game g:games){if(g.homeGoals<0||g.awayGoals<0)continue;boolean home=g.homeId==teamId;double f=home?g.homeGoals:g.awayGoals,ag=home?g.awayGoals:g.homeGoals;s.add(f,ag,weight(i++));}}
    static void mergeMissing(Series base,Series fallback,int target){if(base==null||fallback==null||base.n>=target||fallback.weight<=0)return;if(fallback.n>base.n){base.forSum=fallback.forSum;base.againstSum=fallback.againstSum;base.weight=fallback.weight;base.n=Math.min(target,fallback.n);}}

    @SafeVarargs final void prefetchFixtureStats(String key,ArrayList<Game>... groups){
        LinkedHashSet<Long> ids=new LinkedHashSet<>();for(ArrayList<Game> g:groups)if(g!=null)for(Game x:g)if(x.fixtureId>0)ids.add(x.fixtureId);if(ids.isEmpty())return;
        ExecutorService ex=Executors.newFixedThreadPool(Math.min(6,ids.size()));ArrayList<Future<?>> fs=new ArrayList<>();for(Long id:ids)fs.add(ex.submit(()->{try{getCachedFixtureStats(key,id);}catch(Exception ignored){}}));
        long deadline=System.currentTimeMillis()+7000L;for(Future<?> f:fs){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{f.get(left,TimeUnit.MILLISECONDS);}catch(Exception ignored){}}ex.shutdownNow();
    }
    void fetchSeries(String key,ArrayList<Game> games,int teamId,LinkedHashMap<String,Series> dst)throws Exception{
        if(games==null||games.isEmpty())return;int i=0;for(Game fx:games){try{StatSample sm=statSample(key,fx.fixtureId,teamId);double w=weight(i++);for(String name:dst.keySet()){double f=metricValue(sm.team,name),a=metricValue(sm.opp,name);if(!Double.isNaN(f)&&!Double.isNaN(a))dst.get(name).add(f,a,w);}}catch(Exception ignored){i++;}}
    }
    StatSample statSample(String key,long fixture,int teamId)throws Exception{
        JSONArray ar=new JSONObject(getCachedFixtureStats(key,fixture)).optJSONArray("response");StatSample out=new StatSample();if(ar==null)return out;
        for(int i=0;i<ar.length();i++){JSONObject block=ar.optJSONObject(i);if(block==null)continue;JSONObject tm=block.optJSONObject("team");int id=tm==null?0:tm.optInt("id");HashMap<String,Double> target=id==teamId?out.team:out.opp;JSONArray st=block.optJSONArray("statistics");if(st==null)continue;for(int k=0;k<st.length();k++){JSONObject z=st.optJSONObject(k);if(z==null)continue;Object v=z.opt("value");if(v==null||v==JSONObject.NULL)continue;double n=parseNum(String.valueOf(v));if(!Double.isNaN(n))target.put(z.optString("type"),n);}}
        return out;
    }
    static double metricValue(HashMap<String,Double> m,String name){
        String[][] defs={{"Escanteios","Corner Kicks"},{"Laterais","Throwins","Throw-ins","Throw Ins","Throw In"},{"Tiros de meta","Goal Kicks","Goal kicks","Goal Kick"},{"Faltas","Fouls"},{"Finalizações","Total Shots"},{"Chutes no alvo","Shots on Goal"},{"Impedimentos","Offsides"},{"Cartões amarelos","Yellow Cards"},{"Tiros livres","Free Kicks","Free kicks"}};
        for(String[] d:defs)if(d[0].equals(name))for(int i=1;i<d.length;i++)if(m.containsKey(d[i]))return m.get(d[i]);return Double.NaN;
    }
    static double dynamicLineV3(Series home,Series away,Series hh,Series ha,int offset){double hp=projectSide(home,away,hh),ap=projectSide(away,home,ha);double total=hp+ap;if(Double.isNaN(total)||total<1)return -1;return Math.max(.5,Math.floor(total)-offset+.5);}
    static void addProjectionV3(DeepAnalysis d,String name,Series home,Series away,Series h2hHome,Series h2hAway,double line,double lineHigh){
        if("Gols".equals(name)){addGoalProjection(d,home,away,null,null,h2hHome,h2hAway,line,lineHigh,"");return;}
        double hp=projectSide(home,away,h2hHome),ap=projectSide(away,home,h2hAway);if(Double.isNaN(hp)||Double.isNaN(ap))return;MetricProjection m=new MetricProjection(name);m.home=hp;m.away=ap;m.rawTotal=hp+ap;m.total=m.rawTotal;
        int recent=(home==null?0:home.n)+(away==null?0:away.n);int h2=Math.min(h2hHome==null?0:h2hHome.n,h2hAway==null?0:h2hAway.n);m.sample=recent+h2;
        m.recentMean=combinedRecentMean(home,away);m.recentMedian=combinedRecentMedian(home,away);m.stdDev=combinedRecentStd(home,away);
        m.line=line;double spread=Math.max(1.0,Math.sqrt(Math.max(.1,m.total))*1.15);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(line>0)m.overProb=poissonOver(m.total,line);m.lineHigh=lineHigh>0?lineHigh:(line>0?line+2:-1);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);d.metrics.put(name,m);
    }
    static void addGoalProjection(DeepAnalysis d,Series home,Series away,Series homeVenue,Series awayVenue,Series h2hHome,Series h2hAway,double line,double lineHigh,String source){
        double hp=projectGoalSide(home,away,homeVenue,awayVenue,h2hHome,true),ap=projectGoalSide(away,home,awayVenue,homeVenue,h2hAway,false);if(Double.isNaN(hp)||Double.isNaN(ap))return;MetricProjection m=new MetricProjection("Gols");m.home=hp;m.away=ap;m.rawTotal=hp+ap;m.recentMean=combinedRecentMean(home,away);m.recentMedian=combinedRecentMedian(home,away);m.stdDev=combinedRecentStd(home,away);StatisticalCalibrationEngine.GoalSanity gs=StatisticalCalibrationEngine.goalSanity(m.rawTotal,m.recentMean,m.recentMedian,Double.NaN,m.stdDev);m.total=gs.adjustedProjection;m.projectionDivergent=gs.divergent;m.projectionStatus=gs.status;m.projectionReason=gs.reason;m.sample=(home==null?0:home.n)+(away==null?0:away.n)+Math.min(h2hHome==null?0:h2hHome.n,h2hAway==null?0:h2hAway.n);m.source=source==null?"":source;m.line=line;double spread=Math.max(.75,Double.isNaN(m.stdDev)?Math.sqrt(Math.max(.1,m.total)):m.stdDev);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(line>0)m.overProb=poissonOver(m.total,line);m.lineHigh=lineHigh>0?lineHigh:(line>0?line+1:-1);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);d.metrics.put("Gols",m);
    }
    static double projectGoalSide(Series own,Series opp,Series ownVenue,Series oppVenue,Series h2h,boolean homeSide){
        double ownFor=own==null?Double.NaN:own.f(),oppAgainst=opp==null?Double.NaN:opp.a();if(Double.isNaN(ownFor)&&Double.isNaN(oppAgainst))return h2h==null?Double.NaN:h2h.f();double base=combine(ownFor,oppAgainst);double leagueBase=meanFinite(own==null?Double.NaN:own.f(),own==null?Double.NaN:own.a(),opp==null?Double.NaN:opp.f(),opp==null?Double.NaN:opp.a());if(Double.isNaN(leagueBase)||leagueBase<=.15)leagueBase=Math.max(.6,base);double attack=Double.isNaN(ownFor)?1:ownFor/leagueBase,defWeak=Double.isNaN(oppAgainst)?1:oppAgainst/leagueBase;double expected=leagueBase*Math.pow(Math.max(.35,attack),.58)*Math.pow(Math.max(.35,defWeak),.42);double venue=combine(ownVenue==null?Double.NaN:ownVenue.f(),oppVenue==null?Double.NaN:oppVenue.a());if(!Double.isNaN(venue))expected=expected*.76+venue*.24;expected*=homeSide?1.05:.95;double direct=h2h==null?Double.NaN:h2h.f();if(!Double.isNaN(direct))expected=expected*.88+direct*.12;return Math.max(.05,expected);
    }
    static double projectSide(Series ownRecent,Series oppRecent,Series h2h){double base=combine(ownRecent==null?Double.NaN:ownRecent.f(),oppRecent==null?Double.NaN:oppRecent.a());double direct=h2h==null?Double.NaN:h2h.f();if(Double.isNaN(base))return direct;if(Double.isNaN(direct))return base;return base*.86+direct*.14;}
    static double combinedRecentMean(Series h,Series a){return meanFinite(h==null?Double.NaN:h.totalMean(),a==null?Double.NaN:a.totalMean());}
    static double combinedRecentMedian(Series h,Series a){return meanFinite(h==null?Double.NaN:h.totalMedian(),a==null?Double.NaN:a.totalMedian());}
    static double combinedRecentStd(Series h,Series a){return meanFinite(h==null?Double.NaN:h.totalStd(),a==null?Double.NaN:a.totalStd());}
    static double meanFinite(double... xs){double s=0;int n=0;for(double x:xs)if(!Double.isNaN(x)){s+=x;n++;}return n==0?Double.NaN:s/n;}
    static double meanList(List<Double> xs){if(xs==null||xs.isEmpty())return Double.NaN;double s=0;int n=0;for(Double x:xs)if(x!=null&&!Double.isNaN(x)){s+=x;n++;}return n==0?Double.NaN:s/n;}
    static double medianList(List<Double> xs){if(xs==null||xs.isEmpty())return Double.NaN;ArrayList<Double> z=new ArrayList<>();for(Double x:xs)if(x!=null&&!Double.isNaN(x))z.add(x);if(z.isEmpty())return Double.NaN;Collections.sort(z);int n=z.size();return n%2==1?z.get(n/2):(z.get(n/2-1)+z.get(n/2))/2.0;}
    static double stdList(List<Double> xs){double m=meanList(xs);if(Double.isNaN(m))return Double.NaN;double s=0;int n=0;for(Double x:xs)if(x!=null&&!Double.isNaN(x)){double d=x-m;s+=d*d;n++;}return n<=1?0:Math.sqrt(s/(n-1));}
    static double dynamicLine(Series home,Series away,int offset){if(home==null||away==null||home.n==0||away.n==0)return -1;double hp=combine(home.f(),away.a()),ap=combine(away.f(),home.a()),total=hp+ap;if(Double.isNaN(total)||total<1)return -1;return Math.max(.5,Math.floor(total)-offset+.5);}
    static void addProjection(DeepAnalysis d,String name,Series home,Series away,double line,double lineHigh){
        if(home==null||away==null||home.n==0||away.n==0)return;double hp=combine(home.f(),away.a()),ap=combine(away.f(),home.a());if(Double.isNaN(hp)||Double.isNaN(ap))return;MetricProjection m=new MetricProjection(name);m.home=hp;m.away=ap;m.total=hp+ap;m.sample=home.n+away.n;m.line=line;double spread=Math.max(1.0,Math.sqrt(Math.max(.1,m.total))*1.15);m.low=Math.max(0,m.total-spread);m.high=m.total+spread;if(line>0)m.overProb=poissonOver(m.total,line);m.lineHigh=lineHigh>0?lineHigh:(line>0?line+2:-1);if(m.lineHigh>0)m.overProbHigh=poissonOver(m.total,m.lineHigh);d.metrics.put(name,m);
    }
    static double combine(double a,double b){if(Double.isNaN(a))return b;if(Double.isNaN(b))return a;return (a+b)/2.0;}
    static double weight(int i){return Math.max(.38,Math.pow(.90,Math.max(0,i)));}
    static int poissonOver(double lambda,double line){int k=(int)Math.floor(line);double p=Math.exp(-lambda),sum=p;for(int i=1;i<=k;i++){p*=lambda/i;sum+=p;}return (int)Math.round(Math.max(0,Math.min(1,1-sum))*100);}
    static double parseNum(String s){try{return Double.parseDouble(s.replace("%","").trim());}catch(Exception e){return Double.NaN;}}
    JSONObject deepJson(DeepAnalysis d)throws Exception{JSONObject root=new JSONObject();root.put("hm",d.homeMatches);root.put("am",d.awayMatches);root.put("hh",d.h2hMatches);root.put("hvm",d.homeVenueMatches);root.put("avm",d.awayVenueMatches);root.put("src",d.sources);root.put("sc",d.sourceCount);root.put("sq",d.sourceQuality);root.put("agr",d.agreement);root.put("note",d.note);JSONArray ar=new JSONArray();for(MetricProjection m:d.metrics.values()){JSONObject o=new JSONObject();o.put("n",m.name);o.put("h",m.home);o.put("a",m.away);o.put("t",m.total);o.put("rt",m.rawTotal);o.put("rm",m.recentMean);o.put("rmed",m.recentMedian);o.put("lm",m.leagueMean);o.put("sd",m.stdDev);o.put("ml",m.marketLine);o.put("pd",m.projectionDivergent);o.put("ps",m.projectionStatus);o.put("pr",m.projectionReason);o.put("lo",m.low);o.put("hi",m.high);o.put("l",m.line);o.put("p",m.overProb);o.put("l2",m.lineHigh);o.put("p2",m.overProbHigh);o.put("s",m.sample);o.put("src",m.source);ar.put(o);}root.put("m",ar);JSONArray od=new JSONArray();if(d.marketOdds!=null)for(String k:d.marketOdds.keys()){MarketOddsBook.Quote q=d.marketOdds.quote(k);if(!q.available())continue;JSONObject o=new JSONObject();o.put("k",k);o.put("p",q.probability);o.put("b",q.bookmakerCount);o.put("m",q.market);od.put(o);}root.put("od",od);return root;}
    DeepAnalysis parseDeep(String raw){try{JSONObject root=new JSONObject(raw);DeepAnalysis d=new DeepAnalysis();d.homeMatches=root.optInt("hm");d.awayMatches=root.optInt("am");d.h2hMatches=root.optInt("hh");d.homeVenueMatches=root.optInt("hvm");d.awayVenueMatches=root.optInt("avm");d.sources=root.optString("src","");d.sourceCount=root.optInt("sc",0);d.sourceQuality=root.optInt("sq",0);d.agreement=root.optInt("agr",0);d.note=root.optString("note","");JSONArray ar=root.optJSONArray("m");if(ar!=null)for(int i=0;i<ar.length();i++){JSONObject o=ar.optJSONObject(i);if(o==null)continue;MetricProjection m=new MetricProjection(o.optString("n"));m.home=o.optDouble("h");m.away=o.optDouble("a");m.total=o.optDouble("t");m.rawTotal=o.optDouble("rt",m.total);m.recentMean=o.optDouble("rm",Double.NaN);m.recentMedian=o.optDouble("rmed",Double.NaN);m.leagueMean=o.optDouble("lm",Double.NaN);m.stdDev=o.optDouble("sd",Double.NaN);m.marketLine=o.optDouble("ml",Double.NaN);m.projectionDivergent=o.optBoolean("pd",false);m.projectionStatus=o.optString("ps","NORMAL");m.projectionReason=o.optString("pr","");m.low=o.optDouble("lo");m.high=o.optDouble("hi");m.line=o.optDouble("l",-1);m.overProb=o.optInt("p",-1);m.lineHigh=o.optDouble("l2",-1);m.overProbHigh=o.optInt("p2",-1);m.sample=o.optInt("s");m.source=o.optString("src","");d.metrics.put(m.name,m);}JSONArray od=root.optJSONArray("od");if(od!=null)for(int i=0;i<od.length();i++){JSONObject o=od.optJSONObject(i);if(o!=null)d.marketOdds.addConsensus(o.optString("k"),o.optDouble("p",Double.NaN),o.optInt("b",0),o.optString("m",""));}d.complete=!d.metrics.isEmpty();return d;}catch(Exception e){return null;}}
    static String today(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(new java.util.Date());}
    static String future(int days){java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));c.add(java.util.Calendar.DAY_OF_MONTH,days);java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(c.getTime());}
    static int pct(String s){try{return Math.round(Float.parseFloat(s.replace("%","").trim()));}catch(Exception e){return 0;}}

    static HashMap<String,String> mapStats(JSONArray a)throws Exception{HashMap<String,String> m=new HashMap<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Object v=o.opt("value");if(v!=null&&v!=JSONObject.NULL)m.put(o.optString("type"),String.valueOf(v));}return m;}
}
