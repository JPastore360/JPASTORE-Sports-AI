package com.jpastore.sportsai;

/** Routing only: controls source order/time budgets without changing statistical formulas. */
final class ResearchRoutePolicy {
    static long totalBudget(boolean deep){return deep?26000L:15000L;}
    static long fiveDollarBudget(boolean deep){return deep?11000L:7200L;}
    static long apiFootballBudget(boolean deep){return deep?9000L:4800L;}
    static long internetBudget(boolean deep){return deep?5600L:2800L;}
    static boolean useApiFootball(boolean deep,int coverage,int sourceCount){return deep||coverage<72||sourceCount<2;}
    static boolean useInternet(boolean deep,int coverage,int sourceCount){return deep||coverage<85||sourceCount<2;}
    private ResearchRoutePolicy(){}
}
