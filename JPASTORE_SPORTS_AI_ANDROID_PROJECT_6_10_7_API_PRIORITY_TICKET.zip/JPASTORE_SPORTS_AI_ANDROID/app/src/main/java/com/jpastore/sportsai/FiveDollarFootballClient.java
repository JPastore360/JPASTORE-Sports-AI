package com.jpastore.sportsai;

import android.content.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * Fast optional football source backed by 5DollarFootballAPI.
 *
 * Design goals:
 * - never becomes a single point of failure;
 * - respects the provider's short rate window / Retry-After instead of treating it as a daily quota;
 * - batches a full day in one request and recent team history in one request per team;
 * - stores only the user supplied key in the app's persistent preferences, never in source/build files.
 */
final class FiveDollarFootballClient {
    static final String SOURCE="five_dollar_football";
    static final String TITLE="5DollarFootballAPI";
    static final String BASE="https://api.5dollarfootballapi.com/v1/";
    private static final String STORE="jp_persistent_v1", KEY="api_5dollar";
    private static final String META="jp_5dollar_meta", CACHE="jp_5dollar_cache";
    private final Context c;

    FiveDollarFootballClient(Context c){this.c=c;}

    static String key(Context c){return c==null?"":c.getSharedPreferences(STORE,0).getString(KEY,"").trim();}
    static boolean configured(Context c){return !key(c).isEmpty();}
    static void saveKey(Context c,String value){if(c!=null)c.getSharedPreferences(STORE,0).edit().putString(KEY,value==null?"":value.trim()).apply();}
    static void clearKey(Context c){if(c!=null)c.getSharedPreferences(STORE,0).edit().remove(KEY).apply();}

    // 6.10.7: preserve ~10% of the hourly allowance so deep analysis never burns the whole plan.
    static int safeHourlyLimit(Context c){
        if(c==null)return 54;SharedPreferences p=c.getSharedPreferences(META,0);int provider=p.getInt("limit",60);
        if(provider<=0)provider=60;int reserve=Math.max(2,(int)Math.ceil(provider*.10));return Math.max(1,provider-reserve);
    }
    static int localRequestsThisHour(Context c){
        if(c==null)return 0;SharedPreferences p=c.getSharedPreferences(META,0);long now=System.currentTimeMillis(),start=p.getLong("local_window_start",0);
        if(start<=0||now-start>=60L*60*1000L){p.edit().putLong("local_window_start",now).putInt("local_window_count",0).apply();return 0;}return p.getInt("local_window_count",0);
    }
    static int estimatedSafeRemaining(Context c){return Math.max(0,safeHourlyLimit(c)-localRequestsThisHour(c));}
    static boolean budgetAvailable(Context c,int estimatedRequests){
        if(c==null)return false;SharedPreferences p=c.getSharedPreferences(META,0);long now=System.currentTimeMillis();if(p.getLong("retry_until",0)>now)return false;
        int need=Math.max(1,estimatedRequests),local=estimatedSafeRemaining(c),reported=p.getInt("remaining",-1);long reset=p.getLong("reset",0);
        if(reset>0&&reset<100000000000L)reset*=1000L;if(reset>0&&reset<=now)reported=-1;
        return local>=need&&(reported<0||reported>=need+2);
    }
    private static boolean reserveRequestSlot(Context c){
        synchronized(FiveDollarFootballClient.class){
            if(c==null)return false;SharedPreferences p=c.getSharedPreferences(META,0);long now=System.currentTimeMillis(),start=p.getLong("local_window_start",0);int count=p.getInt("local_window_count",0);
            if(start<=0||now-start>=60L*60*1000L){start=now;count=0;}int safe=safeHourlyLimit(c);if(count>=safe)return false;
            p.edit().putLong("local_window_start",start).putInt("local_window_count",count+1).apply();return true;
        }
    }

    static final class Status {
        String plan=""; int usageToday=-1,rateLimit=-1,windowSeconds=-1,burst=-1,remaining=-1; long resetEpoch=0;
        String text(){StringBuilder b=new StringBuilder();b.append(plan==null||plan.isEmpty()?"Plano ativo":plan.toUpperCase(Locale.ROOT));if(usageToday>=0)b.append(" • ").append(usageToday).append(" hoje");if(rateLimit>0){b.append(" • ").append(rateLimit).append("/");if(windowSeconds==3600)b.append("hora");else if(windowSeconds==60)b.append("min");else b.append(windowSeconds).append("s");}if(burst>0)b.append(" • burst ").append(burst).append("/min");if(remaining>=0)b.append(" • restante ").append(remaining);return b.toString();}
    }

    static final class Response {String body="";int remaining=-1,limit=-1;long reset=0;}

    Response request(String path,String apiKey)throws Exception{
        if(apiKey==null||apiKey.trim().isEmpty())throw new IOException("Chave 5DollarFootballAPI não configurada");
        long blocked=c.getSharedPreferences(META,0).getLong("retry_until",0);long now=System.currentTimeMillis();if(blocked>now)throw new IOException("5DollarFootballAPI aguardando janela de rate limit");
        if(!reserveRequestSlot(c))throw new IOException("5DollarFootballAPI preservada: reserva horária atingida • aguarde a próxima janela");
        HttpURLConnection h=(HttpURLConnection)new URL(BASE+path).openConnection();
        h.setRequestProperty("Authorization","Bearer "+apiKey.trim());h.setRequestProperty("Accept","application/json");h.setRequestProperty("User-Agent","J.Pastore-Sports-AI/6.9 Android");
        h.setConnectTimeout(4500);h.setReadTimeout(6500);
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();StringBuilder b=new StringBuilder();if(in!=null){BufferedReader r=new BufferedReader(new InputStreamReader(in));for(String s;(s=r.readLine())!=null;)b.append(s);}
        Response out=new Response();out.body=b.toString();out.remaining=parseIntHeader(h,"X-RateLimit-Remaining");out.limit=parseIntHeader(h,"X-RateLimit-Limit");out.reset=parseLongHeader(h,"X-RateLimit-Reset");
        SharedPreferences.Editor ed=c.getSharedPreferences(META,0).edit();if(out.remaining>=0)ed.putInt("remaining",out.remaining);if(out.limit>=0)ed.putInt("limit",out.limit);if(out.reset>0)ed.putLong("reset",out.reset);ed.putLong("last_ok",System.currentTimeMillis());
        if(code==429){int retry=parseIntHeader(h,"Retry-After");if(retry<=0)retry=60;ed.putLong("retry_until",System.currentTimeMillis()+retry*1000L);ed.apply();throw new IOException("Limite temporário da 5DollarFootballAPI • tente em "+retry+"s");}
        ed.remove("retry_until").apply();
        if(code<200||code>=300)throw new IOException("5DollarFootballAPI HTTP "+code);
        JSONObject root=new JSONObject(out.body);if(root.has("success")&&root.optInt("success",1)==0)throw new IOException(errorMessage(root));Object error=root.opt("error");if(error instanceof JSONObject&&((JSONObject)error).length()>0)throw new IOException(errorMessage(root));
        return out;
    }

    void test(String apiKey,Consumer<Boolean> cb){new Thread(()->{try{request("status",apiKey);cb.accept(true);}catch(Exception e){cb.accept(false);}}).start();}
    void status(String apiKey,Consumer<Status> ok,Consumer<String> err){new Thread(()->{try{Response r=request("status",apiKey);JSONObject root=new JSONObject(r.body),d=root.optJSONObject("data");if(d==null)throw new IOException("Status indisponível");Status s=new Status();s.plan=d.optString("plan","");JSONObject lim=d.optJSONObject("limits"),use=d.optJSONObject("usage");if(lim!=null){s.rateLimit=lim.optInt("rate_limit",-1);s.windowSeconds=lim.optInt("rate_window_seconds",-1);s.burst=lim.isNull("burst_per_minute")?-1:lim.optInt("burst_per_minute",-1);}if(use!=null)s.usageToday=use.optInt("today",-1);SharedPreferences m=c.getSharedPreferences(META,0);s.remaining=r.remaining>=0?r.remaining:m.getInt("remaining",-1);s.resetEpoch=r.reset>0?r.reset:m.getLong("reset",0);ok.accept(s);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    ArrayList<ApiClient.Game> fixtures(String apiKey,String date)throws Exception{
        String ck="fixtures_"+date;String raw=cacheGet(ck,date.equals(ApiClient.today())?3L*60*1000L:30L*60*1000L);if(raw==null){long[] w=dayWindow(date);raw=request("fixtures?start_time="+w[0]+"&end_time="+w[1]+"&lang=pt&per_page=100",apiKey).body;cachePut(ck,raw);}return parseGames(raw);
    }

    ArrayList<ApiClient.Game> live(String apiKey)throws Exception{
        String ck="live",raw=cacheGet(ck,25L*1000L);if(raw==null){raw=request("fixtures?status=live&lang=pt&per_page=500",apiKey).body;cachePut(ck,raw);}return parseGames(raw);
    }

    ApiClient.Game resolve(String apiKey,ApiClient.Game target)throws Exception{
        if(target==null)return null;if(target.fiveId>0&&target.fiveHomeId>0&&target.fiveAwayId>0)return target;ArrayList<ApiClient.Game> day=fixtures(apiKey,ApiClient.dateOf(target));ApiClient.Game best=null;int score=0;for(ApiClient.Game g:day){int s=ApiClient.teamScore(target.home,g.home)+ApiClient.teamScore(target.away,g.away);int rev=ApiClient.teamScore(target.home,g.away)+ApiClient.teamScore(target.away,g.home);s=Math.max(s,rev-20);if(s>score){score=s;best=g;}}if(best!=null&&score>=120){copyFive(target,best);return target;}return null;
    }

    ApiClient.DeepAnalysis deep(String apiKey,ApiClient.Game target,boolean forceDeep)throws Exception{
        ApiClient.Game g=resolve(apiKey,target);if(g==null||g.fiveHomeId<=0||g.fiveAwayId<=0)return null;
        final int page=forceDeep?35:22;ExecutorService ex=Executors.newFixedThreadPool(3);
        Future<ArrayList<JSONObject>> fh=ex.submit(()->teamFinished(apiKey,g.fiveHomeId,page));Future<ArrayList<JSONObject>> fa=ex.submit(()->teamFinished(apiKey,g.fiveAwayId,page));Future<MarketOddsBook> fo=ex.submit(()->odds(apiKey,g));
        ArrayList<JSONObject> home=fh.get(8,TimeUnit.SECONDS),away=fa.get(8,TimeUnit.SECONDS);MarketOddsBook odds;try{odds=fo.get(6,TimeUnit.SECONDS);}catch(Exception e){odds=new MarketOddsBook();}ex.shutdownNow();
        ApiClient.DeepAnalysis d=new ApiClient.DeepAnalysis();d.sourceCount=1;d.sourceQuality=88;d.agreement=50;d.sources=TITLE;d.marketOdds=odds;
        ApiClient.Series hg=new ApiClient.Series(),ag=new ApiClient.Series(),hv=new ApiClient.Series(),av=new ApiClient.Series(),hgh=new ApiClient.Series(),agh=new ApiClient.Series();
        LinkedHashMap<String,ApiClient.Series> hs=metricSeries(),as=metricSeries(),hhs=metricSeries(),has=metricSeries();
        int hi=0;for(JSONObject row:home){addRow(row,g.fiveHomeId,hg,hv,Boolean.TRUE,hs,hi++);if(isOpponent(row,g.fiveAwayId)&&hgh.n<5)addRow(row,g.fiveHomeId,hgh,null,null,hhs,hgh.n);}
        int ai=0;for(JSONObject row:away){addRow(row,g.fiveAwayId,ag,av,Boolean.FALSE,as,ai++);if(isOpponent(row,g.fiveHomeId)&&agh.n<5)addRow(row,g.fiveAwayId,agh,null,null,has,agh.n);}
        d.homeMatches=hg.n;d.awayMatches=ag.n;d.homeVenueMatches=hv.n;d.awayVenueMatches=av.n;d.h2hMatches=Math.min(hgh.n,agh.n);
        ApiClient.addGoalProjection(d,hg,ag,hv,av,hgh,agh,2.5,3.5,TITLE);ApiClient.markSource(d,"Gols",TITLE);
        addMetric(d,"Escanteios",hs,as,hhs,has,8.5,10.5);addMetric(d,"Finalizações",hs,as,hhs,has,ApiClient.dynamicLineV3(hs.get("Finalizações"),as.get("Finalizações"),hhs.get("Finalizações"),has.get("Finalizações"),2),-1);
        addMetric(d,"Chutes no alvo",hs,as,hhs,has,7.5,9.5);addMetric(d,"Cartões amarelos",hs,as,hhs,has,3.5,5.5);
        ApiClient.applyMarketSanity(d);d.complete=!d.metrics.isEmpty();d.note="Fonte rápida 5DollarFootballAPI: histórico em lote por equipe + odds Bet365 quando disponíveis.";return d;
    }


    /** Structured research representation for the multi-sport/ticket engine. Uses the same cached calls as deep(). */
    MultiSportWebClient.Research research(String apiKey,MultiSportClient.Event ev,boolean forceDeep)throws Exception{
        if(ev==null)return null;ApiClient.Game target=new ApiClient.Game(ev.apiSportsId>0?ev.apiSportsId:ev.id,(int)ev.homeId,(int)ev.awayId,(int)ev.leagueId,0,ev.home,ev.away,ev.homeLogo,ev.awayLogo,ev.competition,(ev.date==null?"":ev.date)+"|"+(ev.time==null?"":ev.time),ev.status);
        ApiClient.Game g=resolve(apiKey,target);if(g==null||g.fiveHomeId<=0||g.fiveAwayId<=0)return null;int page=forceDeep?35:22;ExecutorService ex=Executors.newFixedThreadPool(3);
        Future<ArrayList<JSONObject>> fh=ex.submit(()->teamFinished(apiKey,g.fiveHomeId,page)),fa=ex.submit(()->teamFinished(apiKey,g.fiveAwayId,page));Future<MarketOddsBook> fo=ex.submit(()->odds(apiKey,g));
        ArrayList<JSONObject> home=fh.get(forceDeep?10:8,TimeUnit.SECONDS),away=fa.get(forceDeep?10:8,TimeUnit.SECONDS);MarketOddsBook odds;try{odds=fo.get(forceDeep?8:6,TimeUnit.SECONDS);}catch(Exception e){odds=new MarketOddsBook();}ex.shutdownNow();
        MultiSportWebClient web=new MultiSportWebClient(c);MultiSportWebClient.Research r=web.seedResearch(MultiSportClient.FOOTBALL,ev);ArrayList<MultiSportWebClient.GameRow> hr=fiveRows(home),ar=fiveRows(away);
        web.mergeSourceRows(r,hr,ev,TITLE);web.mergeSourceRows(r,ar,ev,TITLE);if(odds!=null)r.marketOdds.merge(odds);web.rebuildResearch(r);r.source=TITLE;r.dataSource=TITLE;r.updatedAt=System.currentTimeMillis();r.diagnostic="5Dollar primária • "+r.commonSample()+" jogos por lado • histórico em lote + odds quando disponíveis.";return r;
    }
    static ArrayList<MultiSportWebClient.GameRow> fiveRows(ArrayList<JSONObject> rows){
        ArrayList<MultiSportWebClient.GameRow> out=new ArrayList<>();if(rows==null)return out;for(JSONObject row:rows){try{JSONObject teams=row.optJSONObject("teams"),ho=teams==null?null:teams.optJSONObject("home"),aw=teams==null?null:teams.optJSONObject("away"),goals=row.optJSONObject("goals"),league=row.optJSONObject("league");if(ho==null||aw==null||goals==null)continue;
            MultiSportWebClient.GameRow g=new MultiSportWebClient.GameRow();g.home=ho.optString("name","");g.away=aw.optString("name","");g.homeId=ho.optLong("id",0);g.awayId=aw.optLong("id",0);g.hs=goals.isNull("home")?-1:goals.optInt("home",-1);g.as=goals.isNull("away")?-1:goals.optInt("away",-1);g.completed=g.hs>=0&&g.as>=0;g.status="FT";g.competition=league==null?"":league.optString("name","");long ts=row.optLong("kickoff_ts",0);String when=localWhen(ts,row.optString("kickoff_utc",""));g.date=when.contains("|")?when.substring(0,when.indexOf('|')):when;g.score=g.completed?g.hs+"-"+g.as:"";g.sources.add(TITLE);if(g.completed)out.add(g);
        }catch(Exception ignored){}}return out;
    }

    MarketOddsBook odds(String apiKey,ApiClient.Game g)throws Exception{
        MarketOddsBook out=new MarketOddsBook();if(g==null||g.fiveId<=0)return out;String ck="odds_"+g.fiveId;long age=ApiClient.isLiveStatus(g.status)?25L*1000L:15L*60*1000L;String raw=cacheGet(ck,age);if(raw==null){raw=request("fixtures/"+g.fiveId+"/odds",apiKey).body;cachePut(ck,raw);}JSONObject data=new JSONObject(raw).optJSONObject("data");if(data==null)return out;JSONArray books=data.optJSONArray("bookmakers");if(books!=null)for(int i=0;i<books.length();i++){JSONObject b=books.optJSONObject(i);if(b==null)continue;parseBookmakerOdds(out,b.optJSONObject("odds"),b.optString("name","Bet365"),ApiClient.isLiveStatus(g.status));}else parseBookmakerOdds(out,data.optJSONObject("odds"),"Bet365",ApiClient.isLiveStatus(g.status));return out;
    }

    ArrayList<JSONObject> teamFinished(String apiKey,long teamId,int perPage)throws Exception{
        String ck="team_finished_"+teamId+"_"+perPage;String raw=cacheGet(ck,4L*60*60*1000L);if(raw==null){raw=request("teams/"+teamId+"/fixtures?status=finished&include=stats&order=desc&per_page="+Math.min(50,Math.max(8,perPage))+"&lang=pt",apiKey).body;cachePut(ck,raw);}JSONArray a=new JSONObject(raw).optJSONArray("data");ArrayList<JSONObject> out=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&"finished".equalsIgnoreCase(o.optString("status")))out.add(o);}return out;
    }

    static ArrayList<ApiClient.Game> parseGames(String raw)throws Exception{ArrayList<ApiClient.Game> out=new ArrayList<>();JSONObject root=new JSONObject(raw);JSONArray a=root.optJSONArray("data");if(a==null)return out;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(parseGame(o));}ApiClient.sortGames(out);return out;}
    static ApiClient.Game parseGame(JSONObject o){JSONObject l=o.optJSONObject("league"),teams=o.optJSONObject("teams"),ho=teams==null?null:teams.optJSONObject("home"),aw=teams==null?null:teams.optJSONObject("away");long ts=o.optLong("kickoff_ts",0);String when=localWhen(ts,o.optString("kickoff_utc",""));ApiClient.Game g=new ApiClient.Game(0,0,0,0,0,ho==null?"":ho.optString("name"),aw==null?"":aw.optString("name"),teamLogo(ho),teamLogo(aw),l==null?"":l.optString("name"),when,mapStatus(o.optString("status"),o.optString("status_reason"),o.optString("status_code")));g.fiveId=o.optLong("id",0);g.fiveHomeId=ho==null?0:ho.optLong("id",0);g.fiveAwayId=aw==null?0:aw.optLong("id",0);g.fiveLeagueId=l==null?0:l.optLong("id",0);JSONObject goals=o.optJSONObject("goals");if(goals!=null){g.homeGoals=goals.isNull("home")?-1:goals.optInt("home",-1);g.awayGoals=goals.isNull("away")?-1:goals.optInt("away",-1);}String sc=o.optString("status_code","");try{if(sc.matches("\\d+"))g.elapsed=Integer.parseInt(sc);}catch(Exception ignored){}return g;}


    static String teamLogo(JSONObject t){if(t==null)return "";String[] k={"logo","image","badge","crest","logo_url","image_url"};for(String x:k){String v=t.optString(x,"");if(v!=null&&v.startsWith("http"))return v;}JSONObject media=t.optJSONObject("media");if(media!=null)for(String x:k){String v=media.optString(x,"");if(v!=null&&v.startsWith("http"))return v;}return "";}
    static void copyFive(ApiClient.Game dst,ApiClient.Game src){if(dst==null||src==null)return;dst.fiveId=src.fiveId;dst.fiveHomeId=src.fiveHomeId;dst.fiveAwayId=src.fiveAwayId;dst.fiveLeagueId=src.fiveLeagueId;if((dst.league==null||dst.league.isEmpty())&&src.league!=null)dst.league=src.league;if((dst.homeLogo==null||dst.homeLogo.isEmpty())&&src.homeLogo!=null)dst.homeLogo=src.homeLogo;if((dst.awayLogo==null||dst.awayLogo.isEmpty())&&src.awayLogo!=null)dst.awayLogo=src.awayLogo;}

    static LinkedHashMap<String,ApiClient.Series> metricSeries(){LinkedHashMap<String,ApiClient.Series> m=new LinkedHashMap<>();m.put("Escanteios",new ApiClient.Series());m.put("Finalizações",new ApiClient.Series());m.put("Chutes no alvo",new ApiClient.Series());m.put("Cartões amarelos",new ApiClient.Series());return m;}
    static void addMetric(ApiClient.DeepAnalysis d,String name,Map<String,ApiClient.Series> h,Map<String,ApiClient.Series> a,Map<String,ApiClient.Series> hh,Map<String,ApiClient.Series> ha,double line,double high){ApiClient.addProjectionV3(d,name,h.get(name),a.get(name),hh.get(name),ha.get(name),line,high);ApiClient.markSource(d,name,TITLE);}

    static void addRow(JSONObject row,long teamId,ApiClient.Series goals,ApiClient.Series venue,Boolean venueHome,Map<String,ApiClient.Series> metrics,int index){JSONObject teams=row.optJSONObject("teams"),home=teams==null?null:teams.optJSONObject("home"),away=teams==null?null:teams.optJSONObject("away");long hid=home==null?0:home.optLong("id"),aid=away==null?0:away.optLong("id");boolean isHome=hid==teamId;if(!isHome&&aid!=teamId)return;double w=ApiClient.weight(index);JSONObject gs=row.optJSONObject("goals");if(gs!=null&&!gs.isNull("home")&&!gs.isNull("away")){double f=isHome?gs.optDouble("home",Double.NaN):gs.optDouble("away",Double.NaN),ag=isHome?gs.optDouble("away",Double.NaN):gs.optDouble("home",Double.NaN);goals.add(f,ag,w);if(venue!=null&&(venueHome==null||venueHome.booleanValue()==isHome))venue.add(f,ag,w);}
        JSONObject corners=row.optJSONObject("corners");if(corners!=null)addMetricValue(metrics.get("Escanteios"),isHome,corners.optDouble("home",Double.NaN),corners.optDouble("away",Double.NaN),w);
        JSONObject cards=row.optJSONObject("cards");if(cards!=null){JSONObject ch=cards.optJSONObject("home"),ca=cards.optJSONObject("away");if(ch!=null&&ca!=null)addMetricValue(metrics.get("Cartões amarelos"),isHome,ch.optDouble("yellow",Double.NaN),ca.optDouble("yellow",Double.NaN),w);}
        JSONObject st=row.optJSONObject("statistics");if(st!=null){JSONObject on=st.optJSONObject("shots_on_target"),off=st.optJSONObject("shots_off_target");if(on!=null){double oh=on.optDouble("home",Double.NaN),oa=on.optDouble("away",Double.NaN);addMetricValue(metrics.get("Chutes no alvo"),isHome,oh,oa,w);if(off!=null){double fh=off.optDouble("home",Double.NaN),fa=off.optDouble("away",Double.NaN);if(!Double.isNaN(oh)&&!Double.isNaN(oa)&&!Double.isNaN(fh)&&!Double.isNaN(fa))addMetricValue(metrics.get("Finalizações"),isHome,oh+fh,oa+fa,w);}}}
    }
    static void addMetricValue(ApiClient.Series s,boolean home,double hv,double av,double w){if(s==null||Double.isNaN(hv)||Double.isNaN(av))return;s.add(home?hv:av,home?av:hv,w);}
    static boolean isOpponent(JSONObject row,long opponentId){JSONObject teams=row.optJSONObject("teams"),h=teams==null?null:teams.optJSONObject("home"),a=teams==null?null:teams.optJSONObject("away");return (h!=null&&h.optLong("id")==opponentId)||(a!=null&&a.optLong("id")==opponentId);}

    static void parseBookmakerOdds(MarketOddsBook book,JSONObject odds,String bookmaker,boolean live){if(book==null||odds==null)return;JSONObject one=odds.optJSONObject("1x2"),stage=stage(one,live);if(stage!=null){LinkedHashMap<String,Double> m=new LinkedHashMap<>();m.put(MarketOddsBook.HOME,stage.optDouble("home",Double.NaN));m.put(MarketOddsBook.DRAW,stage.optDouble("draw",Double.NaN));m.put(MarketOddsBook.AWAY,stage.optDouble("away",Double.NaN));book.addBookmakerMarket(m,bookmaker,"1X2");}
        JSONObject gl=stage(odds.optJSONObject("goal_line"),live);if(gl!=null){double line=gl.optDouble("line",Double.NaN);if(!Double.isNaN(line)){LinkedHashMap<String,Double> m=new LinkedHashMap<>();m.put(MarketOddsBook.totalKey(true,line),gl.optDouble("over",Double.NaN));m.put(MarketOddsBook.totalKey(false,line),gl.optDouble("under",Double.NaN));book.addBookmakerMarket(m,bookmaker,"Total "+line);}}
        JSONObject ah=stage(odds.optJSONObject("asian_handicap"),live);if(ah!=null){double line=ah.optDouble("line",Double.NaN);if(!Double.isNaN(line)){LinkedHashMap<String,Double> m=new LinkedHashMap<>();m.put(MarketOddsBook.handicapKey(true,line),ah.optDouble("home",Double.NaN));m.put(MarketOddsBook.handicapKey(false,-line),ah.optDouble("away",Double.NaN));book.addBookmakerMarket(m,bookmaker,"Asian Handicap "+line);}}
    }
    static JSONObject stage(JSONObject market,boolean live){if(market==null)return null;JSONObject s=live?market.optJSONObject("inplay"):market.optJSONObject("closing");if(s==null&&!live)s=market.optJSONObject("opening");if(s==null&&live)s=market.optJSONObject("closing");return s;}

    static String mapStatus(String s,String reason,String code){String x=s==null?"":s.toLowerCase(Locale.ROOT);if("scheduled".equals(x))return "NS";if("live".equals(x)||"in_play".equals(x))return code==null||code.isEmpty()?"LIVE":code;if("finished".equals(x))return "FT";if("unknown".equals(x)){String r=reason==null?"":reason.toLowerCase(Locale.ROOT);return r.contains("kickoff")?"PST":"UNK";}return s==null||s.isEmpty()?"NS":s.toUpperCase(Locale.ROOT);}
    static String localWhen(long ts,String iso){try{Date d;if(ts>0)d=new Date(ts*1000L);else{SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US);d=in.parse(iso);}SimpleDateFormat out=new SimpleDateFormat("yyyy-MM-dd|HH:mm",Locale.US);out.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));return out.format(d);}catch(Exception e){String day=iso!=null&&iso.length()>=10?iso.substring(0,10):"";return day+"|--:--";}}
    static long[] dayWindow(String date)throws Exception{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));Date d=f.parse(date);Calendar c=Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));c.setTime(d);long start=c.getTimeInMillis()/1000L;c.add(Calendar.DAY_OF_MONTH,1);return new long[]{start,c.getTimeInMillis()/1000L};}
    static String errorMessage(JSONObject root){JSONObject e=root.optJSONObject("error");if(e!=null){String m=e.optString("message","");if(!m.isEmpty())return m;}return "5DollarFootballAPI recusou a consulta";}
    static int parseIntHeader(HttpURLConnection h,String name){try{String v=h.getHeaderField(name);return v==null?-1:Integer.parseInt(v.trim());}catch(Exception e){return -1;}}
    static long parseLongHeader(HttpURLConnection h,String name){try{String v=h.getHeaderField(name);return v==null?0:Long.parseLong(v.trim());}catch(Exception e){return 0;}}
    void cachePut(String k,String v){c.getSharedPreferences(CACHE,0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long age){SharedPreferences p=c.getSharedPreferences(CACHE,0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=age?p.getString(k,null):null;}
}
