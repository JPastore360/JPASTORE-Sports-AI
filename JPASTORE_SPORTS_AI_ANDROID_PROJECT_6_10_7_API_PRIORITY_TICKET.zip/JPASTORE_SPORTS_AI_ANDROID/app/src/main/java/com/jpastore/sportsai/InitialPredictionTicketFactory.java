package com.jpastore.sportsai;

import java.util.*;

/**
 * Creates clearly-labelled review candidates from the initial 1X2 prediction only.
 * It never promotes them to conservative status and never invents odds/history.
 */
final class InitialPredictionTicketFactory {
    static ArrayList<TicketBatchGenerator.Candidate> football(
            String eventKey,String matchup,String league,String kickoff,
            String home,String away,int homePct,int drawPct,int awayPct){
        ArrayList<TicketBatchGenerator.Candidate> out=new ArrayList<>();
        StatisticalCalibrationEngine.Outcome3 o=StatisticalCalibrationEngine.normalizeOutcome(homePct,drawPct,awayPct,"Predição inicial");
        if(o==null)return out;

        int oneX=o.home+o.draw, xTwo=o.draw+o.away, twelve=o.home+o.away;
        // All mathematically valid 1X2-derived review alternatives are retained so the batch generator
        // can build the requested number of distinct tickets without inventing history or odds.
        add(out,eventKey,matchup,league,kickoff,"Dupla chance",home+" ou Empate",oneX);
        add(out,eventKey,matchup,league,kickoff,"Dupla chance","Empate ou "+away,xTwo);
        add(out,eventKey,matchup,league,kickoff,"Dupla chance",home+" ou "+away,twelve);
        add(out,eventKey,matchup,league,kickoff,"Empate anula",home+" • empate anula",StatisticalCalibrationEngine.drawNoBetProbability(o,true));
        add(out,eventKey,matchup,league,kickoff,"Empate anula",away+" • empate anula",StatisticalCalibrationEngine.drawNoBetProbability(o,false));
        add(out,eventKey,matchup,league,kickoff,"Resultado",home,o.home);
        add(out,eventKey,matchup,league,kickoff,"Resultado","Empate",o.draw);
        add(out,eventKey,matchup,league,kickoff,"Resultado",away,o.away);
        Collections.sort(out,(a,b)->{int z=Integer.compare(b.rawProbability,a.rawProbability);return z!=0?z:a.signature().compareTo(b.signature());});
        return out;
    }

    private static void add(ArrayList<TicketBatchGenerator.Candidate> out,String eventKey,String matchup,String league,String kickoff,String market,String pick,int raw){
        StatisticalCalibrationEngine.Calibration c=StatisticalCalibrationEngine.calibrate(raw,0,0,0,0,0,Double.NaN,Double.NaN,true);
        c.status="REVISÃO NECESSÁRIA";c.risk="RISCO ALTO";c.confidenceLevel="BAIXA";
        out.add(new TicketBatchGenerator.Candidate(eventKey,matchup,league,kickoff,market,pick,c.rawProbability,c.calibratedProbability,c.confidenceScore,0,0,0,Double.NaN,c.status,c.risk,c.confidenceLevel,"SEM FONTE CONFIRMADA","não confirmado"));
    }
    private InitialPredictionTicketFactory(){}
}
