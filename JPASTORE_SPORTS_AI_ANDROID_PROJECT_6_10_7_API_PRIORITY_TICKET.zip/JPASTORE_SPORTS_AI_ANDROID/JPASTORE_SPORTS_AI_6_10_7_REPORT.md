# J.PASTORE AI 6.10.7 — API Priority + Ticket

## Escopo
Correção concentrada somente na rota de pesquisa/análise de futebol e no abastecimento do gerador de bilhetes. Interface, home, logos, persistência estrutural, MarketCollector e fórmulas do motor estatístico foram preservados.

## Causa raiz — análises superficiais
A 5DollarFootballAPI já estava conectada, porém a orquestração externa da análise normal encerrava a camada rápida em cerca de 2,2 s. A própria integração 5Dollar pode precisar resolver o evento, consultar o histórico das duas equipes e consultar odds. Portanto, em vários confrontos a tarefa era cancelada antes de a fonte estruturada entregar a amostra.

Além disso, no lote de bilhetes de futebol o caminho usava `researchPublicOnly()`. Isso significava que o lote podia ignorar justamente as duas APIs configuradas mais úteis para futebol (5Dollar e API-Football) e depender de fontes públicas/fallback.

## Nova rota 6.10.7
1. **5DollarFootballAPI — primária:** recebe a primeira janela real de pesquisa (7,2 s normal / 11 s profunda) e reutiliza cache de histórico/odds.
2. **API-Football — segunda camada:** complementa a 5Dollar quando a cobertura ainda é curta e é sempre usada na análise aprofundada.
3. **Internet/fontes públicas — terceira camada:** confirma/enriquece a análise quando necessário; na análise profunda continua habilitada.
4. **MarketCollector:** permanece separado e preservado para odds/mercados.

### Proteção da cota 5Dollar
O app considera 60 requisições/hora como limite padrão quando o provedor ainda não informou outro valor e mantém cerca de 10% de reserva. Assim, o teto local padrão é **54 requisições/hora**. Cabeçalhos de limite/restante/reset e `Retry-After` continuam sendo respeitados. Cache não consome uma nova chamada de rede.

O objetivo não é “gastar 60 por hora”; é dar prioridade e profundidade à 5Dollar sem provocar 429 nem deixar uma análise consumir a cota inteira.

## Bilhetes
O lote de futebol agora usa a mesma rota priorizada 5Dollar → API-Football → internet. A concorrência de futebol foi reduzida para no máximo 2 análises simultâneas para evitar rajadas no provedor; os demais esportes continuam em até 4.

Quando a análise profunda ainda não existe, o fallback 1X2 passa a expor **8 alternativas matematicamente deriváveis**, sem inventar odds ou histórico:
- 3 duplas chances;
- 2 empate-anula;
- 3 resultados 1X2.

Todas continuam marcadas `REVISÃO NECESSÁRIA / RISCO ALTO` quando não há confirmação real. O modo CONSERVADOR continua rejeitando automaticamente essas seleções.

Teste de lote somente com predição inicial:
- 2 confrontos selecionados;
- 16 alternativas legítimas disponíveis;
- solicitados: 12;
- gerados: 12;
- distintos: 12.

Com 10 solicitados no mesmo cenário, são gerados 10. Se existir literalmente apenas **um único confronto** e nenhum dado além do 1X2, existem somente 8 alternativas distintas legítimas; o app não fabrica uma 9ª/10ª aposta. Com dois ou mais confrontos, o combinador tem pool suficiente para atingir 10/12 nos testes.

## Motor estatístico preservado
`StatisticalCalibrationEngine.java` não foi alterado. SHA-256 antes e depois:
`e5d4b59d20fdc5efa174339540127ec7ec5e2bce8609c4a7e67608fe6253c04e`

Não foram alteradas nesta rodada as fórmulas de:
- rawProbability;
- calibratedProbability;
- confidenceScore;
- forma ponderada;
- Poisson/calibração principal.

## Arquivos de produção alterados
- `app/build.gradle` — somente versão 70 / 6.10.7.
- `ApiClient.java` — orquestração da prioridade das fontes.
- `FiveDollarFootballClient.java` — orçamento/cota local + research estruturado.
- `MultiSportWebClient.java` — rota priorizada para futebol.
- `PremiumView.java` — lote usa a rota priorizada + fallback de predição API-Football.
- `InitialPredictionTicketFactory.java` — 8 alternativas legítimas derivadas do 1X2.
- `ResearchRoutePolicy.java` — novo arquivo isolando somente política de tempo/ordem das fontes.

Arquivos de teste/release/CI também foram atualizados, sem efeito nas fórmulas do app.

## Testes
- API Priority + Ticket: 10/10 + 9 checks Android.
- Initial Ticket Fallback: 29/29.
- Structural Flow: 14/14 + 9 checks Android.
- Agenda + Ticket Optimizer: 13/13.
- Market Collector: 15/15 + 6 checks estruturais.
- Production Tuning: 12/12.
- Speed + Logo/Route: 10/10.
- Logo Optimizer: 8/8.
- Statistical Calibration: 20/20.

## Build
A compilação completa do APK não foi executada neste container por ausência do Android SDK/Gradle. O workflow `build-apk.yml` foi atualizado para validar a 6.10.7, executar toda a regressão, compilar no GitHub Actions e publicar o APK tanto como Artifact quanto em **GitHub Releases**.

## Versão
- versionCode: **70**
- versionName: **6.10.7-api-priority-ticket**
