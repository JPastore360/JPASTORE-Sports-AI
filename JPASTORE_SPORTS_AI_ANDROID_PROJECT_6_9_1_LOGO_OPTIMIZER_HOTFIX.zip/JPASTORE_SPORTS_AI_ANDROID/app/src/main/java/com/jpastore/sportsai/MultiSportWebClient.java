package com.jpastore.sportsai;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.regex.*;
import java.util.concurrent.*;

/**
 * Internet-first research layer for non-football sports.
 * 6.3: Consensus Intelligence Engine. Public structured sources, open-web search, page reading and
 * local evidence fusion are attempted before API-Sports. Each historical result keeps source provenance,
 * duplicate confirmations are merged, score conflicts are flagged instead of averaged blindly, and the
 * J.Pastore IA can calculate transparent source-balanced consensus metrics. API-Sports is last-resort.
 */
class MultiSportWebClient {
    private final Context c;
    private static final String UA="Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36 JPASTORE-Sports-AI/6.9";

    static class SearchItem {
        String title="",snippet="",url="",titlePt="",snippetPt="";
        SearchItem(String t,String s,String u){title=t;snippet=s;url=u;titlePt=t;snippetPt=s;}
    }
    static class Research {
        String query="",source="Internet",diagnostic="",homeName="",awayName="";
        long targetHomeId=0,targetAwayId=0;
        String homeForm="",awayForm="";
        int homeWins=0,homeLosses=0,homeDraws=0,awayWins=0,awayLosses=0,awayDraws=0;
        int homeSample=0,awaySample=0; double homeFor=0,homeAgainst=0,awayFor=0,awayAgainst=0;
        ArrayList<String> recentHome=new ArrayList<>(),recentAway=new ArrayList<>(),h2h=new ArrayList<>();
        ArrayList<SearchItem> web=new ArrayList<>();
        ArrayList<GameRow> mergedHome=new ArrayList<>(),mergedAway=new ArrayList<>(),mergedH2h=new ArrayList<>();
        LinkedHashSet<String> structuredSources=new LinkedHashSet<>();
        MarketOddsBook marketOdds=new MarketOddsBook();
        long updatedAt=System.currentTimeMillis();
        boolean hasStructured(){return !recentHome.isEmpty()||!recentAway.isEmpty()||!h2h.isEmpty();}
        int commonSample(){int a=homeWins+homeDraws+homeLosses,b=awayWins+awayDraws+awayLosses;return Math.min(a,b);}
    }
    static class GameRow {
        String date="",home="",away="",score="",status="";long homeId=0,awayId=0;int hs=-1,as=-1;boolean completed=false,sourceConflict=false;
        LinkedHashSet<String> sources=new LinkedHashSet<>();
        boolean involves(String team){return teamMatch(team,home)||teamMatch(team,away);}
        boolean homeSide(String team){return teamMatch(team,home);}
        String opponent(String team){return homeSide(team)?away:home;}
        String form(String team){if(!completed||hs<0||as<0)return "";int f=homeSide(team)?hs:as,a=homeSide(team)?as:hs;return f>a?"V":(f==a?"E":"D");}
        int confirmations(){return Math.max(1,sources.size());}
        String sourceText(){StringBuilder b=new StringBuilder();for(String x:sources){if(b.length()>0)b.append(" + ");b.append(x);}return b.toString();}
        String row(){return date+" • "+home+" "+(hs>=0?hs:"—")+" × "+(as>=0?as:"—")+" "+away+(sources.size()>1?" • confirmado "+sources.size()+" fontes":"")+(sourceConflict?" • CONFLITO DE FONTE":"");}
    }

    MultiSportWebClient(Context c){this.c=c;}

    void research(String sport, MultiSportClient.Event ev, Consumer<Research> ok, Consumer<String> err){
        research(sport,ev,false,null,ok,err);
    }
    void research(String sport, MultiSportClient.Event ev, ResearchProgress progress, Consumer<Research> ok, Consumer<String> err){
        research(sport,ev,false,progress,ok,err);
    }
    void researchDeep(String sport, MultiSportClient.Event ev, ResearchProgress progress, Consumer<Research> ok, Consumer<String> err){
        research(sport,ev,true,progress,ok,err);
    }
    void research(String sport, MultiSportClient.Event ev, boolean deep, ResearchProgress progress, Consumer<Research> ok, Consumer<String> err){
        new Thread(()->{
            try{
                Research r=seedResearch(sport,ev);report(progress,4,"Preparando identidade e aliases");
                boolean highlight=MultiSportClient.BASKETBALL.equals(sport)&&HighlightlyBasketballClient.configured(c);
                int workers=highlight?4:3;
                report(progress,9,highlight?"FAST Basketball • Highlightly + fontes públicas em paralelo":"Consultando fontes estruturadas em paralelo");
                ExecutorService ex=Executors.newFixedThreadPool(workers);CompletionService<Research> cs=new ExecutorCompletionService<>(ex);
                cs.submit(()->{Research x=seedResearch(sport,ev);try{loadStructured(sport,ev,x);}catch(Exception ignored){}return x;});
                cs.submit(()->{Research x=seedResearch(sport,ev);try{loadSofaHistory(sport,ev,x);}catch(Exception ignored){}return x;});
                cs.submit(()->{Research x=seedResearch(sport,ev);try{loadSportsDbHistory(sport,ev,x);}catch(Exception ignored){}return x;});
                if(highlight)cs.submit(()->{try{return new HighlightlyBasketballClient(c).research(HighlightlyBasketballClient.key(c),ev,deep);}catch(Exception ignored){return null;}});
                long deadline=System.currentTimeMillis()+(deep?7200L:4300L);int received=0;
                while(received<workers){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{Future<Research> f=cs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;Research x=f.get();mergeResearch(r,x,ev);received++;report(progress,14+Math.min(26,received*7),"Cruzando fontes • "+r.commonSample()+" jogos por lado");}catch(Exception ignored){received++;}}
                ex.shutdownNow();rebuildResearch(r);

                // A análise normal tem orçamento curto: web aberta só entra quando as fontes rápidas
                // ainda não entregaram evidência mínima. A análise profunda continua podendo ampliar a varredura.
                boolean enough=r.commonSample()>=(deep?8:5)&&r.structuredSources.size()>=2;
                if(!enough){
                    report(progress,44,deep?"Análise Profunda • ampliando busca na internet":"Cobertura curta • busca web com orçamento de tempo");
                    mergeResearch(r,timedOpenWebHistory(sport,ev,deep,deep?5200L:1800L),ev);
                } else report(progress,58,"Fontes rápidas suficientes • evitando espera desnecessária");
                if(deep)mergeResearch(r,timedDeepWebSweep(sport,ev,3000L),ev);
                rebuildResearch(r);

                int minPublic=deep?5:3;
                if(r.commonSample()<minPublic)try{loadApiHistory(sport,ev,r);}catch(Exception ex2){if(r.diagnostic==null||r.diagnostic.trim().isEmpty())r.diagnostic="As fontes rápidas não completaram a amostra e a API complementar não respondeu agora.";}
                try{loadOptionalOdds(sport,ev,r);}catch(Exception ignored){}
                report(progress,84,"J.Pastore IA • consenso, dispersão e mercado");

                // Pesquisa de contexto não bloqueia mais um histórico estruturado já utilizável.
                if(r.web.isEmpty()&&(!r.hasStructured()||deep)){ArrayList<SearchItem> ctx=timedWebSearch(r.query,deep?8:4,deep?2600L:1200L);for(SearchItem it:ctx)addSearchUnique(r.web,it);}
                localize(r.web);rebuildResearch(r);
                if(!r.hasStructured()&&r.web.isEmpty())throw new IOException("Nenhuma fonte respondeu agora");
                if(r.hasStructured()){
                    r.source=sourceLabel(r);boolean api=r.structuredSources.contains("API-Sports");
                    SportConsensusEngine.Consensus cc=SportConsensusEngine.analyze(sport,ev,r);
                    r.diagnostic="Fast Research 6.9: "+r.recentHome.size()+" jogos de "+safe(r.homeName,"participante 1")+", "+r.recentAway.size()+" de "+safe(r.awayName,"participante 2")+" e "+r.h2h.size()+" H2H • "+sourceLabel(r)+" • "+cc.level+" • "+cc.sourceCount+" fontes • convergência "+cc.agreement+"%"+(highlight?" • Highlightly ativa.":"")+(api?" • API-Sports complementar.":"");
                }
                report(progress,100,deep?"Análise Profunda concluída":"Análise rápida concluída");ok.accept(r);
            }catch(Exception e){report(progress,100,"Pesquisa concluída com cobertura limitada");err.accept(e.getMessage()==null?"Pesquisa indisponível":e.getMessage());}
        }).start();
    }

    /** Public/provider synchronous research used by the unified engine. API-Sports remains disabled here,
     * but an explicitly configured Highlightly key can be used as a fast basketball source. */
    Research researchPublicOnly(String sport,MultiSportClient.Event ev,boolean deep,ResearchProgress progress)throws Exception{
        Research r=seedResearch(sport,ev);report(progress,4,"Preparando aliases e identidade");boolean highlight=MultiSportClient.BASKETBALL.equals(sport)&&HighlightlyBasketballClient.configured(c);int workers=highlight?4:3;
        ExecutorService ex=Executors.newFixedThreadPool(workers);CompletionService<Research> cs=new ExecutorCompletionService<>(ex);
        cs.submit(()->{Research x=seedResearch(sport,ev);try{loadStructured(sport,ev,x);}catch(Exception ignored){}return x;});
        cs.submit(()->{Research x=seedResearch(sport,ev);try{loadSofaHistory(sport,ev,x);}catch(Exception ignored){}return x;});
        cs.submit(()->{Research x=seedResearch(sport,ev);try{loadSportsDbHistory(sport,ev,x);}catch(Exception ignored){}return x;});
        if(highlight)cs.submit(()->{try{return new HighlightlyBasketballClient(c).research(HighlightlyBasketballClient.key(c),ev,deep);}catch(Exception ignored){return null;}});
        long deadline=System.currentTimeMillis()+(deep?6800L:4000L);int received=0;while(received<workers){long left=deadline-System.currentTimeMillis();if(left<=0)break;try{Future<Research> f=cs.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;mergeResearch(r,f.get(),ev);received++;report(progress,12+Math.min(28,received*7),"Cruzando fontes rápidas");}catch(Exception ignored){received++;}}ex.shutdownNow();rebuildResearch(r);
        boolean enough=r.commonSample()>=(deep?8:5)&&r.structuredSources.size()>=2;report(progress,48,enough?"Amostra rápida suficiente":"Cobertura curta • busca web limitada");
        if(!enough)mergeResearch(r,timedOpenWebHistory(sport,ev,deep,deep?5000L:1700L),ev);
        if(deep)mergeResearch(r,timedDeepWebSweep(sport,ev,2800L),ev);rebuildResearch(r);
        if(r.web.isEmpty()&&(!r.hasStructured()||deep)){ArrayList<SearchItem> ctx=timedWebSearch(r.query,deep?8:4,deep?2400L:1100L);for(SearchItem it:ctx)addSearchUnique(r.web,it);}localize(r.web);rebuildResearch(r);
        report(progress,100,"Pesquisa concluída • "+r.commonSample()+" jogos por lado");return r;
    }

    Research seedResearch(String sport,MultiSportClient.Event ev){Research r=new Research();r.query=buildQuery(sport,ev);if(ev!=null){r.homeName=safe(ev.home,"");r.awayName=safe(ev.away,"");r.targetHomeId=ev.homeId;r.targetAwayId=ev.awayId;}return r;}
    void mergeResearch(Research dst,Research src,MultiSportClient.Event ev){if(dst==null||src==null)return;mergeSourceRows(dst,new ArrayList<>(src.mergedHome),ev,"");mergeSourceRows(dst,new ArrayList<>(src.mergedAway),ev,"");mergeSourceRows(dst,new ArrayList<>(src.mergedH2h),ev,"");dst.structuredSources.addAll(src.structuredSources);if(src.marketOdds!=null)dst.marketOdds.merge(src.marketOdds);for(SearchItem it:src.web)addSearchUnique(dst.web,it);}

    /** Runs slow/open-web enrichment behind a hard budget. Results are accumulated in a temporary
     * Research object so a cancelled worker cannot mutate the UI-visible analysis after timeout. */
    Research timedOpenWebHistory(String sport,MultiSportClient.Event ev,boolean deep,long maxMs){
        ExecutorService ex=Executors.newSingleThreadExecutor();Future<Research> f=ex.submit(()->{Research x=seedResearch(sport,ev);try{loadOpenWebHistory(sport,ev,x,deep);}catch(Exception ignored){}rebuildResearch(x);return x;});
        try{return f.get(Math.max(250L,maxMs),TimeUnit.MILLISECONDS);}catch(Exception e){f.cancel(true);return null;}finally{ex.shutdownNow();}
    }
    Research timedDeepWebSweep(String sport,MultiSportClient.Event ev,long maxMs){
        ExecutorService ex=Executors.newSingleThreadExecutor();Future<Research> f=ex.submit(()->{Research x=seedResearch(sport,ev);try{deepWebSweep(sport,ev,x);}catch(Exception ignored){}return x;});
        try{return f.get(Math.max(250L,maxMs),TimeUnit.MILLISECONDS);}catch(Exception e){f.cancel(true);return null;}finally{ex.shutdownNow();}
    }
    ArrayList<SearchItem> timedWebSearch(String query,int limit,long maxMs){
        ExecutorService ex=Executors.newSingleThreadExecutor();Future<ArrayList<SearchItem>> f=ex.submit(()->{try{return webSearch(query,limit);}catch(Exception e){return new ArrayList<>();}});
        try{return f.get(Math.max(250L,maxMs),TimeUnit.MILLISECONDS);}catch(Exception e){f.cancel(true);return new ArrayList<>();}finally{ex.shutdownNow();}
    }
    static void report(ResearchProgress p,int percent,String stage){if(p!=null)try{p.onProgress(Math.max(0,Math.min(100,percent)),stage);}catch(Exception ignored){}}

    String buildQuery(String sport,MultiSportClient.Event e){
        String pair=e==null?"":e.matchup();String comp=e==null?"":safe(e.competition,"");String base=(pair+" "+comp).trim();
        if(MultiSportClient.MMA.equals(sport))return base+" MMA estatísticas cartel últimos resultados luta";
        if(MultiSportClient.F1.equals(sport))return base+" Fórmula 1 resultados classificação pilotos estatísticas";
        if(MultiSportClient.NFL.equals(sport))return base+" NFL estatísticas confronto lesões forma recente resultados";
        if(MultiSportClient.BASEBALL.equals(sport))return base+" baseball estatísticas confronto forma recente resultados";
        if(MultiSportClient.BASKETBALL.equals(sport))return base+" basquete estatísticas confronto forma recente resultados";
        if(MultiSportClient.FOOTBALL.equals(sport))return base+" futebol últimos jogos estatísticas confronto forma gols escanteios cartões";
        return base+" esporte estatísticas confronto resultados";
    }

    void loadStructured(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        String path=espnPath(sport,ev);if(path==null||ev==null)return;
        Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("UTC"));Date end=cal.getTime();cal.add(Calendar.DAY_OF_MONTH,-210);Date start=cal.getTime();
        SimpleDateFormat f=new SimpleDateFormat("yyyyMMdd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
        String url="https://site.api.espn.com/apis/site/v2/sports/"+path+"/scoreboard?dates="+f.format(start)+"-"+f.format(end)+"&limit=1000";
        String raw=cached("ms_espn_"+sport+"_"+safe(ev.home,"x")+"_"+safe(ev.away,"y"),url,90L*60*1000L);
        ArrayList<GameRow> all=parseScoreboard(raw);Collections.sort(all,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));
        mergeSourceRows(r,all,ev,"ESPN");
    }


    /** Public structured fallback. SofaScore has no official public API contract, so failures are silent
     * and the app immediately continues to the configured provider. No missing values are invented. */
    void loadSofaHistory(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        if(ev==null||r==null||MultiSportClient.F1.equals(sport))return;
        String slug=sofaSportSlug(sport);if(slug.isEmpty())return;
        long[] pair=sofaFindPairIds(slug,ev);
        long home=pair[0]>0?pair[0]:sofaFindTeamId(safe(ev.home,""),slug);
        long away=pair[1]>0?pair[1]:sofaFindTeamId(safe(ev.away,""),slug);
        ArrayList<GameRow> hr=new ArrayList<>(),ar=new ArrayList<>();
        if(home>0)hr=sofaTeamRows(home);
        if(away>0)ar=sofaTeamRows(away);
        mergeSourceRows(r,hr,ev,"SofaScore");
        mergeSourceRows(r,ar,ev,"SofaScore");
    }

    static String sofaSportSlug(String sport){
        if(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NBA.equals(sport))return "basketball";
        if(MultiSportClient.BASEBALL.equals(sport))return "baseball";
        if(MultiSportClient.NFL.equals(sport))return "american-football";
        if(MultiSportClient.MMA.equals(sport))return "mma";
        if(MultiSportClient.FOOTBALL.equals(sport))return "football";
        return "";
    }

    /** Resolve IDs diretamente pelo calendário do dia. É mais confiável que procurar os times
     * separadamente quando os nomes são abreviados (ex.: W, BC, Breakers) ou há homônimos. */
    long[] sofaFindPairIds(String sportSlug,MultiSportClient.Event ev)throws Exception{
        long[] out={0,0};if(ev==null||safe(ev.date,"").length()<10)return out;
        ArrayList<String> dates=new ArrayList<>();dates.add(ev.date.substring(0,10));
        String prev=shiftDate(ev.date.substring(0,10),-1),next=shiftDate(ev.date.substring(0,10),1);if(!prev.isEmpty())dates.add(prev);if(!next.isEmpty())dates.add(next);
        for(String date:dates){
            try{
                String url="https://api.sofascore.com/api/v1/sport/"+sportSlug+"/scheduled-events/"+date;
                String raw=sofaCached("schedule_"+sportSlug+"_"+date,url,20L*60*1000L);JSONArray a=new JSONObject(raw).optJSONArray("events");if(a==null)continue;
                for(int i=0;i<a.length();i++){
                    JSONObject e=a.optJSONObject(i);if(e==null)continue;JSONObject h=e.optJSONObject("homeTeam"),v=e.optJSONObject("awayTeam");if(h==null||v==null)continue;
                    String hn=h.optString("name",""),vn=v.optString("name","");
                    if(teamMatch(ev.home,hn)&&teamMatch(ev.away,vn)){out[0]=h.optLong("id",0);out[1]=v.optLong("id",0);return out;}
                    if(teamMatch(ev.home,vn)&&teamMatch(ev.away,hn)){out[0]=v.optLong("id",0);out[1]=h.optLong("id",0);return out;}
                }
            }catch(Exception ignored){}
        }
        return out;
    }

    static String shiftDate(String date,int days){
        try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);Date d=f.parse(date);Calendar c=Calendar.getInstance();c.setTime(d);c.add(Calendar.DAY_OF_MONTH,days);return f.format(c.getTime());}catch(Exception e){return "";}
    }

    long sofaFindTeamId(String name,String sportSlug)throws Exception{
        if(name==null||name.trim().isEmpty())return 0;
        String q=URLEncoder.encode(name.trim(),"UTF-8");
        String url="https://api.sofascore.com/api/v1/search/all/?q="+q+"&page=0";
        String raw=sofaCached("search_"+sportSlug+"_"+norm(name),url,12L*60*60*1000L);
        JSONArray results=new JSONObject(raw).optJSONArray("results");if(results==null)return 0;
        long bestId=0;double best=-1;
        for(int i=0;i<results.length();i++){
            JSONObject item=results.optJSONObject(i);if(item==null||!"team".equalsIgnoreCase(item.optString("type")))continue;
            JSONObject e=item.optJSONObject("entity");if(e==null)continue;JSONObject sp=e.optJSONObject("sport");String ss=sp==null?"":sp.optString("slug","");
            if(!sportSlug.equalsIgnoreCase(ss))continue;String n=first(e.optString("name",""),e.optString("shortName",""));
            double sim=teamSimilarity(name,n);if(sim<0.42)continue;
            double score=item.optDouble("score",0)+(sim*100_000_000d);if(norm(name).equals(norm(n)))score+=1_000_000_000d;else if(norm(n).contains(norm(name))||norm(name).contains(norm(n)))score+=100_000_000d;
            if(score>best){best=score;bestId=e.optLong("id",0);}
        }
        return bestId;
    }

    ArrayList<GameRow> sofaTeamRows(long teamId)throws Exception{
        ArrayList<GameRow> out=new ArrayList<>();HashSet<Long> seen=new HashSet<>();
        for(int page=0;page<2&&out.size()<16;page++){
            String url="https://api.sofascore.com/api/v1/team/"+teamId+"/events/last/"+page;
            String raw=sofaCached("team_"+teamId+"_last_"+page,url,45L*60*1000L);JSONObject root=new JSONObject(raw);JSONArray evs=root.optJSONArray("events");if(evs==null)break;
            for(int i=0;i<evs.length();i++){JSONObject e=evs.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id>0&&!seen.add(id))continue;GameRow g=sofaEvent(e);if(g!=null&&g.completed)out.add(g);}
            if(!root.optBoolean("hasNextPage",false))break;
        }
        Collections.sort(out,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));return out;
    }

    GameRow sofaEvent(JSONObject e){
        if(e==null)return null;JSONObject h=e.optJSONObject("homeTeam"),a=e.optJSONObject("awayTeam");if(h==null||a==null)return null;
        GameRow g=new GameRow();g.home=h.optString("name","");g.away=a.optString("name","");g.homeId=h.optLong("id",0);g.awayId=a.optLong("id",0);
        JSONObject hs=e.optJSONObject("homeScore"),as=e.optJSONObject("awayScore");g.hs=sofaScore(hs);g.as=sofaScore(as);
        JSONObject st=e.optJSONObject("status");String type=st==null?"":st.optString("type","");g.status=first(type,st==null?"":st.optString("description",""));g.completed="finished".equalsIgnoreCase(type)||(st!=null&&st.optInt("code",0)==100);
        long ts=e.optLong("startTimestamp",0);if(ts>0){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));g.date=f.format(new Date(ts*1000L));}
        g.score=(g.hs>=0?String.valueOf(g.hs):"—")+" × "+(g.as>=0?String.valueOf(g.as):"—");if(g.hs<0||g.as<0)g.completed=false;return g;
    }

    static int sofaScore(JSONObject s){if(s==null)return -1;int v=intValue(s.opt("current"));if(v>=0)return v;v=intValue(s.opt("display"));if(v>=0)return v;return intValue(s.opt("normaltime"));}

    String sofaCached(String key,String url,long ttl)throws Exception{
        String k="sofa_"+Integer.toHexString(key.hashCode());android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;
        try{String raw=fetchSofa(url);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception ex){if(old!=null)return old;throw ex;}
    }

    String fetchSofa(String url)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(5500);h.setReadTimeout(6500);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept","application/json");h.setRequestProperty("Referer","https://www.sofascore.com/");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader br=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String x;(x=br.readLine())!=null;)b.append(x);return b.toString();
    }

    /** Optional real bookmaker odds. Provider odds are calibration evidence only and never gate analysis. */
    void loadOptionalOdds(String sport,MultiSportClient.Event ev,Research r){
        if(ev==null||r==null)return;
        // Highlightly is the preferred optional basketball market source when explicitly configured.
        if(MultiSportClient.BASKETBALL.equals(sport)&&HighlightlyBasketballClient.configured(c)){
            try{HighlightlyBasketballClient hc=new HighlightlyBasketballClient(c);hc.resolve(HighlightlyBasketballClient.key(c),ev);MarketOddsBook hb=hc.odds(HighlightlyBasketballClient.key(c),ev);if(hb!=null&&!hb.isEmpty())r.marketOdds.merge(hb);}catch(Exception ignored){}
        }
        if(!(c instanceof MainActivity)||ev.id<=0)return;
        String source=safe(ev.apiSource,sport);
        // IDs owned only by public/Highlightly sources must never be sent to API-Sports.
        if(source.startsWith("public-")||source.contains(HighlightlyBasketballClient.SOURCE))return;
        if(MultiSportClient.MMA.equals(sport)||MultiSportClient.F1.equals(sport)||MultiSportClient.NBA.equals(source))return;
        if(MultiSportClient.BASKETBALL.equals(sport))source=MultiSportClient.BASKETBALL;
        MultiSportClient guard=new MultiSportClient(c);if(guard.apiCircuitOpen(source))return;
        String key=((MainActivity)c).apiKeyFor(source);if(key==null||key.trim().isEmpty())return;
        MarketOddsBook b=new MarketOddsClient(c).sport(source,key.trim(),ev);if(b!=null&&!b.isEmpty())r.marketOdds.merge(b);
    }

    /** Structured historical fallback using the API source that supplied the schedule card. */
    void loadApiHistory(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        if(ev==null||!(c instanceof MainActivity))return;
        if(ev.apiSource!=null&&(ev.apiSource.startsWith("public-")||ev.apiSource.contains(HighlightlyBasketballClient.SOURCE))){r.diagnostic="Cobertura estruturada parcial; IDs de fontes públicas/Highlightly não são reutilizados como IDs da API-Sports.";return;}
        if(MultiSportClient.MMA.equals(sport)||MultiSportClient.F1.equals(sport))return; // separate models required
        String source=safe(ev.apiSource,sport);
        if(MultiSportClient.BASKETBALL.equals(sport)&&!MultiSportClient.NBA.equals(source))source=MultiSportClient.BASKETBALL;
        MainActivity a=(MainActivity)c;MultiSportClient guard=new MultiSportClient(c);if(guard.apiCircuitOpen(source)){r.diagnostic="A cota diária da API complementar acabou; o Research Engine continua somente com internet pública e cache.";return;}String key=a.apiKeyFor(source);
        if(key==null||key.trim().isEmpty()){r.diagnostic="A busca pública continua ativa sem chave; não há API opcional configurada para complementar o histórico.";return;}
        if(ev.homeId<=0&&ev.awayId<=0){r.diagnostic="A agenda não forneceu IDs dos participantes para recuperar o histórico estruturado.";return;}
        MultiSportClient cli=new MultiSportClient(c);
        StringBuilder trace=new StringBuilder();
        ArrayList<GameRow> homeRows=new ArrayList<>(),awayRows=new ArrayList<>();

        if(ev.homeId>0)homeRows=apiTeamRows(cli,source,ev.homeId,ev.leagueId,ev.season,key,trace);
        if(ev.awayId>0)awayRows=apiTeamRows(cli,source,ev.awayId,ev.leagueId,ev.season,key,trace);
        mergeSourceRows(r,homeRows,ev,"API-Sports");
        mergeSourceRows(r,awayRows,ev,"API-Sports");

        if(ev.homeId>0&&ev.awayId>0){
            try{ArrayList<GameRow> rows=apiRows(cli,source,apiRaw(cli,source,"games?h2h="+ev.homeId+"-"+ev.awayId,key));mergeSourceRows(r,rows,ev,"API-Sports");}catch(Exception ex){appendTrace(trace,"H2H indisponível");}
        }
        if(r.commonSample()<3&&trace.length()>0)r.diagnostic="Histórico API parcial: "+trace+".";
    }

    /**
     * Funde resultados estruturados de fontes diferentes. Um jogo parcial de uma fonte pode
     * completar a amostra de outra; duplicatas são removidas por data, placar e nomes equivalentes.
     * Isso evita descartar um confronto só porque nenhuma fonte, isoladamente, trouxe 3-8 jogos.
     */
    void mergeSourceRows(Research r,ArrayList<GameRow> rows,MultiSportClient.Event ev,String sourceName){
        if(r==null||rows==null||ev==null)return;boolean any=false;
        synchronized(r){
        for(GameRow g:rows){
            if(g==null||!g.completed||g.hs<0||g.as<0)continue;
            // Busca Web pode trazer o domínio real (ex.: flashscore.com); não substituímos por um rótulo genérico.
            if(sourceName!=null&&!sourceName.trim().isEmpty()&&!("Busca Web".equals(sourceName)&&!g.sources.isEmpty()))g.sources.add(sourceName.trim());
            boolean hm=matchesTarget(g,ev.home,ev.homeId),am=matchesTarget(g,ev.away,ev.awayId);
            if(hm){addUniqueGame(r.mergedHome,g);any=true;}
            if(am){addUniqueGame(r.mergedAway,g);any=true;}
            if(hm&&am)addUniqueGame(r.mergedH2h,g);
        }
        if(any&&sourceName!=null&&!sourceName.trim().isEmpty())r.structuredSources.add(sourceName.trim());
        if(any){for(GameRow g:rows){if(g==null)continue;if(teamMatch(ev.home,g.home))TeamIdentityResolver.remember(c,ev.home,g.home);if(teamMatch(ev.home,g.away))TeamIdentityResolver.remember(c,ev.home,g.away);if(teamMatch(ev.away,g.home))TeamIdentityResolver.remember(c,ev.away,g.home);if(teamMatch(ev.away,g.away))TeamIdentityResolver.remember(c,ev.away,g.away);}}
        rebuildResearch(r);
        }
    }

    static boolean matchesTarget(GameRow g,String name,long id){
        if(g==null)return false;
        if(id>0&&(g.homeId==id||g.awayId==id))return true;
        return teamMatch(name,g.home)||teamMatch(name,g.away);
    }

    static void addUniqueGame(ArrayList<GameRow> dst,GameRow g){
        if(dst==null||g==null)return;
        for(GameRow x:dst){
            if(!sameGame(x,g))continue;
            boolean sameScore=scoreEquivalent(x,g);
            if(!sameScore&&sameIdentityDate(x,g))x.sourceConflict=true;
            x.sources.addAll(g.sources);
            return;
        }
        dst.add(g);Collections.sort(dst,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));
        while(dst.size()>28)dst.remove(dst.size()-1);
    }

    static boolean scoreEquivalent(GameRow a,GameRow b){
        if(a==null||b==null||a.hs<0||a.as<0||b.hs<0||b.as<0)return false;
        boolean direct=teamMatch(a.home,b.home)&&teamMatch(a.away,b.away);
        boolean reverse=teamMatch(a.home,b.away)&&teamMatch(a.away,b.home);
        return direct?(a.hs==b.hs&&a.as==b.as):(reverse&&a.hs==b.as&&a.as==b.hs);
    }
    static boolean sameIdentityDate(GameRow a,GameRow b){
        if(a==null||b==null)return false;String ad=safe(a.date,""),bd=safe(b.date,"");
        boolean direct=teamMatch(a.home,b.home)&&teamMatch(a.away,b.away);
        boolean reverse=teamMatch(a.home,b.away)&&teamMatch(a.away,b.home);
        return (direct||reverse)&&!ad.isEmpty()&&ad.equals(bd);
    }
    static boolean sameGame(GameRow a,GameRow b){
        if(a==null||b==null)return false;
        String ad=safe(a.date,""),bd=safe(b.date,"");
        if(!ad.isEmpty()&&!bd.isEmpty()&&!ad.equals(bd))return false;
        boolean direct=teamMatch(a.home,b.home)&&teamMatch(a.away,b.away);
        boolean reverse=teamMatch(a.home,b.away)&&teamMatch(a.away,b.home);
        if(!(direct||reverse))return false;
        // Mesma data + mesmos participantes = o mesmo evento, mesmo quando duas fontes discordam do placar.
        if(!ad.isEmpty()&&ad.equals(bd))return true;
        // Sem data, só deduplicamos se o placar também coincide; isso evita fundir jogos diferentes do mesmo confronto.
        return scoreEquivalent(a,b);
    }

    void rebuildResearch(Research r){
        if(r==null)return;
        r.recentHome.clear();r.recentAway.clear();r.h2h.clear();
        r.homeWins=r.homeLosses=r.homeDraws=r.awayWins=r.awayLosses=r.awayDraws=0;
        r.homeSample=r.awaySample=0;r.homeFor=r.homeAgainst=r.awayFor=r.awayAgainst=0;
        fillTeam(r.mergedHome,r.homeName,r.targetHomeId,r.recentHome,true,r);
        fillTeam(r.mergedAway,r.awayName,r.targetAwayId,r.recentAway,false,r);
        for(GameRow g:r.mergedH2h){if(g!=null&&g.completed){r.h2h.add(g.row());if(r.h2h.size()>=5)break;}}
        finishForms(r);
    }

    static String sourceLabel(Research r){
        if(r==null||r.structuredSources.isEmpty())return "Internet";
        StringBuilder b=new StringBuilder("Fontes combinadas • ");
        int i=0;for(String s:r.structuredSources){if(i++>0)b.append(" + ");b.append(s);}
        return b.toString();
    }

    ArrayList<GameRow> apiTeamRows(MultiSportClient cli,String source,long teamId,long leagueId,String season,String key,StringBuilder trace)throws Exception{
        String base="games?team="+teamId;ArrayList<GameRow> rows=new ArrayList<>();
        LinkedHashSet<String> attempts=new LinkedHashSet<>();
        attempts.add(base);
        if(leagueId>0)attempts.add(base+"&league="+leagueId);
        for(String ss:seasonCandidates(season)){
            if(leagueId>0)attempts.add(base+"&league="+leagueId+"&season="+URLEncoder.encode(ss,"UTF-8"));
            else attempts.add(base+"&season="+URLEncoder.encode(ss,"UTF-8"));
        }
        Exception last=null;LinkedHashMap<String,GameRow> merged=new LinkedHashMap<>();int calls=0;
        for(String path:attempts){
            if(calls++>=3)break;
            try{
                ArrayList<GameRow> got=apiRows(cli,source,apiRaw(cli,source,path,key));
                for(GameRow g:got){if(g==null||!g.completed)continue;String k=safe(g.date,"")+"|"+norm(g.home)+"|"+norm(g.away)+"|"+g.hs+"|"+g.as;if(!merged.containsKey(k))merged.put(k,g);}
                rows=new ArrayList<>(merged.values());Collections.sort(rows,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));if(countCompleted(rows)>=8)break;
            }catch(Exception ex){last=ex;}
        }
        if(countCompleted(rows)<3&&last!=null)appendTrace(trace,"time "+teamId+": "+safe(last.getMessage(),"consulta recusada"));
        Collections.sort(rows,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));return rows;
    }


    /**
     * Open-web research engine. It does not trust prediction text as statistics. Only explicit,
     * past score lines found in search snippets/pages are converted to GameRow objects.
     * Search and extracted team histories are cached aggressively to protect mobile data and APIs.
     */
    void loadOpenWebHistory(String sport,MultiSportClient.Event ev,Research r)throws Exception{loadOpenWebHistory(sport,ev,r,false);}
    void loadOpenWebHistory(String sport,MultiSportClient.Event ev,Research r,boolean deep)throws Exception{
        if(ev==null||r==null||MultiSportClient.F1.equals(sport)||MultiSportClient.MMA.equals(sport))return;
        ExecutorService ex=Executors.newFixedThreadPool(2);
        Future<ArrayList<GameRow>> fh=ex.submit(()->webTeamHistory(sport,safe(ev.home,""),safe(ev.competition,""),r,deep));
        Future<ArrayList<GameRow>> fa=ex.submit(()->webTeamHistory(sport,safe(ev.away,""),safe(ev.competition,""),r,deep));
        ArrayList<GameRow> home=new ArrayList<>(),away=new ArrayList<>();
        try{home=fh.get(deep?14:10,TimeUnit.SECONDS);}catch(Exception ignored){}try{away=fa.get(deep?14:10,TimeUnit.SECONDS);}catch(Exception ignored){}ex.shutdownNow();
        mergeSourceRows(r,home,ev,"Busca Web");mergeSourceRows(r,away,ev,"Busca Web");
        if(r.h2h.size()<(deep?4:2)){
            try{
                LinkedHashSet<String> qs=new LinkedHashSet<>();
                for(String h:TeamIdentityResolver.variants(c,ev.home))for(String a:TeamIdentityResolver.variants(c,ev.away)){qs.add("\""+h+"\" \""+a+"\" "+sportWord(sport)+" resultado h2h");if(qs.size()>=(deep?5:2))break;}
                ArrayList<SearchItem> exact=new ArrayList<>();for(String q:qs){try{for(SearchItem it:webSearch(q,deep?7:4))addSearchUnique(exact,it);}catch(Exception ignored){}}
                addWebItems(r,exact,deep?14:8);ArrayList<GameRow> rows=new ArrayList<>();int reads=0;
                Collections.sort(exact,(a,b)->Integer.compare(webRank(b,ev.home+" "+ev.away,ev.competition),webRank(a,ev.home+" "+ev.away,ev.competition)));
                for(SearchItem it:exact){ArrayList<GameRow> sn=extractWebRows((it.title+"\n"+it.snippet),ev.home,sport);tagRows(sn,webSourceName(it));mergeUniqueRows(rows,sn);if(reads<(deep?4:1)&&goodResultPage(it,ev.home+" "+ev.away)){String page=readPublicPage(it.url,true);reads++;ArrayList<GameRow> pg=extractWebRows(page.replaceFirst("^\\[READER\\]\\n",""),ev.home,sport);tagRows(pg,webSourceName(it));mergeUniqueRows(rows,pg);}if(rows.size()>=(deep?10:5))break;}
                mergeSourceRows(r,rows,ev,"Busca Web");
            }catch(Exception ignored){}
        }
    }

    ArrayList<GameRow> webTeamHistory(String sport,String team,String competition,Research r)throws Exception{return webTeamHistory(sport,team,competition,r,false);}
    ArrayList<GameRow> webTeamHistory(String sport,String team,String competition,Research r,boolean deep)throws Exception{
        ArrayList<GameRow> cachedRows=readWebTeamCache(sport,team,competition,deep?8L*60*60*1000L:18L*60*60*1000L);if(cachedRows!=null&&!cachedRows.isEmpty()&&(!deep||cachedRows.size()>=8))return cachedRows;
        ArrayList<GameRow> rows=new ArrayList<>();ArrayList<SearchItem> all=new ArrayList<>();LinkedHashSet<String> queries=new LinkedHashSet<>();String sw=sportWord(sport),comp=safe(competition,"");
        ArrayList<String> vars=TeamIdentityResolver.variants(c,team);if(vars.isEmpty())vars.add(team);int maxAlias=deep?4:2;
        for(int i=0;i<Math.min(maxAlias,vars.size());i++){String v=vars.get(i);queries.add("\""+v+"\" "+sw+" últimos jogos resultados scores");queries.add("\""+v+"\" "+sw+" last matches results recent form");if(!comp.isEmpty())queries.add("\""+v+"\" \""+comp+"\" resultados tabela jogos recentes");if(deep){queries.add(v+" "+sw+" resultados 2026 2025 2024");queries.add(v+" "+sw+" fixtures results statistics form");}}
        ExecutorService qx=Executors.newFixedThreadPool(Math.min(deep?5:3,Math.max(1,queries.size())));ArrayList<Future<ArrayList<SearchItem>>> fs=new ArrayList<>();for(String q:queries)fs.add(qx.submit(()->{try{return webSearch(q,deep?9:7);}catch(Exception e){return new ArrayList<>();}}));
        for(Future<ArrayList<SearchItem>> f:fs){try{for(SearchItem it:f.get(deep?10:7,TimeUnit.SECONDS))addSearchUnique(all,it);}catch(Exception ignored){}}qx.shutdownNow();Collections.sort(all,(a,b)->Integer.compare(webRank(b,team,competition),webRank(a,team,competition)));addWebItems(r,all,deep?14:8);
        int pages=0;boolean readerUsed=false,maxReached=false;for(SearchItem it:all){if(rows.size()>=(deep?18:10)){maxReached=true;break;}ArrayList<GameRow> sn=extractWebRows(it.title+"\n"+it.snippet,team,sport);tagRows(sn,webSourceName(it));mergeUniqueRows(rows,sn);if(rows.size()>=(deep?14:8)&&!deep)break;if(pages>=(deep?7:3)||!goodResultPage(it,team))continue;String page=readPublicPage(it.url,!readerUsed);if(page.startsWith("[READER]\n"))readerUsed=true;page=page.replaceFirst("^\\[READER\\]\\n","");pages++;ArrayList<GameRow> pg=extractWebRows(page,team,sport);tagRows(pg,webSourceName(it));mergeUniqueRows(rows,pg);}
        Collections.sort(rows,(a,b)->safe(b.date,"").compareTo(safe(a.date,"")));while(rows.size()>(deep?20:14))rows.remove(rows.size()-1);if(!rows.isEmpty())writeWebTeamCache(sport,team,competition,rows);return rows;
    }

    void deepWebSweep(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        if(ev==null||r==null)return;LinkedHashSet<String> qs=new LinkedHashSet<>();String sw=sportWord(sport);for(String h:TeamIdentityResolver.variants(c,ev.home)){qs.add(h+" "+sw+" scores results stats recent");if(qs.size()>=3)break;}for(String a:TeamIdentityResolver.variants(c,ev.away)){qs.add(a+" "+sw+" scores results stats recent");if(qs.size()>=6)break;}qs.add(ev.matchup()+" "+sw+" h2h results stats");ArrayList<SearchItem> web=new ArrayList<>();ExecutorService dx=Executors.newFixedThreadPool(Math.min(4,Math.max(1,qs.size())));ArrayList<Future<ArrayList<SearchItem>>> df=new ArrayList<>();for(String q:qs)df.add(dx.submit(()->{try{return webSearch(q,8);}catch(Exception e){return new ArrayList<>();}}));for(Future<ArrayList<SearchItem>> f:df)try{for(SearchItem it:f.get(10,TimeUnit.SECONDS))addSearchUnique(web,it);}catch(Exception ignored){}dx.shutdownNow();addWebItems(r,web,18);
    }

    /** Warm public caches in the background. Never spends the configured API quota. */
    void prefetch(String sport,List<MultiSportClient.Event> events){if(events==null||events.isEmpty())return;new Thread(()->{int n=Math.min(5,events.size());for(int i=0;i<n;i++){MultiSportClient.Event ev=events.get(i);try{Research r=seedResearch(sport,ev);loadStructured(sport,ev,r);loadSofaHistory(sport,ev,r);webTeamHistory(sport,safe(ev.home,""),safe(ev.competition,""),r,false);webTeamHistory(sport,safe(ev.away,""),safe(ev.competition,""),r,false);}catch(Exception ignored){}}}).start();}

    static String webSourceName(SearchItem it){String h=sourceHost(it==null?"":it.url);return h.isEmpty()?"Web pública":h;}
    static void tagRows(ArrayList<GameRow> rows,String source){if(rows==null||source==null||source.trim().isEmpty())return;for(GameRow g:rows)if(g!=null)g.sources.add(source.trim());}

    static String sportWord(String sport){
        if(MultiSportClient.FOOTBALL.equals(sport))return "football futebol soccer";
        if(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NBA.equals(sport))return "basketball basquete";
        if(MultiSportClient.BASEBALL.equals(sport))return "baseball";
        if(MultiSportClient.NFL.equals(sport))return "american football NFL";
        if(MultiSportClient.MMA.equals(sport))return "MMA";
        return "sports";
    }

    void addWebItems(Research r,ArrayList<SearchItem> src,int max){if(r==null||src==null)return;for(SearchItem it:src){if(r.web.size()>=max)break;boolean dup=false;for(SearchItem old:r.web)if(sameSearch(old,it)){dup=true;break;}if(!dup)r.web.add(it);}}
    static void addSearchUnique(ArrayList<SearchItem> out,SearchItem it){if(out==null||it==null)return;for(SearchItem x:out)if(sameSearch(x,it))return;out.add(it);}
    static boolean sameSearch(SearchItem a,SearchItem b){if(a==null||b==null)return false;String au=safe(a.url,""),bu=safe(b.url,"");if(!au.isEmpty()&&!bu.isEmpty())return au.equalsIgnoreCase(bu);return norm(a.title).equals(norm(b.title));}

    static int webRank(SearchItem it,String team,String competition){
        if(it==null)return -999;String txt=(safe(it.title,"")+" "+safe(it.snippet,"")).toLowerCase(Locale.ROOT);String host=sourceHost(it.url);int s=0;
        if(teamMatch(team,txt))s+=55;if(competition!=null&&!competition.trim().isEmpty()&&txt.contains(competition.toLowerCase(Locale.ROOT)))s+=18;
        if(hasAny(txt,"results","resultados","last matches","recent matches","schedule","fixtures","form","últimos jogos","jogos recentes"))s+=30;
        if(hasAny(txt,"final score","terminado","finished","ft","won","lost","vitória","derrota"))s+=18;
        if(trustedSportsHost(host))s+=30;
        String u=safe(it.url,"").toLowerCase(Locale.ROOT);if(hasAny(u,"results","resultados","matches","schedule","fixtures","team","stats"))s+=16;
        if(hasAny(txt,"prediction","predictions","odds","betting tips","apostas","prognóstico"))s-=12;
        return s;
    }
    static boolean trustedSportsHost(String h){String x=safe(h,"");String[] d={"basketball-reference.com","baseball-reference.com","pro-football-reference.com","realgm.com","365scores.com","aiscore.com","sofascore.com","sportytrader.com","globalsportsarchive.com","tigerscores365.com","flashscore.com","espn.com","nbl.com.au","fiba.basketball"};for(String z:d)if(x.endsWith(z)||x.contains(z))return true;return false;}
    static boolean goodResultPage(SearchItem it,String team){if(it==null||it.url==null||!it.url.startsWith("http"))return false;int rank=webRank(it,team,"");if(rank>=55)return true;String u=it.url.toLowerCase(Locale.ROOT);return hasAny(u,"results","matches","schedule","fixtures","stats");}

    /** Direct page first; Jina Reader is a free, no-key fallback for JS-heavy/public pages. */
    String readPublicPage(String url,boolean allowReader){
        if(url==null||!url.startsWith("http"))return "";String text="";
        try{text=pageTextCached("direct",url,12L*60*60*1000L,false);}catch(Exception ignored){}
        if(scoreEvidenceCount(text)>=3||!allowReader)return text;
        try{String r=pageTextCached("reader",url,18L*60*60*1000L,true);if(scoreEvidenceCount(r)>scoreEvidenceCount(text))return "[READER]\n"+r;}catch(Exception ignored){}
        return text;
    }
    String pageTextCached(String mode,String url,long ttl,boolean reader)throws Exception{
        android.content.SharedPreferences p=c.getSharedPreferences("jp_open_web_cache",0);String key="page_"+mode+"_"+Integer.toHexString(url.hashCode());String old=p.getString(key,null);long ts=p.getLong(key+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;
        String raw=reader?fetchReader(url):fetch(url);String text=reader?raw:htmlToLines(raw);if(text.length()>70000)text=text.substring(0,70000);p.edit().putString(key,text).putLong(key+"_ts",System.currentTimeMillis()).apply();return text;
    }
    String fetchReader(String target)throws Exception{
        String u="https://r.jina.ai/"+target;HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(7500);h.setReadTimeout(12000);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept","text/plain");h.setRequestProperty("X-Return-Format","markdown");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("Reader HTTP "+code);BufferedReader br=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String x;(x=br.readLine())!=null;)b.append(x).append('\n');return b.toString();
    }
    static String htmlToLines(String html){if(html==null)return "";String x=html.replaceAll("(?is)<script[^>]*>.*?</script>"," ").replaceAll("(?is)<style[^>]*>.*?</style>"," ");x=x.replaceAll("(?i)<br\\s*/?>","\\n").replaceAll("(?i)</(?:p|div|li|tr|td|th|h[1-6]|table)>","\\n");x=x.replaceAll("(?is)<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#x27;","'");return x.replaceAll("[ \\t]+"," ").replaceAll("\\n{3,}","\\n\\n");}
    static int scoreEvidenceCount(String s){if(s==null)return 0;Matcher m=Pattern.compile("(?<!\\d)(\\d{1,3})\\s*[-–:]\\s*(\\d{1,3})(?!\\d)").matcher(s);int n=0;while(m.find()&&n<20)n++;return n;}

    ArrayList<GameRow> extractWebRows(String text,String team,String sport){
        ArrayList<GameRow> out=new ArrayList<>();if(text==null||text.trim().isEmpty()||team==null||team.trim().isEmpty())return out;
        String[] lines=text.replace("\r","").split("\n");
        for(String raw:lines){String line=cleanWebLine(raw);if(line.length()<7||line.length()>420)continue;if(rejectPredictionLine(line))continue;GameRow g=parsePerspectiveTableRow(line,team,sport);if(g==null)g=parseNamedScoreRow(line,team,sport);if(g==null)g=parsePerspectiveResultRow(line,team,sport);if(g!=null&&g.completed)addUniqueGame(out,g);if(out.size()>=12)break;}
        return out;
    }
    static String cleanWebLine(String s){if(s==null)return "";return s.replace("**","").replace("__","").replace("`","").replaceAll("\\[[^\\]]+\\]\\([^\\)]+\\)"," ").replaceAll("\\s+"," ").trim();}
    static boolean rejectPredictionLine(String s){String x=s.toLowerCase(Locale.ROOT);return hasAny(x,"prediction","predictions","odds","betting tip","best bet","prognóstico","palpite","handicap","over/under")&&!hasAny(x,"final","finished","terminado","ft","last matches","results","resultados");}

    GameRow parseNamedScoreRow(String line,String team,String sport){
        Pattern p=Pattern.compile("(?iu)([\\p{L}][\\p{L}0-9 .&'’\\-]{1,58}?)\\s+(\\d{1,3})\\s*[-–:]\\s*(\\d{1,3})\\s+([\\p{L}][\\p{L}0-9 .&'’\\-]{1,58})");Matcher m=p.matcher(line);
        while(m.find()){
            int a=intValue(m.group(2)),b=intValue(m.group(3));if(!plausibleScore(sport,a,b)||looksLikeClock(line,m.start(2),m.end(3),a,b))continue;String left=cleanNameCandidate(m.group(1)),right=cleanNameCandidate(m.group(4));
            boolean lt=teamMatch(team,left),rt=teamMatch(team,right);if(lt==rt)continue;GameRow g=new GameRow();g.date=extractWebDate(line);g.status="FT";g.completed=true;
            if(lt){g.home=team;g.away=right;g.hs=a;g.as=b;}else{g.home=left;g.away=team;g.hs=a;g.as=b;}if(g.away.isEmpty()||g.home.isEmpty())continue;g.score=g.hs+" × "+g.as;return g;
        }return null;
    }
    GameRow parsePerspectiveTableRow(String line,String team,String sport){
        if(line.indexOf('|')<0)return null;String[] raw=line.split("\\|");ArrayList<String> cels=new ArrayList<>();for(String z:raw){String z2=z.trim();if(!z2.isEmpty())cels.add(z2);}if(cels.size()<3)return null;
        int ri=-1;String res="";for(int i=0;i<cels.size();i++){String z=cels.get(i).toUpperCase(Locale.ROOT);if(z.equals("W")||z.equals("L")||z.equals("D")||z.matches("[WLD],.*")){ri=i;res=z.substring(0,1);break;}}if(ri<0)return null;
        int sf=-1,sa=-1;for(int i=ri;i<cels.size();i++){Matcher sm=Pattern.compile("(?<!\\d)(\\d{1,3})\\s*[-–:]\\s*(\\d{1,3})(?!\\d)").matcher(cels.get(i));if(sm.find()){sf=intValue(sm.group(1));sa=intValue(sm.group(2));if("W".equals(res)&&sf<sa){int t=sf;sf=sa;sa=t;}if("L".equals(res)&&sf>sa){int t=sf;sf=sa;sa=t;}break;}if(isPlainScore(cels.get(i))&&i+1<cels.size()&&isPlainScore(cels.get(i+1))){sf=intValue(cels.get(i));sa=intValue(cels.get(i+1));break;}}
        if(!plausibleScore(sport,sf,sa))return null;String opp="";boolean away=false;for(int i=ri-1;i>=0;i--){String z=cels.get(i);if("@".equals(z)){away=true;continue;}if(looksDateCell(z)||z.matches("\\d+")||z.length()<2)continue;opp=cleanNameCandidate(z);break;}if(opp.isEmpty()||teamMatch(team,opp))return null;
        GameRow g=new GameRow();g.date=extractWebDate(line);g.status="FT";g.completed=true;if(away){g.home=opp;g.away=team;g.hs=sa;g.as=sf;}else{g.home=team;g.away=opp;g.hs=sf;g.as=sa;}g.score=g.hs+" × "+g.as;return g;
    }
    GameRow parsePerspectiveResultRow(String line,String team,String sport){
        String low=line.toLowerCase(Locale.ROOT);if(!looksResultContext(low))return null;Matcher sc=Pattern.compile("(?<!\\d)(\\d{1,3})\\s*(?:[-–:]|\\s)\\s*(\\d{1,3})(?!\\d)").matcher(line);int s1=-1,s2=-1,pos=-1,scoreEnd=-1;while(sc.find()){int a=intValue(sc.group(1)),b=intValue(sc.group(2));if(plausibleScore(sport,a,b)&&!looksLikeClock(line,sc.start(),sc.end(),a,b)){s1=a;s2=b;pos=sc.start();scoreEnd=sc.end();}}if(pos<0)return null;
        String before=line.substring(0,pos).replaceAll("(?i)\\b(?:FT|FINAL|FINISHED|TERMINADO|END)\\b"," ");String after=line.substring(Math.min(line.length(),Math.max(pos,scoreEnd))).trim();
        String opp="";boolean teamFirst=false;String lower=before.toLowerCase(Locale.ROOT),tlow=team.toLowerCase(Locale.ROOT);int ti=lower.indexOf(tlow);if(ti>=0){teamFirst=ti<before.length()/2;String rem=teamFirst?before.substring(ti+team.length()):before.substring(0,ti);opp=cleanNameCandidate(rem);}else if(teamMatch(team,before)){opp=cleanNameCandidate(removeTeamTokens(before,team));teamFirst=true;}else if(teamMatch(team,after)){opp=cleanNameCandidate(before);teamFirst=false;}else return null;
        if(opp.isEmpty()||teamMatch(team,opp))return null;String result=extractResultLetter(line);int teamScore=teamFirst?s1:s2,oppScore=teamFirst?s2:s1;if("W".equals(result)&&teamScore<oppScore){int t=teamScore;teamScore=oppScore;oppScore=t;}if("L".equals(result)&&teamScore>oppScore){int t=teamScore;teamScore=oppScore;oppScore=t;}
        GameRow g=new GameRow();g.date=extractWebDate(line);g.status="FT";g.completed=true;g.home=team;g.away=opp;g.hs=teamScore;g.as=oppScore;g.score=g.hs+" × "+g.as;return g;
    }

    static boolean plausibleScore(String sport,int a,int b){if(a<0||b<0)return false;int max=300;if(MultiSportClient.BASEBALL.equals(sport))max=40;else if(MultiSportClient.NFL.equals(sport))max=100;else if(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NBA.equals(sport))max=250;return a<=max&&b<=max&&(a+b)>0;}
    static boolean looksLikeClock(String line,int start,int end,int a,int b){if(line==null||a>23||b>59)return false;int l=Math.max(0,start-12),r=Math.min(line.length(),end+8);String x=line.substring(l,r).toLowerCase(Locale.ROOT);return x.contains(" am")||x.contains(" pm")||x.contains("at ")||x.matches(".*\\b\\d{1,2}:\\d{2}\\b.*");}
    static boolean isPlainScore(String s){return s!=null&&s.trim().matches("\\d{1,3}");}
    static boolean looksResultContext(String s){return hasAny(s," ft "," final ","finished","terminado","result","resultado"," w "," l "," win"," loss","won","lost")||extractWebDate(s).length()>0;}
    static String extractResultLetter(String s){String x=" "+s.toUpperCase(Locale.ROOT)+" ";if(x.matches(".*\\bW\\b.*")||x.contains(" WON ")||x.contains(" WIN "))return "W";if(x.matches(".*\\bL\\b.*")||x.contains(" LOST ")||x.contains(" LOSS "))return "L";return "";}
    static String removeTeamTokens(String src,String team){String x=src;for(String t:tokens(team))x=x.replaceAll("(?iu)\\b"+Pattern.quote(t)+"\\b"," ");return x;}
    static String cleanNameCandidate(String s){if(s==null)return "";String x=s.replace('|',' ').replaceAll("(?i)\\b(?:FT|FINAL|FINISHED|TERMINADO|RESULTS?|RESULTADOS?|LAST MATCHES|RECENT MATCHES|WON|LOST|WIN|LOSS)\\b"," ");x=x.replaceAll("\\b\\d{1,2}[:/]\\d{1,2}(?::\\d{2})?\\b"," ").replaceAll("\\b\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}\\b"," ").replaceAll("\\b\\d{1,2}[-/]\\d{1,2}[-/]\\d{2,4}\\b"," ");x=x.replaceAll("(?i)\\b\\d{1,2}\\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\s+20\\d{2}\\b"," ").replaceAll("(?i)\\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\s+\\d{1,2},?\\s+20\\d{2}\\b"," ");x=x.replaceAll("(?i)\\b[WLD]\\b$"," ").replaceAll("^[^\\p{L}]+|[^\\p{L}0-9.&'’\\- ]+$","").replaceAll("\\s+"," ").trim();if(x.length()>60)x=x.substring(Math.max(0,x.length()-60)).trim();return x;}

    static boolean looksDateCell(String s){if(s==null)return false;String x=s.toLowerCase(Locale.ROOT);return x.matches(".*\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}.*")||x.matches(".*\\d{1,2}[-/]\\d{1,2}[-/]\\d{2,4}.*")||x.matches(".*(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[ ,.-]+\\d{1,2}.*");}
    static String extractWebDate(String s){if(s==null)return "";Matcher y=Pattern.compile("(20\\d{2})[-/](\\d{1,2})[-/](\\d{1,2})").matcher(s);if(y.find())return y.group(1)+"-"+pad2(y.group(2))+"-"+pad2(y.group(3));Matcher d=Pattern.compile("(\\d{1,2})[-/](\\d{1,2})[-/](20\\d{2})").matcher(s);if(d.find())return d.group(3)+"-"+pad2(d.group(2))+"-"+pad2(d.group(1));try{Matcher m=Pattern.compile("(?i)(\\d{1,2}\\s+[A-Za-z]{3,9}\\s+20\\d{2}|[A-Za-z]{3,9}\\s+\\d{1,2},?\\s+20\\d{2})").matcher(s);if(m.find()){String v=m.group(1).replaceAll("\\s+"," ").trim();String[] fmts={"d MMM yyyy","d MMMM yyyy","MMM d, yyyy","MMMM d, yyyy","MMM d yyyy","MMMM d yyyy"};for(String f:fmts)try{SimpleDateFormat in=new SimpleDateFormat(f,Locale.US);in.setLenient(false);Date dt=in.parse(v);if(dt!=null)return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(dt);}catch(Exception ignored){}}}catch(Exception ignored){}return "";}

    static String pad2(String s){try{int n=Integer.parseInt(s);return n<10?"0"+n:String.valueOf(n);}catch(Exception e){return s;}}

    static void mergeUniqueRows(ArrayList<GameRow> dst,ArrayList<GameRow> src){if(dst==null||src==null)return;for(GameRow g:src)addUniqueGame(dst,g);}
    ArrayList<GameRow> readWebTeamCache(String sport,String team,String comp,long ttl){try{android.content.SharedPreferences p=c.getSharedPreferences("jp_open_web_cache",0);String key="hist64_"+Integer.toHexString((sport+"|"+norm(team)+"|"+norm(comp)).hashCode());long ts=p.getLong(key+"_ts",0);String raw=p.getString(key,null);if(raw==null||System.currentTimeMillis()-ts>ttl)return null;JSONArray a=new JSONArray(raw);ArrayList<GameRow> out=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;GameRow g=new GameRow();g.date=o.optString("d","");g.home=o.optString("h","");g.away=o.optString("a","");g.hs=o.optInt("hs",-1);g.as=o.optInt("as",-1);g.status="FT";g.completed=g.hs>=0&&g.as>=0;g.sourceConflict=o.optBoolean("conf",false);JSONArray src=o.optJSONArray("src");if(src!=null)for(int j=0;j<src.length();j++){String z=src.optString(j,"");if(!z.isEmpty())g.sources.add(z);}if(g.sources.isEmpty())g.sources.add("Web cache");if(g.completed)out.add(g);}return out;}catch(Exception e){return null;}}
    void writeWebTeamCache(String sport,String team,String comp,ArrayList<GameRow> rows){try{JSONArray a=new JSONArray();for(GameRow g:rows){if(g==null||!g.completed)continue;JSONObject o=new JSONObject();o.put("d",g.date);o.put("h",g.home);o.put("a",g.away);o.put("hs",g.hs);o.put("as",g.as);o.put("conf",g.sourceConflict);JSONArray src=new JSONArray();for(String z:g.sources)src.put(z);o.put("src",src);a.put(o);if(a.length()>=14)break;}String key="hist64_"+Integer.toHexString((sport+"|"+norm(team)+"|"+norm(comp)).hashCode());c.getSharedPreferences("jp_open_web_cache",0).edit().putString(key,a.toString()).putLong(key+"_ts",System.currentTimeMillis()).apply();}catch(Exception ignored){}}

    /** Fallback público final usando TheSportsDB v1. */
    void loadSportsDbHistory(String sport,MultiSportClient.Event ev,Research r)throws Exception{
        if(ev==null||r==null||MultiSportClient.F1.equals(sport)||MultiSportClient.MMA.equals(sport))return;
        String expected=tsdbSportName(sport);if(expected.isEmpty())return;
        JSONObject match=findTsdbEvent(safe(ev.home,"")+"_vs_"+safe(ev.away,""),expected);
        if(match==null)match=findTsdbEvent(safe(ev.away,"")+"_vs_"+safe(ev.home,""),expected);
        if(match==null)return;
        String leagueId=match.optString("idLeague",""),season=first(match.optString("strSeason",""),safe(ev.season,""));if(leagueId.isEmpty())return;
        LinkedHashMap<String,GameRow> all=new LinkedHashMap<>();int calls=0;
        for(String ss:seasonCandidates(season)){
            if(calls++>=2)break;
            String url="https://www.thesportsdb.com/api/v1/json/123/eventsseason.php?id="+URLEncoder.encode(leagueId,"UTF-8")+"&s="+URLEncoder.encode(ss,"UTF-8");
            JSONArray a=new JSONObject(tsdbCached("season_"+leagueId+"_"+ss,url,6L*60*60*1000L)).optJSONArray("events");if(a==null)continue;
            for(int i=0;i<a.length();i++){GameRow g=tsdbEvent(a.optJSONObject(i));if(g!=null&&g.completed){String k=safe(g.date,"")+"|"+norm(g.home)+"|"+norm(g.away)+"|"+g.hs+"|"+g.as;all.put(k,g);}}
        }
        ArrayList<GameRow> rows=new ArrayList<>(all.values());Collections.sort(rows,(x,y)->safe(y.date,"").compareTo(safe(x.date,"")));mergeSourceRows(r,rows,ev,"TheSportsDB");
    }
    JSONObject findTsdbEvent(String q,String expectedSport)throws Exception{
        if(q==null||q.replace("_","").trim().isEmpty())return null;String url="https://www.thesportsdb.com/api/v1/json/123/searchevents.php?e="+URLEncoder.encode(q,"UTF-8");
        JSONArray a=new JSONObject(tsdbCached("event_"+norm(q),url,12L*60*60*1000L)).optJSONArray("event");if(a==null)return null;JSONObject best=null;double score=-1;
        for(int i=0;i<a.length();i++){JSONObject e=a.optJSONObject(i);if(e==null||!expectedSport.equalsIgnoreCase(e.optString("strSport","")))continue;double s=teamSimilarity(q.replace("_vs_"," "),e.optString("strEvent",""));if(s>score){score=s;best=e;}}return score>=0.30?best:null;
    }
    static String tsdbSportName(String sport){if(MultiSportClient.FOOTBALL.equals(sport))return "Soccer";if(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NBA.equals(sport))return "Basketball";if(MultiSportClient.BASEBALL.equals(sport))return "Baseball";if(MultiSportClient.NFL.equals(sport))return "American Football";return "";}
    GameRow tsdbEvent(JSONObject e){if(e==null)return null;String h=e.optString("strHomeTeam",""),a=e.optString("strAwayTeam","");if(h.isEmpty()||a.isEmpty())return null;GameRow g=new GameRow();g.home=h;g.away=a;g.homeId=longValue(e.opt("idHomeTeam"));g.awayId=longValue(e.opt("idAwayTeam"));g.date=e.optString("dateEvent","");g.hs=intValue(e.opt("intHomeScore"));g.as=intValue(e.opt("intAwayScore"));g.status=first(e.optString("strStatus",""),e.optString("strProgress",""));g.completed=g.hs>=0&&g.as>=0&&(isFinal(g.status)||looksPastWithScore(g.date,g.status,g.hs,g.as)||(!g.date.isEmpty()&&g.date.compareTo(today())<0));g.score=(g.hs>=0?String.valueOf(g.hs):"—")+" × "+(g.as>=0?String.valueOf(g.as):"—");return g;}
    String tsdbCached(String key,String url,long ttl)throws Exception{String k="tsdb_"+Integer.toHexString(key.hashCode());android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;try{String raw=fetchJson(url);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception ex){if(old!=null)return old;throw ex;}}
    String fetchJson(String url)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(5500);h.setReadTimeout(6500);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept","application/json");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader br=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String x;(x=br.readLine())!=null;)b.append(x);return b.toString();}
    static double teamSimilarity(String a,String b){String x=norm(a),y=norm(b);if(x.isEmpty()||y.isEmpty())return 0;if(x.equals(y))return 1;if(x.contains(y)||y.contains(x))return .88;HashSet<String>A=tokens(a),B=tokens(b);if(A.isEmpty()||B.isEmpty())return 0;int n=0;for(String s:A)if(B.contains(s))n++;double cover=n/(double)Math.max(1,Math.min(A.size(),B.size()));double jac=n/(double)Math.max(1,A.size()+B.size()-n);return .55*cover+.45*jac;}
    static long longValue(Object o){try{if(o==null||o==JSONObject.NULL)return 0;String s=String.valueOf(o).replaceAll("[^0-9]","");return s.isEmpty()?0:Long.parseLong(s);}catch(Exception e){return 0;}}
    static String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}

    /** Gera a temporada informada e até duas anteriores. Aceita 2026, 2026-2027 ou 2026/2027. */
    static ArrayList<String> seasonCandidates(String season){
        ArrayList<String> out=new ArrayList<>();String s=season==null?"":season.trim();
        if(s.isEmpty())s=String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        if(!s.isEmpty())out.add(s);
        Matcher range=Pattern.compile("^(\\d{4})([-/])(\\d{4})$").matcher(s);
        if(range.find()){
            try{int a=Integer.parseInt(range.group(1)),b=Integer.parseInt(range.group(3));String sep=range.group(2);out.add((a-1)+sep+(b-1));out.add((a-2)+sep+(b-2));}catch(Exception ignored){}
        }else if(s.matches("\\d{4}")){
            try{int y=Integer.parseInt(s);out.add(String.valueOf(y-1));out.add(String.valueOf(y-2));}catch(Exception ignored){}
        }
        LinkedHashSet<String> uniq=new LinkedHashSet<>();for(String x:out)if(x!=null&&!x.trim().isEmpty())uniq.add(x.trim());return new ArrayList<>(uniq);
    }

    static int countCompleted(ArrayList<GameRow> rows){int n=0;if(rows!=null)for(GameRow g:rows)if(g!=null&&g.completed)n++;return n;}
    static void clearTeamSample(Research r,boolean home){if(r==null)return;if(home){r.recentHome.clear();r.homeWins=r.homeLosses=r.homeDraws=r.homeSample=0;r.homeFor=r.homeAgainst=0;}else{r.recentAway.clear();r.awayWins=r.awayLosses=r.awayDraws=r.awaySample=0;r.awayFor=r.awayAgainst=0;}}
    static void appendTrace(StringBuilder b,String s){if(b==null||s==null||s.trim().isEmpty())return;if(b.length()>0)b.append("; ");b.append(s);}
    static void addLocalH2h(ArrayList<GameRow> rows,String a,String b,ArrayList<String> out){if(rows==null||out==null)return;for(GameRow g:rows){if(g!=null&&g.completed&&g.involves(a)&&g.involves(b)){out.add(g.row());if(out.size()>=5)break;}}}

    String apiRaw(MultiSportClient cli,String source,String path,String key)throws Exception{
        String cacheKey="api_hist_"+source+"_"+path;android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String k="msw_"+Integer.toHexString(cacheKey.hashCode());String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<24L*60*60*1000L)return old;
        try{String raw=cli.get(source,path,key);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception ex){if(old!=null)return old;throw ex;}
    }

    ArrayList<GameRow> apiRows(MultiSportClient cli,String source,String raw){
        ArrayList<GameRow> out=new ArrayList<>();try{JSONArray a=new JSONObject(raw).optJSONArray("response");if(a==null)return out;for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;MultiSportClient.Event e;
            if(MultiSportClient.NBA.equals(source))e=cli.parseNba(o);else if(MultiSportClient.NFL.equals(source))e=cli.parseNfl(o);else e=cli.parseGenericGame(source,o);
            GameRow g=fromEvent(e);if(g!=null)out.add(g);
        }}catch(Exception ignored){}return out;
    }

    GameRow fromEvent(MultiSportClient.Event e){if(e==null||safe(e.home,"").isEmpty())return null;GameRow g=new GameRow();g.date=safe(e.date,"");g.home=safe(e.home,"");g.away=safe(e.away,"");g.homeId=e.homeId;g.awayId=e.awayId;g.status=safe(e.status,"");int[] sc=scorePair(e.score);g.hs=sc[0];g.as=sc[1];g.completed=(isFinal(g.status)||looksPastWithScore(g.date,g.status,g.hs,g.as))&&g.hs>=0&&g.as>=0;g.score=e.score;return g;}
    static boolean isFinal(String s){String x=s==null?"":s.toLowerCase(Locale.ROOT);return x.equals("ft")||x.equals("aot")||x.equals("end")||x.equals("ended")||x.contains("finished")||x.contains("final")||x.contains("complete")||x.contains("closed")||x.contains("after overtime")||x.contains("after extra")||x.contains("após prorrogação")||x.contains("encerrad");}
    static boolean looksPastWithScore(String date,String status,int hs,int as){if(hs<0||as<0)return false;String x=status==null?"":status.toLowerCase(Locale.ROOT);if(x.contains("live")||x.equals("ns")||x.contains("not started")||x.contains("scheduled")||x.contains("programad"))return false;if(date==null||date.length()<10)return false;String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());return date.substring(0,10).compareTo(today)<0;}
    static int[] scorePair(String s){int[] out={-1,-1};if(s==null)return out;Matcher m=Pattern.compile("(\\d{1,3})\\s*(?:×|x|-|–|:)\\s*(\\d{1,3})").matcher(s);if(m.find())try{out[0]=Integer.parseInt(m.group(1));out[1]=Integer.parseInt(m.group(2));}catch(Exception ignored){}return out;}

    void fillTeam(ArrayList<GameRow> all,String team,ArrayList<String> rows,boolean first,Research r){fillTeam(all,team,0,rows,first,r);}
    void fillTeam(ArrayList<GameRow> all,String team,long teamId,ArrayList<String> rows,boolean first,Research r){int n=0;for(GameRow g:all){if(!g.completed)continue;boolean byId=teamId>0&&(g.homeId==teamId||g.awayId==teamId);if(!byId&&!g.involves(team))continue;boolean homeSide=byId?(g.homeId==teamId):g.homeSide(team);int pf=homeSide?g.hs:g.as,pa=homeSide?g.as:g.hs;String fm=pf>pa?"V":(pf==pa?"E":"D");if("V".equals(fm)){if(first)r.homeWins++;else r.awayWins++;}else if("D".equals(fm)){if(first)r.homeLosses++;else r.awayLosses++;}else if("E".equals(fm)){if(first)r.homeDraws++;else r.awayDraws++;}if(pf>=0&&pa>=0){if(first){r.homeFor+=pf;r.homeAgainst+=pa;r.homeSample++;}else{r.awayFor+=pf;r.awayAgainst+=pa;r.awaySample++;}}rows.add(fm+" • "+g.row());if(++n>=8)break;}}
    void finishForms(Research r){r.homeForm=formText(r.recentHome);r.awayForm=formText(r.recentAway);}
    String formText(ArrayList<String> rows){StringBuilder b=new StringBuilder();for(String s:rows){if(s==null||s.isEmpty())continue;String x=s.substring(0,1);if("VDE".contains(x))b.append(x).append(' ');}return b.toString().trim();}

    static String espnPath(String sport,MultiSportClient.Event ev){
        String comp=ev==null?"":safe(ev.competition,"").toLowerCase(Locale.ROOT);
        if(MultiSportClient.BASKETBALL.equals(sport)){if(comp.contains("wnba"))return "basketball/wnba";if(comp.contains("ncaa")&&comp.contains("women"))return "basketball/womens-college-basketball";if(comp.contains("ncaa"))return "basketball/mens-college-basketball";return comp.contains("nba")?"basketball/nba":null;}
        if(MultiSportClient.NFL.equals(sport))return comp.contains("nfl")?"football/nfl":null;
        if(MultiSportClient.BASEBALL.equals(sport))return comp.contains("mlb")?"baseball/mlb":null;
        if(MultiSportClient.MMA.equals(sport))return "mma/ufc";
        if(MultiSportClient.F1.equals(sport))return "racing/f1";
        if(MultiSportClient.FOOTBALL.equals(sport)){String slug=InternetStatsClient.leagueSlug(ev==null?"":ev.competition);return slug==null?null:"soccer/"+slug;}
        return null;
    }

    ArrayList<GameRow> parseScoreboard(String raw){ArrayList<GameRow> out=new ArrayList<>();try{JSONArray evs=new JSONObject(raw).optJSONArray("events");if(evs==null)return out;for(int i=0;i<evs.length();i++){
        JSONObject e=evs.optJSONObject(i);if(e==null)continue;JSONArray comps=e.optJSONArray("competitions");JSONObject cp=comps==null||comps.length()==0?null:comps.optJSONObject(0);if(cp==null)continue;JSONArray ps=cp.optJSONArray("competitors");if(ps==null||ps.length()<1)continue;GameRow g=new GameRow();String iso=e.optString("date","");g.date=iso.length()>=10?iso.substring(0,10):iso;
        for(int j=0;j<ps.length();j++){JSONObject z=ps.optJSONObject(j);if(z==null)continue;JSONObject tm=z.optJSONObject("team");JSONObject ath=z.optJSONObject("athlete");String name=tm!=null?first(tm.optString("displayName",""),tm.optString("name","")):(ath!=null?first(ath.optString("displayName",""),ath.optString("fullName","")):first(z.optString("displayName",""),z.optString("name","")));String side=z.optString("homeAway","");int score=intValue(z.opt("score"));if("home".equalsIgnoreCase(side)||g.home.isEmpty()){if(g.home.isEmpty()||"home".equalsIgnoreCase(side)){g.home=name;g.hs=score;}}else{g.away=name;g.as=score;}}
        if(g.away.isEmpty()&&ps.length()>1){JSONObject z=ps.optJSONObject(1);JSONObject tm=z==null?null:z.optJSONObject("team");JSONObject ath=z==null?null:z.optJSONObject("athlete");g.away=tm!=null?first(tm.optString("displayName",""),tm.optString("name","")):(ath!=null?first(ath.optString("displayName",""),ath.optString("fullName","")):"");g.as=z==null?-1:intValue(z.opt("score"));}
        JSONObject st=e.optJSONObject("status"),tp=st==null?null:st.optJSONObject("type");g.status=tp==null?"":first(tp.optString("shortDetail",""),tp.optString("detail",""),tp.optString("name",""));g.completed=tp!=null&&(tp.optBoolean("completed",false)||"post".equalsIgnoreCase(tp.optString("state"))||tp.optString("name","").toLowerCase(Locale.ROOT).contains("final"));if(!g.home.isEmpty())out.add(g);
    }}catch(Exception ignored){}return out;}

    ArrayList<SearchItem> webSearch(String query,int limit)throws Exception{
        // 6.4: nenhum mecanismo é ponto único de falha. DuckDuckGo e Bing são
        // consultados em paralelo e as respostas são fundidas e deduplicadas.
        String enc=URLEncoder.encode(query,"UTF-8");ArrayList<SearchItem> out=new ArrayList<>();ExecutorService sx=Executors.newFixedThreadPool(2);
        Future<String> fd=sx.submit(()->{try{return cached("search64_ddg_"+query,"https://html.duckduckgo.com/html/?kl=br-pt&q="+enc,6L*60*60*1000L);}catch(Exception e){return "";}});
        Future<String> fb=sx.submit(()->{try{return cached("search64_bing_"+query,"https://www.bing.com/search?q="+enc+"&setlang=pt-br&cc=br",6L*60*60*1000L);}catch(Exception e){return "";}});
        String html="",bing="";try{html=fd.get(8,TimeUnit.SECONDS);}catch(Exception ignored){}try{bing=fb.get(8,TimeUnit.SECONDS);}catch(Exception ignored){}sx.shutdownNow();
        if(!html.isEmpty()){
            Pattern block=Pattern.compile("(?is)<a[^>]*class=\"[^\"]*result__a[^\"]*\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?<a[^>]*class=\"[^\"]*result__snippet[^\"]*\"[^>]*>(.*?)</a>");Matcher m=block.matcher(html);
            while(m.find()&&out.size()<limit){String u=decodeDuck(m.group(1));String t=clean(m.group(2)),sn=clean(m.group(3));if(!t.isEmpty())addSearchUnique(out,new SearchItem(t,sn,u));}
            Pattern a=Pattern.compile("(?is)<a[^>]*class=\"[^\"]*result__a[^\"]*\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>");Matcher z=a.matcher(html);while(z.find()&&out.size()<limit){String t=clean(z.group(2));if(!t.isEmpty())addSearchUnique(out,new SearchItem(t,"",decodeDuck(z.group(1))));}
        }
        if(!bing.isEmpty()){
            Pattern b=Pattern.compile("(?is)<li[^>]*class=\"b_algo\"[^>]*>.*?<h2>\\s*<a[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?(?:<p>(.*?)</p>)?.*?</li>");Matcher bm=b.matcher(bing);
            while(bm.find()&&out.size()<limit*2){String t=clean(bm.group(2)),sn=clean(bm.group(3));if(!t.isEmpty())addSearchUnique(out,new SearchItem(t,sn,bm.group(1).replace("&amp;","&")));}
        }
        while(out.size()>Math.max(limit,1))out.remove(out.size()-1);localize(out);return out;
    }

    void localize(ArrayList<SearchItem> list){if(list==null)return;for(SearchItem it:list){it.titlePt=ptTitle(it);it.snippetPt=ptSummary(it);}}
    static String uiTitle(SearchItem it){if(it==null)return "Fonte pública";return safe(it.titlePt,safe(it.title,"Fonte pública"));}
    static String uiSnippet(SearchItem it){if(it==null)return "Conteúdo público relacionado ao confronto.";return safe(it.snippetPt,safe(it.snippet,"Conteúdo público relacionado ao confronto."));}
    static String ptTitle(SearchItem it){String all=((it==null?"":it.title)+" "+(it==null?"":it.snippet)).toLowerCase(Locale.ROOT);String host=sourceHost(it==null?"":it.url);int[] sc=findScore(all);String type;
        if(sc[0]>=0)type="Resultado e retrospecto";
        else if(hasAny(all,"player stats","estatísticas de jogadores","rebounds","assists"))type="Estatísticas de jogadores";
        else if(hasAny(all,"prediction","predictions","previsão","prognóstico"))type="Previsões e histórico";
        else if(hasAny(all,"live score","livescore","placar ao vivo"))type="Placar e estatísticas";
        else if(hasAny(all,"standings","classification","classificação","table"))type="Classificação e desempenho";
        else type="Informações do confronto";
        return type+(host.isEmpty()?"":" • "+host);
    }
    static String ptSummary(SearchItem it){String raw=((it==null?"":it.title)+" "+(it==null?"":it.snippet)).replaceAll("\\s+"," ").trim();String low=raw.toLowerCase(Locale.ROOT);int[] sc=findScore(low);ArrayList<String> parts=new ArrayList<>();
        if(sc[0]>=0)parts.add("A fonte menciona um resultado de "+sc[0]+"–"+sc[1]+" relacionado ao histórico pesquisado.");
        if(hasAny(low,"player stats","rebounds","assists","minutes played","field goals","free throws"))parts.add("Há dados de jogadores, como pontos, rebotes, assistências, minutos e aproveitamento.");
        if(hasAny(low,"live score","match results","real-time scores","livescore"))parts.add("A página oferece placar, resultados e atualização do confronto.");
        if(hasAny(low,"prediction","predictions"))parts.add("A fonte também apresenta previsões ou tendências para o confronto.");
        if(hasAny(low,"h2h","head to head","past results","recent form"))parts.add("Há referência a retrospecto, resultados anteriores ou forma recente.");
        if(parts.isEmpty())parts.add("Fonte pública encontrada com informações sobre o confronto, resultados e contexto esportivo.");
        StringBuilder b=new StringBuilder();for(String s:parts){if(b.length()>0)b.append(' ');b.append(s);if(b.length()>210)break;}return b.toString();
    }
    static int[] findScore(String s){int[] o={-1,-1};if(s==null)return o;Matcher m=Pattern.compile("(?<!\\d)(\\d{1,3})\\s*[-–:]\\s*(\\d{1,3})(?!\\d)").matcher(s);while(m.find()){int end=m.end();if(end<s.length()&&(s.charAt(end)=='-'||s.charAt(end)=='/'))continue;try{o[0]=Integer.parseInt(m.group(1));o[1]=Integer.parseInt(m.group(2));return o;}catch(Exception ignored){}}return o;}
    static boolean hasAny(String s,String... xs){if(s==null)return false;for(String x:xs)if(s.contains(x))return true;return false;}
    static String sourceHost(String u){try{String h=new URL(u).getHost().toLowerCase(Locale.ROOT);if(h.startsWith("www."))h=h.substring(4);return h;}catch(Exception e){return "";}}

    String cached(String key,String url,long ttl)throws Exception{String k="msw_"+Integer.toHexString(key.hashCode());android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_web",0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;try{String raw=fetch(url);p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception e){if(old!=null)return old;throw e;}}
    String fetch(String url)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(5500);h.setReadTimeout(6500);h.setRequestProperty("User-Agent",UA);h.setRequestProperty("Accept-Language","pt-BR,pt;q=0.9,en;q=0.6");h.setRequestProperty("Accept","text/html,application/json;q=0.9,*/*;q=0.8");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s).append('\n');return b.toString();}

    static String decodeDuck(String u){try{String x=u.replace("&amp;","&");int p=x.indexOf("uddg=");if(p>=0){String v=x.substring(p+5);int e=v.indexOf('&');if(e>=0)v=v.substring(0,e);return URLDecoder.decode(v,"UTF-8");}return x.startsWith("//")?"https:"+x:x;}catch(Exception e){return u;}}
    static String clean(String h){if(h==null)return "";String x=h.replaceAll("(?is)<[^>]+>"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#x27;","'").replace("&nbsp;"," ");return x.replaceAll("\\s+"," ").trim();}
    static int intValue(Object o){try{if(o==null||o==JSONObject.NULL)return -1;String s=String.valueOf(o).replaceAll("[^0-9-]","");return s.isEmpty()?-1:Integer.parseInt(s);}catch(Exception e){return -1;}}
    static String safe(String s,String d){return s==null||s.trim().isEmpty()?d:s;}
    static String first(String... a){for(String s:a)if(s!=null&&!s.trim().isEmpty()&&!"null".equalsIgnoreCase(s.trim()))return s;return "";}
    static boolean teamMatch(String a,String b){return TeamIdentityResolver.matches(a,b);}
    static String norm(String s){if(s==null)return "";String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);return x.replaceAll("[^a-z0-9]","");}
    static HashSet<String> tokens(String s){HashSet<String> o=new HashSet<>();if(s==null)return o;String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]"," ");for(String z:x.split("\\s+"))if(z.length()>2&&!Arrays.asList("the","club","team","football","basketball","baseball").contains(z))o.add(z);return o;}
}
