#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/jpastore-ai-tests"
rm -rf "$OUT" && mkdir -p "$OUT"

javac -encoding UTF-8 -d "$OUT" \
  "$ROOT/app/src/main/java/com/jpastore/sportsai/StatisticalCalibrationEngine.java" \
  "$ROOT/app/src/main/java/com/jpastore/sportsai/MarketOddsBook.java" \
  "$ROOT/tools/StatisticalCalibrationEngineSelfTest.java"
java -cp "$OUT" com.jpastore.sportsai.StatisticalCalibrationEngineSelfTest

echo "Core statistical tests complete. Provider path tests are run by the GitHub workflow with lightweight Android/JSON stubs."
