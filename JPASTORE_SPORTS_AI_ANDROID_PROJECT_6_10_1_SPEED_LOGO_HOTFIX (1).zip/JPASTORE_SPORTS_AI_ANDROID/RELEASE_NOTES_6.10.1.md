# J.PASTORE Sports AI 6.10.1 Speed + Logo Hotfix

- Análise automática: orçamento total reduzido para ~4,2 s.
- Fontes rápidas: janela normal ~2,2 s.
- Consenso web normal: até ~0,85 s somente quando necessário.
- API-Football normal: fallback de até ~0,55 s somente quando nenhuma base utilizável foi obtida.
- Odds normais: até ~0,45 s; Análise Profunda mantém orçamento maior.
- Logos: SofaScore por nome+esporte vira resolvedor prioritário, antes de TheSportsDB/Wikipedia.
- Logos 5Dollar são preservados quando existirem na resposta.
- Cache e todas as funções existentes preservados.
