# J.Pastore Sports AI 4.7 — Motion UI

- Mantém applicationId `com.jpastore.sportsai` e a mesma estrutura do projeto.
- VersionCode 38 / VersionName 4.7.0-motion-ui.
- Bola de futebol agora gira e pulsa em todos os loaders principais e compactos.
- Anel orbital animado torna o movimento visível mesmo com a simetria da bola.
- Splash mantém 3 segundos e recebe a mesma animação Motion UI.
- Seleção de dias redesenhada com dia da semana + data e destaque premium.
- Filtro de horários redesenhado em painel escuro com relógio de Brasília ao vivo.
- Seletor manual de horário redesenhado com relógio digital e TimePicker 24h.
- Tema nativo do Android ajustado para dark, deixando diálogos e relógio coerentes com o app.
