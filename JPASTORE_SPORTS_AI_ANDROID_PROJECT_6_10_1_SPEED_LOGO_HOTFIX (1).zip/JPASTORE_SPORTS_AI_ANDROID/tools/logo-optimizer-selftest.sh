#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
SRC="$ROOT/app/src/main/java/com/jpastore/sportsai"
UI="$SRC/PremiumView.java"
MULTI="$SRC/MultiSportClient.java"
pass(){ echo "PASS: $1"; }
grep -Fq 'e.homeId=h.optLong("id",0)' "$MULTI" && grep -Fq 'e.awayId=a.optLong("id",0)' "$MULTI" && pass 'IDs SofaScore preservados'
grep -Fq 'https://img.sofascore.com/api/v1/team/' "$MULTI" && pass 'URL direta de badge SofaScore ativa'
grep -Fq 'resolveTeamBadgeSmart' "$UI" && pass 'resolver assíncrono multi-fonte ativo'
grep -Fq 'resolveSofaBadge(sport,team)' "$UI" && grep -Fq 'String resolveSofaBadge' "$SRC/MultiSportWebClient.java" && pass 'resolver SofaScore por nome/esporte ativo'
grep -Fq 'www.thesportsdb.com/api/v1/json/123/searchteams.php' "$UI" && pass 'fallback TheSportsDB ativo'
grep -Fq 'en.wikipedia.org/api/rest_v1/page/summary/' "$UI" && pass 'fallback Wikipedia ativo'
grep -Fq 'teamInitials' "$UI" && pass 'fallback por iniciais reais ativo'
! grep -Fq 'center(c,"FC"' "$UI" && pass 'fallback genérico FC removido'
grep -Fq 'jp_badges_v2' "$UI" && grep -Fq '_miss' "$UI" && pass 'cache persistente e cache negativo ativos'
grep -Fq 'logoField(ho)' "$SRC/FiveDollarFootballClient.java" && pass 'logos fornecidos pela 5Dollar preservados'
echo 'ALL LOGO OPTIMIZER TESTS PASSED: 10'
