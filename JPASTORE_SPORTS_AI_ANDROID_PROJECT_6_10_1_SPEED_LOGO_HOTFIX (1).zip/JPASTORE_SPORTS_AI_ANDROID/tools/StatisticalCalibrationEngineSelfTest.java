package com.jpastore.sportsai;
import java.util.*;

public class StatisticalCalibrationEngineSelfTest {
 static int ok=0;
 static void check(boolean b,String name){if(!b)throw new AssertionError("FAIL: "+name);System.out.println("PASS: "+name);ok++;}
 public static void main(String[] args){
  StatisticalCalibrationEngine.Calibration t1=StatisticalCalibrationEngine.calibrate(80,4,10,2,90,70,Double.NaN,.22,false);
  check(t1.calibratedProbability<=63 && ("BAIXA".equals(t1.confidenceLevel)||"MUITO BAIXA".equals(t1.confidenceLevel)) && !"RISCO MENOR".equals(t1.risk),"1 baixa cobertura reduz probabilidade/confiança");

  StatisticalCalibrationEngine.Calibration t2=StatisticalCalibrationEngine.calibrate(90,88,15,3,90,82,55,.15,false);
  check("REVISÃO NECESSÁRIA".equals(t2.status),"2 IA 90 x mercado 55 => revisão");

  StatisticalCalibrationEngine.Calibration t3=StatisticalCalibrationEngine.calibrate(72,82,12,3,90,80,69,.16,false);
  check(!"REVISÃO NECESSÁRIA".equals(t3.status) && "NORMAL".equals(t3.marketDivergence),"3 IA 72 x mercado 69 coerente");

  StatisticalCalibrationEngine.DoubleChance d1=StatisticalCalibrationEngine.doubleChance(48,28,24,"Vasco","Coritiba");
  check(d1.homeSide && d1.pick.equals("Vasco ou empate") && d1.oneX>d1.xTwo,"4 dupla chance 1X/X2 sem inversão");

  check(Math.abs(StatisticalCalibrationEngine.jointProbability(Arrays.asList(70,70))-49.0)<.01,"5 70% x 70% = 49%");

  double p8=StatisticalCalibrationEngine.jointProbability(Arrays.asList(80,80,80,80,80,80,80,80));
  check(p8<20 && "PENALIZAÇÃO ALTA".equals(StatisticalCalibrationEngine.ticketPenalty(8)) && "RISCO ALTO".equals(StatisticalCalibrationEngine.ticketRisk(8,p8)),"6 oito seleções não são 80% nem baixo risco");

  check(StatisticalCalibrationEngine.sourceQualityScore(Arrays.asList("Web pública"))<70,"7 fonte única não equivale a consenso forte");

  check(!StatisticalCalibrationEngine.isPregameStatus("LIVE") && StatisticalCalibrationEngine.isPregameStatus("SCHEDULED") && !StatisticalCalibrationEngine.isPregameStatus("") && !StatisticalCalibrationEngine.isPregameStatus("UNKNOWN"),"8 LIVE/UNKNOWN excluídos do pré-jogo");

  StatisticalCalibrationEngine.GoalSanity g=StatisticalCalibrationEngine.goalSanity(2.9,1.8,1.7,2.25,.55);
  check(g.divergent && g.adjustedProjection<2.9 && g.status.contains("REVISÃO"),"9 projeção de gols divergente é recalibrada");

  StatisticalCalibrationEngine.Calibration t10=StatisticalCalibrationEngine.calibrate(76,0,0,0,0,0,Double.NaN,Double.NaN,true);
  check(t10.confidenceScore<45 && !"FAVORÁVEL".equals(t10.status) && !"RISCO MENOR".equals(t10.risk),"10 fallback/cache sem dados externos reduz confiança");

  double[] nv=StatisticalCalibrationEngine.noVig(2.0,3.5,4.0);double sum=0;for(double x:nv)sum+=x;check(Math.abs(sum-100)<.001,"extra odds normalizadas sem margem somam 100%");
  StatisticalCalibrationEngine.Calibration cap=StatisticalCalibrationEngine.calibrate(99,95,25,4,95,95,Double.NaN,.08,false);check(cap.calibratedProbability<=90,"extra acima de 90 exige mercado convergente real");
  StatisticalCalibrationEngine.Calibration noMarket=StatisticalCalibrationEngine.calibrate(76,70,12,2,82,70,Double.NaN,.20,false);StatisticalCalibrationEngine.Calibration withMarket=StatisticalCalibrationEngine.calibrate(76,70,12,2,82,70,75,.20,false);check(noMarket.confidenceScore<withMarket.confidenceScore,"extra ausência de mercado não ganha pontos artificiais de convergência");
  check("REVISÃO NECESSÁRIA".equals(StatisticalCalibrationEngine.divergenceLabel(90,55)),"extra divergência é medida contra probabilidade bruta");

  StatisticalCalibrationEngine.Outcome3 po=StatisticalCalibrationEngine.poissonOutcome(1.65,1.05);
  check(po!=null&&po.home+po.draw+po.away==100&&po.home>po.away,"15 Poisson 1X2 próprio normaliza em 100%");
  int dnb=StatisticalCalibrationEngine.drawNoBetProbability(po,true);
  check(dnb>po.home&&dnb<100,"16 empate anula remove a massa do empate corretamente");

  MarketOddsBook mb=new MarketOddsBook();LinkedHashMap<String,Double> win=new LinkedHashMap<>();win.put(MarketOddsBook.HOME,1.80);win.put(MarketOddsBook.DRAW,3.60);win.put(MarketOddsBook.AWAY,4.80);mb.addBookmakerMarket(win,"Casa A","Match Winner");
  double mh=mb.probability(MarketOddsBook.HOME),md=mb.probability(MarketOddsBook.DRAW),ma=mb.probability(MarketOddsBook.AWAY);
  check(Math.abs(mh+md+ma-100)<.01&&Math.abs(mb.doubleChance(true)-(mh+md))<.01,"17 odds por casa removem margem e derivam 1X corretamente");
  int hp1=StatisticalCalibrationEngine.normalHandicapProbability(2.0,11.0,true,2.5),hp2=StatisticalCalibrationEngine.normalHandicapProbability(2.0,11.0,true,7.5);
  check(hp2>hp1&&hp2<100,"18 handicap positivo aumenta segurança sem chegar a 100%");

  LinkedHashMap<String,Double> totals=new LinkedHashMap<>();totals.put(MarketOddsBook.totalKey(true,214.5),1.91);totals.put(MarketOddsBook.totalKey(false,214.5),1.91);mb.addBookmakerMarket(totals,"Casa A","Total Points");
  check(mb.totalLines().size()==1&&Math.abs(mb.mainTotalLine()-214.5)<.01,"19 linha real de total é preservada e reconhecida");
  check(!StatisticalCalibrationEngine.isPregameStatus("HT")&&!StatisticalCalibrationEngine.isPregameStatus("Q3"),"20 status ao vivo nunca entra no bilhete pré-jogo");
  System.out.println("ALL TESTS PASSED: "+ok);
 }
}
