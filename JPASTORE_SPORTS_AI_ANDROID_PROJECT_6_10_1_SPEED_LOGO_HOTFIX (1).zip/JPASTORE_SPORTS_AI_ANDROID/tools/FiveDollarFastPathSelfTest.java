package com.jpastore.sportsai;
public class FiveDollarFastPathSelfTest {
  static int n=0;
  static void eq(String name, Object got, Object exp){ n++; if(exp==null?got!=null:!exp.equals(got)) throw new AssertionError(name+": got="+got+" expected="+exp); System.out.println("PASS: "+name+" -> "+got); }
  public static void main(String[] args) throws Exception {
    eq("scheduled maps to NS", FiveDollarFootballClient.mapStatus("scheduled","",""), "NS");
    eq("finished maps to FT", FiveDollarFootballClient.mapStatus("finished","",""), "FT");
    eq("live minute preserved", FiveDollarFootballClient.mapStatus("live","","73"), "73");
    eq("live without minute", FiveDollarFootballClient.mapStatus("live","",""), "LIVE");
    eq("postponed/unknown kickoff", FiveDollarFootballClient.mapStatus("unknown","kickoff postponed",""), "PST");
    long[] w=FiveDollarFootballClient.dayWindow("2026-09-22");
    long seconds=w[1]-w[0];
    if(seconds < 23*3600 || seconds > 25*3600) throw new AssertionError("day window invalid: "+seconds);
    n++; System.out.println("PASS: São Paulo day window -> "+seconds+"s");
    System.out.println("ALL 5DOLLAR FAST PATH TESTS PASSED: "+n);
  }
}
