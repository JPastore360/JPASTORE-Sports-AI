package com.jpastore.sportsai;
public class HighlightlyBasketballSelfTest {
  static int n=0;
  static void eq(String name,Object got,Object exp){n++;if(exp==null?got!=null:!exp.equals(got))throw new AssertionError(name+": got="+got+" expected="+exp);System.out.println("PASS: "+name+" -> "+got);}
  static void yes(String name,boolean v){n++;if(!v)throw new AssertionError(name);System.out.println("PASS: "+name);}
  public static void main(String[] args){
    eq("basketball source id", HighlightlyBasketballClient.SOURCE, "highlightly_basketball");
    eq("Highlightly direct base", HighlightlyBasketballClient.BASE, "https://basketball.highlightly.net/");
    eq("scheduled uses prematch odds", HighlightlyBasketballClient.oddsTypeForStatus("SCHEDULED"), "prematch");
    eq("live uses live odds", HighlightlyBasketballClient.oddsTypeForStatus("Q3"), "live");
    yes("Basic plan does not waste calls on paid odds", !HighlightlyBasketballClient.oddsAvailableForTier("BASIC"));
    yes("Free plan does not waste calls on paid odds", !HighlightlyBasketballClient.oddsAvailableForTier("FREE"));
    yes("Paid/unknown tier may try odds", HighlightlyBasketballClient.oddsAvailableForTier("PRO"));
    int[] s=HighlightlyBasketballClient.scorePair("98-91");yes("basketball score parser",s[0]==98&&s[1]==91);
    String[] a=HighlightlyBasketballClient.localIso("2026-09-22T23:30:00Z");eq("UTC to Sao Paulo time",a[1],"20:30");
    String[] b=HighlightlyBasketballClient.localIso("2026-09-22T01:30:00.000Z");eq("UTC date rollover Sao Paulo",b[0],"2026-09-21");eq("UTC rollover time",b[1],"22:30");
    System.out.println("ALL HIGHLIGHTLY FAST PATH TESTS PASSED: "+n);
  }
}
