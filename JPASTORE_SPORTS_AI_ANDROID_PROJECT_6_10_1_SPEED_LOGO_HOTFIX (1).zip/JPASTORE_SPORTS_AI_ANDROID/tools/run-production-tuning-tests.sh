#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="${TMPDIR:-/tmp}/jpastore-production-tests"
rm -rf "$TMP" && mkdir -p "$TMP/src/com/jpastore/sportsai" "$TMP/src/android/content" "$TMP/out"
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content; public class Context { public SharedPreferences getSharedPreferences(String n,int m){return null;} }
JAVA
cat > "$TMP/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content; public interface SharedPreferences {String getString(String k,String d);Editor edit();interface Editor{Editor putString(String k,String v);void apply();}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/MultiSportClient.java" <<'JAVA'
package com.jpastore.sportsai; class MultiSportClient {static final String FOOTBALL="FUTEBOL",BASKETBALL="BASQUETE",NBA="NBA",NFL="NFL",BASEBALL="BASEBALL",MMA="MMA",F1="F1";static class Event {long id,homeId,awayId;String sport="",competition="",home="",away="",date="",status="SCHEDULED";}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/MultiSportWebClient.java" <<'JAVA'
package com.jpastore.sportsai; import java.util.*; class MultiSportWebClient {static class GameRow {String date="",home="",away="",score="",status="",competition="",competitionType="";long homeId,awayId;int hs=-1,as=-1;boolean completed,sourceConflict;LinkedHashSet<String> sources=new LinkedHashSet<>();boolean involves(String t){return TeamIdentityResolver.matches(t,home)||TeamIdentityResolver.matches(t,away);}boolean homeSide(String t){return TeamIdentityResolver.matches(t,home);}int confirmations(){return Math.max(1,sources.size());}}static class Research {int homeWins,homeDraws,homeLosses,awayWins,awayDraws,awayLosses,homeSample,awaySample;double homeFor,homeAgainst,awayFor,awayAgainst;ArrayList<GameRow> mergedHome=new ArrayList<>(),mergedAway=new ArrayList<>(),mergedH2h=new ArrayList<>();LinkedHashSet<String> structuredSources=new LinkedHashSet<>();MarketOddsBook marketOdds=new MarketOddsBook();boolean hasStructured(){return !mergedHome.isEmpty()||!mergedAway.isEmpty()||!mergedH2h.isEmpty();}}static void addUniqueGame(ArrayList<GameRow> out,GameRow g){for(GameRow x:out)if(x.date.equals(g.date)&&TeamIdentityResolver.matches(x.home,g.home)&&TeamIdentityResolver.matches(x.away,g.away)){x.sources.addAll(g.sources);return;}out.add(g);}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/ApiClient.java" <<'JAVA'
package com.jpastore.sportsai; final class ApiClient {static double poissonOver(double mean,double line){return 50;}}
JAVA
cp "$ROOT/app/src/main/java/com/jpastore/sportsai/"{EventStandards.java,StatisticalCalibrationEngine.java,MarketOddsBook.java,ProductionTuningEngine.java,SportConsensusEngine.java,SportTicketEngine.java,SportPresentationRules.java,TeamIdentityResolver.java} "$TMP/src/com/jpastore/sportsai/"
cp "$ROOT/tools/ProductionTuningSelfTest.java" "$TMP/src/com/jpastore/sportsai/"
javac -encoding UTF-8 -d "$TMP/out" $(find "$TMP/src" -name '*.java')
java -cp "$TMP/out" com.jpastore.sportsai.ProductionTuningSelfTest
