#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
SRC="$ROOT/app/src/main/java/com/jpastore/sportsai"
API="$SRC/ApiClient.java"
WEB="$SRC/MultiSportWebClient.java"
UI="$SRC/PremiumView.java"
FIVE="$SRC/FiveDollarFootballClient.java"
pass(){ echo "PASS: $1"; }

grep -Fq "6.10.1-speed-logo-hotfix" "$ROOT/app/build.gradle" && pass "versão 6.10.1"
grep -Fq 'forceDeep?15000L:4200L' "$API" && pass "orçamento total normal ~4,2s"
grep -Fq 'forceDeep?7000L:2200L' "$API" && pass "janela de fontes rápidas ~2,2s"
grep -Fq 'forceDeep?6200L:850L' "$API" && pass "consenso web normal ~0,85s"
grep -Fq 'forceDeep?5000L:550L' "$API" && pass "API-Football fallback normal ~0,55s"
grep -Fq 'forceDeep?4500L:350L' "$API" && grep -Fq 'ensureGoalFallbackTimed' "$API" && pass "OpenFootball fallback também tem timeout"
grep -Fq 'forceDeep?1100L:450L' "$API" && pass "odds normais ~0,45s"
grep -Fq 'String resolveSofaBadge' "$WEB" && grep -Fq 'h.setConnectTimeout(1200);h.setReadTimeout(1600);' "$WEB" && pass "resolver SofaScore rápido"
grep -Fq 'resolveSofaBadge(sport,team)' "$UI" && pass "resolver SofaScore conectado à UI"
grep -Fq 'logoField(ho)' "$FIVE" && pass "logo 5Dollar preservado"
echo "ALL SPEED + LOGO HOTFIX TESTS PASSED: 10"
