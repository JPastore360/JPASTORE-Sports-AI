# J.Pastore Sports AI 4.8 — Digital Clock

- Mantém `applicationId com.jpastore.sportsai`, o mesmo módulo `app` e a mesma raiz `JPASTORE_SPORTS_AI_ANDROID/`.
- VersionCode 39 / VersionName 4.8.0-digital-clock.
- Remove completamente o `TimePicker` híbrido/nativo do seletor manual.
- Novo relógio 100% digital, com horário atual de Brasília separado do horário selecionado.
- Visor grande `HH:MM` com acabamento premium.
- Ajustes rápidos: -1h, +1h, -5min e +5min.
- Atalhos: Agora, Próxima 1h, Manhã 09:00, Tarde 14:00, Noite 19:00 e Meia-noite 00:00.
- Botão Aplicar horário preserva o filtro já usado pelo motor de confrontos.
- Nenhuma alteração em Vision AI, bilhetes, API, busca ou demais telas.
