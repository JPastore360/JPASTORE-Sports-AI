# J.Pastore Sports AI 4.9.0 — Atualização preservada

- Mantém exatamente o `applicationId com.jpastore.sportsai`.
- `versionCode` avançado para 40.
- APK debug e release agora usam a mesma chave estável `app/jpastore-sports-stable.jks`.
- O workflow atual pode continuar compilando com `:app:assembleDebug`; o APK resultante será assinado com a chave estável do projeto.
- A partir da primeira instalação desta versão, as próximas atualizações podem ser instaladas por cima, desde que esta mesma chave seja preservada e o `versionCode` continue aumentando.
- Chave da API migra para o armazenamento persistente nomeado `jp_persistent_v1`, separado dos caches temporários.
- Compatibilidade de projeto preservada: mesmo nome, mesma pasta raiz `JPASTORE_SPORTS_AI_ANDROID/` e mesmo módulo `app`.

## Atenção para esta primeira migração
As versões anteriores eram compiladas com a chave debug efêmera do GitHub Actions. Por isso, a versão 4.9 pode exigir uma última desinstalação da versão antiga. Depois de instalar a 4.9, não substitua nem regenere `app/jpastore-sports-stable.jks`.
