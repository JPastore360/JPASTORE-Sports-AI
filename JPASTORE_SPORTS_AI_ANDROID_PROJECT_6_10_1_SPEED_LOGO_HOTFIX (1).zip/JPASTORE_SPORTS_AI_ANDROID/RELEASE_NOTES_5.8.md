# J.Pastore Sports AI 5.8

- Bilhete criado permanece visível na própria agenda multiesporte.
- Botão muda para **VER BILHETE • X** quando há seleções salvas.
- Botão **NOVO BILHETE IA** permite iniciar outra seleção sem esconder o bilhete atual.
- Barra fixa **BILHETE ATIVO** mostra o total de seleções e oferece **FINALIZAR**.
- Após gerar o bilhete múltiplo, o app permanece na agenda e só abre o resumo quando o usuário escolher finalizar.
- Mantidos applicationId e assinatura para atualização por cima.
