# J.Pastore Sports AI 5.2.1

- Mantém `applicationId com.jpastore.sportsai`.
- `versionCode 44` / `versionName 5.2.1-multisport-premium`.
- Confirma navegação de Basquete/NBA, MMA, Fórmula 1, NFL e Baseball para a tela completa `sportDetail` (screen 19).
- O cartão multiesporte exibe `ABRIR ANÁLISE 5.2.1`.
- A agenda e a tela de detalhes exibem `V5.2.1 • DETALHES PREMIUM` para confirmar visualmente que o APK novo foi instalado.
- Mantém Internet First + pesquisa web + J.Pastore IA + Estatísticas + H2H + Web.
- Sem alteração no nome do projeto, módulo `app`, package ou assinatura estável.
