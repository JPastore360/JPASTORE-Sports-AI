# J.Pastore Sports AI 6.2

- Internet First Research Engine para Basquete, NFL e Baseball.
- Pesquisa em múltiplas consultas por equipe e competição.
- Leitura de páginas públicas e extração de placares históricos explícitos.
- Jina Reader sem chave como fallback de leitura para páginas públicas difíceis de extrair.
- Fusão com ESPN, SofaScore e TheSportsDB antes de recorrer à API-Sports.
- API-Sports passa a ser último recurso para histórico.
- Cache de histórico por equipe por 18h e cache de API histórica por 24h.
- Agenda futura cacheada por 4h para economizar cota.
- Deduplicação de jogos entre fontes.
