# J.Pastore Sports AI 5.7

- Corrige o Bilhete IA multiconfronto que podia terminar em uma aba vazia.
- Histórico complementar passa a usar IDs reais dos participantes quando disponíveis.
- Reconhecimento de partidas encerradas ficou mais robusto.
- Bilhete múltiplo usa limiar adaptativo com no mínimo 3 resultados válidos por lado, sem inventar dados.
- Se nenhuma seleção tiver base, mantém a tela de seleção e informa o motivo em vez de abrir bilhete vazio.
- applicationId preservado: `com.jpastore.sportsai`.
