# J.Pastore Sports AI 5.5

## Correções principais

- A aba WEB agora apresenta títulos e resumos em português do Brasil, mesmo quando a fonte original está em inglês.
- A busca pública continua sendo priorizada; a fonte original permanece acessível pelo botão ABRIR FONTE.
- Corrigido o motivo da ausência de estatísticas em ligas fora do feed ESPN usado pela versão 5.4 (ex.: LNBP).
- Os eventos multiesporte agora preservam IDs de equipe, liga, temporada e fonte de API.
- Quando a internet não fornece uma amostra histórica estruturada suficiente, o app usa a API da própria modalidade já configurada no aparelho como fallback histórico.
- O fallback tenta primeiro time + liga + temporada, depois amplia a consulta quando necessário; recupera até 8 resultados recentes por participante e até 5 confrontos diretos, com cache para reduzir consumo de requisições.
- O H2H também pode ser derivado dos históricos dos próprios times, reduzindo dependência de um endpoint específico.
- A mensagem de diagnóstico agora informa quantos jogos foram realmente recuperados ou se a fonte estruturada recusou/não cobriu a consulta.
- A origem dos dados passa a ser exibida na aba ESTAT., sem inventar números quando nenhuma fonte confiável responde.

## Compatibilidade

- applicationId: com.jpastore.sportsai
- versionCode: 47
- versionName: 5.5.0-ptbr-history-fallback
- Mantida a assinatura estável para instalação por cima.
