# J.Pastore Sports AI 6.1

- Motor multifonte para Basquete/NFL/Baseball.
- Combina ESPN, SofaScore, API-Sports e TheSportsDB.
- Soma históricos parciais e remove partidas duplicadas antes de calcular a amostra.
- SofaScore usa correspondência de nomes mais tolerante.
- API-Sports tenta primeiro o ID real do time e limita chamadas para preservar cota.
- TheSportsDB entra apenas como último fallback quando ainda faltam 3 jogos por lado.
- Mantém o bilhete multiconfronto e ignora apenas confrontos sem base suficiente.
