# J.PASTORE Sports AI 6.9 — Turbo Multi-API Engine

Version: `6.9.0-turbo-multi-api`  
VersionCode: `61`  
ApplicationId preserved: `com.jpastore.sportsai`

## New: Highlightly Basketball FAST

- New **Highlightly Basketball • BASQUETE FAST** card in `MAIS > APIs & FONTES`.
- User can paste, replace, test and remove the Highlightly key inside the app.
- Key remains local in persistent app preferences; it is not hard-coded into the APK.
- Direct Highlightly Basketball endpoint (`basketball.highlightly.net`) is primary.
- All-Sports endpoint is accepted as an automatic compatibility fallback.
- Daily quota circuit breaker and request counters are supported.
- Free/BASIC plan detection avoids repeatedly calling the paid odds endpoint.
- Basketball agenda, last-five form, H2H and (when plan permits) odds feed the existing calibrated J.PASTORE engine.

## Turbo Multi-API performance

- Football daily agenda now merges 5Dollar + public structured schedule + web catalog in parallel.
- Basketball agenda merges Highlightly + ESPN/SofaScore/TheSportsDB/open-web sources in parallel.
- API-Sports is a complement, not a gate. It is called only when fast/public coverage is insufficient.
- Slow open-web enrichment has a hard time budget and can no longer hold the analysis overlay indefinitely.
- Football live sources are queried concurrently.
- Team search aliases are queried concurrently.
- Normal game analysis has short budgets; deep analysis remains available when the user explicitly wants more coverage.
- Resilient cache supplies the last valid schedule if all current providers fail.

## Football home-screen correction

- The home page no longer depends only on unfinished games for visual population.
- Active/upcoming matches remain first; when fewer than six are available, recent finished games from the loaded day fill the highlights section.
- This prevents the home screen from appearing to contain only one match when the day is already partially completed.

## Statistical engine preserved

All 6.7/6.8 calibration rules remain active: raw vs calibrated probability, coverage separation, Confidence Score, no-vig market probability, dynamic probability caps, Poisson football model, source quality, sample-size confidence, pregame status filtering and multiplicative ticket probability.
