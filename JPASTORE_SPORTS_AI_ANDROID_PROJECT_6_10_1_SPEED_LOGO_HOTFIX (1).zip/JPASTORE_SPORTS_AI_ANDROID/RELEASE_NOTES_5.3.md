# J.Pastore Sports AI 5.3

- Multiesportes agora abre diretamente em **J.Pastore IA / Análise Completa** ao tocar no confronto.
- Removido o uso de popup informativo como destino de evento multiesporte.
- Basquete/NBA, NFL e Baseball: forma recente, vitórias/derrotas, médias de pontos/runs a favor e contra quando a amostra pública permite.
- H2H e resultados recentes são exibidos somente quando encontrados.
- MMA e F1 priorizam contexto web e histórico disponível; o app sinaliza quando não há amostra estruturada suficiente.
- Internet First: web pública e dados estruturados antes da API de agenda/status.
- Build marker: JP-MULTISPORT-FULL-ANALYSIS-5.3.0.
- applicationId preservado: com.jpastore.sportsai.
- versionCode 45.
