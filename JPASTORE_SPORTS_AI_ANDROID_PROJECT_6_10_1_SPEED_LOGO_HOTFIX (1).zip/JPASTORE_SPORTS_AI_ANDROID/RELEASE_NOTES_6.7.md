# J.Pastore Sports AI 6.7 — Calibrated Market Engine

Esta versão aprofunda o motor estatístico sem substituir a interface nem a arquitetura API-independent da 6.5/6.6.

## Revisão estatística
- Probabilidade bruta, probabilidade calibrada, cobertura, Confidence Score e risco permanecem campos distintos.
- Teto dinâmico por cobertura e bloqueio de 100%.
- Confidence Score separado da probabilidade: dados, amostra, convergência, mercado e estabilidade.
- Divergência com mercado é medida contra a estimativa original do modelo, antes da aproximação/calibração.
- Segurança impede FAVORÁVEL/RISCO MENOR com cobertura <20%, Confidence Score <45, divergência >15 p.p., fonte única fraca ou inconsistência relevante.

## Odds e mercado
- Novo MarketOddsBook remove a margem por bookmaker/mercado antes de agregar consenso.
- Odds reais são opcionais: nenhuma falta/limite de API interrompe a análise.
- Futebol pré-jogo usa /odds; futebol ao vivo usa /odds/live, sem misturar snapshots.
- Dupla chance e empate-anula podem ser derivados do mercado 1X2 sem margem quando o mercado direto não existe.
- Basquete/NFL/Baseball usam odds compatíveis apenas quando o evento veio da própria API com ID válido; IDs de agenda pública não são reutilizados como IDs privados.

## Futebol
- 1X2 próprio por Poisson a partir dos gols esperados; API Prediction deixa de ser fonte única.
- Quando existem dois modelos, há blend ponderado em vez de aceitar uma única fonte como verdade.
- Validação automática 1X/X2 evita inversão textual de equipe.
- Empate anula e handicap positivo só são promovidos quando a linha real existe (handicap) e passa pela calibração.
- Projeção de gols pondera forma recente, casa/fora, ataque, defesa, média histórica da competição quando houver ao menos 8 partidas válidas e H2H com peso reduzido; sanity check contra média, mediana e linha principal real. Se a média da liga não estiver disponível, ela não é inventada.

## Outros esportes
- Modo CONSERVADOR prioriza handicap positivo real, depois total alternativo e só então moneyline/vencedor quando há vantagem estatística/confiança suficiente.
- Totais usam média ponderada e dispersão; quando odds existem, escolhem uma linha efetivamente encontrada no mercado.
- Market probability é exibida somente quando veio de odds reais normalizadas.

## Ao vivo
- Novo LiveAnalysisEngine separado do pré-jogo.
- Considera placar, minuto/tempo restante e expectativa de gols remanescentes.
- Linhas ao vivo só aparecem quando /odds/live retorna dados atuais; odds pré-jogo não são reaproveitadas como live.
- Eventos LIVE/HT/Q1-Q4 continuam bloqueados no gerador automático de bilhete pré-jogo.

## Bilhete e fontes
- Probabilidade conjunta aproximada = produto das probabilidades calibradas; índice médio é mostrado separadamente.
- Penalização explícita conforme quantidade de seleções.
- Uma fonte nunca é chamada de consenso; aparece como FONTE ÚNICA • CONFIANÇA LIMITADA.
- Logs [JP_AI] registram raw/calibrated/market/coverage/sample/source/confidence/risk/projection/reason.

## Correção de compilação descoberta na revisão
- Foram restaurados ApiClient.today(), ApiClient.future() e ApiClient.pct(), que haviam sido removidos acidentalmente durante a serialização de odds da revisão anterior e causariam `cannot find symbol` no Java compiler.

## Testes
- 20 testes do núcleo estatístico: 20 aprovados.
- Compilação Java das classes centrais alteradas com stubs Android: aprovada sem erros de código.
- O assembleDebug Android completo depende de Android SDK/Gradle; o workflow GitHub incluído executa essa etapa e diferencia erro de código de falha transitória de rede.
