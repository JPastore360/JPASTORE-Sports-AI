# J.Pastore Sports AI 5.1 — Multiesportes Premium

- Mantém o mesmo projeto, applicationId `com.jpastore.sportsai`, módulo `app` e assinatura estável.
- Home agora exibe as 6 modalidades de forma visível: Futebol, Basquete, MMA, Fórmula 1, NFL e Baseball.
- Novo seletor horizontal Premium com indicação de modalidade configurada.
- Identidade do cabeçalho alterada para “Sports AI • Multiesportes”.
- Central Multiesportes redesenhada em cards 2x3, com status de conexão e ação clara por esporte.
- Botão dedicado para APIs & Fontes dentro da Central Multiesportes.
- Futebol continua com o motor completo de IA, estatísticas, Radar, Bilhete e Vision AI.
- Modalidades adicionais mantêm suas APIs específicas, cache e agenda em horário de Brasília.
- J.Pastore Vision AI permanece integrado para análise de prints.
