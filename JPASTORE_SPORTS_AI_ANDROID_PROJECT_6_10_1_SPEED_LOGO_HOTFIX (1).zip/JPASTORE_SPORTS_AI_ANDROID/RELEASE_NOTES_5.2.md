# J.Pastore Sports AI 5.2 — Multiesportes Premium

- Mantido o projeto `JPASTORE_SPORTS_AI_ANDROID`, applicationId `com.jpastore.sportsai` e assinatura estável.
- Basquete/NBA, MMA, Fórmula 1, NFL e Baseball agora abrem uma tela completa de análise em vez de um popup simples.
- Nova navegação por Visão, J.Pastore IA, Estatísticas, H2H e Web.
- Nova camada Internet First para modalidades não futebol: tenta histórico público estruturado e depois pesquisa web, mantendo a API-Sports como complemento para agenda/status.
- Forma recente e confrontos diretos são mostrados somente quando a camada web localiza amostra real; dados ausentes não são inventados.
- J.Pastore IA multiesporte responde perguntas usando o contexto encontrado na web e no histórico estruturado.
- Busca principal renomeada para Busca Multiesporte, incluindo nomes já carregados das modalidades e fallback para pesquisa web quando o futebol não resolve a consulta.
- Resultados da busca web aparecem dentro do app e podem abrir a fonte original no navegador.
- Mantido o J.Pastore Vision AI para leitura de prints/bilhetes.
