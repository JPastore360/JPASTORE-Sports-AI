# J.PASTORE Sports AI 6.10 — Production Tuning

Versão incremental baseada na 6.9.1 Logo Optimizer HOTFIX. Nenhuma integração existente foi removida.

## Principais ajustes
- Agenda do futebol mais ampla: removido encerramento antecipado após apenas 8 jogos/primeira fonte e renovado o namespace de cache da agenda.
- Agenda multiesporte só reduz o orçamento de espera quando já existem pelo menos 15 eventos e 3 fontes respondidas.
- Relógio/filtro de horário agora usa TimePicker 24h com seleção minuto a minuto, além de botões ±1 min/±1h e atalhos existentes.
- Forma Recente 2.0 com recência, competição, força do adversário, qualidade da fonte, winsorization e amostra ponderada equivalente.
- Pré-temporada e amistosos recentes permanecem na amostra com peso reduzido (0,60 e 0,45).
- Baseline de liga, ataque/defesa normalizados, descanso, back-to-back <48h e H2H temporalmente limitado.
- Basquete com expectedHomePoints, expectedAwayPoints, expectedTotal e projectedMargin.
- Contagem de fontes independentes deduplicada e convergência por direção dos sinais.
- Confidence Score separado da probabilidade com pesos 25/15/20/15/15/10.
- Regras de risco mais conservadoras e market check preservado sem copiar o mercado.
- Status centralizados e proteção contra null/undefined.
- Timezone centralizado com auditoria original/event/device/converted.
- Fallback de logotipo por iniciais reais e nunca “FC” para basquete.
- Nomes longos podem ocupar até duas linhas.
- Cache mantém dataSource, cacheAge e lastUpdated.
- Log de auditoria [JP_AI_ANALYSIS] com métricas do modelo e [JP_AI_TIME] para conversão de horário.

## Validação
- 20/20 testes do motor estatístico calibrado.
- 10/10 testes Production Tuning A–J.
- 8/8 testes Logo Optimizer.
- Compilação Java do núcleo: OK.
- Varredura de sintaxe dos arquivos Android alterados: OK (dependências Android ausentes no ambiente local são esperadas).
- Regressão estática de funções críticas: aprovada.

## Casos A–J
A. Alvark Tokyo × Ryukyu Golden Kings — B2B, H2H imediato, recência e alias/deduplicação.
B. Cairns Taipans × Tasmania JackJumpers — pré-temporada mantida com peso reduzido.
C. Shanghai Sharks × RSSB Tigers — normalização de baseline entre CBA/BAL/internacional.
D. Nagasaki Velca × Shimane Susanoo Magic — forma, H2H, médias, mercado e convergência.
E. Uma fonte — FONTE ÚNICA, nunca consenso.
F. Três fontes concordando — CONSENSO FORTE quando amostra/convergência também sustentam.
G. Logo ausente no basquete — iniciais, nunca FC.
H. Dados inexistentes — null/undefined não são renderizados.
I. Partida futura — sem placar inexistente.
J. LIVE — excluído automaticamente do motor pré-jogo.

## Antes → depois
- Agenda: primeira fonte + 8 jogos podia encerrar a coleta → fontes públicas têm chance real de completar a lista; cache parcial antigo é invalidado.
- Horário: passos de 5 minutos → qualquer minuto via TimePicker, com ±1 minuto.
- Forma: média simples dominante → média bruta + média ponderada por recência/competição/adversário.
- Pré-temporada: podia desaparecer ou valer como liga atual → entra com peso 0,60.
- Fontes: rótulo combinado podia divergir do contador → uniqueSourceCount efetivo + convergência.
- H2H: histórico pouco sensível à idade → peso temporal, com bônus 1,20 apenas no encontro <48h.
- Basquete: total derivado de média genérica → expectedHome + expectedAway e projectedMargin.
- UI: null/FC/truncamento → texto seguro, iniciais e até duas linhas.

## Arquivos principais modificados
app/build.gradle
app/src/main/java/com/jpastore/sportsai/ApiClient.java
app/src/main/java/com/jpastore/sportsai/MainActivity.java
app/src/main/java/com/jpastore/sportsai/MultiSportClient.java
app/src/main/java/com/jpastore/sportsai/MultiSportWebClient.java
app/src/main/java/com/jpastore/sportsai/PremiumView.java
app/src/main/java/com/jpastore/sportsai/SportConsensusEngine.java
app/src/main/java/com/jpastore/sportsai/SportTicketEngine.java
app/src/main/java/com/jpastore/sportsai/StatisticalCalibrationEngine.java

## Novos módulos
app/src/main/java/com/jpastore/sportsai/EventStandards.java
app/src/main/java/com/jpastore/sportsai/ProductionTuningEngine.java
app/src/main/java/com/jpastore/sportsai/SportPresentationRules.java
tools/ProductionTuningSelfTest.java
tools/run-production-tuning-tests.sh
ci/build-apk-6.10-PRODUCTION.yml
FULL_ANALYSIS_BUILD_6_10
