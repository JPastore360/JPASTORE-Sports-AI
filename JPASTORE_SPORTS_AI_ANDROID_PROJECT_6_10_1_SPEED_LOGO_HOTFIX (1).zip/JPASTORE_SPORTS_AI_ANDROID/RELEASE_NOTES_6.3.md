# J.Pastore Sports AI 6.3 — Consensus Intelligence Engine

- Internet First mantido: fontes públicas e web aberta antes da API-Sports.
- Cada resultado histórico preserva a origem da fonte.
- Duplicatas confirmadas por mais de uma fonte ganham peso de confirmação.
- Divergências de placar entre fontes são marcadas como conflito e recebem peso menor; não são "promediadas" cegamente.
- Novo consenso J.Pastore IA: média ponderada por recência e confirmação, mediana, dispersão, cobertura e índice de convergência entre fontes.
- Bilhete IA passa a usar o consenso para vencedor/total quando a base normal existe.
- Bilhete múltiplo ganha leitura EXPLORATÓRIA quando existem dados reais suficientes para calcular uma média, mas o limiar padrão não fecha; o usuário decide se mantém ou remove.
- Tela J.Pastore IA mostra fontes, jogos únicos, confirmações, conflitos e base por fonte.
- Perguntas sobre "média", "consenso", "base" e "convergência" retornam a explicação da amostra usada.
- applicationId preservado: com.jpastore.sportsai.
