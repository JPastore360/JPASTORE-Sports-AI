# J.Pastore Sports AI 6.0

- Corrige bilhete multiconfronto que terminava sem seleção quando a temporada atual ainda não tinha histórico.
- Busca histórico pelo ID real do participante e tenta a temporada atual e até duas anteriores.
- Um confronto sem base é ignorado sem cancelar os demais.
- O resumo final informa quantos confrontos foram válidos e quantos foram ignorados.
