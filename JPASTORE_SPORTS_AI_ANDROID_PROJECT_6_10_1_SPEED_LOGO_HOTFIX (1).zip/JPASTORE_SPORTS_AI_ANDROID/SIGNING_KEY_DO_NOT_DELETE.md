# NÃO APAGAR — chave de atualização do J.Pastore Sports AI

Arquivo obrigatório: `app/jpastore-sports-stable.jks`
Alias: `jpastore-sports`
SHA-256 do certificado: `9E:DC:3B:07:D7:A2:E0:21:99:D1:F5:A0:62:75:A8:96:DD:A2:CA:AB:AA:1E:FF:D2:D5:E9:EA:0C:0D:A5:09:86`

Essa chave é o que permite ao Android reconhecer uma nova compilação como atualização do app já instalado. Todas as versões futuras precisam reutilizar exatamente este arquivo e manter `applicationId com.jpastore.sportsai`. Também é obrigatório usar `versionCode` maior que a versão instalada.

Não regenere a chave e não troque o alias/senhas no `app/build.gradle`.
