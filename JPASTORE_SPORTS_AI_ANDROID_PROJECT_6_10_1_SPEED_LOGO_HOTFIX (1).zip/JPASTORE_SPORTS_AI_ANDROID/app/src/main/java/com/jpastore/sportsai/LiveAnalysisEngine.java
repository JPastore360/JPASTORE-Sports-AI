package com.jpastore.sportsai;

import java.util.*;

/** Separate in-play model. It never reuses a pre-game ticket recommendation as a live pick. */
final class LiveAnalysisEngine {
    static String report(ApiClient.Game g,ApiClient.DeepAnalysis d){
        StringBuilder b=new StringBuilder("MODO AO VIVO • MODELO SEPARADO\n");
        if(g==null||!ApiClient.isLiveStatus(g.status))return "Este confronto não está marcado como AO VIVO.";
        b.append("Placar atual: ").append(g.homeGoals>=0?g.homeGoals:"—").append(" × ").append(g.awayGoals>=0?g.awayGoals:"—").append(" • status ").append(safe(g.status)).append(" • minuto ").append(g.elapsed>0?g.elapsed:"—").append(".\n");
        if(g.homeGoals<0||g.awayGoals<0||g.elapsed<=0){
            b.append("DADOS INSUFICIENTES — placar/tempo restante não foram confirmados. O modelo AO VIVO não reutiliza probabilidades pré-jogo para preencher essa lacuna.\n");
            appendLiveMarket(b,d);return b.toString();
        }
        ApiClient.MetricProjection gm=d==null?null:d.metrics.get("Gols");
        if(gm==null||gm.home<=0||gm.away<=0){
            b.append("DADOS INSUFICIENTES — falta uma base de gols esperados independente para projetar o tempo restante.\n");appendLiveMarket(b,d);return b.toString();
        }
        double remaining=Math.max(0,Math.min(1,(90.0-Math.min(90,g.elapsed))/90.0));
        double stateHome=1.0,stateAway=1.0;int diff=g.homeGoals-g.awayGoals;
        if(diff<0)stateHome=1.08;else if(diff>0)stateAway=1.08;
        if(Math.abs(diff)>=2){if(diff>0)stateHome=.94;else stateAway=.94;}
        double lh=Math.max(.01,gm.home*remaining*stateHome),la=Math.max(.01,gm.away*remaining*stateAway);
        StatisticalCalibrationEngine.Outcome3 o=conditionalOutcome(g.homeGoals,g.awayGoals,lh,la);
        int coverage=ApiClient.coveragePercent(d),sample=d==null?0:d.homeMatches+d.awayMatches+d.h2hMatches,sc=d==null?0:d.sourceCount,sq=d==null?0:d.sourceQuality,agr=d==null?0:d.agreement;
        double vr=gm.total>0&&!Double.isNaN(gm.stdDev)?gm.stdDev/gm.total:Double.NaN;
        b.append("Tempo restante estimado: ").append((int)Math.round(remaining*90)).append(" min • gols esperados restantes: ").append(fmt(lh+la)).append(" (casa ").append(fmt(lh)).append(" / fora ").append(fmt(la)).append(").\n");
        if(o!=null){
            b.append("Probabilidades AO VIVO brutas: ").append(g.home).append(" ").append(o.home).append("% • empate ").append(o.draw).append("% • ").append(g.away).append(" ").append(o.away).append("%.\n");
            boolean home=o.home>=o.away;int raw=Math.max(o.home,o.away);double market=d==null||d.marketOdds==null?Double.NaN:d.marketOdds.probability(home?MarketOddsBook.HOME:MarketOddsBook.AWAY);
            StatisticalCalibrationEngine.Calibration cal=StatisticalCalibrationEngine.calibrate(raw,coverage,sample,sc,sq,agr,market,vr,false);
            b.append("Cenário líder calibrado: ").append(home?g.home:g.away).append(" ").append(cal.calibratedProbability).append("% • mercado live sem margem ").append(StatisticalCalibrationEngine.fmtMarket(market)).append(" • Confidence Score ").append(cal.confidenceScore).append("/100 • ").append(cal.confidenceLevel).append(" • ").append(cal.status).append(".\n");
        }
        double projectedFinal=g.homeGoals+g.awayGoals+lh+la;b.append("Total final central projetado: ").append(fmt(projectedFinal)).append(" gols. ");
        appendLiveMarket(b,d);
        b.append("O modelo AO VIVO considera placar e tempo restante e fica separado do gerador de bilhete pré-jogo. Linhas live só entram quando o endpoint in-play retornou odds atuais.");
        return b.toString();
    }

    static StatisticalCalibrationEngine.Outcome3 conditionalOutcome(int hg,int ag,double lh,double la){
        int max=10;double[] h=StatisticalCalibrationEngine.poissonMass(lh,max),a=StatisticalCalibrationEngine.poissonMass(la,max);double ph=0,pd=0,pa=0,total=0;
        for(int i=0;i<=max;i++)for(int j=0;j<=max;j++){double p=h[i]*a[j];total+=p;int fh=hg+i,fa=ag+j;if(fh>fa)ph+=p;else if(fh==fa)pd+=p;else pa+=p;}
        if(total<=0)return null;return StatisticalCalibrationEngine.normalizeOutcome((int)Math.round(ph/total*10000),(int)Math.round(pd/total*10000),(int)Math.round(pa/total*10000),"Poisson condicional AO VIVO");
    }
    static void appendLiveMarket(StringBuilder b,ApiClient.DeepAnalysis d){
        if(d==null||d.marketOdds==null||d.marketOdds.isEmpty()){b.append("Linhas AO VIVO atuais: indisponíveis; nenhuma odd é inventada.\n");return;}
        double line=d.marketOdds.mainTotalLine();if(!Double.isNaN(line))b.append("Linha live principal localizada: ").append(fmt(line)).append(" gols • over sem margem ").append(StatisticalCalibrationEngine.fmtMarket(d.marketOdds.total(true,line))).append(".\n");else b.append("Odds live recebidas, mas sem uma linha principal de total validável.\n");
    }
    static String fmt(double x){return Double.isNaN(x)?"—":String.format(new Locale("pt","BR"),"%.1f",x);}
    static String safe(String s){return s==null?"":s;}
    private LiveAnalysisEngine(){}
}
