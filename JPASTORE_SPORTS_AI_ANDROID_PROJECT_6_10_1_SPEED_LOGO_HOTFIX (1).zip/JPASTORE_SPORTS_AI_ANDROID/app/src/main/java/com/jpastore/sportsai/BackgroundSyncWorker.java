package com.jpastore.sportsai;
import android.content.Context;import androidx.annotation.NonNull;import androidx.work.Worker;import androidx.work.WorkerParameters;
public class BackgroundSyncWorker extends Worker{
 public BackgroundSyncWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull public Result doWork(){try{new WebDataClient(getApplicationContext()).warm();return Result.success();}catch(Exception e){return Result.retry();}}
}
