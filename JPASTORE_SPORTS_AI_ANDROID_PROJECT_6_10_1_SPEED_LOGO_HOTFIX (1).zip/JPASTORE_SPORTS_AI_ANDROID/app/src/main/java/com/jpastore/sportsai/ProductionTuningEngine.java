package com.jpastore.sportsai;

import java.text.*;
import java.util.*;

/**
 * 6.10 production tuning layer. Android-free by design so weighting rules can be unit tested.
 * Missing context never creates fake ratings: neutral weights (1.00) are used when evidence is absent.
 */
final class ProductionTuningEngine {
    static final class WeightedTeam {
        int games=0,wins=0,draws=0,losses=0;
        double rawFor=Double.NaN,rawAgainst=Double.NaN;
        double weightedFor=Double.NaN,weightedAgainst=Double.NaN,weightedMargin=Double.NaN,weightedWinRate=Double.NaN;
        double recentFormScore=Double.NaN,effectiveSample=0,averageOpponentStrength=1.0,recencyScore=55;
        double normalizedOffense=Double.NaN,normalizedDefense=Double.NaN;
        int daysRest=-1;
    }
    static final class Context {
        WeightedTeam home=new WeightedTeam(),away=new WeightedTeam();
        double leagueAveragePoints=Double.NaN,leagueAveragePace=Double.NaN,leagueAverageEfficiency=Double.NaN;
        double expectedHomePoints=Double.NaN,expectedAwayPoints=Double.NaN,expectedTotal=Double.NaN,projectedMargin=Double.NaN;
        boolean backToBackSeries=false;
        int lastMeetingDaysAgo=-1;
        double lastMeetingWeight=1.0;
        String leagueBaselineLabel="INDISPONÍVEL";
    }
    static final class WeightedGame {
        MultiSportWebClient.GameRow row; double weight,recencyWeight,competitionWeight,opponentStrengthWeight; int ageDays;
        WeightedGame(MultiSportWebClient.GameRow r){row=r;}
    }
    static final class OpponentProfile {int games,wins,draws;}

    static Context analyze(String sport,MultiSportClient.Event e,List<MultiSportWebClient.GameRow> homeRows,List<MultiSportWebClient.GameRow> awayRows,List<MultiSportWebClient.GameRow> h2hRows){
        Context out=new Context();
        ArrayList<MultiSportWebClient.GameRow> union=new ArrayList<>();addUnique(union,homeRows);addUnique(union,awayRows);addUnique(union,h2hRows);
        Date target=parseDate(e==null?"":e.date);if(target==null)target=new Date();
        Map<String,OpponentProfile> profiles=buildOpponentProfiles(union);
        out.leagueAveragePoints=leagueBaseline(union,e==null?"":e.competition);
        if(!Double.isNaN(out.leagueAveragePoints))out.leagueBaselineLabel="MÉDIA DA LIGA "+fmt(out.leagueAveragePoints);
        out.home=weightedTeam(homeRows,e==null?"":e.home,e==null?0:e.homeId,e==null?"":e.competition,target,profiles,out.leagueAveragePoints);
        out.away=weightedTeam(awayRows,e==null?"":e.away,e==null?0:e.awayId,e==null?"":e.competition,target,profiles,out.leagueAveragePoints);
        out.home.daysRest=daysRest(homeRows,e==null?"":e.home,e==null?0:e.homeId,target);
        out.away.daysRest=daysRest(awayRows,e==null?"":e.away,e==null?0:e.awayId,target);
        MultiSportWebClient.GameRow latest=latestH2h(h2hRows);if(latest!=null){Date d=parseDate(latest.date);if(d!=null){out.lastMeetingDaysAgo=Math.max(0,daysBetween(d,target));if(out.lastMeetingDaysAgo<=2){out.backToBackSeries=true;out.lastMeetingWeight=1.20;}}}
        if(!Double.isNaN(out.home.weightedFor)&&!Double.isNaN(out.away.weightedFor)){
            double base=Double.isNaN(out.leagueAveragePoints)?mean(out.home.weightedFor,out.away.weightedFor,out.home.weightedAgainst,out.away.weightedAgainst):out.leagueAveragePoints;
            out.expectedHomePoints=robustExpected(out.home.weightedFor,out.away.weightedAgainst,base)*1.015;
            out.expectedAwayPoints=robustExpected(out.away.weightedFor,out.home.weightedAgainst,base)*.985;
            double restDelta=restModifier(out.home.daysRest)-restModifier(out.away.daysRest);
            out.expectedHomePoints+=restDelta;out.expectedAwayPoints-=restDelta;
            if(out.backToBackSeries&&latest!=null&&latest.hs>=0&&latest.as>=0){boolean homeWasHome=e!=null&&sameTeam(e.home,latest.home);double prevHome=homeWasHome?latest.hs:latest.as,prevAway=homeWasHome?latest.as:latest.hs;out.expectedHomePoints=out.expectedHomePoints*.90+prevHome*.10;out.expectedAwayPoints=out.expectedAwayPoints*.90+prevAway*.10;}
            out.expectedTotal=out.expectedHomePoints+out.expectedAwayPoints;out.projectedMargin=out.expectedHomePoints-out.expectedAwayPoints;
        }
        return out;
    }

    static WeightedTeam weightedTeam(List<MultiSportWebClient.GameRow> rows,String team,long id,String currentCompetition,Date target,Map<String,OpponentProfile> profiles,double leagueAverage){
        WeightedTeam out=new WeightedTeam();if(rows==null||rows.isEmpty())return out;
        ArrayList<MultiSportWebClient.GameRow> valid=new ArrayList<>();for(MultiSportWebClient.GameRow g:rows)if(g!=null&&g.completed&&g.hs>=0&&g.as>=0&&involves(g,team,id))valid.add(g);
        Collections.sort(valid,(a,b)->safe(b.date).compareTo(safe(a.date)));if(valid.size()>15)valid=new ArrayList<>(valid.subList(0,15));
        if(valid.isEmpty())return out;
        ArrayList<Double> rawPf=new ArrayList<>(),rawPa=new ArrayList<>();for(MultiSportWebClient.GameRow g:valid){boolean home=homeSide(g,team,id);rawPf.add((double)(home?g.hs:g.as));rawPa.add((double)(home?g.as:g.hs));}
        out.rawFor=mean(rawPf);out.rawAgainst=mean(rawPa);double pfLo=robustLow(rawPf),pfHi=robustHigh(rawPf),paLo=robustLow(rawPa),paHi=robustHigh(rawPa);
        double wf=0,wa=0,ww=0,wWin=0,wOpp=0,wRec=0;int i=0;
        for(MultiSportWebClient.GameRow g:valid){boolean home=homeSide(g,team,id);int pf=home?g.hs:g.as,pa=home?g.as:g.hs;String opponent=home?g.away:g.home;int age=ageDays(g.date,target,i);double rw=recencyWeight(age),cw=competitionWeight(g.competition,currentCompetition,age),ow=opponentStrengthWeight(profiles,opponent);double source=sourceWeight(g);double w=rw*cw*ow*source;if(w<=0)continue;
            double cpf=clamp(pf,pfLo,pfHi),cpa=clamp(pa,paLo,paHi);wf+=cpf*w;wa+=cpa*w;ww+=w;wOpp+=ow*w;wRec+=rw*w;if(pf>pa){out.wins++;wWin+=w;}else if(pf==pa){out.draws++;wWin+=.5*w;}else out.losses++;out.games++;i++;}
        if(ww>0){out.weightedFor=wf/ww;out.weightedAgainst=wa/ww;out.weightedMargin=out.weightedFor-out.weightedAgainst;out.weightedWinRate=wWin/ww;out.recentFormScore=out.weightedWinRate*100.0;out.effectiveSample=ww;out.averageOpponentStrength=wOpp/ww;out.recencyScore=100.0*wRec/ww;}
        if(!Double.isNaN(leagueAverage)&&leagueAverage>0&&!Double.isNaN(out.weightedFor)){out.normalizedOffense=out.weightedFor/leagueAverage;out.normalizedDefense=leagueAverage/Math.max(1,out.weightedAgainst);}
        return out;
    }

    static double competitionWeight(String competition,String current,int ageDays){String c=norm(competition),cur=norm(current);if(has(c,"preseason","pre-season","pre season","summer league","pretemporada","pré-temporada","pre-temporada","preparator"))return .60;if(has(c,"friendly","amistoso","exhibition"))return .45;if(has(c,"cup","copa","taca","taça","playoff","champions","euroleague"))return .90;if(!c.isEmpty()&&!cur.isEmpty()&&(c.equals(cur)||c.contains(cur)||cur.contains(c))){if(ageDays>120)return .50;return 1.00;}if(ageDays>120)return .50;return .75;}
    static double recencyWeight(int days){if(days<=7)return 1.00;if(days<=30)return .90;if(days<=60)return .75;if(days<=120)return .55;return .35;}
    static double h2hWeight(int days){if(days<0)return .25;if(days<30)return 1.00;if(days<=90)return .70;if(days<=365)return .40;return .20;}
    static double opponentStrengthWeight(Map<String,OpponentProfile> profiles,String opponent){OpponentProfile p=profiles.get(canonical(opponent));if(p==null||p.games<3)return 1.00;double wr=(p.wins+.5*p.draws)/(double)p.games;if(wr>=.70)return 1.10;if(wr>=.58)return 1.05;if(wr<=.30)return .90;if(wr<=.42)return .95;return 1.00;}
    static double sourceWeight(MultiSportWebClient.GameRow g){if(g==null||g.sources.isEmpty())return .82;double q=0;for(String s:g.sources)q+=StatisticalCalibrationEngine.sourceWeight(s)/100.0;q/=g.sources.size();double confirm=1.0+Math.min(.12,Math.max(0,g.sources.size()-1)*.04);double conflict=g.sourceConflict?.60:1.0;return (.72+.28*q)*confirm*conflict;}

    static Map<String,OpponentProfile> buildOpponentProfiles(List<MultiSportWebClient.GameRow> rows){HashMap<String,OpponentProfile> m=new HashMap<>();if(rows==null)return m;for(MultiSportWebClient.GameRow g:rows){if(g==null||!g.completed||g.hs<0||g.as<0)continue;OpponentProfile h=m.computeIfAbsent(canonical(g.home),k->new OpponentProfile()),a=m.computeIfAbsent(canonical(g.away),k->new OpponentProfile());h.games++;a.games++;if(g.hs>g.as)h.wins++;else if(g.as>g.hs)a.wins++;else{h.draws++;a.draws++;}}return m;}
    static double leagueBaseline(List<MultiSportWebClient.GameRow> rows,String current){ArrayList<Double> exact=new ArrayList<>(),all=new ArrayList<>();String cur=norm(current);if(rows!=null)for(MultiSportWebClient.GameRow g:rows){if(g==null||!g.completed||g.hs<0||g.as<0)continue;double v=(g.hs+g.as)/2.0;all.add(v);String gc=norm(g.competition);if(!cur.isEmpty()&&!gc.isEmpty()&&(gc.contains(cur)||cur.contains(gc)))exact.add(v);}ArrayList<Double> use=exact.size()>=3?exact:all;if(use.size()<3)return Double.NaN;return winsorMean(use);}
    static int daysRest(List<MultiSportWebClient.GameRow> rows,String team,long id,Date target){Date latest=null;if(rows!=null)for(MultiSportWebClient.GameRow g:rows){if(g==null||!g.completed||!involves(g,team,id))continue;Date d=parseDate(g.date);if(d!=null&&d.before(target)&&(latest==null||d.after(latest)))latest=d;}return latest==null?-1:Math.max(0,daysBetween(latest,target));}
    static double restModifier(int days){if(days<0)return 0;if(days==0)return -1.0;if(days==1)return -.35;if(days<=3)return 0;if(days>=4)return .35;return 0;}
    static MultiSportWebClient.GameRow latestH2h(List<MultiSportWebClient.GameRow> rows){MultiSportWebClient.GameRow best=null;if(rows!=null)for(MultiSportWebClient.GameRow g:rows)if(g!=null&&g.completed&&(best==null||safe(g.date).compareTo(safe(best.date))>0))best=g;return best;}
    static double robustExpected(double offense,double oppDefense,double base){double sum=0,w=0;if(pos(offense)){sum+=offense*.45;w+=.45;}if(pos(oppDefense)){sum+=oppDefense*.35;w+=.35;}if(pos(base)){sum+=base*.20;w+=.20;}return w<=0?Double.NaN:sum/w;}

    static int ageDays(String date,Date target,int fallbackIndex){Date d=parseDate(date);return d==null?Math.min(365,fallbackIndex*14):Math.max(0,daysBetween(d,target));}
    static Date parseDate(String s){if(s==null||s.length()<8)return null;for(String p:new String[]{"yyyy-MM-dd","dd/MM/yyyy","MM/dd/yyyy"})try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setLenient(false);return f.parse(s.substring(0,Math.min(s.length(),10)));}catch(Exception ignored){}return null;}
    static int daysBetween(Date a,Date b){return (int)Math.floor(Math.abs(b.getTime()-a.getTime())/86400000.0);}
    static boolean involves(MultiSportWebClient.GameRow g,String team,long id){if(g==null)return false;if(id>0&&(g.homeId==id||g.awayId==id))return true;return g.involves(team);}
    static boolean homeSide(MultiSportWebClient.GameRow g,String team,long id){if(id>0&&(g.homeId==id||g.awayId==id))return g.homeId==id;return g.homeSide(team);}
    static boolean sameTeam(String a,String b){String x=canonical(a),y=canonical(b);return !x.isEmpty()&&(x.equals(y)||x.contains(y)||y.contains(x));}
    static String canonical(String s){return TeamIdentityResolver.norm(s);}
    static String norm(String s){return safe(s).toLowerCase(Locale.ROOT);}
    static boolean has(String s,String... xs){for(String x:xs)if(s.contains(x))return true;return false;}
    static void addUnique(ArrayList<MultiSportWebClient.GameRow> out,List<MultiSportWebClient.GameRow> rows){if(rows==null)return;for(MultiSportWebClient.GameRow g:rows)MultiSportWebClient.addUniqueGame(out,g);}
    static double winsorMean(Collection<Double> xs){if(xs==null||xs.isEmpty())return Double.NaN;ArrayList<Double> a=new ArrayList<>(xs);double lo=robustLow(a),hi=robustHigh(a),s=0;int n=0;for(Double v:a)if(v!=null&&!Double.isNaN(v)){s+=clamp(v,lo,hi);n++;}return n==0?Double.NaN:s/n;}
    static double robustLow(Collection<Double> xs){double med=median(xs),mad=mad(xs,med);if(Double.isNaN(med))return -Double.MAX_VALUE;double band=mad>0?3.5*1.4826*mad:Math.max(1,2.2*std(xs));return med-band;}
    static double robustHigh(Collection<Double> xs){double med=median(xs),mad=mad(xs,med);if(Double.isNaN(med))return Double.MAX_VALUE;double band=mad>0?3.5*1.4826*mad:Math.max(1,2.2*std(xs));return med+band;}
    static double mad(Collection<Double> xs,double med){if(Double.isNaN(med)||xs==null)return Double.NaN;ArrayList<Double> d=new ArrayList<>();for(Double v:xs)if(v!=null&&!Double.isNaN(v))d.add(Math.abs(v-med));return median(d);}
    static double median(Collection<Double> xs){if(xs==null||xs.isEmpty())return Double.NaN;ArrayList<Double> a=new ArrayList<>();for(Double v:xs)if(v!=null&&!Double.isNaN(v))a.add(v);if(a.isEmpty())return Double.NaN;Collections.sort(a);int n=a.size();return n%2==1?a.get(n/2):(a.get(n/2-1)+a.get(n/2))/2.0;}
    static double mean(Collection<Double> xs){if(xs==null||xs.isEmpty())return Double.NaN;double s=0;int n=0;for(Double v:xs)if(v!=null&&!Double.isNaN(v)){s+=v;n++;}return n==0?Double.NaN:s/n;}
    static double mean(double... xs){double s=0;int n=0;for(double x:xs)if(!Double.isNaN(x)){s+=x;n++;}return n==0?Double.NaN:s/n;}
    static double std(Collection<Double> xs){double m=mean(xs);if(Double.isNaN(m))return 0;double s=0;int n=0;for(Double v:xs)if(v!=null&&!Double.isNaN(v)){double d=v-m;s+=d*d;n++;}return n<=1?0:Math.sqrt(s/(n-1));}
    static double clamp(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
    static boolean pos(double x){return !Double.isNaN(x)&&x>0;}
    static String safe(String s){return s==null?"":s.trim();}
    static String fmt(double x){return Double.isNaN(x)?"—":String.format(Locale.US,"%.1f",x);}
    private ProductionTuningEngine(){}
}
