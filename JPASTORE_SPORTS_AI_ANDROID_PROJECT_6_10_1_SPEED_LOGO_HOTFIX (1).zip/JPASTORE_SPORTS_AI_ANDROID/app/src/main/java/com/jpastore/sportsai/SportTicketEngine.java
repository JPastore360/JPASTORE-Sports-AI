package com.jpastore.sportsai;

import java.util.*;

/**
 * Calibrated ticket engine for non-football sports.
 * Coverage, estimated probability, model confidence and risk are intentionally separate.
 */
class SportTicketEngine {
    static final String CONSERVADOR="CONSERVADOR", EQUILIBRADO="EQUILIBRADO", AGRESSIVO="AGRESSIVO";

    static class Pick {
        String market="",pick="",detail="",risk="",status="",confidenceLevel="",sourceQuality="";
        int rawProbability=0,confidence=0,sample=0,coverage=0,confidenceScore=0,sourceCount=0;
        double marketProbability=Double.NaN;
        Pick(String market,String pick,StatisticalCalibrationEngine.Calibration c,String detail){
            this.market=market;this.pick=pick;this.detail=detail==null?"":detail;
            if(c!=null){rawProbability=c.rawProbability;confidence=c.calibratedProbability;sample=c.sampleSize;coverage=c.coverage;confidenceScore=c.confidenceScore;sourceCount=c.sourceCount;marketProbability=c.marketProbability;risk=c.risk;status=c.status;confidenceLevel=c.confidenceLevel;sourceQuality=StatisticalCalibrationEngine.sourceQualityLabel(c.sourceQuality);}
        }
    }
    static class Result {
        ArrayList<Pick> picks=new ArrayList<>();
        int sample=0,coverage=0,sourceCount=0,sourceQuality=0,agreement=0,confirmed=0,conflicts=0,confidenceScore=0;
        String quality="COBERTURA LIMITADA",note="",consensus="";
        boolean ready(){return !picks.isEmpty();}
    }

    static Result build(String sport, MultiSportClient.Event e, MultiSportWebClient.Research r, String mode){
        Result out=new Result();
        if(e==null){out.note="Selecione um confronto.";return out;}
        if(!StatisticalCalibrationEngine.isPregameStatus(e.status)){out.note="Evento fora do pré-jogo ("+safe(e.status)+"). Partidas LIVE, encerradas, canceladas ou adiadas não entram automaticamente no bilhete pré-jogo.";return out;}
        SportConsensusEngine.Consensus cc=SportConsensusEngine.analyze(sport,e,r);
        applyConsensus(out,cc);
        if(r==null||(!r.hasStructured()&&!cc.usable())){
            out.note="DADOS INSUFICIENTES — o motor não encontrou histórico estruturado suficiente. Cache/fallback podem manter a consulta, mas a confiança permanece reduzida.";
            return out;
        }
        int hs=r.homeWins+r.homeDraws+r.homeLosses, as=r.awayWins+r.awayDraws+r.awayLosses;
        out.sample=Math.max(Math.min(hs,as),cc.minGames());
        int baseCoverage=coverage(hs,as,r.homeSample,r.awaySample);
        out.coverage=Math.max(baseCoverage,cc.coverage);
        out.quality=coverageLabel(out.coverage);

        if(MultiSportClient.F1.equals(sport)){
            out.note="Fórmula 1 exige dados por piloto (treinos, classificação e grid). O app não inventa vencedor/pódio sem esses dados.";
            return out;
        }

        int min=minSample(mode);
        int usableHome=Math.max(hs,cc.homeGames), usableAway=Math.max(as,cc.awayGames);
        double varianceRatio=varianceRatio(cc.totalMean,cc.totalStd);
        boolean importantConflict=cc.conflictGames>=2 || (cc.sourceCount==1&&cc.sourceQuality<65);

        MarketOddsBook odds=r.marketOdds==null?new MarketOddsBook():r.marketOdds;

        // Winner/moneyline. Real bookmaker odds are used only as calibration evidence when available.
        if(usableHome>=min&&usableAway>=min&&!safe(e.home).isEmpty()&&!safe(e.away).isEmpty()){
            double h=consensusStrength(cc,true,r),a=consensusStrength(cc,false,r);
            boolean homeLead=h>=a;String lead=homeLead?e.home:e.away;
            int raw=winnerRawProbability(sport,h,a);
            double market=odds.probability(homeLead?MarketOddsBook.HOME:MarketOddsBook.AWAY);
            StatisticalCalibrationEngine.Calibration cal=StatisticalCalibrationEngine.calibrate(raw,out.coverage,out.sample,cc.sourceCount,cc.sourceQuality,cc.agreement,(int)Math.round(cc.recencyScore),market,varianceRatio,importantConflict);
            boolean conservativeWinnerOk=!CONSERVADOR.equals(mode)||(cal.calibratedProbability>=64&&cal.confidenceScore>=60&&!"REVISÃO NECESSÁRIA".equals(cal.status));
            if(cal.calibratedProbability>=winnerThreshold(mode)&&conservativeWinnerOk){
                String src=cc.sourceCount>=2?"consenso entre fontes":"fonte única";
                String detail="Forma + margem + "+src+" • bruta "+cal.rawProbability+"% • calibrada "+cal.calibratedProbability+"% • mercado sem margem "+StatisticalCalibrationEngine.fmtMarket(market)+" • Confidence Score "+cal.confidenceScore+"/100 • "+cal.marketDivergence+" • "+cal.reason;
                out.picks.add(new Pick(winnerMarket(sport),lead,cal,detail));
            }
        }

        // Positive handicap is conservative only when that real line exists in bookmaker data.
        if(CONSERVADOR.equals(mode)&&(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NFL.equals(sport))&&usableHome>=min&&usableAway>=min&&!Double.isNaN(cc.marginStd)&&cc.marginStd>0){
            addPositiveHandicaps(out,sport,e,r,cc,odds,importantConflict);
        }

        // Totals use weighted mean/dispersion. If real lines exist, choose one of them; never fabricate market odds.
        if((MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NFL.equals(sport)||MultiSportClient.BASEBALL.equals(sport))&&usableHome>=min&&usableAway>=min){
            double avg=MultiSportClient.BASKETBALL.equals(sport)&&!Double.isNaN(cc.expectedTotal)&&cc.expectedTotal>0?cc.expectedTotal:(!Double.isNaN(cc.totalMean)&&cc.totalMean>0?cc.totalMean:legacyTotal(r));
            if(avg>0){
                double std=(!Double.isNaN(cc.totalStd)&&cc.totalStd>0)?cc.totalStd:defaultStd(sport,avg);
                double target=referenceLine(sport,avg,mode),line=selectAvailableTotalLine(odds,target);
                if(Double.isNaN(line))line=target;
                int raw=totalOverProbability(sport,avg,std,line);double market=odds.total(true,line);
                StatisticalCalibrationEngine.Calibration cal=StatisticalCalibrationEngine.calibrate(raw,out.coverage,out.sample,cc.sourceCount,cc.sourceQuality,cc.agreement,(int)Math.round(cc.recencyScore),market,Math.abs(std/Math.max(1.0,avg)),importantConflict);
                if(cal.calibratedProbability>=totalThreshold(mode)){
                    String unit=MultiSportClient.BASEBALL.equals(sport)?"corridas":"pontos";
                    String lineOrigin=MarketOddsBook.valid(market)?"linha real disponível":"linha estatística (mercado indisponível)";
                    String detail=lineOrigin+" "+fmtHalf(line)+" • projeção "+fmt(avg)+" • esperados "+fmt(cc.expectedHomePoints)+" × "+fmt(cc.expectedAwayPoints)+" • mediana "+fmt(cc.totalMedian)+" • dispersão "+fmt(std)+" • bruta "+raw+"% • calibrada "+cal.calibratedProbability+"% • mercado sem margem "+StatisticalCalibrationEngine.fmtMarket(market)+" • Confidence Score "+cal.confidenceScore+"/100 • "+cal.reason;
                    out.picks.add(new Pick("Total da partida","Mais de "+fmtHalf(line)+" "+unit,cal,detail));
                }
            }
        }

        if(MultiSportClient.MMA.equals(sport)&&out.picks.size()>1)while(out.picks.size()>1)out.picks.remove(out.picks.size()-1);
        Collections.sort(out.picks,(x,y)->{
            int sx=safetyRank(x.status),sy=safetyRank(y.status);if(sx!=sy)return Integer.compare(sx,sy);
            int px=marketPriority(sport,mode,x.market),py=marketPriority(sport,mode,y.market);if(px!=py)return Integer.compare(px,py);
            int c=Integer.compare(y.confidenceScore,x.confidenceScore);if(c!=0)return c;return Integer.compare(y.confidence,x.confidence);
        });
        int max=CONSERVADOR.equals(mode)?1:(EQUILIBRADO.equals(mode)?2:3);
        while(out.picks.size()>max)out.picks.remove(out.picks.size()-1);
        if(!out.picks.isEmpty()){int s=0;for(Pick p:out.picks)s+=p.confidenceScore;out.confidenceScore=Math.round(s/(float)out.picks.size());}

        if(out.picks.isEmpty())out.note="A base foi analisada, mas nenhuma seleção ultrapassou os limiares calibrados do modo "+mode+". O app prefere informar dados insuficientes a forçar uma escolha.";
        else if(out.coverage<20)out.note="DADOS LIMITADOS — BAIXA CONFIABILIDADE. As probabilidades continuam visíveis, porém perdem peso e não podem receber RISCO MENOR/FAVORÁVEL.";
        else out.note=(cc.sourceCount<=1?"FONTE ÚNICA • CONFIANÇA LIMITADA":(cc.sourceCount==2?"CONSENSO MODERADO":"CONSENSO FORTE"))+" • convergência "+cc.agreement+"%. Probabilidade não é Confidence Score e não é garantia de resultado.";
        audit(e,sport,r,cc,out);
        return out;
    }

    static Result buildForMulti(String sport, MultiSportClient.Event e, MultiSportWebClient.Research r, String mode){
        Result out=build(sport,e,r,mode);
        if(out.ready()||e==null||r==null||!StatisticalCalibrationEngine.isPregameStatus(e.status)||MultiSportClient.F1.equals(sport))return out;
        // Relax only the minimum sample for a multi-ticket; never relax safety labels or probability caps.
        SportConsensusEngine.Consensus cc=SportConsensusEngine.analyze(sport,e,r);applyConsensus(out,cc);
        if(!cc.usable())return out;
        int sample=cc.minGames();int coverage=Math.max(out.coverage,cc.coverage);double h=consensusStrength(cc,true,r),a=consensusStrength(cc,false,r);
        int raw=winnerRawProbability(sport,h,a);
        boolean homeLead=h>=a;double market=r.marketOdds==null?Double.NaN:r.marketOdds.probability(homeLead?MarketOddsBook.HOME:MarketOddsBook.AWAY);
        StatisticalCalibrationEngine.Calibration cal=StatisticalCalibrationEngine.calibrate(raw,coverage,sample,cc.sourceCount,cc.sourceQuality,cc.agreement,(int)Math.round(cc.recencyScore),market,varianceRatio(cc.totalMean,cc.totalStd),true);
        if(sample>=2&&cal.calibratedProbability>=52){
            String lead=homeLead?e.home:e.away;
            out.sample=sample;out.coverage=coverage;out.quality=coverageLabel(coverage);out.confidenceScore=cal.confidenceScore;
            out.picks.add(new Pick(winnerMarket(sport),lead,cal,"Seleção exploratória calibrada • não recebeu relaxamento de segurança • "+cal.reason));
            out.note="Referência exploratória. Como a amostra é reduzida, a seleção permanece ATENÇÃO/REVISÃO NECESSÁRIA conforme o Confidence Score.";
        }
        return out;
    }

    static void audit(MultiSportClient.Event e,String sport,MultiSportWebClient.Research r,SportConsensusEngine.Consensus c,Result out){
        try{Pick p=out!=null&&!out.picks.isEmpty()?out.picks.get(0):null;int rawFound=r==null?0:r.mergedHome.size()+r.mergedAway.size()+r.mergedH2h.size();System.out.println("[JP_AI_ANALYSIS] matchId="+(e==null?0:e.id)+" sport="+safe(sport)+" league="+(e==null?"":safe(e.competition))+" home="+(e==null?"":safe(e.home))+" away="+(e==null?"":safe(e.away))+" rawGamesFound="+rawFound+" uniqueGames="+c.uniqueGames+" weightedGames="+fmt(Math.min(c.homeEffectiveSample,c.awayEffectiveSample))+" homeRawAverage="+fmt(c.homeRawFor)+" homeWeightedAverage="+fmt(c.homeFor)+" awayRawAverage="+fmt(c.awayRawFor)+" awayWeightedAverage="+fmt(c.awayFor)+" homeFormScore="+fmt(c.homeFormScore)+" awayFormScore="+fmt(c.awayFormScore)+" leagueBaseline="+fmt(c.leagueAveragePoints)+" homeOpponentStrength="+fmt(c.homeOpponentStrength)+" awayOpponentStrength="+fmt(c.awayOpponentStrength)+" daysRestHome="+c.daysRestHome+" daysRestAway="+c.daysRestAway+" backToBack="+c.backToBack+" lastMeetingDaysAgo="+c.lastMeetingDaysAgo+" sourceCount="+c.sourceCount+" sourceConvergence="+c.agreement+" coverage="+(out==null?0:out.coverage)+" rawProbability="+(p==null?0:p.rawProbability)+" calibratedProbability="+(p==null?0:p.confidence)+" marketProbability="+(p==null?"—":StatisticalCalibrationEngine.fmtMarket(p.marketProbability))+" confidenceScore="+(p==null?0:p.confidenceScore)+" risk="+(p==null?"SEM SELEÇÃO":p.risk)+" selectedMarket="+(p==null?"SEM SELEÇÃO":p.market+" / "+p.pick)+" projectedTotal="+fmt(c.expectedTotal)+" projectedMargin="+fmt(c.projectedMargin));}catch(Exception ignored){}
    }

    static void applyConsensus(Result out,SportConsensusEngine.Consensus c){if(out==null||c==null)return;out.sourceCount=c.sourceCount;out.sourceQuality=c.sourceQuality;out.agreement=c.agreement;out.confirmed=c.confirmedGames;out.conflicts=c.conflictGames;out.consensus=c.note;}
    static double consensusStrength(SportConsensusEngine.Consensus c,boolean home,MultiSportWebClient.Research r){
        double wr=home?c.homeWinRate:c.awayWinRate,margin=home?c.homeMargin:c.awayMargin;
        if(!Double.isNaN(wr)&&!Double.isNaN(margin)){double off=home?c.homeNormalizedOffense:c.awayNormalizedOffense,def=home?c.homeNormalizedDefense:c.awayNormalizedDefense;double norm=.5;if(!Double.isNaN(off)&&!Double.isNaN(def))norm=clamp((off+def)/2.0,.75,1.25)-.75;else norm=.5;double rest=home?c.daysRestHome:c.daysRestAway;double restScore=rest<0?.5:(rest==0?.40:(rest==1?.47:(rest>=4?.54:.50)));double h2h=home?c.h2hHomeEdge:(1.0-c.h2hHomeEdge);return wr*.58+normalizedMargin(margin,r)*.17+norm*.14+restScore*.05+h2h*.06;}
        if(r==null)return 0;return home?strength(r.homeWins,r.homeDraws,r.homeLosses,r.homeFor,r.homeAgainst,r.homeSample):strength(r.awayWins,r.awayDraws,r.awayLosses,r.awayFor,r.awayAgainst,r.awaySample);
    }
    static double normalizedMargin(double margin,MultiSportWebClient.Research r){double scale=20;return clamp(margin,-scale,scale)/(scale*2.0)+.5;}
    static double legacyTotal(MultiSportWebClient.Research r){if(r==null||r.homeSample<=0||r.awaySample<=0)return Double.NaN;double ht=(r.homeFor+r.homeAgainst)/Math.max(1,r.homeSample),at=(r.awayFor+r.awayAgainst)/Math.max(1,r.awaySample);return (ht+at)/2.0;}
    static double strength(int w,int d,int l,double pf,double pa,int sample){int n=Math.max(1,w+d+l);double win=w/(double)n,draw=d/(double)n;double margin=sample>0?(pf-pa)/sample:0;return win*.78+draw*.12+(clamp(margin,-20,20)/40.0+.5)*.10;}

    static int winnerRawProbability(String sport,double h,double a){double gap=Math.abs(h-a);double scale=MultiSportClient.BASKETBALL.equals(sport)?78:(MultiSportClient.BASEBALL.equals(sport)?68:72);return clamp((int)Math.round(50+Math.min(.50,gap)*scale),51,89);}
    static int totalOverProbability(String sport,double mean,double std,double line){double p;if(MultiSportClient.BASEBALL.equals(sport))p=ApiClient.poissonOver(mean,line);else p=StatisticalCalibrationEngine.normalOver(mean,std,line);return clamp((int)Math.round(p),1,99);}
    static double defaultStd(String sport,double mean){if(MultiSportClient.BASKETBALL.equals(sport))return Math.max(10,mean*.06);if(MultiSportClient.NFL.equals(sport))return Math.max(8,mean*.17);if(MultiSportClient.BASEBALL.equals(sport))return Math.max(2.8,Math.sqrt(Math.max(1,mean)));return Math.max(1,mean*.15);}
    static double varianceRatio(double mean,double std){return (!Double.isNaN(mean)&&mean>0&&!Double.isNaN(std)&&std>=0)?std/mean:Double.NaN;}
    static int minSample(String mode){return CONSERVADOR.equals(mode)?5:(EQUILIBRADO.equals(mode)?4:3);}
    static int winnerThreshold(String mode){return CONSERVADOR.equals(mode)?61:(EQUILIBRADO.equals(mode)?58:55);}
    static int totalThreshold(String mode){return CONSERVADOR.equals(mode)?60:(EQUILIBRADO.equals(mode)?57:54);}
    static double referenceLine(String sport,double avg,String mode){double offset;if(MultiSportClient.BASEBALL.equals(sport))offset=CONSERVADOR.equals(mode)?1.0:(EQUILIBRADO.equals(mode)?.5:0);else if(MultiSportClient.NFL.equals(sport))offset=CONSERVADOR.equals(mode)?3.5:(EQUILIBRADO.equals(mode)?1.5:.5);else offset=CONSERVADOR.equals(mode)?4.5:(EQUILIBRADO.equals(mode)?2.5:.5);return Math.max(.5,roundHalf(avg-offset));}
    static String winnerMarket(String sport){if(MultiSportClient.NFL.equals(sport))return "Moneyline";if(MultiSportClient.MMA.equals(sport))return "Vencedor da luta";return "Vencedor da partida";}
    static int safetyRank(String status){if("FAVORÁVEL".equals(status))return 0;if("ATENÇÃO".equals(status))return 1;return 2;}
    static int marketPriority(String sport,String mode,String market){
        if(CONSERVADOR.equals(mode)&&(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NFL.equals(sport))){if("Handicap positivo".equals(market))return 0;if("Total da partida".equals(market))return 1;if("Moneyline".equals(market)||"Vencedor da partida".equals(market))return 2;}return 1;
    }
    static double selectAvailableTotalLine(MarketOddsBook odds,double target){
        if(odds==null||odds.isEmpty())return Double.NaN;double best=Double.NaN,dist=Double.POSITIVE_INFINITY;
        for(double line:odds.totalLines()){double d=Math.abs(line-target);if(d<dist){dist=d;best=line;}}return best;
    }
    static void addPositiveHandicaps(Result out,String sport,MultiSportClient.Event e,MultiSportWebClient.Research r,SportConsensusEngine.Consensus cc,MarketOddsBook odds,boolean importantConflict){
        if(odds==null||odds.isEmpty()||Double.isNaN(cc.homeMargin)||Double.isNaN(cc.awayMargin))return;
        double expectedHomeMargin=!Double.isNaN(cc.projectedMargin)?cc.projectedMargin:(cc.homeMargin-cc.awayMargin)/2.0,std=cc.marginStd;if(Double.isNaN(std)||std<=0)return;
        ArrayList<Pick> candidates=new ArrayList<>();
        for(boolean homeSide:new boolean[]{true,false})for(MarketOddsBook.HandicapQuote q:odds.positiveHandicaps(homeSide)){
            double max=MultiSportClient.BASKETBALL.equals(sport)?8.5:7.5;if(q.line<=0||q.line>max||Math.abs(q.line-Math.rint(q.line))<.01)continue;
            int raw=StatisticalCalibrationEngine.normalHandicapProbability(expectedHomeMargin,std,homeSide,q.line);if(raw<=0)continue;
            StatisticalCalibrationEngine.Calibration cal=StatisticalCalibrationEngine.calibrate(raw,out.coverage,out.sample,cc.sourceCount,cc.sourceQuality,cc.agreement,(int)Math.round(cc.recencyScore),q.probability,Math.abs(std/Math.max(1.0,Math.abs(expectedHomeMargin)+std)),importantConflict);
            if(cal.calibratedProbability<60)continue;String team=homeSide?e.home:e.away;
            String detail="Linha real • margem esperada mandante "+fmt(expectedHomeMargin)+" • dispersão de margem "+fmt(std)+" • bruta "+raw+"% • calibrada "+cal.calibratedProbability+"% • mercado sem margem "+StatisticalCalibrationEngine.fmtMarket(q.probability)+" • "+q.bookmakerCount+" casa(s) • "+cal.reason;
            candidates.add(new Pick("Handicap positivo",team+" +"+fmtHalf(q.line),cal,detail));
        }
        Collections.sort(candidates,(a,b)->{int s=Integer.compare(safetyRank(a.status),safetyRank(b.status));if(s!=0)return s;int c=Integer.compare(b.confidenceScore,a.confidenceScore);return c!=0?c:Integer.compare(b.confidence,a.confidence);});
        if(!candidates.isEmpty())out.picks.add(candidates.get(0));
    }
    static int coverage(int hs,int as,int hp,int ap){int n=Math.min(hs,as),p=Math.min(hp,ap);if(n<=0)return 4;if(n==1)return 10;if(n==2)return 18;if(n==3)return 32;if(n<=5)return 48;if(n<=7)return 64;if(n<=10)return 76;return Math.min(92,80+Math.min(12,p));}
    static String coverageLabel(int c){if(c>=85)return "COBERTURA FORTE";if(c>=50)return "COBERTURA MODERADA";if(c<20)return "DADOS LIMITADOS";return "COBERTURA LIMITADA";}
    static String fmt(double x){return Double.isNaN(x)?"—":String.format(new Locale("pt","BR"),"%.1f",x);}
    static String fmtHalf(double x){return String.format(new Locale("pt","BR"),"%.1f",roundHalf(x));}
    static double roundHalf(double x){return Math.round(x*2.0)/2.0;}
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    static int clamp(int v,int a,int b){return Math.max(a,Math.min(b,v));}
    static String safe(String s){return s==null?"":s.trim();}
}
