package com.jpastore.sportsai;

/** Progress reported by the Internet-first research pipeline. */
interface ResearchProgress {
    void onProgress(int percent, String stage);
}
