package com.jpastore.sportsai;

import java.util.*;

/** Android-free presentation safeguards used by the sports UI and unit tests. */
final class SportPresentationRules {
    static String clean(String s){if(s==null)return "";String x=s.trim();return "null".equalsIgnoreCase(x)||"undefined".equalsIgnoreCase(x)?"":x;}
    static String initials(String team){String raw=clean(team);if(raw.isEmpty())return "•";String clean=raw.replaceAll("(?iu)\\b(fc|cf|sc|ac|ec|afc|club|clube|de|do|da|the)\\b"," ").replaceAll("[^\\p{L}0-9 ]"," ").trim().replaceAll("\\s+"," ");if(clean.isEmpty())clean=raw;String[] z=clean.split(" ");StringBuilder b=new StringBuilder();for(String q:z)if(!q.isEmpty()){b.append(q.substring(0,1).toUpperCase(new Locale("pt","BR")));if(b.length()>=3)break;}if(b.length()==1&&clean.length()>1)b.append(clean.substring(1,2).toUpperCase(new Locale("pt","BR")));return b.length()==0?"•":b.toString();}
    static String statusText(String rawStatus,String score,String period,String clock){String st=EventStandards.normalizeStatus(rawStatus),sc=clean(score);if(EventStandards.FINISHED.equals(st))return sc.isEmpty()?"ENCERRADO":sc;if(EventStandards.LIVE.equals(st)||EventStandards.HALFTIME.equals(st))return (sc.isEmpty()?"AO VIVO":sc)+(clean(period).isEmpty()?"":" • "+clean(period))+(clean(clock).isEmpty()?"":" • "+clean(clock));if(EventStandards.POSTPONED.equals(st))return "ADIADO";if(EventStandards.CANCELLED.equals(st))return "CANCELADO";return "PROGRAMADO";}
    private SportPresentationRules(){}
}
