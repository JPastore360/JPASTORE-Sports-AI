package com.jpastore.sportsai;

import java.util.*;

/**
 * Central statistical calibration layer. Probability is kept separate from data coverage,
 * model confidence and ticket risk. This class is intentionally Android-free so the core
 * rules can be unit-tested with plain Java.
 */
final class StatisticalCalibrationEngine {
    static final double NO_MARKET = Double.NaN;

    static final class Calibration {
        int rawProbability;
        int calibratedProbability;
        int coverage;
        int sampleSize;
        int sourceCount;
        int sourceQuality;
        int confidenceScore;
        int recencyScore=55;
        double marketProbability = Double.NaN;
        double variance = Double.NaN;
        String marketDivergence = "MERCADO INDISPONÍVEL";
        String confidenceLevel = "MUITO BAIXA";
        String risk = "RISCO ALTO";
        String status = "REVISÃO NECESSÁRIA";
        String reason = "Dados insuficientes";
    }

    static final class DoubleChance {
        int oneX;
        int xTwo;
        boolean homeSide;
        String pick;
    }

    static final class Outcome3 {
        int home, draw, away;
        String source="";
    }

    static final class GoalSanity {
        double originalProjection;
        double adjustedProjection;
        double recentMean;
        double recentMedian;
        double marketLine;
        boolean divergent;
        String status = "NORMAL";
        String reason = "Projeção compatível com a base recente";
    }

    static Calibration calibrate(int rawProbability, int coverage, int sampleSize,
                                 int sourceCount, int sourceQuality, int agreement,
                                 double marketProbability, double variance,
                                 boolean importantInconsistency) {
        return calibrate(rawProbability,coverage,sampleSize,sourceCount,sourceQuality,agreement,55,marketProbability,variance,importantInconsistency);
    }

    static Calibration calibrate(int rawProbability, int coverage, int sampleSize,
                                 int sourceCount, int sourceQuality, int agreement, int recencyScore,
                                 double marketProbability, double variance,
                                 boolean importantInconsistency) {
        Calibration c = new Calibration();
        c.rawProbability = clamp(rawProbability, 1, 99);
        c.coverage = clamp(coverage, 0, 100);
        c.sampleSize = Math.max(0, sampleSize);
        c.sourceCount = Math.max(0, sourceCount);
        c.sourceQuality = clamp(sourceQuality, 0, 100);
        c.recencyScore = clamp(recencyScore,0,100);
        c.marketProbability = validProbability(marketProbability) ? marketProbability : Double.NaN;
        c.variance = variance;

        double sampleQ = sampleScore(sampleSize) / 100.0;
        double sourceQ = sourceCount <= 0 ? .15 : sourceCount == 1 ? .35 : sourceCount == 2 ? .68 : .88;
        sourceQ = sourceQ * .65 + (c.sourceQuality / 100.0) * .35;
        double convergenceQ = sourceCount <= 1 ? .35 : clamp(agreement, 0, 100) / 100.0;
        double stabilityQ = stabilityScore(variance) / 100.0;
        double reliability = .35 * (c.coverage / 100.0) + .25 * sampleQ + .20 * sourceQ + .10 * convergenceQ + .10 * stabilityQ;

        // Low coverage is deliberately conservative: an attractive raw number is not allowed
        // to masquerade as a high-certainty estimate when the evidence is thin.
        double shrink = c.coverage < 20 ? Math.min(.44, reliability) : (.30 + .65 * reliability);
        shrink = Math.max(.18, Math.min(.92, shrink));
        double calibrated = 50.0 + (c.rawProbability - 50.0) * shrink;

        c.marketDivergence = divergenceLabel(c.rawProbability, c.marketProbability);
        if (validProbability(c.marketProbability)) {
            double diff = Math.abs(c.rawProbability - c.marketProbability);
            double marketWeight;
            if (diff <= 5) marketWeight = .18;
            else if (diff <= 10) marketWeight = .25;
            else if (diff <= 15) marketWeight = .32;
            else marketWeight = reliability >= .72 ? .28 : .45;
            calibrated = calibrated * (1.0 - marketWeight) + c.marketProbability * marketWeight;
        }

        int cap = probabilityCap(c.coverage);
        boolean marketConvergent = validProbability(c.marketProbability) && Math.abs(calibrated - c.marketProbability) <= 5.0;
        boolean stable = stabilityScore(variance) >= 70;
        if (cap > 90 && !(sampleSize >= 11 && sourceCount >= 3 && marketConvergent && stable && !importantInconsistency)) cap = 90;
        if (c.coverage < 20) calibrated = Math.min(calibrated, cap - 2); // visible safety buffer for very poor coverage
        c.calibratedProbability = clamp((int)Math.round(calibrated), 1, Math.min(99, cap));

        c.confidenceScore = confidenceScore(c.coverage, sampleSize, sourceCount, c.sourceQuality,
                agreement, c.recencyScore, c.marketProbability, c.calibratedProbability, variance);
        c.confidenceLevel = confidenceLevel(c.confidenceScore, sampleSize);
        if (c.coverage < 20 && !("MUITO BAIXA".equals(c.confidenceLevel))) c.confidenceLevel = "BAIXA";

        double marketDiff = validProbability(c.marketProbability) ? Math.abs(c.rawProbability - c.marketProbability) : 0;
        boolean weakSingleSource = sourceCount == 1 && sourceQuality < 70;
        boolean safety = c.coverage < 20 || c.confidenceScore < 45 || marketDiff > 15 || weakSingleSource || importantInconsistency;
        if (marketDiff > 15 || importantInconsistency) c.status = "REVISÃO NECESSÁRIA";
        else if (safety || c.confidenceScore < 60) c.status = "ATENÇÃO";
        else if (c.calibratedProbability >= 68 && c.confidenceScore >= 60) c.status = "FAVORÁVEL";
        else c.status = "ATENÇÃO";

        if (!safety && c.calibratedProbability >= 62 && c.confidenceScore >= 70 && c.coverage >= 60 && c.sampleSize >= 7 && c.sourceCount >= 2) c.risk = "RISCO MENOR";
        else if (c.calibratedProbability >= 58 && c.confidenceScore >= 40) c.risk = "RISCO MODERADO";
        else c.risk = "RISCO ALTO";

        if (safety && "RISCO MENOR".equals(c.risk)) c.risk = "RISCO MODERADO";
        if (safety && "FAVORÁVEL".equals(c.status)) c.status = marketDiff > 15 ? "REVISÃO NECESSÁRIA" : "ATENÇÃO";
        c.reason = reason(c, weakSingleSource, importantInconsistency);
        return c;
    }

    static int probabilityCap(int coverage) {
        if (coverage < 20) return 65;
        if (coverage < 50) return 72;
        if (coverage < 70) return 80;
        if (coverage < 85) return 87;
        return 92;
    }

    static int confidenceScore(int coverage, int sampleSize, int sourceCount, int sourceQuality,
                               int agreement, int recencyScore, double marketProbability, int calibratedProbability,
                               double variance) {
        double data = .70 * clamp(coverage, 0, 100) + .30 * clamp(sourceQuality, 0, 100);
        double sample = sampleScore(sampleSize);
        double convergence;
        if (sourceCount <= 0) convergence = 20;
        else if (sourceCount == 1) convergence = Math.min(35, 20 + sourceQuality * .15);
        else convergence = clamp(agreement, 0, 100);
        double market = validProbability(marketProbability)
                ? Math.max(0, 100 - Math.abs(calibratedProbability - marketProbability) * 5.0)
                : 25; // mercado ausente reduz a confiança; não existe convergência a premiar
        double stability = stabilityScore(variance);
        double recency=clamp(recencyScore,0,100);
        return clamp((int)Math.round(data * .25 + sample * .15 + convergence * .20 + recency * .15 + market * .15 + stability * .10), 0, 100);
    }

    static int confidenceScore(int coverage,int sampleSize,int sourceCount,int sourceQuality,int agreement,double marketProbability,int calibratedProbability,double variance){return confidenceScore(coverage,sampleSize,sourceCount,sourceQuality,agreement,55,marketProbability,calibratedProbability,variance);}

    static int sampleScore(int n) {
        if (n <= 0) return 5;
        if (n <= 3) return 20;
        if (n <= 6) return 40;
        if (n <= 10) return 60;
        if (n <= 20) return 80;
        return 100;
    }

    static String sampleLabel(int n) {
        if (n <= 3) return "MUITO BAIXA";
        if (n <= 6) return "BAIXA";
        if (n <= 10) return "MODERADA";
        if (n <= 20) return "BOA";
        return "FORTE";
    }

    static String confidenceLevel(int score, int sample) {
        if(score<40)return "BAIXA";
        if(score<60)return "MODERADA";
        if(score<80)return "BOA";
        return "FORTE";
    }

    static int stabilityScore(double variance) {
        if (Double.isNaN(variance) || variance < 0) return 55;
        // variance here is a coefficient of variation (std/mean) when available.
        if (variance <= .12) return 95;
        if (variance <= .20) return 82;
        if (variance <= .30) return 68;
        if (variance <= .45) return 50;
        return 30;
    }

    static String divergenceLabel(double modelProbability, double marketProbability) {
        if (!validProbability(marketProbability)) return "MERCADO INDISPONÍVEL";
        double d = Math.abs(modelProbability - marketProbability);
        if (d <= 5) return "NORMAL";
        if (d <= 10) return "DIVERGÊNCIA LEVE";
        if (d <= 15) return "ATENÇÃO";
        return "REVISÃO NECESSÁRIA";
    }

    static double[] noVig(double... decimalOdds) {
        if (decimalOdds == null || decimalOdds.length == 0) return new double[0];
        double sum = 0; double[] p = new double[decimalOdds.length];
        for (int i=0;i<decimalOdds.length;i++) {
            if (decimalOdds[i] <= 1.0 || Double.isNaN(decimalOdds[i])) return new double[0];
            p[i] = 1.0 / decimalOdds[i]; sum += p[i];
        }
        if (sum <= 0) return new double[0];
        for (int i=0;i<p.length;i++) p[i] = p[i] / sum * 100.0;
        return p;
    }

    static Outcome3 normalizeOutcome(int home,int draw,int away,String source){
        int sum=Math.max(0,home)+Math.max(0,draw)+Math.max(0,away);if(sum<=0)return null;
        Outcome3 o=new Outcome3();o.home=clamp((int)Math.round(Math.max(0,home)*100.0/sum),0,100);o.draw=clamp((int)Math.round(Math.max(0,draw)*100.0/sum),0,100);o.away=100-o.home-o.draw;if(o.away<0){o.draw=Math.max(0,o.draw+o.away);o.away=0;}o.source=source==null?"":source;return o;
    }

    static Outcome3 poissonOutcome(double lambdaHome,double lambdaAway){
        if(Double.isNaN(lambdaHome)||Double.isNaN(lambdaAway)||lambdaHome<=0||lambdaAway<=0)return null;
        double ph=0,pd=0,pa=0;int max=12;
        double[] h=poissonMass(lambdaHome,max),a=poissonMass(lambdaAway,max);
        for(int i=0;i<=max;i++)for(int j=0;j<=max;j++){double p=h[i]*a[j];if(i>j)ph+=p;else if(i==j)pd+=p;else pa+=p;}
        double sum=ph+pd+pa;if(sum<=0)return null;Outcome3 o=new Outcome3();o.home=(int)Math.round(ph/sum*100);o.draw=(int)Math.round(pd/sum*100);o.away=100-o.home-o.draw;o.source="Poisson próprio";return o;
    }

    static Outcome3 blendOutcome(Outcome3 primary,Outcome3 independent,double independentWeight){
        if(primary==null)return independent;if(independent==null)return primary;double w=Math.max(0,Math.min(1,independentWeight));
        int h=(int)Math.round(primary.home*(1-w)+independent.home*w),d=(int)Math.round(primary.draw*(1-w)+independent.draw*w),a=100-h-d;
        return normalizeOutcome(h,d,a,(primary.source==null?"":primary.source)+" + "+(independent.source==null?"":independent.source));
    }

    static int drawNoBetProbability(Outcome3 o,boolean homeSide){
        if(o==null)return 0;double decisive=o.home+o.away;if(decisive<=0)return 0;return clamp((int)Math.round((homeSide?o.home:o.away)*100.0/decisive),1,99);
    }

    static int poissonHandicapProbability(double lambdaHome,double lambdaAway,boolean homeSide,double positiveLine){
        if(Double.isNaN(lambdaHome)||Double.isNaN(lambdaAway)||lambdaHome<=0||lambdaAway<=0||positiveLine<=0)return 0;
        int max=14;double[] h=poissonMass(lambdaHome,max),a=poissonMass(lambdaAway,max);double win=0,total=0;
        for(int i=0;i<=max;i++)for(int j=0;j<=max;j++){double p=h[i]*a[j];total+=p;double adjusted=homeSide?(i+positiveLine-j):(j+positiveLine-i);if(adjusted>0)win+=p;}
        return total<=0?0:clamp((int)Math.round(win/total*100),1,99);
    }

    static int normalHandicapProbability(double expectedHomeMargin,double std,boolean homeSide,double positiveLine){
        if(Double.isNaN(expectedHomeMargin)||Double.isNaN(std)||std<=0||positiveLine<=0)return 0;
        double p=homeSide?1.0-normalCdf((-positiveLine-expectedHomeMargin)/std):normalCdf((positiveLine-expectedHomeMargin)/std);
        return clamp((int)Math.round(p*100),1,99);
    }

    static double[] poissonMass(double lambda,int max){
        double[] p=new double[max+1];p[0]=Math.exp(-lambda);double sum=p[0];for(int i=1;i<max;i++){p[i]=p[i-1]*lambda/i;sum+=p[i];}p[max]=Math.max(0,1-sum);return p;
    }

    static DoubleChance doubleChance(int home, int draw, int away, String homeName, String awayName) {
        int sum = home + draw + away;
        if (sum <= 0) return null;
        double h = home * 100.0 / sum, d = draw * 100.0 / sum, a = away * 100.0 / sum;
        DoubleChance out = new DoubleChance();
        out.oneX = clamp((int)Math.round(h+d), 1, 99);
        out.xTwo = clamp((int)Math.round(d+a), 1, 99);
        out.homeSide = out.oneX >= out.xTwo;
        out.pick = out.homeSide ? safe(homeName)+" ou empate" : "Empate ou "+safe(awayName);
        return out;
    }

    static double jointProbability(Collection<Integer> probabilities) {
        if (probabilities == null || probabilities.isEmpty()) return 0;
        double p = 1.0;
        for (Integer v: probabilities) if (v != null) p *= clamp(v,0,100) / 100.0;
        return p * 100.0;
    }

    static String ticketPenalty(int selections) {
        if (selections <= 2) return "SEM PENALIDADE ADICIONAL";
        if (selections <= 4) return "PENALIZAÇÃO PEQUENA";
        if (selections <= 6) return "PENALIZAÇÃO MODERADA";
        if (selections <= 9) return "PENALIZAÇÃO ALTA";
        return "PENALIZAÇÃO MUITO ALTA";
    }

    static String ticketRisk(int selections, double jointProbability) {
        if (selections >= 10) return "RISCO MUITO ALTO";
        if (selections >= 7) return "RISCO ALTO";
        if (selections >= 5) return jointProbability >= 35 ? "RISCO MODERADO-ALTO" : "RISCO ALTO";
        if (selections >= 3) return jointProbability >= 45 ? "RISCO MODERADO" : "RISCO MODERADO-ALTO";
        if (jointProbability >= 60) return "RISCO MODERADO";
        return "RISCO ALTO";
    }

    static boolean isPregameStatus(String status) {
        String raw=safe(status).toUpperCase(Locale.ROOT).replace('_',' ').replace('-',' ');
        if(raw.isEmpty())return false;
        if(EventStandards.isLive(raw)||EventStandards.isFinished(raw)||EventStandards.POSTPONED.equals(EventStandards.normalizeStatus(raw))||EventStandards.CANCELLED.equals(EventStandards.normalizeStatus(raw)))return false;
        return raw.equals("SCHEDULED")||raw.equals("NOT STARTED")||raw.equals("UPCOMING")||raw.equals("TIMED")||raw.equals("NS")||raw.equals("PRE");
    }

    static int sourceWeight(String source) {
        String s = safe(source).toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return 45;
        if (containsAny(s,"official","oficial","league","liga oficial","federation","federação")) return 100;
        if (containsAny(s,"highlightly","5dollar","espn","sofascore","api-football","api-sports","thesportsdb","sportsdb")) return 90;
        if (containsAny(s,"openfootball","flashscore","soccerway","basketball-reference","fbref")) return 82;
        if (containsAny(s,"web pública","busca web","internet")) return 62;
        return 50;
    }

    static int sourceQualityScore(Collection<String> sources) {
        if (sources == null || sources.isEmpty()) return 35;
        double sum=0, w=0;
        for (String s:sources) { int q=sourceWeight(s); sum += q; w++; }
        return w==0?35:clamp((int)Math.round(sum/w),0,100);
    }

    static String sourceQualityLabel(int score) {
        if (score >= 85) return "ALTA";
        if (score >= 65) return "MÉDIA";
        return "BAIXA";
    }

    static GoalSanity goalSanity(double projection, double recentMean, double recentMedian,
                                 double marketLine, double stdDev) {
        GoalSanity g = new GoalSanity();
        g.originalProjection = projection; g.adjustedProjection = projection;
        g.recentMean = recentMean; g.recentMedian = recentMedian; g.marketLine = marketLine;
        ArrayList<Double> refs = new ArrayList<>();
        if (positive(recentMean)) refs.add(recentMean);
        if (positive(recentMedian)) refs.add(recentMedian);
        if (positive(marketLine)) refs.add(marketLine);
        if (refs.isEmpty() || !positive(projection)) return g;
        double center=0; for(double v:refs) center+=v; center/=refs.size();
        double abs = Math.abs(projection-center);
        double tolerance = Math.max(.55, positive(stdDev)?Math.min(1.0,stdDev*.85):.65);
        boolean far = abs > tolerance && abs / Math.max(.75,center) > .20;
        if (far) {
            g.divergent = true;
            // Re-anchor, but preserve model information instead of replacing it with the reference.
            g.adjustedProjection = projection*.55 + center*.45;
            g.status = "PROJEÇÃO DIVERGENTE — REVISÃO NECESSÁRIA";
            g.reason = "Projeção distante da média/mediana recente"+(positive(marketLine)?" e da linha de mercado":"")+"; aplicada correção conservadora";
        }
        return g;
    }

    static double normalOver(double mean, double std, double line) {
        if (!positive(std)) std = 1.0;
        double z = (line - mean) / std;
        return (1.0 - normalCdf(z)) * 100.0;
    }

    static double normalCdf(double z) {
        // Abramowitz-Stegun approximation, sufficient for calibration/display purposes.
        double x=Math.abs(z), t=1.0/(1.0+0.2316419*x);
        double d=0.3989422804014327*Math.exp(-x*x/2.0);
        double p=1.0-d*t*(0.319381530+t*(-0.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))));
        return z>=0?p:1.0-p;
    }

    static String fmtMarket(double p) { return validProbability(p) ? String.format(Locale.US,"%.0f%%",p) : "—"; }

    private static String reason(Calibration c, boolean weakSingleSource, boolean importantInconsistency) {
        ArrayList<String> r=new ArrayList<>();
        if (c.coverage < 20) r.add("DADOS LIMITADOS — BAIXA CONFIABILIDADE");
        if (c.sampleSize <= 6) r.add("amostra "+sampleLabel(c.sampleSize).toLowerCase(Locale.ROOT));
        if (weakSingleSource) r.add("fonte única fraca");
        if (validProbability(c.marketProbability) && Math.abs(c.rawProbability-c.marketProbability)>15) r.add("forte divergência contra o mercado");
        if (importantInconsistency) r.add("inconsistência estatística importante");
        if (r.isEmpty()) r.add("calibração compatível com a qualidade da base");
        return join(r," • ");
    }

    private static String join(List<String> a,String sep){StringBuilder b=new StringBuilder();for(String s:a){if(b.length()>0)b.append(sep);b.append(s);}return b.toString();}
    private static boolean validProbability(double p){return !Double.isNaN(p)&&p>0&&p<100.0001;}
    private static boolean positive(double x){return !Double.isNaN(x)&&x>0;}
    private static boolean containsAny(String s,String... v){for(String x:v)if(s.contains(x))return true;return false;}
    private static String safe(String s){return s==null?"":s.trim();}
    private static int clamp(int v,int a,int b){return Math.max(a,Math.min(b,v));}
}
