package com.jpastore.sportsai;

import java.util.*;

/** Lightweight OCR post-processor for screenshots. It classifies what was read and extracts useful football terms. */
public final class VisionAnalyzer {
    public static final class Result {
        public String type = "IMAGEM";
        public int confidence = 0;
        public String sport = "FUTEBOL";
        public final ArrayList<String> markets = new ArrayList<>();
        public final ArrayList<String> selections = new ArrayList<>();
        public final ArrayList<String> usefulLines = new ArrayList<>();
        public String summary = "";
    }

    private VisionAnalyzer() {}

    public static Result analyze(String raw) {
        Result r = new Result();
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) {
            r.summary = "Nenhum texto legível foi encontrado no print.";
            return r;
        }
        String low = normalize(text);
        r.sport = detectSport(low);
        int bet = hits(low, new String[]{"odd", "odds", "cotacao", "aposta", "bilhete", "dupla chance", "mais de", "menos de", "ambas marcam", "cash out", "selecao", "retorno"});
        int stats = hits(low, new String[]{"posse", "finaliz", "chutes", "escante", "faltas", "cartoes", "imped", "passes", "ataques", "estatisticas"});
        int match = hits(low, new String[]{" x ", " vs ", " versus ", "ao vivo", "intervalo", "1 tempo", "2 tempo", "premier league", "serie a", "la liga", "champions", "libertadores"});

        if (bet >= stats && bet >= match && bet >= 2) {
            r.type = "BILHETE";
            r.confidence = Math.min(98, 55 + bet * 7);
        } else if (stats >= 2 && stats >= match) {
            r.type = "ESTATÍSTICAS";
            r.confidence = Math.min(96, 55 + stats * 7);
        } else {
            r.type = "PARTIDA";
            r.confidence = Math.min(92, 50 + Math.max(1, match) * 8);
        }

        addMarket(r.markets, low, "Gols", "gol", "mais de", "menos de", "ambas marcam", "over", "under");
        addMarket(r.markets, low, "Escanteios", "escante", "corner");
        addMarket(r.markets, low, "Cartões", "cartao", "cartoes", "yellow card", "red card");
        addMarket(r.markets, low, "Faltas", "falta", "fouls");
        addMarket(r.markets, low, "Finalizações", "finaliz", "chutes", "shots");
        addMarket(r.markets, low, "Impedimentos", "imped", "offsides");
        addMarket(r.markets, low, "Laterais", "lateral", "throw in", "throw-in");
        addMarket(r.markets, low, "Tiros de meta", "tiro de meta", "goal kick");
        addMarket(r.markets, low, "Resultado / dupla chance", "dupla chance", "empate", "1x2", "vencedor", "resultado final");

        String[] lines = text.split("\\r?\\n");
        for (String original : lines) {
            String line = cleanup(original);
            if (line.length() < 3) continue;
            String n = normalize(line);
            if (isNoise(n)) continue;
            if (r.usefulLines.size() < 18) r.usefulLines.add(line);
            if (looksLikeSelection(n) && r.selections.size() < 14 && !containsIgnoreCase(r.selections, line)) {
                r.selections.add(line);
            }
        }

        StringBuilder s = new StringBuilder();
        s.append(r.type).append(" reconhecido • ").append(r.sport);
        if (!r.markets.isEmpty()) s.append(" • ").append(r.markets.size()).append(" mercados detectados");
        if (!r.selections.isEmpty()) s.append(" • ").append(r.selections.size()).append(" linhas relevantes");
        s.append(". A imagem serve como entrada; a confirmação esportiva continua sendo feita com os dados do J.Pastore Sports AI.");
        r.summary = s.toString();
        return r;
    }

    private static String detectSport(String low) {
        int basket=hits(low,new String[]{"nba","basket","quarter","rebote","assistencia","3 pontos","lakers","celtics"});
        int mma=hits(low,new String[]{"ufc","mma","round","ko","tko","submission","finalizacao","peso leve","peso pena"});
        int f1=hits(low,new String[]{"formula 1","f1","grand prix","grid","pole position","pit stop","verstappen","ferrari","mclaren"});
        int nfl=hits(low,new String[]{"nfl","touchdown","quarterback","field goal","super bowl","yards","1st down"});
        int baseball=hits(low,new String[]{"mlb","baseball","inning","home run","strikeout","pitcher","runs"});
        int max=Math.max(basket,Math.max(mma,Math.max(f1,Math.max(nfl,baseball))));
        if(max<2)return "FUTEBOL";if(max==basket)return "BASQUETE";if(max==mma)return "MMA";if(max==f1)return "FÓRMULA 1";if(max==nfl)return "NFL";return "BASEBALL";
    }

    private static boolean looksLikeSelection(String n) {
        return containsAny(n, new String[]{"mais de", "menos de", "over", "under", "ou empate", "dupla chance", "ambas marcam", "escante", "cartao", "cartoes", "gol", "finaliz", "chute", "falta", "imped", "vencedor", "empate anula", "draw no bet"});
    }

    private static boolean isNoise(String n) {
        return n.matches("^[0-9.,%+\\- ]+$") || containsAny(n, new String[]{"saldo", "deposito", "apostar agora", "login", "cadastre-se", "termos e condicoes"});
    }

    private static void addMarket(ArrayList<String> out, String low, String label, String... terms) {
        if (containsAny(low, terms) && !out.contains(label)) out.add(label);
    }

    private static int hits(String low, String[] terms) {
        int n = 0;
        for (String term : terms) if (low.contains(term)) n++;
        return n;
    }

    private static boolean containsAny(String text, String[] terms) {
        for (String t : terms) if (text.contains(t)) return true;
        return false;
    }

    private static boolean containsIgnoreCase(ArrayList<String> a, String v) {
        for (String s : a) if (s.equalsIgnoreCase(v)) return true;
        return false;
    }

    private static String cleanup(String s) {
        if (s == null) return "";
        return s.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
    }

    static String normalize(String s) {
        if (s == null) return "";
        String n = java.text.Normalizer.normalize(s.toLowerCase(new Locale("pt", "BR")), java.text.Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "").replace('×', 'x').replaceAll("\\s+", " ").trim();
    }
}
