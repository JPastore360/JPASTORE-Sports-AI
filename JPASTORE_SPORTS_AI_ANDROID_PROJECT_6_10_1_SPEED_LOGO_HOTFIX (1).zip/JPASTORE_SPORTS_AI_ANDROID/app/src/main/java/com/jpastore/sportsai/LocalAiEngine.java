package com.jpastore.sportsai;
import java.util.*;

/** Evidence-first local analyst. It never invents statistics: it only verbalizes values already calculated by the app. */
public final class LocalAiEngine {
 static String pct(int v){ return v>0 ? Math.min(99,v)+"%" : "dados insuficientes"; }
 static String fmt(double v){ return Double.isNaN(v)?"—":String.format(new Locale("pt","BR"),"%.1f",v); }

 static int[] sorted(ApiClient.Prediction p){
  if(p==null)return new int[]{0,0,0};
  int[] v={p.home,p.draw,p.away};Arrays.sort(v);return v;
 }
 static String confidence(ApiClient.Prediction p,ApiClient.DeepAnalysis d){
  StatisticalCalibrationEngine.Outcome3 outcome=TicketStore.outcomeModel(p,d);if(outcome==null)return "DADOS INSUFICIENTES";
  StatisticalCalibrationEngine.DoubleChance dc=StatisticalCalibrationEngine.doubleChance(outcome.home,outcome.draw,outcome.away,"Casa","Fora");if(dc==null)return "DADOS INSUFICIENTES";
  int cov=ApiClient.coveragePercent(d),sample=d==null?0:d.homeMatches+d.awayMatches+d.h2hMatches,sc=d==null?0:d.sourceCount,sq=d==null?0:d.sourceQuality,agr=d==null?0:d.agreement;double vr=Double.NaN;ApiClient.MetricProjection gm=d==null?null:d.metrics.get("Gols");if(gm!=null&&!Double.isNaN(gm.stdDev)&&gm.total>0)vr=gm.stdDev/gm.total;double market=d==null||d.marketOdds==null?Double.NaN:d.marketOdds.doubleChance(dc.homeSide);
  StatisticalCalibrationEngine.Calibration c=StatisticalCalibrationEngine.calibrate(dc.homeSide?dc.oneX:dc.xTwo,cov,sample,sc,sq,agr,market,vr,false);return c.confidenceLevel+" • Confidence Score "+c.confidenceScore+"/100 • "+c.status;
 }
 static String leader(ApiClient.Game g, ApiClient.Prediction p){
  if(p==null) return "Não há dados suficientes para apontar tendência principal.";
  int ph=Math.min(99,p.home),pd=Math.min(99,p.draw),pa=Math.min(99,p.away);int max=Math.max(ph,Math.max(pd,pa));
  ArrayList<String> top=new ArrayList<>();
  if(ph==max)top.add(g.home);
  if(pd==max)top.add("empate");
  if(pa==max)top.add(g.away);
  if(top.size()>1)return "Os cenários "+joinPt(top)+" aparecem empatados na maior probabilidade calculada ("+max+"%).";
  if(ph==max)return g.home+" aparece com a maior probabilidade calculada ("+ph+"%).";
  if(pa==max)return g.away+" aparece com a maior probabilidade calculada ("+pa+"%).";
  return "O empate aparece com a maior probabilidade calculada ("+pd+"%).";
 }
 static String joinPt(ArrayList<String> a){
  if(a.size()==1)return a.get(0);if(a.size()==2)return a.get(0)+" e "+a.get(1);
  StringBuilder b=new StringBuilder();for(int i=0;i<a.size();i++){if(i>0)b.append(i==a.size()-1?" e ":", ");b.append(a.get(i));}return b.toString();
 }
 static String tendency(ApiClient.Game g,ApiClient.Prediction p){
  if(p==null)return "";
  int hd=p.home+p.draw,ad=p.away+p.draw;String dc=hd>=ad?g.home+" ou empate":"Empate ou "+g.away;
  int[] v=sorted(p);int gap=v[2]-v[1];
  StringBuilder b=new StringBuilder("Tendência combinada: ").append(dc).append(". A confiança considera as probabilidades e os comparativos do confronto");
  if(gap<=3)b.append(" e está reduzida porque os dois cenários principais estão muito próximos");
  return b.append(".").toString();
 }
 static String metricLine(ApiClient.MetricProjection m){
  StringBuilder b=new StringBuilder();
  b.append(m.name).append(": projeção calibrada ").append(fmt(m.total)).append(" no total");
  if(!Double.isNaN(m.rawTotal)&&Math.abs(m.rawTotal-m.total)>.05)b.append(" • projeção bruta ").append(fmt(m.rawTotal));
  b.append(" (").append(fmt(m.home)).append(" × ").append(fmt(m.away)).append(")");
  b.append(", faixa ").append(fmt(m.low)).append("–").append(fmt(m.high));
  if(!Double.isNaN(m.recentMean))b.append(" • média recente ").append(fmt(m.recentMean));
  if(!Double.isNaN(m.recentMedian))b.append(" • mediana ").append(fmt(m.recentMedian));if(!Double.isNaN(m.leagueMean))b.append(" • média da competição ").append(fmt(m.leagueMean));
  if("Gols".equals(m.name)){
   int mais15=ApiClient.poissonOver(m.total,1.5),mais25=ApiClient.poissonOver(m.total,2.5),menos35=100-ApiClient.poissonOver(m.total,3.5);
   b.append(". Mais de 1,5 gols: ").append(mais15).append("%");b.append(" • Mais de 2,5 gols: ").append(mais25).append("%");b.append(" • Menos de 3,5 gols: ").append(menos35).append("%");
  }else{if(m.line>0&&m.overProb>=0)b.append(", mais de ").append(fmt(m.line)).append(": ").append(m.overProb).append("%");if(m.lineHigh>0&&m.overProbHigh>=0)b.append(" • mais de ").append(fmt(m.lineHigh)).append(": ").append(m.overProbHigh).append("%");}
  if(m.projectionDivergent)b.append(". ").append(m.projectionStatus).append(" — ").append(m.projectionReason);
  b.append(". Amostra: ").append(m.sample).append(" observações válidas");if(m.source!=null&&!m.source.isEmpty())b.append(" • fonte ").append(m.source);return b.append(".").toString();
 }
 static int marketCount(ApiClient.DeepAnalysis d){
  if(d==null)return 0;String[] core={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};int n=0;for(String k:core)if(d.metrics.get(k)!=null)n++;return n;
 }
 static String ptGoalPhrase(String raw){
  if(raw==null||raw.trim().isEmpty()||"null".equalsIgnoreCase(raw.trim()))return "";String x=raw.trim();String low=x.toLowerCase(Locale.ROOT);
  if(low.contains("over")){String n=x.replaceAll("[^0-9.,]","").replace('.',',');return "Mais de "+(n.isEmpty()?"2,5":n)+" gols";}
  if(low.contains("under")){String n=x.replaceAll("[^0-9.,]","").replace('.',',');return "Menos de "+(n.isEmpty()?"2,5":n)+" gols";}
  return x;
 }
 static String report(ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s){return report(g,p,s,null);}
 static String report(ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s, ApiClient.DeepAnalysis d){
  if(g==null) return "Selecione um confronto para iniciar a análise.";
  StringBuilder b=new StringBuilder();
  b.append("J.PASTORE AI • ANÁLISE CONTEXTUAL\n\n");
  b.append(g.home).append(" × ").append(g.away).append("\n");
  b.append(g.league==null?"Competição não informada":g.league).append("\n\n");
  if(ApiClient.isLiveStatus(g.status)){b.append(LiveAnalysisEngine.report(g,d));return b.toString();}
  if(p==null)b.append("LEITURA\nProbabilidades principais ainda estão sendo calculadas. Nenhum percentual ausente será inventado.\n\n");
  else{
   b.append("LEITURA\n").append(leader(g,p)).append(" Casa ").append(pct(p.home)).append(" • Empate ").append(pct(p.draw)).append(" • Fora ").append(pct(p.away)).append(".\n\n");
   b.append("TENDÊNCIA DO MOTOR\n").append(tendency(g,p)).append("\n\n");
   String linhaGols=ptGoalPhrase(p.underOver);if(!linhaGols.isEmpty()) b.append("GOLS\nTendência calculada: ").append(linhaGols).append(".\n\n");
   StatisticalCalibrationEngine.Outcome3 outcome=TicketStore.outcomeModel(p,d);StatisticalCalibrationEngine.DoubleChance dc=outcome==null?null:StatisticalCalibrationEngine.doubleChance(outcome.home,outcome.draw,outcome.away,g.home,g.away);if(dc!=null){int raw=dc.homeSide?dc.oneX:dc.xTwo;int cov=ApiClient.coveragePercent(d),sample=d==null?0:d.homeMatches+d.awayMatches+d.h2hMatches,sc=d==null?0:d.sourceCount,sq=d==null?0:d.sourceQuality,agr=d==null?0:d.agreement;double vr=Double.NaN;ApiClient.MetricProjection gm=d==null?null:d.metrics.get("Gols");if(gm!=null&&!Double.isNaN(gm.stdDev)&&gm.total>0)vr=gm.stdDev/gm.total;double market=d==null||d.marketOdds==null?Double.NaN:d.marketOdds.doubleChance(dc.homeSide);StatisticalCalibrationEngine.Calibration cal=StatisticalCalibrationEngine.calibrate(raw,cov,sample,sc,sq,agr,market,vr,false);b.append("CALIBRAÇÃO DA DUPLA CHANCE\nMercado: ").append(dc.pick).append("\nModelo de resultado: ").append(outcome.source).append("\nProbabilidade IA bruta: ").append(raw).append("%\nProbabilidade calibrada: ").append(cal.calibratedProbability).append("%\nMercado sem margem: ").append(StatisticalCalibrationEngine.fmtMarket(market)).append("\nCobertura: ").append(cov).append("% • Amostra: ").append(sample).append(" • Fontes: ").append(sc).append("\nConfidence Score: ").append(cal.confidenceScore).append("/100 • Confiança: ").append(cal.confidenceLevel).append(" • Risco: ").append(cal.risk).append("\nStatus: ").append(cal.status).append("\nJustificativa: ").append(cal.reason).append("\n\n");}
  }
  if(d!=null&&!d.metrics.isEmpty()){
   int coverage=ApiClient.coveragePercent(d),base=d.homeMatches+d.awayMatches+d.h2hMatches;
   b.append("BASE ESTATÍSTICA\n");
   b.append(g.home).append(": ").append(d.homeMatches).append(" jogos recentes");if(d.homeVenueMatches>0)b.append(" • ").append(d.homeVenueMatches).append(" em casa");b.append("\n");
   b.append(g.away).append(": ").append(d.awayMatches).append(" jogos recentes");if(d.awayVenueMatches>0)b.append(" • ").append(d.awayVenueMatches).append(" fora");b.append("\n");
   b.append("Confrontos diretos: ").append(d.h2hMatches).append(" • base principal: ").append(base).append(" jogos\n");b.append("Cobertura de eventos: ").append(coverage).append("% • mercados com dados válidos: ").append(marketCount(d)).append("/10\n");
   if(d.sources!=null&&!d.sources.isEmpty())b.append("Fontes: ").append(d.sources).append("\n");b.append("\n");
   b.append("PROJEÇÕES DE EVENTOS\n");
   String[] order={"Gols","Escanteios","Laterais","Tiros de meta","Faltas","Finalizações","Chutes no alvo","Impedimentos","Cartões amarelos","Tiros livres"};
   for(String k:order){ApiClient.MetricProjection m=d.metrics.get(k);if(m!=null)b.append("• ").append(metricLine(m)).append("\n");else b.append("• ").append(k).append(": dados insuficientes nas fontes disponíveis.\n");}
   if(d.h2hMatches>0)b.append("• Confrontos diretos: ").append(d.h2hMatches).append(" jogos entraram com peso menor que a forma recente.\n");
   b.append("\n");
  }else{
   b.append("BASE ESTATÍSTICA\nA camada aprofundada ainda não concluiu a coleta. O app busca até 10 jogos recentes de cada equipe, recorte casa/fora e até 5 confrontos diretos; internet primeiro e API somente como complemento.\n\n");
  }
  if(p!=null){
   b.append("EVIDÊNCIAS\n");int n=0;
   for(Map.Entry<String,Integer> e:p.comparison.entrySet()){
    String[] z=e.getKey().split("\\|");if(z.length<2||!"H".equals(z[1]))continue;Integer av=p.comparison.get(z[0]+"|A");if(av==null)continue;
    b.append("• ").append(z[0]).append(": ").append(g.home).append(" ").append(e.getValue()).append("% × ").append(g.away).append(" ").append(av).append("%\n");if(++n>=6)break;
   }
   if(n==0)b.append("• Comparativos detalhados ainda não disponíveis.\n");
  }
  b.append("\nQUALIDADE DOS DADOS\n");if(d!=null)b.append("Cobertura ponderada: ").append(ApiClient.coveragePercent(d)).append("%. ");if(d!=null&&!d.note.isEmpty())b.append(d.note).append(". ");
  b.append("Somente informações presentes nas fontes e cálculos do aplicativo são usadas. Estatísticas ausentes permanecem como dados insuficientes.");return b.toString();
 }
 static String answer(String q, ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s){return answer(q,g,p,s,null);}
 static String answer(String q, ApiClient.Game g, ApiClient.Prediction p, ApiClient.Stats s, ApiClient.DeepAnalysis d){
  if(g==null)return "Selecione um confronto primeiro.";String x=q==null?"":q.toLowerCase(Locale.ROOT);
  if(x.contains("escante"))return metricAnswer("Escanteios",d);if(x.contains("lateral")||x.contains("throw"))return metricAnswer("Laterais",d);if(x.contains("tiro de meta")||x.contains("goal kick"))return metricAnswer("Tiros de meta",d);if(x.contains("falta"))return metricAnswer("Faltas",d);if(x.contains("chute")||x.contains("finaliza"))return metricAnswer(x.contains("alvo")?"Chutes no alvo":"Finalizações",d);if(x.contains("cart"))return metricAnswer("Cartões amarelos",d);if(x.contains("imped"))return metricAnswer("Impedimentos",d);
  if(x.contains("gol")||x.contains("mais de")||x.contains("menos de")||x.contains("over")||x.contains("under")){ApiClient.MetricProjection m=d==null?null:d.metrics.get("Gols");if(m!=null)return metricLine(m)+" É uma estimativa estatística, não uma garantia.";if(p==null||p.underOver==null||p.underOver.isEmpty())return "Ainda não há evidência suficiente sobre gols para este confronto.";return "Para gols, a tendência disponível é: "+ptGoalPhrase(p.underOver)+". Isso é uma estimativa estatística, não uma garantia.";}
  if(x.contains("quem")||x.contains("vence")||x.contains("melhor")||x.contains("favor"))return leader(g,p)+" Confiança: "+confidence(p,d)+".";
  if(x.contains("prob"))return p==null?"Dados insuficientes para probabilidades.":"Probabilidades brutas atuais: "+g.home+" "+pct(p.home)+", empate "+pct(p.draw)+", "+g.away+" "+pct(p.away)+". A seleção final usa calibração e teto dinâmico.";
  if(x.contains("por que")||x.contains("porque")||x.contains("evid")){if(p==null||p.comparison.isEmpty())return "Os comparativos necessários ainda não estão disponíveis.";StringBuilder b=new StringBuilder("A leitura usa os comparativos disponíveis: ");int n=0;for(String k:p.comparison.keySet()){if(k.endsWith("|H")){if(n++>0)b.append(", ");b.append(k.substring(0,k.length()-2));if(n==6)break;}}return b.append(". Nenhum dado ausente é inventado.").toString();}
  return report(g,p,s,d);
 }
 static String metricAnswer(String name,ApiClient.DeepAnalysis d){ApiClient.MetricProjection m=d==null?null:d.metrics.get(name);return m==null?name+": dados insuficientes na fonte para esta análise.":metricLine(m)+" A projeção usa histórico recente e deve ser tratada como estimativa.";}
 private LocalAiEngine(){}
}
