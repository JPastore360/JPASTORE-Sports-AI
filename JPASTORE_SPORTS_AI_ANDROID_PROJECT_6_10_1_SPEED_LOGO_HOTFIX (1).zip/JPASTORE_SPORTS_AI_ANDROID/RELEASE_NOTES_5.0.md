# J.Pastore Sports AI 5.0.0 — Multiesportes

- Mantém applicationId `com.jpastore.sportsai` e a chave de assinatura estável.
- Futebol preservado com o motor atual.
- Nova Central Multiesportes com Basquete/NBA, MMA, Fórmula 1, NFL e Baseball.
- Nova central **APIs & Fontes** com configuração independente para API-Football, API-Basketball, API-NBA, API-MMA, API-Formula-1, API-NFL e API-Baseball.
- Chaves salvas no armazenamento persistente `jp_persistent_v1`, separado do cache.
- Cache independente por modalidade para economizar requisições.
- J.Pastore Vision AI passa a detectar a modalidade provável do print.
- Atalho “6 ESPORTES” no cabeçalho das telas principais.
- Compatível com instalação por cima da versão 4.9, desde que a versão 4.9 instalada tenha sido assinada pela mesma chave estável incluída no projeto.
