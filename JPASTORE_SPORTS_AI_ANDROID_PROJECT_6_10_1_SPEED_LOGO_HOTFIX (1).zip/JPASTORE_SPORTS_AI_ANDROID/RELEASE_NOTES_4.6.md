# J.Pastore Sports AI 4.6 — Football Loader

- Projeto e applicationId preservados: `com.jpastore.sportsai`.
- VersionCode 37 / VersionName 4.6.0-football-loader.
- Splash inicial premium com bola de futebol animada por 3 segundos.
- Identidade J.Pastore Sports AI mantida na abertura.
- Barra discreta de progresso no splash.
- Loader com bola de futebol em buscas e carregamentos reais.
- Mensagens contextuais: partidas, ao vivo, campeonatos, confrontos diretos e análise.
- Loader específico na J.Pastore Vision AI durante leitura do print.
- Loader específico para escalações oficiais.
- Loader compacto enquanto a IA cruza histórico e mercados, sem travar desnecessariamente a navegação.
- O tempo de 3 segundos é aplicado somente na abertura; carregamentos internos duram apenas o tempo real da operação.
- Nome do ZIP, pasta raiz, módulo `app` e `applicationId` permanecem compatíveis com o workflow existente.
