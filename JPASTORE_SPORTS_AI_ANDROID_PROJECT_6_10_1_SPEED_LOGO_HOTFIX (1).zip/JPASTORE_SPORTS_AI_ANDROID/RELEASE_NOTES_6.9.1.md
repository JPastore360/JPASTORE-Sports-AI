# J.Pastore Sports AI 6.9.1 — Logo Optimizer

- preserva IDs dos times vindos do SofaScore;
- usa `img.sofascore.com/api/v1/team/{id}/image` sem nova consulta JSON;
- fallback assíncrono por nome usando TheSportsDB e Wikipedia;
- cache persistente de badges e cache negativo de 12h;
- remove fallback genérico `FC` e usa iniciais reais do clube;
- mantém a interface e o motor 6.9 Turbo Multi-API.
