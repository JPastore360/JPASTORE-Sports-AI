# J.Pastore Sports AI 4.5 — Vision AI

- Projeto e applicationId preservados: `com.jpastore.sportsai`.
- VersionCode 36 / VersionName 4.5.0-vision-ai-review.
- Nova área J.Pastore Vision AI integrada à área de conversa.
- Importação de prints pela galeria.
- Recebimento de imagens pelo menu Compartilhar de outros apps.
- OCR local com ML Kit Text Recognition.
- Classificação automática de print: bilhete, partida ou estatísticas.
- Reconhecimento de times, mercados e linhas esportivas.
- Busca/localização de confrontos reconhecidos no print.
- Cruzamento do print com o motor estatístico já existente.
- Revisão de linhas do bilhete com indicação: mais conservadora, moderada, atenção ou dados insuficientes.
- Botão “Perguntar IA” para perguntas sobre o próprio print.
- Busca premium com autocomplete de times e campeonatos.
- Horários mantidos no padrão de Brasília.

Observação: as probabilidades e revisões são estimativas estatísticas e não garantem resultados esportivos.
