# J.Pastore Sports AI 6.4 — Research Engine 2.0

- Research Engine 2.0 aplicado ao futebol e às demais modalidades.
- Agenda pública e pesquisa web primeiro; APIs limitadas passam a complementar somente lacunas.
- Resolução de aliases de equipes, cache inteligente e pré-busca para reduzir repetição e latência.
- Fontes públicas pesquisadas em paralelo, com fusão e deduplicação de resultados.
- Consensus Intelligence: média ponderada, mediana, dispersão, confirmação entre fontes e penalização de conflitos.
- Análise Profunda disponível no futebol e nas demais modalidades para rodadas extras de investigação.
- Bilhete IA aceita referências exploratórias somente quando existe amostra real suficiente, sempre identificadas para revisão.
- Tela de carregamento renovada: bola e arcos giram em sentidos opostos.
- Barra de progresso agora acompanha etapas reais da agenda, pesquisa, análise e geração de bilhete.

Application ID preservado: `com.jpastore.sportsai`.

HOTFIX DE COMPILACAO
- Restaurado o helper publicFootballGames(String date), reutilizado por Ao Vivo e Busca Ampliada.
- Mantém a estratégia Internet First sem consumir API-Sports nessas consultas públicas.
