# J.Pastore Sports AI 5.9

- Botão **CRIAR BILHETE IA** e **BILHETE CRIADO** ficam sempre visíveis na agenda multiesporte.
- Com bilhete vazio, o botão mostra **BILHETE CRIADO • 0**; com seleções, vira **VER BILHETE • X**.
- O fluxo de seleção usa **GERAR BILHETE**, e o resumo final continua em **VER / FINALIZAR**.
- Novo fallback público estruturado via SofaScore para recuperar jogos recentes quando ESPN/API-Sports não retornam amostra suficiente.
- API-Sports permanece como fallback final configurado pelo usuário; números ausentes não são inventados.
