# J.Pastore Sports AI 6.8 — Fast Research + 5DollarFootballAPI

A 6.8 preserva o motor calibrado da 6.7 e adiciona uma rota rápida opcional para futebol usando a 5DollarFootballAPI. A nova fonte não substitui os fallbacks já existentes e nunca vira ponto único de falha.

## Configuração dentro do app
- Novo cartão **5DollarFootballAPI • FAST** em `MAIS → APIs & FONTES`.
- Campo para o usuário **colar a chave** diretamente no app.
- Ações: `SALVAR E TESTAR`, `TESTAR CONEXÃO` e `REMOVER CHAVE`.
- Exibe plano/uso/rate limit quando o endpoint de status responder.
- A chave é salva localmente nas preferências persistentes do aplicativo; não fica hard-coded no código-fonte nem precisa ser colocada no GitHub.

## Rota FAST do futebol
- Agenda diária em lote via 5DollarFootballAPI antes das rotas mais lentas.
- Placares ao vivo com cache curto.
- Histórico recente do mandante e visitante consultado em paralelo.
- Odds por partida alimentam o MarketOddsBook da 6.7 para remover margem e calibrar probabilidades.
- IDs da 5Dollar são armazenados separadamente dos IDs da API-Football, evitando mistura entre provedores.
- Resultados provenientes de fontes diferentes são deduplicados e mesclados preservando os IDs corretos.

## Velocidade
- InternetStats e 5Dollar executam em paralelo no primeiro estágio da análise.
- A pesquisa web aprofundada só é acionada automaticamente quando a cobertura rápida é insuficiente ou há poucas fontes independentes.
- API-Sports antiga permanece como complemento/fallback, não como requisito para iniciar a análise.
- Cache evita repetir agenda, odds e histórico em janelas curtas.

## Rate limit
- Headers `X-RateLimit-*` são persistidos para diagnóstico.
- HTTP 429 respeita `Retry-After` e abre um bloqueio apenas pela janela indicada.
- O limite temporário da 5Dollar não bloqueia o app: as demais fontes continuam disponíveis.

## Estatística
- Todas as regras da 6.7 foram preservadas: probabilidade bruta/calibrada separadas, cobertura, Confidence Score, no-vig, Poisson, sanity checks, dupla chance validada, filtro pré-jogo e probabilidade conjunta do bilhete.
- A 5Dollar é tratada como fonte de alta qualidade, mas uma fonte isolada nunca é chamada de consenso.

## Compatibilidade
- applicationId continua `com.jpastore.sportsai`.
- versionCode 60.
- versionName `6.8.0-fast-research-5dollar`.
