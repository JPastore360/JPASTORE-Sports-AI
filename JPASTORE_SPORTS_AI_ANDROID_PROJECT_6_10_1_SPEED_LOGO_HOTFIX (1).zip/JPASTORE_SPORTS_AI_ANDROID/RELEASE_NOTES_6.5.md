# J.Pastore Sports AI 6.5 — API-Independent Engine

## Correção estrutural
A agenda multiesportes não depende mais de uma única API nem de uma única fonte pública.

### Zero-Key Schedule
As agendas passam a consultar em paralelo:
1. Sofascore público
2. ESPN scoreboard público (sem chave)
3. TheSportsDB V1 gratuito
4. Busca web aberta (DuckDuckGo + Bing, apenas domínios esportivos reconhecidos)

A API-Sports é somente complemento opcional.

### Circuit breaker de quota
Quando a API retorna 429 ou mensagem de limite/quota, ela é pausada até o próximo dia em America/Sao_Paulo. O app não repete chamadas inúteis e continua nas fontes públicas.

### Cache resiliente
A última agenda pública válida de cada modalidade/data é preservada por até 7 dias para evitar tela vazia em falhas temporárias de rede/fontes.

### Basquete
Basquete/NBA usam agregação pública antes de API-Basketball/API-NBA. ESPN cobre NBA/WNBA/NCAA; Sofascore e TheSportsDB ampliam a cobertura internacional; busca web atua como último fallback público.

- applicationId preservado: com.jpastore.sportsai
- versionCode: 57
- versionName: 6.5.0-api-independent
