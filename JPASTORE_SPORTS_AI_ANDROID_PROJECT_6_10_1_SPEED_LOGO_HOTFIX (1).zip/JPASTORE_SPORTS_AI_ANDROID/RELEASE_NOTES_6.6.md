# J.Pastore Sports AI 6.6 — Calibrated Statistical Engine

## Objetivo
Revisão profunda do motor estatístico mantendo interface, busca, esportes, histórico, APIs, cache e fallback existentes. A prioridade passa a ser calibração e transparência, não aparência de confiança.

## Principais mudanças
- Separação real de probabilidade bruta, probabilidade calibrada, cobertura, Confidence Score, risco e mercado sem margem.
- Teto dinâmico por cobertura; 100% nunca é exibido e >90% exige evidência forte + mercado real convergente.
- Odds decimais suportadas pelo núcleo via normalização no-vig quando estiverem disponíveis; nenhuma odd é inventada.
- Divergência modelo x mercado classificada em NORMAL, DIVERGÊNCIA LEVE, ATENÇÃO e REVISÃO NECESSÁRIA.
- Regra de segurança impede FAVORÁVEL/RISCO MENOR com cobertura <20%, Confidence Score <45, divergência >15pp ou fonte única fraca.
- Confidence Score 0–100 independente da probabilidade.
- Dupla chance validada matematicamente por P(1X)=P(1)+P(X) e P(X2)=P(X)+P(2), com vínculo explícito aos nomes das equipes.
- Modelo de gols refeito com ataque/defesa, casa/fora, liga/base, H2H secundário, variância e sanity check; Poisson nas linhas de gols.
- Uma fonte não é mais chamada de consenso.
- Pré-jogo rejeita LIVE/FINISHED/CANCELLED/POSTPONED.
- Bilhete mostra média das seleções e probabilidade conjunta multiplicativa separadamente, com penalização e risco global por quantidade.
- Logs [JP_AI] registram origem dos percentuais e motivo da classificação.

## Compatibilidade
applicationId preservado: `com.jpastore.sportsai`.

## Revisão final de integração
- Divergência persistida no bilhete corrigida para comparar probabilidade bruta com mercado, não a probabilidade já calibrada.
- Status pré-jogo passou a usar whitelist; status vazio/desconhecido não entra automaticamente.
- Cobertura por seleção no futebol foi separada da cobertura global: gols e demais mercados usam a própria amostra, e dupla chance usa amostra de resultado/mandante/visitante/H2H.
- Mercado indisponível deixa de receber pontuação artificialmente neutra no Confidence Score.
- Logs `[JP_AI]` agora incluem `projection=` explicitamente.
- Tela de visão usa “confiança da leitura” para não confundir OCR/classificação da imagem com Confidence Score do modelo.

- Caminho público do futebol unificado ao mesmo modelo de gols: séries do mandante/visitante, recorte casa/fora, H2H com peso reduzido, confirmação de fontes e penalização de conflitos.
- Modo ENXUTO compara linhas conservadoras de gols (Over 1,5 / Under 3,5 / Under 4,5; Over 0,5 apenas como alternativa de última prioridade) por Confidence Score, evitando inflar acerto com linha excessivamente baixa.
- Cabeçalho visual não usa mais a palavra “consenso” quando existe apenas uma fonte.
- Eventos extraídos da busca web são normalizados como `NS`; status `WEB`, vazio ou desconhecido não é aceito diretamente pelo filtro pré-jogo.
