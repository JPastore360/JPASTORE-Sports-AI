package com.jpastore.sportsai;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.concurrent.*;
import java.util.regex.*;

/** API-Sports client for the non-football modules. Keeps each sport isolated and cache-aware. */
public class MultiSportClient {
    final Context c;
    MultiSportClient(Context c){this.c=c;}

    static final String FOOTBALL="football", BASKETBALL="basketball", NBA="nba", MMA="mma", F1="f1", NFL="nfl", BASEBALL="baseball";
    static final String[] MODULES={FOOTBALL,BASKETBALL,MMA,F1,NFL,BASEBALL};
    static final String[] SOURCES={FOOTBALL,BASKETBALL,NBA,MMA,F1,NFL,BASEBALL};

    static String label(String id){
        if(BASKETBALL.equals(id))return "Basquete";
        if(NBA.equals(id))return "NBA";
        if(MMA.equals(id))return "MMA";
        if(F1.equals(id))return "Fórmula 1";
        if(NFL.equals(id))return "NFL";
        if(BASEBALL.equals(id))return "Baseball";
        return "Futebol";
    }
    static String icon(String id){
        if(BASKETBALL.equals(id)||NBA.equals(id))return "🏀";
        if(MMA.equals(id))return "🥊";
        if(F1.equals(id))return "🏎";
        if(NFL.equals(id))return "🏈";
        if(BASEBALL.equals(id))return "⚾";
        return "⚽";
    }
    static String sourceTitle(String id){
        if(NBA.equals(id))return "API-NBA";
        if(BASKETBALL.equals(id))return "API-BASKETBALL";
        if(MMA.equals(id))return "API-MMA";
        if(F1.equals(id))return "API-FORMULA-1";
        if(NFL.equals(id))return "API-NFL & NCAA";
        if(BASEBALL.equals(id))return "API-BASEBALL";
        return "API-FOOTBALL";
    }
    static String base(String id){
        if(BASKETBALL.equals(id))return "https://v1.basketball.api-sports.io/";
        if(NBA.equals(id))return "https://v2.nba.api-sports.io/";
        if(MMA.equals(id))return "https://v1.mma.api-sports.io/";
        if(F1.equals(id))return "https://v1.formula-1.api-sports.io/";
        if(NFL.equals(id))return "https://v1.american-football.api-sports.io/";
        if(BASEBALL.equals(id))return "https://v1.baseball.api-sports.io/";
        return "https://v3.football.api-sports.io/";
    }

    static class ApiStatus {String plan="";int current=-1,limit=-1;boolean active=false;String text(){String p=plan==null||plan.isEmpty()?"Plano":plan;return current>=0&&limit>0?p+" • "+current+"/"+limit+" hoje":p+(active?" • ativo":"");}}

    static class Event {
        long id,homeId,awayId,leagueId;
        String sport="",apiSource="",competition="",season="",home="",away="",homeLogo="",awayLogo="",date="",time="",status="",score="",detail="";
        Event(String sport){this.sport=sport;this.apiSource=sport;}
        String when(){return (date==null?"":date)+(time==null||time.isEmpty()?"":" • "+time);}
        String matchup(){return away==null||away.trim().isEmpty()?home:home+" × "+away;}
    }

    String get(String source,String path,String key)throws Exception{
        if(apiCircuitOpen(source))throw new IOException("API complementar pausada até amanhã por limite diário");
        HttpURLConnection h=(HttpURLConnection)new URL(base(source)+path).openConnection();
        h.setRequestProperty("x-apisports-key",key);h.setRequestProperty("Accept","application/json");
        h.setRequestProperty("User-Agent","J.Pastore-Sports-AI/6.8 Android");h.setConnectTimeout(7000);h.setReadTimeout(9000);
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();
        if(in==null){if(code==429)markApiCircuit(source);throw new IOException("HTTP "+code);}
        BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();for(String s;(s=r.readLine())!=null;)b.append(s);
        String body=b.toString();String remaining=h.getHeaderField("x-ratelimit-requests-remaining");if("0".equals(remaining))markApiCircuit(source);if(code==429||quotaText(body)){markApiCircuit(source);throw new IOException("Limite diário da API atingido • modo web continua ativo");}
        if(code<200||code>=300)throw new IOException("HTTP "+code);
        JSONObject root=new JSONObject(body);Object errors=root.opt("errors");
        if(errors instanceof JSONObject&&((JSONObject)errors).length()>0){if(quotaText(String.valueOf(errors)))markApiCircuit(source);throw new IOException("API recusou a consulta");}
        if(errors instanceof JSONArray&&((JSONArray)errors).length()>0){if(quotaText(String.valueOf(errors)))markApiCircuit(source);throw new IOException("API recusou a consulta");}
        return body;
    }
    static boolean quotaText(String s){String x=s==null?"":s.toLowerCase(Locale.ROOT);return x.contains("rate limit")||x.contains("request limit")||x.contains("requests limit")||x.contains("daily limit")||x.contains("quota")||x.contains("too many requests");}
    String localDay(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));return f.format(new Date());}
    void markApiCircuit(String source){c.getSharedPreferences("jp_api_circuit",0).edit().putString("blocked_"+source,localDay()).apply();}
    boolean apiCircuitOpen(String source){return localDay().equals(c.getSharedPreferences("jp_api_circuit",0).getString("blocked_"+source,""));}
    void clearApiCircuit(String source){c.getSharedPreferences("jp_api_circuit",0).edit().remove("blocked_"+source).apply();}
    void test(String source,String key,Consumer<Boolean> cb){new Thread(()->{try{get(source,"status",key);cb.accept(true);}catch(Exception e){cb.accept(false);}}).start();}
    void status(String source,String key,Consumer<ApiStatus> ok,Consumer<String> err){new Thread(()->{try{JSONObject root=new JSONObject(get(source,"status",key));JSONObject r=root.optJSONObject("response");if(r==null)throw new IOException("Status indisponível");ApiStatus s=new ApiStatus();JSONObject sub=r.optJSONObject("subscription"),req=r.optJSONObject("requests");if(sub!=null){s.plan=sub.optString("plan","");s.active=sub.optBoolean("active",false);}if(req!=null){s.current=req.optInt("current",-1);s.limit=req.optInt("limit_day",-1);}ok.accept(s);}catch(Exception e){err.accept(e.getMessage());}}).start();}

    void cachePut(String k,String v){c.getSharedPreferences("jp_multisport_cache",0).edit().putString(k,v).putLong(k+"_ts",System.currentTimeMillis()).apply();}
    String cacheGet(String k,long age){android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_cache",0);long ts=p.getLong(k+"_ts",0);return System.currentTimeMillis()-ts<=age?p.getString(k,null):null;}

    void events(String sport,String date,String key,String secondaryKey,Consumer<ArrayList<Event>> ok,Consumer<String> err){events(sport,date,key,secondaryKey,null,ok,err);}
    void events(String sport,String date,String key,String secondaryKey,ResearchProgress progress,Consumer<ArrayList<Event>> ok,Consumer<String> err){new Thread(()->{
        try{
            report(progress,4,"Modo independente • consultando 4 fontes públicas");ArrayList<Event> out=new ArrayList<>();
            try{out.addAll(loadPublicSchedule(sport,date));}catch(Exception ignored){}
            out=dedupe(out);report(progress,76,"Internet pública • "+out.size()+" eventos confirmados");

            // 6.5: API-Sports NÃO é requisito para abrir agenda. Ela só tenta enriquecer quando
            // a cobertura pública ficou curta e o circuito de quota ainda está disponível.
            boolean needApi=out.isEmpty()||(BASKETBALL.equals(sport)&&out.size()<2);
            if(needApi){
                report(progress,84,out.isEmpty()?"Web sem agenda confirmada • tentando complemento opcional":"Cobertura web curta • complemento opcional");
                if(BASKETBALL.equals(sport)){
                    if(key!=null&&!key.trim().isEmpty()&&!apiCircuitOpen(BASKETBALL))try{out.addAll(load(BASKETBALL,date,key.trim()));}catch(Exception ignored){}
                    if(secondaryKey!=null&&!secondaryKey.trim().isEmpty()&&!apiCircuitOpen(NBA))try{out.addAll(load(NBA,date,secondaryKey.trim()));}catch(Exception ignored){}
                }else if(key!=null&&!key.trim().isEmpty()&&!apiCircuitOpen(sport))try{out.addAll(load(sport,date,key.trim()));}catch(Exception ignored){}
            }
            out=dedupe(out);if(!out.isEmpty())writeResilientSchedule(sport,date,out);
            if(out.isEmpty()){ArrayList<Event> stale=readResilientSchedule(sport,date);if(!stale.isEmpty()){out=stale;report(progress,94,"Usando última agenda pública válida salva no aparelho");}}
            sort(out);String tail=apiCircuitOpen(BASKETBALL)&&BASKETBALL.equals(sport)?" • API diária esgotada, sem bloquear o app":"";report(progress,100,"Agenda pronta • "+out.size()+" eventos"+tail);ok.accept(out);
        }catch(Exception e){ArrayList<Event> stale=readResilientSchedule(sport,date);if(!stale.isEmpty()){sort(stale);report(progress,100,"Agenda recuperada do cache resiliente");ok.accept(stale);}else{report(progress,100,"Agenda pública temporariamente limitada");err.accept(e.getMessage()==null?"Dados públicos indisponíveis":e.getMessage());}}
    }).start();}

    static void report(ResearchProgress p,int percent,String stage){if(p!=null)try{p.onProgress(Math.max(0,Math.min(100,percent)),stage);}catch(Exception ignored){}}

    /** 6.5 Zero-Key Schedule: nenhuma API paga é ponto único de falha. */
    ArrayList<Event> loadPublicSchedule(String sport,String date)throws Exception{
        String slug=publicSportSlug(sport);if(slug.isEmpty())return new ArrayList<>();ArrayList<Event> out=new ArrayList<>();
        ExecutorService ex=Executors.newFixedThreadPool(4);ArrayList<Future<ArrayList<Event>>> fs=new ArrayList<>();
        fs.add(ex.submit(()->safePublic(()->loadSofaSchedule(sport,date))));
        fs.add(ex.submit(()->safePublic(()->loadEspnSchedule(sport,date))));
        fs.add(ex.submit(()->safePublic(()->loadSportsDbSchedule(sport,date))));
        fs.add(ex.submit(()->safePublic(()->loadOpenWebSchedule(sport,date))));
        for(Future<ArrayList<Event>> f:fs)try{out.addAll(f.get(10,TimeUnit.SECONDS));}catch(Exception ignored){}ex.shutdownNow();out=dedupe(out);
        if(!out.isEmpty()){writeResilientSchedule(sport,date,out);return out;}ArrayList<Event> stale=readResilientSchedule(sport,date);if(!stale.isEmpty())return stale;return out;
    }
    interface EventLoader{ArrayList<Event> get()throws Exception;}
    ArrayList<Event> safePublic(EventLoader l){try{return l.get();}catch(Exception e){return new ArrayList<>();}}

    ArrayList<Event> loadSofaSchedule(String sport,String date)throws Exception{
        String slug=publicSportSlug(sport);if(slug.isEmpty())return new ArrayList<>();String ck="public_schedule_v65_sofa_"+slug+"_"+date;String raw=cacheGet(ck,35L*60*1000L);
        if(raw==null){raw=httpJson("https://api.sofascore.com/api/v1/sport/"+slug+"/scheduled-events/"+date,"https://www.sofascore.com/");cachePut(ck,raw);}JSONArray arr=new JSONObject(raw).optJSONArray("events");ArrayList<Event> out=new ArrayList<>();if(arr==null)return out;for(int i=0;i<arr.length();i++){Event e=parsePublicEvent(sport,date,arr.optJSONObject(i));if(e!=null){e.apiSource="public-sofa";e.detail="Sofascore público • "+safe(e.competition,"Competição");out.add(e);}}return out;
    }

    ArrayList<Event> loadEspnSchedule(String sport,String date)throws Exception{
        ArrayList<Event> out=new ArrayList<>();for(String path:espnSchedulePaths(sport)){
            try{String url="https://site.api.espn.com/apis/site/v2/sports/"+path+"/scoreboard?dates="+date.replace("-","") ;String raw=publicCached("espn_"+path+"_"+date,url,30L*60*1000L);JSONArray a=new JSONObject(raw).optJSONArray("events");if(a==null)continue;for(int i=0;i<a.length();i++){Event e=parseEspnEvent(sport,path,a.optJSONObject(i));if(e!=null)out.add(e);}}catch(Exception ignored){}
        }return out;
    }
    ArrayList<String> espnSchedulePaths(String sport){ArrayList<String> p=new ArrayList<>();if(BASKETBALL.equals(sport)||NBA.equals(sport)){p.add("basketball/nba");p.add("basketball/wnba");p.add("basketball/mens-college-basketball");p.add("basketball/womens-college-basketball");}else if(NFL.equals(sport)){p.add("football/nfl");p.add("football/college-football");}else if(BASEBALL.equals(sport)){p.add("baseball/mlb");p.add("baseball/college-baseball");}return p;}
    Event parseEspnEvent(String sport,String path,JSONObject o){if(o==null)return null;Event e=new Event(sport);e.apiSource="public-espn";try{e.id=Long.parseLong(o.optString("id","0"));}catch(Exception ignored){}String iso=o.optString("date","");if(!iso.isEmpty()){String[] z=localIso(iso);e.date=z[0];e.time=z[1];}JSONObject comp=null;JSONArray cs=o.optJSONArray("competitions");if(cs!=null&&cs.length()>0)comp=cs.optJSONObject(0);if(comp==null)return null;JSONArray teams=comp.optJSONArray("competitors");if(teams==null)return null;for(int i=0;i<teams.length();i++){JSONObject x=teams.optJSONObject(i),t=x==null?null:x.optJSONObject("team");if(t==null)continue;boolean home="home".equalsIgnoreCase(x.optString("homeAway"));String name=first(t.optString("displayName",""),t.optString("shortDisplayName",""));String logo=t.optString("logo","");String sc=x.optString("score","");if(home){e.home=name;e.homeLogo=logo;if(!sc.isEmpty())e.score=sc+" × "+(e.score.contains(" × ")?e.score.substring(e.score.indexOf(" × ")+3):"—");}else{e.away=name;e.awayLogo=logo;String left=e.score.contains(" × ")?e.score.substring(0,e.score.indexOf(" × ")):"—";if(!sc.isEmpty())e.score=left+" × "+sc;}}
        JSONObject st=comp.optJSONObject("status");if(st!=null){JSONObject ty=st.optJSONObject("type");if(ty!=null)e.status=first(ty.optString("description",""),ty.optString("state",""));}JSONObject season=o.optJSONObject("season");if(season!=null)e.season=String.valueOf(season.optInt("year",0));e.competition=espnCompetition(path,o);e.detail="ESPN público • "+safe(e.competition,"Basquete");return e.home.isEmpty()||e.away.isEmpty()?null:e;}
    String espnCompetition(String path,JSONObject o){String name="";if(path!=null){if(path.endsWith("/nba"))name="NBA";else if(path.endsWith("/wnba"))name="WNBA";else if(path.endsWith("mens-college-basketball"))name="NCAA Men";else if(path.endsWith("womens-college-basketball"))name="NCAA Women";else if(path.endsWith("/nfl"))name="NFL";else if(path.endsWith("college-football"))name="NCAA Football";else if(path.endsWith("/mlb"))name="MLB";}JSONArray leagues=o.optJSONArray("leagues");if(leagues!=null&&leagues.length()>0){JSONObject l=leagues.optJSONObject(0);if(l!=null)name=first(l.optString("abbreviation",""),l.optString("name",""));}if(name.isEmpty()){String uid=o.optString("uid","");if(uid.contains("~l:46"))name="NBA";}return name.isEmpty()?"ESPN Basketball":name;}

    ArrayList<Event> loadSportsDbSchedule(String sport,String date)throws Exception{
        String sn=tsdbSportName(sport);if(sn.isEmpty())return new ArrayList<>();String url="https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d="+URLEncoder.encode(date,"UTF-8")+"&s="+URLEncoder.encode(sn,"UTF-8");String raw=publicCached("tsdb_day_"+sn+"_"+date,url,60L*60*1000L);JSONArray a=new JSONObject(raw).optJSONArray("events");ArrayList<Event> out=new ArrayList<>();if(a==null)return out;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;Event e=new Event(sport);e.apiSource="public-tsdb";try{e.id=Long.parseLong(o.optString("idEvent","0"));}catch(Exception ignored){}e.home=o.optString("strHomeTeam","");e.away=o.optString("strAwayTeam","");e.competition=o.optString("strLeague","");e.date=o.optString("dateEvent",date);e.time=normalizeTime(o.optString("strTime",""));e.status=first(o.optString("strStatus",""),o.optString("strProgress",""));String hs=o.optString("intHomeScore",""),as=o.optString("intAwayScore","");if(!hs.isEmpty()||!as.isEmpty())e.score=emptyScore(hs)+" × "+emptyScore(as);e.detail="TheSportsDB público • "+safe(e.competition,"Basquete");if(!e.home.isEmpty()&&!e.away.isEmpty())out.add(e);}return out;
    }
    String tsdbSportName(String sport){if(BASKETBALL.equals(sport)||NBA.equals(sport))return "Basketball";if(BASEBALL.equals(sport))return "Baseball";if(NFL.equals(sport))return "American Football";if(FOOTBALL.equals(sport))return "Soccer";return "";}

    ArrayList<Event> loadOpenWebSchedule(String sport,String date)throws Exception{
        if(!(BASKETBALL.equals(sport)||NBA.equals(sport)||BASEBALL.equals(sport)||NFL.equals(sport)))return new ArrayList<>();String word=BASKETBALL.equals(sport)||NBA.equals(sport)?"basketball basquete":(BASEBALL.equals(sport)?"baseball":"NFL american football");ArrayList<Event> out=new ArrayList<>();MultiSportWebClient w=new MultiSportWebClient(c);LinkedHashSet<String> qs=new LinkedHashSet<>();qs.add(date+" "+word+" schedule fixtures jogos");qs.add(date+" "+word+" scores resultados");for(String q:qs){ArrayList<MultiSportWebClient.SearchItem> items=w.webSearch(q,8);for(MultiSportWebClient.SearchItem it:items){Event e=parseSearchEvent(sport,date,it);if(e!=null)out.add(e);}}return out;
    }
    Event parseSearchEvent(String sport,String date,MultiSportWebClient.SearchItem it){if(it==null)return null;String host=MultiSportWebClient.sourceHost(it.url);if(!MultiSportWebClient.trustedSportsHost(host))return null;String line=(it.title+" "+it.snippet).replaceAll("\\s+"," ").trim();if(line.toLowerCase(Locale.ROOT).contains("prediction")||line.toLowerCase(Locale.ROOT).contains("odds"))return null;Matcher m=Pattern.compile("(?iu)([\\p{L}0-9][\\p{L}0-9 .&'’\\-]{1,45}?)\\s+(?:vs\\.?|v\\.?|×| x | - | at )\\s+([\\p{L}0-9][\\p{L}0-9 .&'’\\-]{1,45})").matcher(line);if(!m.find())return null;String h=cleanTeam(m.group(1)),a=cleanTeam(m.group(2));if(h.length()<2||a.length()<2||h.equalsIgnoreCase(a))return null;Event e=new Event(sport);e.apiSource="public-web";e.home=h;e.away=a;e.date=date;e.competition=host;e.status="NS";e.detail="Busca web pública • "+host;return e;}
    static String cleanTeam(String s){if(s==null)return "";String x=s.replaceAll("(?iu)^(schedule|fixtures|scores|results|resultado|resultados|jogos|basketball|basquete)\\s*[:\\-]?\\s*","").replaceAll("\\s+"," ").trim();if(x.length()>52)x=x.substring(x.length()-52);return x.trim();}

    String httpJson(String url,String referer)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setInstanceFollowRedirects(true);h.setConnectTimeout(5500);h.setReadTimeout(7000);h.setRequestProperty("User-Agent","J.Pastore-Sports-AI/6.8 Android");h.setRequestProperty("Accept","application/json");if(referer!=null&&!referer.isEmpty())h.setRequestProperty("Referer",referer);int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader br=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder b=new StringBuilder();for(String x;(x=br.readLine())!=null;)b.append(x);return b.toString();}
    String publicCached(String key,String url,long ttl)throws Exception{String k="pub65_"+Integer.toHexString(key.hashCode());android.content.SharedPreferences p=c.getSharedPreferences("jp_multisport_public",0);String old=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(old!=null&&System.currentTimeMillis()-ts<ttl)return old;try{String raw=httpJson(url,"");p.edit().putString(k,raw).putLong(k+"_ts",System.currentTimeMillis()).apply();return raw;}catch(Exception e){if(old!=null)return old;throw e;}}
    void writeResilientSchedule(String sport,String date,ArrayList<Event> rows){try{JSONArray a=new JSONArray();for(Event e:dedupe(rows)){JSONObject o=new JSONObject();o.put("id",e.id);o.put("src",e.apiSource);o.put("c",e.competition);o.put("h",e.home);o.put("a",e.away);o.put("hl",e.homeLogo);o.put("al",e.awayLogo);o.put("d",e.date);o.put("t",e.time);o.put("st",e.status);o.put("sc",e.score);o.put("dt",e.detail);a.put(o);}String k="resilient_"+sport+"_"+date;c.getSharedPreferences("jp_resilient_schedule",0).edit().putString(k,a.toString()).putLong(k+"_ts",System.currentTimeMillis()).apply();}catch(Exception ignored){}}
    ArrayList<Event> readResilientSchedule(String sport,String date){ArrayList<Event> out=new ArrayList<>();try{String k="resilient_"+sport+"_"+date;android.content.SharedPreferences p=c.getSharedPreferences("jp_resilient_schedule",0);String raw=p.getString(k,null);long ts=p.getLong(k+"_ts",0);if(raw==null||System.currentTimeMillis()-ts>7L*24*60*60*1000L)return out;JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;Event e=new Event(sport);e.id=o.optLong("id",0);e.apiSource=o.optString("src","cache-public");e.competition=o.optString("c","");e.home=o.optString("h","");e.away=o.optString("a","");e.homeLogo=o.optString("hl","");e.awayLogo=o.optString("al","");e.date=o.optString("d",date);e.time=o.optString("t","");e.status=o.optString("st","");e.score=o.optString("sc","");e.detail=o.optString("dt","Cache público resiliente");if(!e.home.isEmpty())out.add(e);}}catch(Exception ignored){}return out;}
    static String normalizeTime(String s){if(s==null)return "";Matcher m=Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(s);if(m.find()){int h=Integer.parseInt(m.group(1));return String.format(Locale.US,"%02d:%s",h,m.group(2));}return "";}

    String publicSportSlug(String sport){if(FOOTBALL.equals(sport))return "football";if(BASKETBALL.equals(sport)||NBA.equals(sport))return "basketball";if(BASEBALL.equals(sport))return "baseball";if(NFL.equals(sport))return "american-football";if(MMA.equals(sport))return "mma";if(F1.equals(sport))return "motorsport";return "";}
    Event parsePublicEvent(String sport,String date,JSONObject o){if(o==null)return null;Event e=new Event(sport);e.apiSource="public-sofa";e.id=o.optLong("id",0);e.date=date;long ts=o.optLong("startTimestamp",0);if(ts>0){Date d=new Date(ts*1000L);SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US),tf=new SimpleDateFormat("HH:mm",Locale.US);TimeZone z=TimeZone.getTimeZone("America/Sao_Paulo");df.setTimeZone(z);tf.setTimeZone(z);e.date=df.format(d);e.time=tf.format(d);}JSONObject tour=o.optJSONObject("tournament"),cat=tour==null?null:tour.optJSONObject("category");if(tour!=null)e.competition=tour.optString("name","");if(cat!=null&&!cat.optString("name","").isEmpty()&&!e.competition.toLowerCase(Locale.ROOT).contains(cat.optString("name","").toLowerCase(Locale.ROOT)))e.competition=e.competition+" • "+cat.optString("name","");JSONObject h=o.optJSONObject("homeTeam"),a=o.optJSONObject("awayTeam");if(h!=null){e.home=h.optString("name","");e.homeLogo="";}if(a!=null){e.away=a.optString("name","");e.awayLogo="";}JSONObject st=o.optJSONObject("status");if(st!=null)e.status=first(st.optString("type",""),st.optString("description",""));JSONObject hs=o.optJSONObject("homeScore"),as=o.optJSONObject("awayScore");String hv=hs==null?"":numString(hs.opt("current")),av=as==null?"":numString(as.opt("current"));if(!hv.isEmpty()||!av.isEmpty())e.score=emptyScore(hv)+" × "+emptyScore(av);e.homeId=0;e.awayId=0;e.detail="Internet pública • "+safe(e.competition,"Competição")+" • "+safe(e.status,"programado");if(e.home.isEmpty()&&F1.equals(sport)){e.home=first(o.optString("name",""),e.competition);e.away="Fórmula 1";}return e.home.isEmpty()?null:e;}


    /** Starts only public/cache warm-up. It never calls API-Sports. */
    void prefetchPublicHistory(String sport,List<Event> events){new MultiSportWebClient(c).prefetch(sport,events);}

    ArrayList<Event> load(String source,String date,String key)throws Exception{
        String ck="v1_"+source+"_"+date;long ttl=6*60*1000L;
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        if(date!=null&&!date.equals(today))ttl=4L*60*60*1000L; // agendas futuras/passadas mudam pouco
        if(F1.equals(source))ttl=6L*60*60*1000L;
        String raw=cacheGet(ck,ttl);
        if(raw==null){
            String path;
            if(F1.equals(source)){String year=date!=null&&date.length()>=4?date.substring(0,4):String.valueOf(Calendar.getInstance().get(Calendar.YEAR));path="races?season="+year+"&type=Race";}
            else if(MMA.equals(source))path="fights?date="+date+"&timezone=America%2FSao_Paulo";
            else if(NBA.equals(source))path="games?date="+date;
            else path="games?date="+date+"&timezone=America%2FSao_Paulo";
            raw=get(source,path,key);cachePut(ck,raw);
        }
        JSONObject root=new JSONObject(raw);JSONArray a=root.optJSONArray("response");ArrayList<Event> out=new ArrayList<>();if(a==null)return out;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;Event e;
            if(F1.equals(source))e=parseF1(o,date);else if(MMA.equals(source))e=parseMma(o);else if(NBA.equals(source))e=parseNba(o);else if(NFL.equals(source))e=parseNfl(o);else e=parseGenericGame(source,o);
            if(e!=null)out.add(e);
        }
        if(F1.equals(source))out=selectF1(out,date);
        return out;
    }

    Event parseGenericGame(String sport,JSONObject o){
        Event e=new Event(sport);e.apiSource=sport;e.id=o.optLong("id",0);e.date=o.optString("date","");e.time=o.optString("time","");
        JSONObject st=o.optJSONObject("status");if(st!=null)e.status=first(st.optString("short",""),st.optString("long",""));
        JSONObject lg=o.optJSONObject("league");if(lg!=null){e.competition=lg.optString("name","");e.leagueId=lg.optLong("id",0);e.season=first(lg.optString("season",""),String.valueOf(lg.optInt("season",0)));if("0".equals(e.season))e.season="";}
        JSONObject teams=o.optJSONObject("teams");if(teams!=null){JSONObject h=teams.optJSONObject("home"),a=teams.optJSONObject("away");if(h!=null){e.homeId=h.optLong("id",0);e.home=h.optString("name","");e.homeLogo=h.optString("logo","");}if(a!=null){e.awayId=a.optLong("id",0);e.away=a.optString("name","");e.awayLogo=a.optString("logo","");}}
        JSONObject scores=o.optJSONObject("scores");if(scores!=null){String hs=scoreValue(scores.opt("home")),as=scoreValue(scores.opt("away"));if(!hs.isEmpty()||!as.isEmpty())e.score=emptyScore(hs)+" × "+emptyScore(as);}
        if(e.date!=null&&e.date.contains("T")){String[] z=localIso(e.date);e.date=z[0];e.time=z[1];}
        e.detail=sourceTitle(sport)+" • "+safe(e.competition,"Competição")+" • "+safe(e.status,"Status não informado");return e;
    }

    Event parseNba(JSONObject o){
        Event e=new Event(BASKETBALL);e.apiSource=NBA;e.id=o.optLong("id",0);e.competition="NBA • "+o.optString("league","standard");e.season=String.valueOf(o.optInt("season",0));if("0".equals(e.season))e.season="";
        JSONObject d=o.optJSONObject("date");if(d!=null){String[] z=localIso(d.optString("start",""));e.date=z[0];e.time=z[1];}
        JSONObject st=o.optJSONObject("status");if(st!=null)e.status=statusNba(st.optInt("short",0),st.optString("long",""));
        JSONObject teams=o.optJSONObject("teams");if(teams!=null){JSONObject h=teams.optJSONObject("home"),v=teams.optJSONObject("visitors");if(h!=null){e.homeId=h.optLong("id",0);e.home=h.optString("name","");e.homeLogo=h.optString("logo","");}if(v!=null){e.awayId=v.optLong("id",0);e.away=v.optString("name","");e.awayLogo=v.optString("logo","");}}
        JSONObject scores=o.optJSONObject("scores");if(scores!=null){JSONObject h=scores.optJSONObject("home"),v=scores.optJSONObject("visitors");String hs=h==null?"":numString(h.opt("points")),vs=v==null?"":numString(v.opt("points"));if(!hs.isEmpty()||!vs.isEmpty())e.score=emptyScore(hs)+" × "+emptyScore(vs);}
        e.detail="API-NBA • temporada "+o.optInt("season",0)+" • "+safe(e.status,"status não informado");return e;
    }

    Event parseNfl(JSONObject o){
        Event e=new Event(NFL);e.apiSource=NFL;JSONObject game=o.optJSONObject("game");if(game==null)game=o;e.id=game.optLong("id",0);JSONObject d=game.optJSONObject("date");if(d!=null){e.date=d.optString("date","");e.time=d.optString("time","");}JSONObject st=game.optJSONObject("status");if(st!=null)e.status=first(st.optString("short",""),st.optString("long",""));
        JSONObject lg=o.optJSONObject("league");if(lg!=null){e.competition=lg.optString("name","NFL")+(game.optString("week","").isEmpty()?"":" • "+game.optString("week"));e.leagueId=lg.optLong("id",0);e.season=first(lg.optString("season",""),String.valueOf(lg.optInt("season",0)));if("0".equals(e.season))e.season="";}
        JSONObject teams=o.optJSONObject("teams");if(teams!=null){JSONObject h=teams.optJSONObject("home"),a=teams.optJSONObject("away");if(h!=null){e.homeId=h.optLong("id",0);e.home=h.optString("name","");e.homeLogo=h.optString("logo","");}if(a!=null){e.awayId=a.optLong("id",0);e.away=a.optString("name","");e.awayLogo=a.optString("logo","");}}
        JSONObject scores=o.optJSONObject("scores");if(scores!=null){String hs=scoreValue(scores.opt("home")),as=scoreValue(scores.opt("away"));if(!hs.isEmpty()||!as.isEmpty())e.score=emptyScore(hs)+" × "+emptyScore(as);}
        e.detail="API-NFL • "+safe(game.optString("stage","") ,"temporada")+" • "+safe(e.status,"status não informado");return e;
    }

    Event parseMma(JSONObject o){
        Event e=new Event(MMA);e.apiSource=MMA;e.id=o.optLong("id",o.optLong("fight_id",0));e.date=first(o.optString("date",""),o.optString("fight_date",""));e.time=o.optString("time","");e.competition=first(o.optString("category",""),o.optString("event",""),o.optString("event_name",""),o.optString("promotion","MMA"));
        JSONObject st=o.optJSONObject("status");e.status=st==null?o.optString("status",""):first(st.optString("short",""),st.optString("long",""));
        JSONObject fs=o.optJSONObject("fighters");if(fs!=null){JSONObject f1=firstObj(fs,"first","home","fighter1"),f2=firstObj(fs,"second","away","fighter2");if(f1!=null){e.homeId=f1.optLong("id",0);e.home=f1.optString("name","");e.homeLogo=first(f1.optString("logo",""),f1.optString("photo",""));}if(f2!=null){e.awayId=f2.optLong("id",0);e.away=f2.optString("name","");e.awayLogo=first(f2.optString("logo",""),f2.optString("photo",""));}}
        if(e.home.isEmpty()){Object f1=o.opt("fighter1"),f2=o.opt("fighter2");e.home=nameValue(f1);e.away=nameValue(f2);}
        String winner=o.optString("winner","");String method=o.optString("method","");if(!winner.isEmpty())e.score="Vencedor: "+winner+(method.isEmpty()?"":" • "+method);
        e.detail="API-MMA • "+safe(e.competition,"Evento")+" • "+safe(e.status,"status não informado");return e;
    }

    Event parseF1(JSONObject o,String selectedDate){
        Event e=new Event(F1);e.apiSource=F1;e.id=o.optLong("id",0);JSONObject comp=o.optJSONObject("competition");if(comp!=null)e.home=comp.optString("name","");else e.home=first(o.optString("competition",""),o.optString("name",""));
        JSONObject circuit=o.optJSONObject("circuit");if(circuit!=null){e.away=circuit.optString("name","");e.awayLogo=circuit.optString("image","");}
        if(e.away.isEmpty())e.away=o.optString("circuit","");e.competition=first(o.optString("type",""),"Grand Prix");e.status=o.optString("status","");
        String d=o.optString("date","");if(d.contains("T")){String[] z=localIso(d);e.date=z[0];e.time=z[1];}else{e.date=d;e.time=o.optString("time","");}
        e.detail="API-FORMULA-1 • "+safe(e.competition,"Race")+" • "+safe(e.status,"programada");return e;
    }

    static JSONObject firstObj(JSONObject p,String... keys){for(String k:keys){JSONObject o=p.optJSONObject(k);if(o!=null)return o;}return null;}
    static String nameValue(Object o){if(o instanceof JSONObject)return ((JSONObject)o).optString("name","");return o==null?"":String.valueOf(o);}
    static String safe(String s,String d){return s==null||s.trim().isEmpty()?d:s;}
    static String first(String... s){for(String x:s)if(x!=null&&!x.trim().isEmpty()&&!"null".equalsIgnoreCase(x.trim()))return x;return "";}
    static String emptyScore(String s){return s==null||s.isEmpty()?"—":s;}
    static String numString(Object o){if(o==null||o==JSONObject.NULL)return "";return String.valueOf(o).replace(".0","");}
    static String scoreValue(Object o){if(o==null||o==JSONObject.NULL)return "";if(o instanceof Number||o instanceof String)return numString(o);if(o instanceof JSONObject){JSONObject q=(JSONObject)o;String[] ks={"total","points","runs","score"};for(String k:ks){String v=numString(q.opt(k));if(!v.isEmpty())return v;}}return "";}
    static String statusNba(int s,String longStatus){if(s==1)return "NS";if(s==2)return "LIVE";if(s==3)return "FT";if(s==4)return "PST";if(s==5)return "DLY";if(s==6)return "CANC";return first(longStatus,String.valueOf(s));}

    static String[] localIso(String iso){
        if(iso==null||iso.trim().isEmpty())return new String[]{"",""};
        String[] patterns={"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'","yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mmXXX"};
        for(String p:patterns)try{SimpleDateFormat in=new SimpleDateFormat(p,Locale.US);if(p.endsWith("'Z'"))in.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=in.parse(iso);SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US),tf=new SimpleDateFormat("HH:mm",Locale.US);TimeZone z=TimeZone.getTimeZone("America/Sao_Paulo");df.setTimeZone(z);tf.setTimeZone(z);return new String[]{df.format(d),tf.format(d)};}catch(Exception ignored){}
        String d=iso.length()>=10?iso.substring(0,10):iso;String t=iso.length()>=16?iso.substring(11,16):"";return new String[]{d,t};
    }

    static ArrayList<Event> dedupe(ArrayList<Event> in){LinkedHashMap<String,Event> m=new LinkedHashMap<>();if(in==null)return new ArrayList<>();for(Event e:in){if(e==null||safe(e.home,"").isEmpty())continue;String h=normName(e.home),a=normName(e.away),d=safe(e.date,"");String k=e.sport+"|"+h+"|"+a+"|"+d;if(a.isEmpty())k+="|"+safe(e.time,"");Event old=m.get(k);if(old==null)m.put(k,e);else mergeEvent(old,e);}return new ArrayList<>(m.values());}
    static void mergeEvent(Event a,Event b){if(a==null||b==null)return;if(safe(a.time,"").isEmpty()&&!safe(b.time,"").isEmpty())a.time=b.time;if(safe(a.score,"").isEmpty()&&!safe(b.score,"").isEmpty())a.score=b.score;if(safe(a.status,"").isEmpty()&&!safe(b.status,"").isEmpty())a.status=b.status;if(safe(a.competition,"").isEmpty()&&!safe(b.competition,"").isEmpty())a.competition=b.competition;if(safe(a.homeLogo,"").isEmpty()&&!safe(b.homeLogo,"").isEmpty())a.homeLogo=b.homeLogo;if(safe(a.awayLogo,"").isEmpty()&&!safe(b.awayLogo,"").isEmpty())a.awayLogo=b.awayLogo;if(a.id<=0&&b.id>0)a.id=b.id;String sa=safe(a.apiSource,""),sb=safe(b.apiSource,"");if(!sb.isEmpty()&&!sa.contains(sb))a.apiSource=sa.isEmpty()?sb:sa+"+"+sb;if(safe(a.detail,"").isEmpty()&&!safe(b.detail,"").isEmpty())a.detail=b.detail;}
    static String normName(String s){if(s==null)return "";String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);return x.replaceAll("[^a-z0-9]","");}
    static void sort(ArrayList<Event> a){Collections.sort(a,(x,y)->(safe(x.date,"")+"|"+safe(x.time,"")).compareTo(safe(y.date,"")+"|"+safe(y.time,"")));}
    static ArrayList<Event> selectF1(ArrayList<Event> all,String date){ArrayList<Event> exact=new ArrayList<>();for(Event e:all)if(date.equals(e.date))exact.add(e);if(!exact.isEmpty())return exact;ArrayList<Event> future=new ArrayList<>();for(Event e:all)if(e.date!=null&&e.date.compareTo(date)>=0)future.add(e);sort(future);while(future.size()>8)future.remove(future.size()-1);return future;}
}
