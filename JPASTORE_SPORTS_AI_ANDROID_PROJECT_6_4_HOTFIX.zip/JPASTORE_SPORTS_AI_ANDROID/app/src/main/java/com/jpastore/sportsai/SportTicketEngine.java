package com.jpastore.sportsai;

import java.util.*;

/**
 * Bilhete IA for non-football sports. It only uses structured recent results already
 * collected by MultiSportWebClient. Research Engine 2.0 can combine public sources, but it never invents bookmaker odds or missing stats.
 */
class SportTicketEngine {
    static final String CONSERVADOR="CONSERVADOR", EQUILIBRADO="EQUILIBRADO", AGRESSIVO="AGRESSIVO";

    static class Pick {
        String market="",pick="",detail="",risk="";
        int confidence=0,sample=0;
        Pick(String market,String pick,int confidence,int sample,String risk,String detail){
            this.market=market;this.pick=pick;this.confidence=confidence;this.sample=sample;this.risk=risk;this.detail=detail;
        }
    }
    static class Result {
        ArrayList<Pick> picks=new ArrayList<>();
        int sample=0,coverage=0,sourceCount=0,agreement=0,confirmed=0,conflicts=0;
        String quality="COBERTURA LIMITADA",note="",consensus="";
        boolean ready(){return !picks.isEmpty();}
    }

    static Result build(String sport, MultiSportClient.Event e, MultiSportWebClient.Research r, String mode){
        Result out=new Result();
        if(e==null){out.note="Selecione um confronto.";return out;}
        SportConsensusEngine.Consensus cc=SportConsensusEngine.analyze(sport,e,r);
        applyConsensus(out,cc);
        if(r==null||(!r.hasStructured()&&!cc.usable())){
            out.note="Ainda não há histórico suficiente para formar nem mesmo um consenso exploratório. A J.Pastore IA não cria números ausentes.";
            return out;
        }
        int hs=r==null?0:r.homeWins+r.homeDraws+r.homeLosses, as=r==null?0:r.awayWins+r.awayDraws+r.awayLosses;
        out.sample=Math.max(Math.min(hs,as),cc.minGames());
        int baseCoverage=r==null?0:coverage(hs,as,r.homeSample,r.awaySample);
        out.coverage=Math.max(baseCoverage,cc.coverage);
        if(cc.usable())out.quality=cc.level;else out.quality=out.coverage>=80?"COBERTURA FORTE":(out.coverage>=55?"COBERTURA MODERADA":"COBERTURA LIMITADA");

        if(MultiSportClient.F1.equals(sport)){
            out.note="Fórmula 1 exige dados por piloto (treinos, classificação e grid). Este evento ainda não traz uma dupla de pilotos comparável; por isso o app não inventa vencedor/pódio.";
            return out;
        }

        int min=minSample(mode);
        int usableHome=Math.max(hs,cc.homeGames),usableAway=Math.max(as,cc.awayGames);
        if(usableHome>=min&&usableAway>=min&&!safe(e.home).isEmpty()&&!safe(e.away).isEmpty()){
            double h=consensusStrength(cc,true,r),a=consensusStrength(cc,false,r);
            double gap=Math.abs(h-a);String lead=h>=a?e.home:e.away;
            int conf=calibrateWinner(gap,out.sample,mode);
            if(cc.usable())conf=consensusCalibrate(conf,cc.agreement,cc.conflictGames);
            if(conf>=winnerThreshold(mode)){
                String market=winnerMarket(sport);
                String detail="J.Pastore IA • forma + margem + consenso de fontes"+(cc.usable()?" • "+cc.note:"");
                out.picks.add(new Pick(market,lead,conf,out.sample,risk(conf),detail));
            }
        }

        if((MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NFL.equals(sport)||MultiSportClient.BASEBALL.equals(sport)) && usableHome>=min && usableAway>=min){
            double avg=!Double.isNaN(cc.totalMean)&&cc.totalMean>0?cc.totalMean:legacyTotal(r);
            if(avg>0){
                double line=referenceLine(sport,avg,mode);int conf=totalConfidence(mode,out.sample);if(cc.usable())conf=consensusCalibrate(conf,cc.agreement,cc.conflictGames);
                String unit=MultiSportClient.BASEBALL.equals(sport)?"corridas":"pontos";
                String detail="Linha de referência IA baseada no consenso (~"+fmt(avg)+" "+unit+")"+(cc.usable()?" • "+cc.sourceCount+" fontes • convergência "+cc.agreement+"%":"")+". Confirme a linha real antes de usar.";
                out.picks.add(new Pick("Total da partida","Mais de "+fmtHalf(line)+" "+unit,conf,out.sample,risk(conf),detail));
            }
        }

        if(MultiSportClient.MMA.equals(sport)&&out.picks.size()>1)while(out.picks.size()>1)out.picks.remove(out.picks.size()-1);
        int max=CONSERVADOR.equals(mode)?1:(EQUILIBRADO.equals(mode)?2:3);
        Collections.sort(out.picks,(x,y)->Integer.compare(y.confidence,x.confidence));while(out.picks.size()>max)out.picks.remove(out.picks.size()-1);

        if(out.picks.isEmpty())out.note="A base foi analisada, mas o modo "+mode+" ainda não atingiu o limiar normal. No bilhete múltiplo, o motor 6.4 pode entregar uma leitura EXPLORATÓRIA baseada no consenso para você decidir.";
        else out.note="Sugestões estatísticas para revisão • "+(cc.usable()?cc.level+" • "+cc.agreement+"% de convergência":"base recente")+". Não são garantia de resultado.";
        return out;
    }


    /** Multi-confronto: tenta o modo solicitado e, sem forçar dados, usa um limiar adaptativo
     * quando há pelo menos 3 jogos válidos de cada lado. Isso evita terminar em bilhete vazio
     * apenas porque o modo conservador exigia 5 partidas. */
    static Result buildForMulti(String sport, MultiSportClient.Event e, MultiSportWebClient.Research r, String mode){
        Result out=build(sport,e,r,mode);
        if(out.ready()||e==null||r==null||MultiSportClient.F1.equals(sport))return out;
        SportConsensusEngine.Consensus cc=SportConsensusEngine.analyze(sport,e,r);applyConsensus(out,cc);
        int hs=r.homeWins+r.homeDraws+r.homeLosses,as=r.awayWins+r.awayDraws+r.awayLosses;
        int common=Math.max(Math.min(hs,as),cc.minGames());
        int scoreSample=Math.max(Math.min(r.homeSample,r.awaySample),cc.minGames());
        boolean exploratory=cc.usable();

        if(common>=3){
            out.sample=common;out.coverage=Math.max(coverage(hs,as,r.homeSample,r.awaySample),cc.coverage);if(cc.usable())out.quality=cc.level;
            double h=consensusStrength(cc,true,r),a=consensusStrength(cc,false,r),gap=Math.abs(h-a);
            if(gap>=0.045&&!safe(e.home).isEmpty()&&!safe(e.away).isEmpty()){
                String lead=h>=a?e.home:e.away;int conf=Math.max(56,Math.min(68,(int)Math.round(55+gap*40+Math.min(5,common-3))));conf=consensusCalibrate(conf,cc.agreement,cc.conflictGames);
                out.picks.add(new Pick(winnerMarket(sport),lead,conf,common,risk(conf),"Seleção adaptativa • forma + margem + consenso"+(cc.usable()?" • "+cc.note:"")));
            }
        }

        // Consensus Intelligence 6.4 + Research Engine 2.0: quando o limiar normal não fecha, entrega uma referência
        // exploratória calculada da média consolidada em vez de descartar silenciosamente o confronto.
        if(out.picks.isEmpty()&&exploratory&&(MultiSportClient.BASKETBALL.equals(sport)||MultiSportClient.NFL.equals(sport)||MultiSportClient.BASEBALL.equals(sport))&&!Double.isNaN(cc.totalMean)&&cc.totalMean>0){
            String unit=MultiSportClient.BASEBALL.equals(sport)?"corridas":"pontos";double line=referenceLine(sport,cc.totalMean,mode);
            int conf=Math.max(53,Math.min(64,50+cc.agreement/10+Math.min(5,cc.minGames())));if(cc.conflictGames>0)conf=Math.max(51,conf-Math.min(6,cc.conflictGames*2));
            out.sample=cc.minGames();out.coverage=cc.coverage;out.quality=cc.level;
            out.picks.add(new Pick("Total da partida","Mais de "+fmtHalf(line)+" "+unit,conf,cc.minGames(),"EXPLORATÓRIO","Consenso J.Pastore IA • média consolidada ~"+fmt(cc.totalMean)+" "+unit+" • mediana "+fmt(cc.totalMedian)+" • "+cc.sourceCount+" fontes • convergência "+cc.agreement+"%. Você decide se a referência é válida."));
        }
        if(out.picks.isEmpty()&&exploratory&&!safe(e.home).isEmpty()&&!safe(e.away).isEmpty()){
            double h=consensusStrength(cc,true,r),a=consensusStrength(cc,false,r),gap=Math.abs(h-a);if(gap>=0.015){String lead=h>=a?e.home:e.away;int conf=Math.max(52,Math.min(61,50+cc.agreement/12+Math.min(4,cc.minGames())));out.sample=cc.minGames();out.coverage=cc.coverage;out.quality=cc.level;out.picks.add(new Pick(winnerMarket(sport),lead,conf,cc.minGames(),"EXPLORATÓRIO","Leitura de consenso com amostra reduzida • "+cc.note+". Revisão humana recomendada."));}
        }
        if(out.picks.isEmpty())out.note=cc.usable()?"A IA encontrou dados, calculou o consenso, mas não houve direção suficiente nem para uma referência exploratória responsável.":"Ainda faltam pelo menos 2 resultados válidos por participante para calcular uma média comparável.";
        else if("EXPLORATÓRIO".equals(out.picks.get(0).risk))out.note="Referência exploratória criada do consenso real das fontes. Ela aparece para você avaliar; não é previsão garantida nem dado inventado.";
        else out.note="Seleção adaptativa baseada em consenso para bilhete múltiplo. Revise antes de finalizar.";
        return out;
    }

    static void applyConsensus(Result out,SportConsensusEngine.Consensus c){if(out==null||c==null)return;out.sourceCount=c.sourceCount;out.agreement=c.agreement;out.confirmed=c.confirmedGames;out.conflicts=c.conflictGames;out.consensus=c.note;}
    static double consensusStrength(SportConsensusEngine.Consensus c,boolean home,MultiSportWebClient.Research r){
        double wr=home?c.homeWinRate:c.awayWinRate,margin=home?c.homeMargin:c.awayMargin;if(!Double.isNaN(wr)&&!Double.isNaN(margin))return wr*.78+clamp(margin,-25,25)/100.0;
        if(r==null)return 0;return home?strength(r.homeWins,r.homeDraws,r.homeLosses,r.homeFor,r.homeAgainst,r.homeSample):strength(r.awayWins,r.awayDraws,r.awayLosses,r.awayFor,r.awayAgainst,r.awaySample);
    }
    static int consensusCalibrate(int base,int agreement,int conflicts){int v=base;if(agreement>0)v+=(agreement-65)/12;v-=Math.min(6,conflicts*2);return Math.max(51,Math.min(78,v));}
    static double legacyTotal(MultiSportWebClient.Research r){if(r==null||r.homeSample<=0||r.awaySample<=0)return Double.NaN;double ht=(r.homeFor+r.homeAgainst)/Math.max(1,r.homeSample),at=(r.awayFor+r.awayAgainst)/Math.max(1,r.awaySample);return (ht+at)/2.0;}

    static double strength(int w,int d,int l,double pf,double pa,int sample){
        int n=Math.max(1,w+d+l);double win=w/(double)n,draw=d/(double)n;double margin=sample>0?(pf-pa)/sample:0;
        return win*.72+draw*.18+clamp(margin,-20,20)/100.0;
    }
    static int minSample(String mode){return CONSERVADOR.equals(mode)?5:(EQUILIBRADO.equals(mode)?4:3);}
    static int winnerThreshold(String mode){return CONSERVADOR.equals(mode)?66:(EQUILIBRADO.equals(mode)?61:57);}
    static int calibrateWinner(double gap,int sample,String mode){
        int base=(int)Math.round(54+Math.min(.42,gap)*48);int bonus=Math.min(8,Math.max(0,sample-3));int v=base+bonus;
        int cap=CONSERVADOR.equals(mode)?78:(EQUILIBRADO.equals(mode)?75:72);return Math.max(51,Math.min(cap,v));
    }
    static int totalConfidence(String mode,int sample){int b=CONSERVADOR.equals(mode)?65:(EQUILIBRADO.equals(mode)?61:58);return Math.min(72,b+Math.max(0,Math.min(5,sample-3)));}
    static double referenceLine(String sport,double avg,String mode){
        double offset;
        if(MultiSportClient.BASEBALL.equals(sport))offset=CONSERVADOR.equals(mode)?1.5:(EQUILIBRADO.equals(mode)?.5:-.5);
        else if(MultiSportClient.NFL.equals(sport))offset=CONSERVADOR.equals(mode)?7.5:(EQUILIBRADO.equals(mode)?3.5:-.5);
        else offset=CONSERVADOR.equals(mode)?12.5:(EQUILIBRADO.equals(mode)?6.5:-.5);
        return Math.max(.5,roundHalf(avg-offset));
    }
    static String winnerMarket(String sport){
        if(MultiSportClient.NFL.equals(sport))return "Moneyline";
        if(MultiSportClient.MMA.equals(sport))return "Vencedor da luta";
        return "Vencedor da partida";
    }
    static int coverage(int hs,int as,int hp,int ap){int n=Math.min(hs,as);int p=Math.min(hp,ap);if(n>=7&&p>=5)return 88;if(n>=5&&p>=4)return 72;if(n>=3)return 56;return 35;}
    static String risk(int c){return c>=70?"RISCO MENOR":(c>=62?"RISCO MODERADO":"RISCO ALTO");}
    static String fmt(double x){return String.format(new Locale("pt","BR"),"%.1f",x);}
    static String fmtHalf(double x){return String.format(new Locale("pt","BR"),"%.1f",roundHalf(x));}
    static double roundHalf(double x){return Math.round(x*2.0)/2.0;}
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    static String safe(String s){return s==null?"":s.trim();}
}
