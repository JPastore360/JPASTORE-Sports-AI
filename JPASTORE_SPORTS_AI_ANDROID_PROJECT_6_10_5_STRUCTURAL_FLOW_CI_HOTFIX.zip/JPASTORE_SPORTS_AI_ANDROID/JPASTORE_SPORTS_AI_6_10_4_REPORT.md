# J.PASTORE SPORTS AI 6.10.4 — RELATÓRIO DE OTIMIZAÇÃO

## Problemas observados
1. A tela inicial podia permanecer com apenas os mesmos poucos confrontos porque aceitava a primeira agenda rápida e não fazia uma segunda expansão.
2. O gerador de bilhete múltiplo pesquisava confronto por confronto e descartava eventos com histórico curto, mesmo quando havia odds reais disponíveis.

## Correções aplicadas
- Agenda em duas etapas: resposta rápida para abrir a tela e expansão em segundo plano quando vierem menos de 18 eventos.
- Expansão multi-fonte: SofaScore, ESPN, TheSportsDB, fonte web, 5Dollar (quando configurada) e API-Football (quando configurada).
- ESPN futebol ampliada para Brasil, Premier League, LaLiga, Bundesliga, Serie A, Ligue 1, Portugal, Champions, Europa League, Libertadores e Sul-Americana.
- Cache da agenda versionado para 6.10.4, evitando reaproveitar cache curto da versão anterior.
- Bilhete múltiplo pesquisa até 4 confrontos em paralelo.
- Pesquisa profunda só é acionada quando a evidência rápida ainda é fraca.
- Último resgate direto pelo MarketCollector quando a pesquisa histórica falha mas pode existir mercado real.
- Cada confronto selecionado gera no máximo uma seleção no bilhete múltiplo.
- Amostra histórica mínima (1 jogo verificável por lado) só pode preencher com REVISÃO NECESSÁRIA / RISCO ALTO.
- Sem histórico suficiente, odds reais sem margem podem preencher como fallback, também com REVISÃO NECESSÁRIA / RISCO ALTO.
- Sem histórico verificável e sem mercado real utilizável, o app não inventa uma aposta.

## Compatibilidade
O motor estatístico principal, calibração, Production Tuning, Market Collector 6.10.3, resolvedor de logos e regras de pré-jogo foram preservados.

## Versão
- versionCode: 67
- versionName: 6.10.4-agenda-ticket-optimizer
