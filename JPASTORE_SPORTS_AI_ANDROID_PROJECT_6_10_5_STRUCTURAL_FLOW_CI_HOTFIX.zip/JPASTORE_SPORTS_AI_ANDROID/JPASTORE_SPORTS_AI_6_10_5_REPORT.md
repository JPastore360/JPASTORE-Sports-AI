# J.PASTORE AI 6.10.5 — Resultado final da correção estrutural

## CAUSA RAIZ HOME
Não havia `take(3)` na UI. A limitação vinha do fluxo: a agenda rápida/parcial podia se tornar a lista final, fontes complementares eram condicionadas a uma quantidade considerada “suficiente”, a paginação não era percorrida integralmente e o tratamento de data dependia parcialmente do timezone do aparelho. O estado de mercado também estava próximo demais do fluxo de análise.

Correção: a home agora é independente de odds. A resposta rápida aparece primeiro e a consolidação completa multi-fonte roda sempre em segundo plano. Paginação é percorrida, timezone da agenda é America/Sao_Paulo, deduplicação ocorre depois da coleta e evento sem odds permanece visível.

## CAUSA RAIZ BILHETES
O app não tinha uma entidade persistente de bilhete gerado. O `TicketStore` anterior persistia um conjunto global de seleções/confrontos e deduplicava pelo confronto, portanto pedir 12 não equivalia a salvar 12 objetos distintos. O modo conservador também podia herdar fallback de revisão no fluxo de múltiplos.

Correção: `TicketBatchGenerator` cria combinações distintas e `GeneratedTicketStore` persiste cada bilhete com ID próprio. O pipeline registra requested -> eligibleSelections -> generated -> afterDedup -> saved -> displayed. O conservador bloqueia REVISÃO NECESSÁRIA e não força seleção.

## ARQUIVOS ALTERADOS/ADICIONADOS
- app/build.gradle
- app/src/main/java/com/jpastore/sportsai/ApiClient.java
- app/src/main/java/com/jpastore/sportsai/EventStandards.java
- app/src/main/java/com/jpastore/sportsai/MarketCollector.java
- app/src/main/java/com/jpastore/sportsai/MarketOddsBook.java
- app/src/main/java/com/jpastore/sportsai/MarketOddsClient.java
- app/src/main/java/com/jpastore/sportsai/MultiSportClient.java
- app/src/main/java/com/jpastore/sportsai/PremiumView.java
- app/src/main/java/com/jpastore/sportsai/SportTicketEngine.java
- app/src/main/java/com/jpastore/sportsai/HomeFlowCore.java
- app/src/main/java/com/jpastore/sportsai/TicketBatchGenerator.java
- app/src/main/java/com/jpastore/sportsai/GeneratedTicketStore.java
- tools/structural-flow-selftest.sh
- tools/ProductionTuningSelfTest.java
- tools/agenda-ticket-optimizer-selftest.sh
- tools/run-market-collector-tests.sh
- ci/build-apk-6.10.5-STRUCTURAL-FLOW.yml

`StatisticalCalibrationEngine.java` permanece sem alteração nesta rodada.

## TESTES
A: 20 eventos de entrada -> 20 exibíveis: PASSOU.
B: requested=12 com pool suficiente -> generated=12, IDs distintos=12, assinaturas distintas=12: PASSOU.
C: recriar o store -> saved=12 continuam persistidos: PASSOU.
D: REVISÃO NECESSÁRIA no CONSERVADOR -> 0 seleção automática: PASSOU.
E: evento sem odds -> continua na home: PASSOU.

Regressão: motor estatístico 20/20; MarketCollector 15/15 + 6 checks; Production Tuning 12/12; Agenda/Ticket 13/13; Speed/Logo 10/10; Logo Optimizer 8/8.

## HOME
antes = resposta parcial podia permanecer com ~3 eventos.
depois = todos os eventos válidos consolidados e deduplicados; teste controlado 20 -> 20.

## BILHETES
solicitados = 12
gerados = 12
salvos = 12
mostrados = 12

## BUILD
O ZIP final foi reaberto e todos os testes acima foram executados novamente diretamente a partir dele; integridade ZIP: PASSOU; workflow YAML: PASSOU; chave de assinatura foi preservada.

A compilação APK 6.10.5 no GitHub Actions NÃO foi disparada automaticamente porque a integração disponível retornou HTTP 403 ao tentar atualizar `.github/workflows/build-apk.yml`. Portanto não há afirmação falsa de build APK concluído. O workflow 6.10.5 está pronto para ser enviado junto com o ZIP.
