# J.PASTORE Sports AI 6.10.5 — Structural Flow

Correção estrutural focada em estabilidade e fluxo. O motor estatístico principal não foi alterado.

## Home
- A agenda da home é independente do coletor de odds.
- A lista rápida aparece primeiro e a consolidação multi-fonte roda em segundo plano.
- Removidos gatilhos de “agenda suficiente” baseados em quantidade curta.
- API-Football e APIs multiesporte percorrem paginação anunciada pelo provedor.
- SofaScore e datas da agenda são normalizados explicitamente para America/Sao_Paulo.
- Logs `[JP_HOME]`: rawEvents, validEvents, afterFilters, afterDedup e displayedEvents.

## Bilhetes
- Novo `TicketBatchGenerator`: gera bilhetes distintos até a quantidade solicitada quando há combinações elegíveis.
- Novo `GeneratedTicketStore`: cada bilhete possui ID único e o lote completo é persistido.
- A tela de bilhetes exibe a contagem solicitada, gerada e salva.
- Quando não há combinações suficientes, o motivo fica explícito em vez de retornar poucos bilhetes silenciosamente.
- Logs `[JP_TICKETS]`: requested, eligibleSelections, generated, afterDedup, saved e displayed.

## Conservador
- `REVISÃO NECESSÁRIA` não entra automaticamente.
- Requer mercado confirmado, Confidence Score >= 60, cobertura >= 50%, amostra >= 5 e sem divergência grave com o mercado.
- Fallback exploratório permanece disponível somente fora do modo conservador.

## MarketCollector
- Mantida a resolução multi-fonte da 6.10.3.
- Estados explícitos: MARKET_FOUND, PARTIAL_MARKET, EVENT_NOT_FOUND, COLLECTOR_FAILED, TIMEOUT e RATE_LIMIT.
- Falha de odds não remove eventos da home.
