# J.Pastore Sports AI 6.10.4 — Agenda + Ticket Optimizer

## Objetivo
Corrigir dois gargalos observados em produção sem refazer o motor estatístico: agenda inicial presa em poucos confrontos e geração de bilhete múltiplo interrompida por amostra histórica curta.

## Agenda inicial
- Mantém a abertura rápida com a primeira malha de dados disponível.
- Se a agenda rápida vier curta, executa uma segunda passagem em segundo plano.
- Cruza SofaScore, ESPN, TheSportsDB, fonte web, 5Dollar quando configurada e API-Football quando configurada.
- ESPN de futebol passa a consultar em paralelo Brasil, Inglaterra, Espanha, Alemanha, Itália, França, Portugal, Champions, Europa League, Libertadores e Sul-Americana.
- O cache foi versionado para evitar reaproveitar uma agenda curta antiga.

## Bilhete múltiplo
- Confrontos selecionados são pesquisados em paralelo, com no máximo 4 workers.
- Tenta primeiro pesquisa pública rápida e odds; só aprofunda quando a evidência ainda é fraca.
- Uma seleção por confronto no modo de múltiplos, evitando que um único evento consuma várias vagas.
- Quando há apenas uma amostra histórica verificável por lado, pode preencher a seleção exclusivamente como REVISÃO NECESSÁRIA / RISCO ALTO.
- Quando o histórico não é suficiente, mas há mercado real válido, pode usar fallback de mercado sem margem, também obrigatoriamente marcado como REVISÃO NECESSÁRIA / RISCO ALTO.
- Se a pesquisa histórica falhar antes de retornar um objeto utilizável, há uma última tentativa direta do coletor de odds para resgatar o confronto sem inventar estatística.
- Nenhuma seleção é inventada quando não existe nem evidência histórica verificável nem mercado real utilizável.

## Compatibilidade
O núcleo de calibração, Production Tuning, Market Collector 6.10.3, regras de status, logos e filtros anteriores foram preservados.
