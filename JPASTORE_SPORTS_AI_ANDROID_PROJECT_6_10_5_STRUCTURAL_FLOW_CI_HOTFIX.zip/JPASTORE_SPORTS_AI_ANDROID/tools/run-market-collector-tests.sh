#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="${TMPDIR:-/tmp}/jpastore-market-collector-tests"
rm -rf "$TMP" && mkdir -p "$TMP/src/com/jpastore/sportsai" "$TMP/src/android/content" "$TMP/src/org/json" "$TMP/out"

cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content; public class Context { public SharedPreferences getSharedPreferences(String n,int m){return null;} }
JAVA
cat > "$TMP/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content; public interface SharedPreferences {String getString(String k,String d);long getLong(String k,long d);Editor edit();interface Editor{Editor putString(String k,String v);Editor putLong(String k,long v);void apply();}}
JAVA
cat > "$TMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json; public class JSONObject {public static final Object NULL=new Object();public JSONObject(){}public JSONObject(String s){}public JSONArray optJSONArray(String k){return null;}public JSONObject optJSONObject(String k){return null;}public String optString(String k,String d){return d;}public String optString(String k){return "";}public boolean optBoolean(String k,boolean d){return d;}public Object opt(String k){return null;}}
JAVA
cat > "$TMP/src/org/json/JSONArray.java" <<'JAVA'
package org.json; public class JSONArray {public int length(){return 0;}public JSONObject optJSONObject(int i){return null;}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/MultiSportClient.java" <<'JAVA'
package com.jpastore.sportsai; import android.content.*;import java.util.*;import org.json.*;class MultiSportClient{static final String BASKETBALL="basketball",NFL="nfl",BASEBALL="baseball",MMA="mma",F1="f1";MultiSportClient(Context c){}boolean apiCircuitOpen(String s){return false;}void markApiCircuit(String s){}static String base(String s){return "http://127.0.0.1/";}String cacheGet(String k,long a){return null;}void cachePut(String k,String v){}ArrayList<Event> load(String s,String d,String k){return new ArrayList<>();}Event parseNfl(JSONObject o){return null;}Event parseGenericGame(String s,JSONObject o){return null;}static class Event{long id,sofaId,apiSportsId,highlightlyId;String apiSource="",home="",away="",status="SCHEDULED",date="",time="",competition="";Event(String s){}}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/MainActivity.java" <<'JAVA'
package com.jpastore.sportsai;import android.content.*;class MainActivity extends Context{String apiKeyFor(String s){return "";}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/HighlightlyBasketballClient.java" <<'JAVA'
package com.jpastore.sportsai;import android.content.*;class HighlightlyBasketballClient{HighlightlyBasketballClient(Context c){}static boolean configured(Context c){return false;}static String key(Context c){return "";}void resolve(String k,MultiSportClient.Event e){}MarketOddsBook odds(String k,MultiSportClient.Event e){return new MarketOddsBook();}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/MarketOddsClient.java" <<'JAVA'
package com.jpastore.sportsai;import android.content.*;class MarketOddsClient{MarketOddsClient(Context c){}MarketOddsBook sport(String s,String k,MultiSportClient.Event e){return new MarketOddsBook();}static String winnerKey(String l,String h,String a){String x=norm(l);if(x.equals("1")||x.equals(norm(h)))return MarketOddsBook.HOME;if(x.equals("2")||x.equals(norm(a)))return MarketOddsBook.AWAY;if(x.equals("x")||x.equals("draw"))return MarketOddsBook.DRAW;return null;}static Boolean side(String l,String h,String a){String x=norm(l);if(x.equals("1")||x.equals("home")||(!norm(h).isEmpty()&&x.contains(norm(h))))return true;if(x.equals("2")||x.equals("away")||(!norm(a).isEmpty()&&x.contains(norm(a))))return false;return null;}static String norm(String s){return s==null?"":s.toLowerCase(java.util.Locale.ROOT).trim();}}
JAVA
cat > "$TMP/src/com/jpastore/sportsai/StatisticalCalibrationEngine.java" <<'JAVA'
package com.jpastore.sportsai;class StatisticalCalibrationEngine{static boolean isPregameStatus(String s){return true;}}
JAVA

cp "$ROOT/app/src/main/java/com/jpastore/sportsai/MarketOddsBook.java" "$TMP/src/com/jpastore/sportsai/"
cp "$ROOT/app/src/main/java/com/jpastore/sportsai/MarketCollector.java" "$TMP/src/com/jpastore/sportsai/"
cp "$ROOT/app/src/main/java/com/jpastore/sportsai/TeamIdentityResolver.java" "$TMP/src/com/jpastore/sportsai/"

cat > "$TMP/src/com/jpastore/sportsai/MarketCollectorSelfTest.java" <<'JAVA'
package com.jpastore.sportsai;import java.util.*;public class MarketCollectorSelfTest{static int n=0;static void ok(boolean v,String m){if(!v)throw new RuntimeException("FAIL: "+m);n++;System.out.println("PASS: "+m);}public static void main(String[]a){MultiSportClient.Event t=new MultiSportClient.Event("basketball"),c=new MultiSportClient.Event("basketball");t.home="TalTech";t.away="Fyllingen Basket";t.date="2026-09-23";c.home="TalTech";c.away="Fyllingen BK";c.date="2026-09-23";ok(MarketCollector.matchScore(t,c)>=130,"TalTech/Fyllingen aliases resolvem o mesmo evento");t.home="BC Neptūnas";t.away="Juventus Utena";c.home="Neptunas Klaipeda";c.away="BC Juventus Utena";ok(MarketCollector.matchScore(t,c)>=130,"Neptunas/Juventus aliases resolvem o mesmo evento");c.home="Neptunas Women";ok(MarketCollector.matchScore(t,c)<0,"categoria feminina incompatível é rejeitada");ok(Math.abs(MarketCollector.extractSigned("1 (-5.5)")+5.5)<.001,"handicap -5.5 preserva sinal");ok(MarketCollector.sofaSide("2 (+5.5)","A","B")==Boolean.FALSE,"rótulo Sofa 2 é visitante");MarketOddsBook b=new MarketOddsBook();LinkedHashMap<String,Double> m=new LinkedHashMap<>();m.put(MarketOddsBook.HOME,1.37);m.put(MarketOddsBook.AWAY,2.85);b.addBookmakerMarket(m,"fixture","moneyline");ok(Math.abs(b.probability(MarketOddsBook.HOME)-67.53)<.2,"moneyline é normalizada sem margem");MarketOddsBook p=new MarketOddsBook();LinkedHashMap<String,Double> one=new LinkedHashMap<>();one.put(MarketOddsBook.HOME,1.8);p.addBookmakerMarket(one,"fixture","moneyline");p.markPartial("fixture");ok(p.availabilityLabel().startsWith("parcial"),"mercado parcial não vira mercado inexistente");MarketOddsBook f=new MarketOddsBook();f.markFailure("fixture");ok(f.availabilityLabel().contains("falha"),"falha de coleta não vira mercado inexistente");MarketOddsBook u=new MarketOddsBook();u.markUnresolved("fixture");ok(u.availabilityLabel().contains("não resolvido"),"evento não resolvido ganha estado próprio");ok("EVENT_NOT_FOUND".equals(u.stateCode()),"estado EVENT_NOT_FOUND");MarketOddsBook to=new MarketOddsBook();to.markTimeout("fixture");ok("TIMEOUT".equals(to.stateCode()),"estado TIMEOUT");MarketOddsBook rl=new MarketOddsBook();rl.markRateLimit("fixture");ok("RATE_LIMIT".equals(rl.stateCode()),"estado RATE_LIMIT");MarketOddsBook pf=new MarketOddsBook();pf.markPartial("fixture");ok("PARTIAL_MARKET".equals(pf.stateCode()),"estado PARTIAL_MARKET");MarketOddsBook cf=new MarketOddsBook();cf.markFailure("fixture");ok("COLLECTOR_FAILED".equals(cf.stateCode()),"estado COLLECTOR_FAILED");ok("MARKET_FOUND".equals(b.stateCode()),"estado MARKET_FOUND");System.out.println("ALL MARKET COLLECTOR TESTS PASSED: "+n);}}
JAVA

javac -encoding UTF-8 -d "$TMP/out" $(find "$TMP/src" -name '*.java')
java -cp "$TMP/out" com.jpastore.sportsai.MarketCollectorSelfTest

grep -Fq 'e.sofaId=e.id' "$ROOT/app/src/main/java/com/jpastore/sportsai/MultiSportClient.java"
grep -Fq 'e.apiSportsId=e.id' "$ROOT/app/src/main/java/com/jpastore/sportsai/MultiSportClient.java"
grep -Fq 'new MarketCollector(c).collect' "$ROOT/app/src/main/java/com/jpastore/sportsai/MultiSportWebClient.java"
grep -Fq '/odds/1/all' "$ROOT/app/src/main/java/com/jpastore/sportsai/MarketCollector.java"
grep -Fq 'apiSportsId' "$ROOT/app/src/main/java/com/jpastore/sportsai/MarketCollector.java"
grep -Fq 'marketAvailability' "$ROOT/app/src/main/java/com/jpastore/sportsai/TicketStore.java"
echo 'STRUCTURAL MARKET COLLECTOR CHECKS PASSED: 6'
