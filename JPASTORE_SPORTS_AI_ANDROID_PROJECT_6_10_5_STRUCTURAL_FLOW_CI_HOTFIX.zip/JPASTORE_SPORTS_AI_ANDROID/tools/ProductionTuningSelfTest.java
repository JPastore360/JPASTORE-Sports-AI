package com.jpastore.sportsai;

import java.util.*;

public class ProductionTuningSelfTest {
    static int ok=0,fail=0;
    static void check(String name,boolean value){if(value){ok++;System.out.println("PASS • "+name);}else{fail++;System.out.println("FAIL • "+name);}}
    static MultiSportWebClient.GameRow g(String date,String comp,String home,String away,int hs,int as,String... src){MultiSportWebClient.GameRow x=new MultiSportWebClient.GameRow();x.date=date;x.competition=comp;x.home=home;x.away=away;x.hs=hs;x.as=as;x.completed=true;x.status="FINISHED";for(String s:src)x.sources.add(s);return x;}
    static MultiSportClient.Event ev(String home,String away,String date,String comp){MultiSportClient.Event e=new MultiSportClient.Event();e.home=home;e.away=away;e.date=date;e.competition=comp;e.sport=MultiSportClient.BASKETBALL;e.status="SCHEDULED";return e;}
    static ArrayList<MultiSportWebClient.GameRow> rows(String team,String prefix,int start,boolean good,String... src){ArrayList<MultiSportWebClient.GameRow>a=new ArrayList<>();for(int i=0;i<5;i++){int pf=good?85+i:73+i,pa=good?76+i:81+i;a.add(g("2026-09-"+String.format(Locale.US,"%02d",start-i),"B.League",team,"Opp "+prefix+i,pf,pa,src));}return a;}
    public static void main(String[] args){
        // A • Alvark × Ryukyu: immediate prior H2H, alias dedupe, old game lower weight.
        MultiSportClient.Event aev=ev("Alvark Tokyo","Ryukyu Golden Kings","2026-09-23","B.League");
        ArrayList<MultiSportWebClient.GameRow> ah=rows("Alvark Tokyo","A",21,true,"Highlightly"),aa=rows("Ryukyu Golden Kings Okinawa","R",21,true,"Highlightly");
        ArrayList<MultiSportWebClient.GameRow> h2h=new ArrayList<>();h2h.add(g("2026-09-22","B.League","Alvark Tokyo","Ryukyu Golden Kings Okinawa",79,83,"Highlightly"));h2h.add(g("2025-12-01","B.League","Ryukyu Golden Kings","Alvark Tokyo",80,72,"TheSportsDB"));
        ProductionTuningEngine.Context ac=ProductionTuningEngine.analyze(MultiSportClient.BASKETBALL,aev,ah,aa,h2h);
        ArrayList<MultiSportWebClient.GameRow> ded=new ArrayList<>();MultiSportWebClient.addUniqueGame(ded,g("2026-09-23","B.League","Alvark Tokyo","Ryukyu Golden Kings",0,0,"A"));MultiSportWebClient.addUniqueGame(ded,g("2026-09-23","B.League","Alvark Tokyo","Ryukyu Golden Kings Okinawa",0,0,"B"));
        check("CASO A • back-to-back <48h + peso 1,20 + alias sem duplicar",ac.backToBackSeries&&ac.lastMeetingDaysAgo==1&&Math.abs(ac.lastMeetingWeight-1.20)<.001&&ded.size()==1&&ProductionTuningEngine.recencyWeight(1)>ProductionTuningEngine.recencyWeight(150));

        // B • preseason participates, but with reduced competition weight.
        double pre=ProductionTuningEngine.competitionWeight("NBL Preseason","NBL",2),official=ProductionTuningEngine.competitionWeight("NBL","NBL",20);
        ArrayList<MultiSportWebClient.GameRow> cairns=new ArrayList<>();cairns.add(g("2026-09-22","NBL Preseason","Cairns Taipans","Tasmania JackJumpers",90,87,"ESPN"));cairns.add(g("2026-08-20","NBL","Cairns Taipans","Perth",82,80,"ESPN"));
        ProductionTuningEngine.Context bc=ProductionTuningEngine.analyze(MultiSportClient.BASKETBALL,ev("Cairns Taipans","Tasmania JackJumpers","2026-09-23","NBL"),cairns,cairns,new ArrayList<>());
        check("CASO B • pré-temporada entra com peso reduzido",Math.abs(pre-.60)<.001&&official>pre&&bc.home.games>=1&&bc.home.effectiveSample>0);

        // C • cross-league baseline and normalization.
        ArrayList<MultiSportWebClient.GameRow> sh=new ArrayList<>();sh.add(g("2026-09-20","CBA","Shanghai Sharks","CBA A",108,99,"SofaScore"));sh.add(g("2026-09-16","CBA","Shanghai Sharks","CBA B",104,101,"SofaScore"));sh.add(g("2026-09-12","CBA","Shanghai Sharks","CBA C",110,103,"SofaScore"));
        ArrayList<MultiSportWebClient.GameRow> rs=new ArrayList<>();rs.add(g("2026-09-20","BAL","RSSB Tigers","BAL A",82,78,"TheSportsDB"));rs.add(g("2026-09-15","BAL","RSSB Tigers","BAL B",79,76,"TheSportsDB"));rs.add(g("2026-09-10","BAL","RSSB Tigers","BAL C",85,81,"TheSportsDB"));
        ProductionTuningEngine.Context cc=ProductionTuningEngine.analyze(MultiSportClient.BASKETBALL,ev("Shanghai Sharks","RSSB Tigers","2026-09-23","International Cup"),sh,rs,new ArrayList<>());
        check("CASO C • baseline entre ligas normaliza ataque/defesa",!Double.isNaN(cc.leagueAveragePoints)&&!Double.isNaN(cc.home.normalizedOffense)&&!Double.isNaN(cc.away.normalizedDefense));

        // D • Nagasaki × Shimane: recent form + H2H + totals + convergence + market reference.
        MultiSportWebClient.Research dr=new MultiSportWebClient.Research();dr.mergedHome=rows("Nagasaki Velca","N",22,true,"Highlightly","ESPN","SofaScore");dr.mergedAway=rows("Shimane Susanoo Magic","S",22,false,"Highlightly","ESPN","SofaScore");dr.mergedH2h.add(g("2026-09-18","B.League","Nagasaki Velca","Shimane Susanoo Magic",88,82,"Highlightly","ESPN"));dr.structuredSources.add("Highlightly");dr.structuredSources.add("ESPN");dr.structuredSources.add("SofaScore");
        MultiSportClient.Event dev=ev("Nagasaki Velca","Shimane Susanoo Magic","2026-09-23","B.League");SportConsensusEngine.Consensus dc=SportConsensusEngine.analyze(MultiSportClient.BASKETBALL,dev,dr);StatisticalCalibrationEngine.Calibration dm=StatisticalCalibrationEngine.calibrate(64,dc.coverage,dc.minGames(),dc.sourceCount,dc.sourceQuality,dc.agreement,(int)dc.recencyScore,61,0.12,false);
        check("CASO D • H2H/forma/médias/mercado/convergência",dc.minGames()>=5&&!Double.isNaN(dc.expectedTotal)&&dc.sourceCount==3&&dc.agreement>=60&&!"REVISÃO NECESSÁRIA".equals(dm.status));

        // E • one independent source cannot become consensus.
        MultiSportWebClient.Research er=new MultiSportWebClient.Research();er.mergedHome=rows("Home E","EH",22,true,"Highlightly");er.mergedAway=rows("Away E","EA",22,false,"Highlightly");er.structuredSources.add("Highlightly");SportConsensusEngine.Consensus ec=SportConsensusEngine.analyze(MultiSportClient.BASKETBALL,ev("Home E","Away E","2026-09-23","B.League"),er);
        check("CASO E • 1 fonte = FONTE ÚNICA, nunca consenso",ec.sourceCount==1&&ec.level.startsWith("FONTE ÚNICA")&&!ec.level.contains("CONSENSO FORTE"));

        // F • 3 independent agreeing sources => strong consensus.
        MultiSportWebClient.Research fr=new MultiSportWebClient.Research();fr.mergedHome=rows("Home F","FH",22,true,"Highlightly","ESPN","SofaScore");fr.mergedAway=rows("Away F","FA",22,false,"Highlightly","ESPN","SofaScore");fr.structuredSources.addAll(Arrays.asList("Highlightly","ESPN","SofaScore"));SportConsensusEngine.Consensus fc=SportConsensusEngine.analyze(MultiSportClient.BASKETBALL,ev("Home F","Away F","2026-09-23","B.League"),fr);
        check("CASO F • 3 fontes concordando = CONSENSO FORTE",fc.sourceCount>=3&&fc.agreement>=75&&"CONSENSO FORTE".equals(fc.level));

        check("CASO G • logo ausente no basquete usa iniciais, nunca FC","RT".equals(SportPresentationRules.initials("RSSB Tigers"))&&!"FC".equals(SportPresentationRules.initials("Nagasaki Velca")));
        check("CASO H • dado inexistente nunca renderiza null",SportPresentationRules.clean("null").isEmpty()&&SportPresentationRules.clean(null).isEmpty());
        check("CASO I • futura não mostra placar inexistente","PROGRAMADO".equals(SportPresentationRules.statusText("SCHEDULED","null","","")));
        check("CASO J • LIVE não entra automaticamente no pré-jogo",!StatisticalCalibrationEngine.isPregameStatus("LIVE")&&StatisticalCalibrationEngine.isPregameStatus("SCHEDULED"));

        // K • Multi-ticket must not die only because historical coverage is missing when real market exists.
        MultiSportWebClient.Research kr=new MultiSportWebClient.Research();LinkedHashMap<String,Double> km=new LinkedHashMap<>();km.put(MarketOddsBook.HOME,1.42);km.put(MarketOddsBook.AWAY,2.80);kr.marketOdds.addBookmakerMarket(km,"book-1","moneyline");SportTicketEngine.Result kres=SportTicketEngine.buildForMulti(MultiSportClient.BASKETBALL,ev("Home K","Away K","2026-09-23","Cup"),kr,SportTicketEngine.CONSERVADOR);
        check("CASO K • mercado real sem histórico NÃO entra automaticamente no conservador",!kres.ready()&&kres.note.contains("SEM SELEÇÃO CONSERVADORA"));

        // L • one verified game per side may fill a multi-ticket, but can never look safe.
        MultiSportWebClient.Research lr=new MultiSportWebClient.Research();lr.mergedHome.add(g("2026-09-20","Cup","Home L","Opp L1",84,78,"SofaScore"));lr.mergedAway.add(g("2026-09-20","Cup","Away L","Opp L2",71,80,"SofaScore"));lr.structuredSources.add("SofaScore");SportTicketEngine.Result lres=SportTicketEngine.buildForMulti(MultiSportClient.BASKETBALL,ev("Home L","Away L","2026-09-23","Cup"),lr,SportTicketEngine.CONSERVADOR);
        check("CASO L • amostra 1 por lado NÃO é forçada no conservador",!lres.ready()&&lres.note.contains("SEM SELEÇÃO CONSERVADORA"));

        System.out.println("RESULTADO: "+ok+"/"+(ok+fail)+" testes aprovados");if(fail>0)System.exit(1);
    }
}
