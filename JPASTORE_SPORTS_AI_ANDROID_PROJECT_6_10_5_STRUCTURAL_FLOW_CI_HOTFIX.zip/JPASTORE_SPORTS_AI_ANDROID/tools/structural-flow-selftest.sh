#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="${TMPDIR:-/tmp}/jpastore-structural-flow-tests"
rm -rf "$TMP" && mkdir -p "$TMP/src/com/jpastore/sportsai" "$TMP/src/android/content" "$TMP/src/android/util" "$TMP/out"

cat > "$TMP/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content;
public interface SharedPreferences {
 String getString(String k,String d);
 long getLong(String k,long d);
 Editor edit();
 interface Editor {Editor putString(String k,String v);Editor putLong(String k,long v);Editor remove(String k);boolean commit();void apply();}
}
JAVA
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content; public class Context { public SharedPreferences getSharedPreferences(String n,int m){return null;} }
JAVA
cat > "$TMP/src/android/util/Base64.java" <<'JAVA'
package android.util;
public final class Base64 {public static final int URL_SAFE=8,NO_WRAP=2,NO_PADDING=1;public static String encodeToString(byte[] b,int flags){return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(b);}public static byte[] decode(String s,int flags){return java.util.Base64.getUrlDecoder().decode(s);}}
JAVA
cp "$ROOT/app/src/main/java/com/jpastore/sportsai/HomeFlowCore.java" "$TMP/src/com/jpastore/sportsai/"
cp "$ROOT/app/src/main/java/com/jpastore/sportsai/TicketBatchGenerator.java" "$TMP/src/com/jpastore/sportsai/"
cp "$ROOT/app/src/main/java/com/jpastore/sportsai/GeneratedTicketStore.java" "$TMP/src/com/jpastore/sportsai/"
cat > "$TMP/src/com/jpastore/sportsai/StructuralFlowSelfTest.java" <<'JAVA'
package com.jpastore.sportsai;
import android.content.*;import java.util.*;
public class StructuralFlowSelfTest {
 static int n=0;static void ok(boolean v,String m){if(!v)throw new RuntimeException("FAIL: "+m);n++;System.out.println("PASS: "+m);}
 static final class MemPrefs implements SharedPreferences {final Map<String,String>s=new HashMap<>();final Map<String,Long>l=new HashMap<>();public String getString(String k,String d){return s.containsKey(k)?s.get(k):d;}public long getLong(String k,long d){return l.containsKey(k)?l.get(k):d;}public Editor edit(){return new Editor(){final Map<String,String>ps=new HashMap<>();final Map<String,Long>pl=new HashMap<>();final Set<String>rm=new HashSet<>();public Editor putString(String k,String v){ps.put(k,v);return this;}public Editor putLong(String k,long v){pl.put(k,v);return this;}public Editor remove(String k){rm.add(k);return this;}void go(){for(String k:rm){s.remove(k);l.remove(k);}s.putAll(ps);l.putAll(pl);}public boolean commit(){go();return true;}public void apply(){go();}};}}
 static final class MemContext extends Context {final Map<String,MemPrefs> all=new HashMap<>();@Override public SharedPreferences getSharedPreferences(String n,int m){return all.computeIfAbsent(n,k->new MemPrefs());}}
 static TicketBatchGenerator.Candidate candidate(int i){return new TicketBatchGenerator.Candidate("event-"+i,"Casa "+i+" × Fora "+i,"Liga","2026-09-23 20:00","Moneyline","Casa "+i,70,68,72,65,6,2,67.0,"FAVORÁVEL","RISCO MENOR","ALTA","ALTA","disponível");}
 public static void main(String[] args){
  // TESTE A — 20 eventos da API precisam chegar à home sem corte oculto.
  ArrayList<HomeFlowCore.EventRef> home=new ArrayList<>();for(int i=0;i<20;i++)home.add(new HomeFlowCore.EventRef(i,"Time "+i,"Rival "+i,"2026-09-23",String.format(Locale.US,"%02d:00",i%24),"SCHEDULED","k"+i,false));HomeFlowCore.Result a=HomeFlowCore.process(home,"2026-09-23","");ok(a.rawEvents==20&&a.validEvents==20&&a.afterFilters==20&&a.afterDedup==20&&a.displayedEvents==20,"TESTE A: 20 eventos permanecem 20 na home");
  // TESTE E — odds ausentes não participam do filtro de inclusão.
  ArrayList<HomeFlowCore.EventRef> noOdds=new ArrayList<>();noOdds.add(new HomeFlowCore.EventRef(0,"A","B","2026-09-23","12:00","SCHEDULED","a",false));noOdds.add(new HomeFlowCore.EventRef(1,"C","D","2026-09-23","13:00","SCHEDULED","b",false));HomeFlowCore.Result e=HomeFlowCore.process(noOdds,"2026-09-23","");ok(e.displayedEvents==2,"TESTE E: evento sem odds continua na home");
  // TESTE B — pool suficiente gera exatamente 12 bilhetes distintos.
  ArrayList<TicketBatchGenerator.Candidate> pool=new ArrayList<>();for(int i=0;i<6;i++)pool.add(candidate(i));TicketBatchGenerator.BatchResult b=TicketBatchGenerator.generate(12,pool,"CONSERVADOR",123456L);ok(b.requested==12&&b.generated==12,"TESTE B: solicitado 12 gera 12");HashSet<String> sig=new HashSet<>(),ids=new HashSet<>();for(TicketBatchGenerator.Ticket t:b.tickets){sig.add(t.signature);ids.add(t.id);}ok(sig.size()==12&&ids.size()==12,"TESTE B: 12 bilhetes têm assinatura e ID únicos");
  // TESTE C — fechar/reabrir equivale a criar outra instância do store sobre o mesmo SharedPreferences.
  MemContext ctx=new MemContext();GeneratedTicketStore store1=new GeneratedTicketStore(ctx);ok(store1.replace(b),"TESTE C: lote persistido");GeneratedTicketStore store2=new GeneratedTicketStore(ctx);GeneratedTicketStore.Snapshot snap=store2.load();ok(snap.generated()==12&&snap.requested==12,"TESTE C: 12 continuam salvos após reabrir");HashSet<String> persistedIds=new HashSet<>();for(TicketBatchGenerator.Ticket t:snap.tickets)persistedIds.add(t.id);ok(persistedIds.size()==12,"TESTE C: IDs persistidos não são sobrescritos");ok(snap.generated()==b.generated,"TESTE B/C: 12 gerados = 12 salvos = 12 mostrados pelo snapshot");
  // TESTE D — revisão necessária jamais passa no conservador.
  TicketBatchGenerator.Candidate review=candidate(99);review.status="REVISÃO NECESSÁRIA • RISCO ALTO";ok(!review.conservativeEligible(),"TESTE D: REVISÃO NECESSÁRIA é bloqueada no conservador");TicketBatchGenerator.BatchResult d=TicketBatchGenerator.generate(1,Collections.singletonList(review),"CONSERVADOR",8L);ok(d.generated==0,"TESTE D: nenhuma seleção conservadora é forçada");
  TicketBatchGenerator.Candidate noMarket=candidate(98);noMarket.marketProbability=Double.NaN;ok(!noMarket.conservativeEligible(),"CONSERVADOR exige mercado confirmado");
  TicketBatchGenerator.Candidate lowCoverage=candidate(97);lowCoverage.coverage=49;ok(!lowCoverage.conservativeEligible(),"CONSERVADOR exige cobertura >= 50%");
  TicketBatchGenerator.Candidate lowSample=candidate(96);lowSample.sample=4;ok(!lowSample.conservativeEligible(),"CONSERVADOR exige amostra >= 5");TicketBatchGenerator.Candidate diverge=candidate(95);diverge.rawProbability=88;diverge.marketProbability=60;ok(!diverge.conservativeEligible(),"CONSERVADOR bloqueia divergência grave com mercado");
  System.out.println("ALL STRUCTURAL FLOW TESTS PASSED: "+n);
 }
}
JAVA
javac -encoding UTF-8 -d "$TMP/out" $(find "$TMP/src" -name '*.java')
java -cp "$TMP/out" com.jpastore.sportsai.StructuralFlowSelfTest

# Structural assertions against the Android integration.
grep -Fq '[JP_HOME]' "$ROOT/app/src/main/java/com/jpastore/sportsai/PremiumView.java"
grep -Fq 'rawEvents=' "$ROOT/app/src/main/java/com/jpastore/sportsai/HomeFlowCore.java"
grep -Fq 'generatedTicketStore.replace(batch)' "$ROOT/app/src/main/java/com/jpastore/sportsai/PremiumView.java"
grep -Fq '[JP_TICKETS]' "$ROOT/app/src/main/java/com/jpastore/sportsai/PremiumView.java"
grep -Fq 'SEM SELEÇÃO CONSERVADORA' "$ROOT/app/src/main/java/com/jpastore/sportsai/SportTicketEngine.java"
grep -Fq 'paging.optInt("total"' "$ROOT/app/src/main/java/com/jpastore/sportsai/MultiSportClient.java"
grep -Fq 'for(TicketBatchGenerator.Ticket t:generated.tickets)' "$ROOT/app/src/main/java/com/jpastore/sportsai/PremiumView.java"
! grep -Eq 'take\(3\)|first\(3\)|subList\(0, *3\)|MAX_ITEMS *= *3|pageSize *= *3|limit *= *3' "$ROOT/app/src/main/java/com/jpastore/sportsai/PremiumView.java"
! grep -Eq 'take\(2\)|first\(2\)|coerceAtMost\(2\)|MAX_TICKETS *= *2|limit *= *2' "$ROOT/app/src/main/java/com/jpastore/sportsai/PremiumView.java" "$ROOT/app/src/main/java/com/jpastore/sportsai/TicketBatchGenerator.java"
echo 'ANDROID INTEGRATION STRUCTURAL CHECKS PASSED: 9'
