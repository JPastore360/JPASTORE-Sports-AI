package com.jpastore.sportsai;

import java.util.*;

/**
 * Android-free home list pipeline. Market/odds state is intentionally not part of
 * the inclusion rules: an existing event remains visible even when odds fail.
 */
final class HomeFlowCore {
    static final class EventRef {
        final int sourceIndex;
        final String home, away, date, time, status, key;
        final boolean marketConfirmed;
        EventRef(int sourceIndex,String home,String away,String date,String time,String status,String key,boolean marketConfirmed){
            this.sourceIndex=sourceIndex;this.home=safe(home);this.away=safe(away);this.date=safe(date);this.time=safe(time);this.status=safe(status);this.key=safe(key);this.marketConfirmed=marketConfirmed;
        }
    }
    static final class Result {
        final ArrayList<EventRef> displayed=new ArrayList<>();
        int rawEvents,validEvents,afterFilters,afterDedup,displayedEvents;
    }

    static Result process(List<EventRef> raw,String selectedDate,String timeFilter){
        Result r=new Result();r.rawEvents=raw==null?0:raw.size();
        String day=safe(selectedDate),clock=safe(timeFilter);ArrayList<EventRef> valid=new ArrayList<>();
        if(raw!=null)for(EventRef e:raw){if(e==null||e.home.isEmpty()||e.away.isEmpty())continue;valid.add(e);}r.validEvents=valid.size();
        ArrayList<EventRef> filtered=new ArrayList<>();
        for(EventRef e:valid){boolean dateOk=day.isEmpty()||e.date.isEmpty()||day.equals(e.date);boolean timeOk=clock.isEmpty()||clock.equals(e.time);if(dateOk&&timeOk)filtered.add(e);}r.afterFilters=filtered.size();
        LinkedHashMap<String,EventRef> unique=new LinkedHashMap<>();for(EventRef e:filtered){String k=e.key.isEmpty()?norm(e.home)+"|"+norm(e.away)+"|"+e.date:e.key;if(!unique.containsKey(k))unique.put(k,e);}r.afterDedup=unique.size();r.displayed.addAll(unique.values());r.displayedEvents=r.displayed.size();return r;
    }

    static String diagnostic(Result r){if(r==null)return "rawEvents=0 validEvents=0 afterFilters=0 afterDedup=0 displayedEvents=0";return "rawEvents="+r.rawEvents+" validEvents="+r.validEvents+" afterFilters="+r.afterFilters+" afterDedup="+r.afterDedup+" displayedEvents="+r.displayedEvents;}
    static String norm(String s){String x=safe(s).toLowerCase(Locale.ROOT);x=java.text.Normalizer.normalize(x,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","");return x.replaceAll("[^a-z0-9]+"," ").trim();}
    static String safe(String s){return s==null?"":s.trim();}
    private HomeFlowCore(){}
}
