package com.jpastore.sportsai;

import java.util.*;

/**
 * Pure combination/persistence model for generated tickets. It does not calculate
 * probabilities; it only consumes already-calibrated selections and forms distinct tickets.
 */
final class TicketBatchGenerator {
    static final class Candidate {
        String eventKey="",matchup="",league="",kickoff="",market="",pick="",status="",risk="",confidenceLevel="",sourceQuality="",marketAvailability="";
        int rawProbability,probability,confidenceScore,coverage,sample,sourceCount;
        double marketProbability=Double.NaN;
        Candidate(){}
        Candidate(String eventKey,String matchup,String league,String kickoff,String market,String pick,int rawProbability,int probability,int confidenceScore,int coverage,int sample,int sourceCount,double marketProbability,String status,String risk,String confidenceLevel,String sourceQuality,String marketAvailability){
            this.eventKey=safe(eventKey);this.matchup=safe(matchup);this.league=safe(league);this.kickoff=safe(kickoff);this.market=safe(market);this.pick=safe(pick);this.rawProbability=rawProbability;this.probability=probability;this.confidenceScore=confidenceScore;this.coverage=coverage;this.sample=sample;this.sourceCount=sourceCount;this.marketProbability=marketProbability;this.status=safe(status);this.risk=safe(risk);this.confidenceLevel=safe(confidenceLevel);this.sourceQuality=safe(sourceQuality);this.marketAvailability=safe(marketAvailability);
        }
        String signature(){return safe(eventKey)+"|"+safe(market)+"|"+safe(pick);}
        boolean marketConfirmed(){return validProbability(marketProbability);}
        boolean severeMarketDivergence(){return marketConfirmed()&&Math.abs(rawProbability-marketProbability)>15.0;}
        boolean conservativeEligible(){return marketConfirmed()&&confidenceScore>=60&&coverage>=50&&sample>=5&&!(status!=null&&status.contains("REVISÃO NECESSÁRIA"))&&!severeMarketDivergence();}
    }
    static final class Ticket {
        String id="",mode="",signature="";long createdAt;int rankScore;final ArrayList<Candidate> selections=new ArrayList<>();
    }
    static final class BatchResult {
        int requested,eligibleSelections,generated,afterDedup;String reason="";final ArrayList<Ticket> tickets=new ArrayList<>();
    }

    static BatchResult generate(int requested,List<Candidate> raw,String mode,long batchSeed){
        BatchResult out=new BatchResult();out.requested=Math.max(1,Math.min(12,requested));String m=safe(mode);ArrayList<Candidate> eligible=new ArrayList<>();HashSet<String> candidateSeen=new HashSet<>();
        if(raw!=null)for(Candidate c:raw){if(c==null||c.eventKey.isEmpty()||c.pick.isEmpty())continue;if("CONSERVADOR".equals(m)&&!c.conservativeEligible())continue;if(candidateSeen.add(c.signature()))eligible.add(c);}out.eligibleSelections=eligible.size();
        if(eligible.isEmpty()){out.reason="nenhuma seleção atende aos critérios do modo "+(m.isEmpty()?"selecionado":m);return out;}
        Collections.sort(eligible,(a,b)->{int s=Integer.compare(b.confidenceScore,a.confidenceScore);if(s!=0)return s;s=Integer.compare(b.coverage,a.coverage);if(s!=0)return s;s=Integer.compare(b.probability,a.probability);return s!=0?s:a.signature().compareTo(b.signature());});
        LinkedHashSet<String> events=new LinkedHashSet<>();for(Candidate c:eligible)events.add(c.eventKey);int eventCount=events.size();int preferred="AGRESSIVO".equals(m)?Math.min(5,eventCount):("EQUILIBRADO".equals(m)?Math.min(4,eventCount):Math.min(3,eventCount));preferred=Math.max(1,preferred);
        LinkedHashMap<String,Ticket> unique=new LinkedHashMap<>();ArrayList<Integer> sizes=new ArrayList<>();for(int s=preferred;s>=1;s--)sizes.add(s);for(int s=preferred+1;s<=Math.min(6,eventCount);s++)sizes.add(s);
        for(int size:sizes){collect(eligible,0,size,new ArrayList<>(),new HashSet<>(),unique,Math.max(2400,out.requested*120));if(unique.size()>=out.requested*8)break;}
        ArrayList<Ticket> ranked=new ArrayList<>(unique.values());Collections.sort(ranked,(a,b)->{int s=Integer.compare(b.rankScore,a.rankScore);if(s!=0)return s;int legs=Integer.compare(a.selections.size(),b.selections.size());if(legs!=0)return legs;return a.signature.compareTo(b.signature);});out.afterDedup=ranked.size();
        int take=Math.min(out.requested,ranked.size());for(int i=0;i<take;i++){Ticket t=ranked.get(i);t.createdAt=batchSeed;t.mode=m;t.id="JP-"+batchSeed+"-"+String.format(Locale.US,"%02d",i+1)+"-"+Integer.toHexString(t.signature.hashCode());out.tickets.add(t);}out.generated=out.tickets.size();if(out.generated<out.requested)out.reason="combinações seguras insuficientes";return out;
    }

    private static void collect(ArrayList<Candidate> src,int at,int target,ArrayList<Candidate> current,HashSet<String> usedEvents,LinkedHashMap<String,Ticket> out,int cap){
        if(out.size()>=cap)return;if(current.size()==target){Ticket t=makeTicket(current);out.putIfAbsent(t.signature,t);return;}int need=target-current.size();for(int i=at;i<=src.size()-need;i++){Candidate c=src.get(i);if(usedEvents.contains(c.eventKey))continue;usedEvents.add(c.eventKey);current.add(c);collect(src,i+1,target,current,usedEvents,out,cap);current.remove(current.size()-1);usedEvents.remove(c.eventKey);if(out.size()>=cap)return;}
    }
    private static Ticket makeTicket(List<Candidate> cs){Ticket t=new Ticket();ArrayList<String> sig=new ArrayList<>();int score=0;for(Candidate c:cs){t.selections.add(c);sig.add(c.signature());score+=c.confidenceScore*3+c.coverage+c.probability;}Collections.sort(sig);StringBuilder b=new StringBuilder();for(String s:sig){if(b.length()>0)b.append("||");b.append(s);}t.signature=b.toString();t.rankScore=cs.isEmpty()?0:Math.round(score/(float)cs.size())-Math.max(0,cs.size()-3)*2;return t;}
    static boolean validProbability(double p){return !Double.isNaN(p)&&p>0&&p<100.0001;}
    static String safe(String s){return s==null?"":s.trim();}
    private TicketBatchGenerator(){}
}
