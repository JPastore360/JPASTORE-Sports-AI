package com.jpastore.sportsai;

import android.content.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import android.util.Base64;

/** Persistent collection of distinct generated tickets. Manual TicketStore remains untouched. */
final class GeneratedTicketStore {
    private static final String PREF="jp_generated_tickets_v1", KEY="batch";
    private final SharedPreferences sp;
    static final class Snapshot {int requested,eligibleSelections,afterDedup;String reason="";final ArrayList<TicketBatchGenerator.Ticket> tickets=new ArrayList<>();int generated(){return tickets.size();}int selections(){int n=0;for(TicketBatchGenerator.Ticket t:tickets)n+=t.selections.size();return n;}}
    GeneratedTicketStore(Context c){sp=c.getSharedPreferences(PREF,0);}
    boolean replace(TicketBatchGenerator.BatchResult batch){if(batch==null)return false;return sp.edit().putString(KEY,encode(batch)).commit();}
    Snapshot load(){return decode(sp.getString(KEY,""));}
    int ticketCount(){return load().generated();}
    int selectionCount(){return load().selections();}
    void clear(){sp.edit().remove(KEY).apply();}

    String copyText(){Snapshot s=load();StringBuilder b=new StringBuilder("J.PASTORE AI • BILHETES GERADOS\n");b.append("Solicitados: ").append(s.requested).append("\nGerados: ").append(s.generated()).append("\n");if(!s.reason.isEmpty())b.append("Motivo: ").append(s.reason).append("\n");b.append("\n");int ix=1;for(TicketBatchGenerator.Ticket t:s.tickets){b.append("BILHETE ").append(ix++).append(" • ID ").append(t.id).append(" • ").append(t.mode).append("\n");for(TicketBatchGenerator.Candidate c:t.selections)b.append("• ").append(c.matchup).append(" — ").append(c.pick).append(" [").append(c.confidenceScore).append("/100, cobertura ").append(c.coverage).append("%, amostra ").append(c.sample).append("]\n");b.append("\n");}return b.toString();}

    static String encode(TicketBatchGenerator.BatchResult batch){StringBuilder b=new StringBuilder();b.append("M\t").append(batch.requested).append("\t").append(batch.eligibleSelections).append("\t").append(batch.afterDedup).append("\t").append(enc(batch.reason)).append('\n');for(TicketBatchGenerator.Ticket t:batch.tickets){b.append("T\t").append(enc(t.id)).append('\t').append(enc(t.mode)).append('\t').append(t.createdAt).append('\t').append(t.rankScore).append('\t').append(enc(t.signature)).append('\n');for(TicketBatchGenerator.Candidate c:t.selections)b.append("S\t").append(enc(c.eventKey)).append('\t').append(enc(c.matchup)).append('\t').append(enc(c.league)).append('\t').append(enc(c.kickoff)).append('\t').append(enc(c.market)).append('\t').append(enc(c.pick)).append('\t').append(c.rawProbability).append('\t').append(c.probability).append('\t').append(c.confidenceScore).append('\t').append(c.coverage).append('\t').append(c.sample).append('\t').append(c.sourceCount).append('\t').append(Double.isNaN(c.marketProbability)?"NaN":Double.toString(c.marketProbability)).append('\t').append(enc(c.status)).append('\t').append(enc(c.risk)).append('\t').append(enc(c.confidenceLevel)).append('\t').append(enc(c.sourceQuality)).append('\t').append(enc(c.marketAvailability)).append('\n');b.append("E\n");}return b.toString();}
    static Snapshot decode(String raw){Snapshot out=new Snapshot();if(raw==null||raw.isEmpty())return out;TicketBatchGenerator.Ticket current=null;try{for(String line:raw.split("\\n")){if(line.isEmpty())continue;String[] p=line.split("\\t",-1);if(p.length==0)continue;if("M".equals(p[0])){out.requested=intv(p,1,0);out.eligibleSelections=intv(p,2,0);out.afterDedup=intv(p,3,0);out.reason=dec(str(p,4));}else if("T".equals(p[0])){current=new TicketBatchGenerator.Ticket();current.id=dec(str(p,1));current.mode=dec(str(p,2));current.createdAt=longv(p,3,0);current.rankScore=intv(p,4,0);current.signature=dec(str(p,5));out.tickets.add(current);}else if("S".equals(p[0])&&current!=null){TicketBatchGenerator.Candidate c=new TicketBatchGenerator.Candidate();c.eventKey=dec(str(p,1));c.matchup=dec(str(p,2));c.league=dec(str(p,3));c.kickoff=dec(str(p,4));c.market=dec(str(p,5));c.pick=dec(str(p,6));c.rawProbability=intv(p,7,0);c.probability=intv(p,8,0);c.confidenceScore=intv(p,9,0);c.coverage=intv(p,10,0);c.sample=intv(p,11,0);c.sourceCount=intv(p,12,0);c.marketProbability=doublev(p,13);c.status=dec(str(p,14));c.risk=dec(str(p,15));c.confidenceLevel=dec(str(p,16));c.sourceQuality=dec(str(p,17));c.marketAvailability=dec(str(p,18));current.selections.add(c);}else if("E".equals(p[0]))current=null;}}catch(Exception ignored){}return out;}
    private static String enc(String s){return Base64.encodeToString((s==null?"":s).getBytes(StandardCharsets.UTF_8),Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING);}
    private static String dec(String s){try{return new String(Base64.decode(s==null?"":s,Base64.URL_SAFE|Base64.NO_WRAP),StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    private static String str(String[] p,int i){return i>=0&&i<p.length?p[i]:"";}private static int intv(String[] p,int i,int d){try{return Integer.parseInt(str(p,i));}catch(Exception e){return d;}}private static long longv(String[] p,int i,long d){try{return Long.parseLong(str(p,i));}catch(Exception e){return d;}}private static double doublev(String[] p,int i){try{return "NaN".equals(str(p,i))?Double.NaN:Double.parseDouble(str(p,i));}catch(Exception e){return Double.NaN;}}
}
